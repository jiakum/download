/******************************************************************************
*
*               COPYRIGHT (c) 2015-2016 GainSpan Corporation
*                         All Rights Reserved
*
* The source code contained or described herein and all documents
* related to the source code ("Material") are owned by GainSpan
* Corporation or its licensors.  Title to the Material remains
* with GainSpan Corporation or its suppliers and licensors.
*
* The Material is protected by worldwide copyright and trade secret
* laws and treaty provisions. No part of the Material may be used,
* copied, reproduced, modified, published, uploaded, posted, transmitted,
* distributed, or disclosed in any way except in accordance with the
* applicable license agreement.
*
* No license under any patent, copyright, trade secret or other
* intellectual property right is granted to or conferred upon you by
* disclosure or delivery of the Materials, either expressly, by
* implication, inducement, estoppel, except in accordance with the
* applicable license agreement.
*
* Unless otherwise agreed by GainSpan in writing, you may not remove or
* alter this notice or any other notice embedded in Materials by GainSpan
* or GainSpan's suppliers or licensors in any way.
*  @file        :  rtp.h
*  @brief       :  This file contains function prototypes used in the rtp_h264.c file.
********************************************************************************/

#ifndef _RTP_H
#define _RTP_H

#include "comm/type.h"
#include "tx_port.h"

/****
 0					 1					 2					 3
 0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1
+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|V=2|P|X|  CC	|M|		PT	|	sequence number					|
+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|						timestamp								|
+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|		synchronization source (SSRC) identifier				|
+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+
|		contributing source (CSRC) identifiers					|
|							....								|
+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+

****/

#define RTP_SIZE_MAX    1460
#define RTP_HEADER_SIZE 16
#define NALU_INDIC_SIZE 4
#define NALU_HEAD_SIZE  1
#define FU_A_INDI_SIZE  1
#define FU_A_HEAD_SIZE  1

/* SINGLE_NALU_DATA_MAX = RTP_SIZE_MAX - RTP_HEADER_SIZE*/
#define SINGLE_NALU_DATA_MAX  (RTP_SIZE_MAX - RTP_HEADER_SIZE)

/* SLICE_NALU_DATA_MAX = RTP_SIZE_MAX - RTP_HEADER_SIZE - FU_A_INDI_SIZE
       - FU_A_HEAD_SIZE */
#define SLICE_NALU_DATA_MAX   (SINGLE_NALU_DATA_MAX - FU_A_INDI_SIZE - FU_A_HEAD_SIZE)

#define MIN(a,b) ( ((a)<(b)) ? (a) : (b) )

typedef struct _RTP_header
{
    U8 magic ;
    U8 channel ;
    U16 embedlen;
    /* byte 0 */
#ifdef WORDS_BIGENDIAN
    U8 version:2;
    U8 padding:1;
    U8 extension:1;
    U8 csrc_len:4;
#else
    U8 csrc_len:4;
    U8 extension:1;
    U8 padding:1;
    U8 version:2;
#endif
    /* byte 1 */
#if WORDS_BIGENDIAN
    U8 marker:1;
    U8 payload:7;
#else
    U8 payload:7;
    U8 marker:1;
#endif
    /* bytes 2, 3 */
    U16 seq_no;
    /* bytes 4-7 */
    U32 timestamp;
    /* bytes 8-11 */
    U32 ssrc;					/* stream number is used here. */
} RTP_header;

S32 rtp_init (S32 free_chn);
S32 rtp_free (S32 free_chn);
UL64 get_randdom_seq (void);
S32 build_rtp_header(RTP_header *r,S32 cur_conn_num, int audio_flag,
                     unsigned int timestamp);
S32 udp_write(S32 len,S32 cur_conn_num, int audio_flag);
S32 send_frame_on_rtp_nw(unsigned char *inbuffer, S32 frame_size,
                         int audio_flag, int marker, unsigned int timestamp);
S32 create_vrtp_socket(const CHAR *host, S32 port,S32 type,S32 cur_conn_num);
S32 create_artp_socket(const CHAR *host, S32 port,S32 type,S32 cur_conn_num);


typedef struct RTP_DEBUG_STATS
{
    U16 videoSeqNo;
    U16 audioSeqNo;
    U32 udpPktTxIn10uSec;
    U32 udpPktTxIn1mSec;
    U32 udpPktTxIn1to10mSec;
    U32 udpPktTxIn10to50mSec;
    U32 udpPktTxIn50plusmSec;
    U32 totalUdpLen;
    U64 maxUdpSendTime;
}RTP_DEBUG_STATS_T;
#endif
