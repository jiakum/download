/******************************************************************************
*
*               COPYRIGHT (c) 2015-2016 GainSpan Corporation
*                         All Rights Reserved
*
* The source code contained or described herein and all documents
* related to the source code ("Material") are owned by GainSpan
* Corporation or its licensors.  Title to the Material remains
* with GainSpan Corporation or its suppliers and licensors.
*
* The Material is protected by worldwide copyright and trade secret
* laws and treaty provisions. No part of the Material may be used,
* copied, reproduced, modified, published, uploaded, posted, transmitted,
* distributed, or disclosed in any way except in accordance with the
* applicable license agreement.
*
* No license under any patent, copyright, trade secret or other
* intellectual property right is granted to or conferred upon you by
* disclosure or delivery of the Materials, either expressly, by
* implication, inducement, estoppel, except in accordance with the
* applicable license agreement.
*
* Unless otherwise agreed by GainSpan in writing, you may not remove or
* alter this notice or any other notice embedded in Materials by GainSpan
* or GainSpan's suppliers or licensors in any way.
*  @file			:	rtsp_client.h
*  @brief			:	This file contains function prototypes
*						related to simple RTSP client
**************************************************************************************/

#ifndef HAVE_RTSP_CLIENT_H
#define HAVE_RTSP_CLIENT_H

#include "nxd_bsd.h"
#include "gsn_includes.h"
#include "osal/gsn_osal_threadx.h"
#include "app_debug.h"
#ifdef DOOR_BELL
#include "AVLB/AVLB_def.h"
#endif
//#define CLIENT_DBG
//#define WLAN_STATS

#ifdef CLIENT_DBG
#define RTSP_CLIENT_DEBUG_INFO AppDbg_Printf
#define RTSP_CLIENT_DEBUG_FAIL AppDbg_Printf
#else
#define RTSP_CLIENT_DEBUG_INFO(...)
#define RTSP_CLIENT_DEBUG_FAIL(...)
#endif

#define RTSP_CLIENT_TIMEOUT

#ifdef RTSP_CLIENT_TIMEOUT
typedef enum TIMEOUT_VAL
{
    TIMEOUT_VAL_USEC,
    TIMEOUT_VAL_SEC,
} TIMEOUT_VAL_T;
#endif

/* client states */
typedef enum RTSP_CLIENT_STATE
{
    RTSP_CLIENT_FAILURE=-1,
    RTSP_CLIENT_SUCCESS=0,
    RTSP_TIMEOUT=1,
    RTSP_CONNECTED=1,
    RTSP_PLAYING,
    RTSP_DISCONNECTED=4,
} RTSP_CLIENT_STATE_T;

#ifdef STNDRD_RTSP_CLIENT
#ifdef DOOR_BELL
#define	RTSP_STR			"rtsp://"
#define SERVER_URL_LEN		32

#define RTSP_LOCAL_PORT		5540
#define LOCAL_CHANNEL		"ch0"

#define RTSP_CLOUD_PORT		8554
#define CLOUD_CHANNEL		"ch0"	/* Need to set based on APP registration*/

#define TLK_START   1
#define TLK_STOP    0
#else
#define Server_URL "rtsp://192.168.240.2/wavAudioTest"
#define RTSP_CLIENT_PORT 8554
#endif
#define RTSP_Version "RTSP/1.0"
#define RTSP_EL "\r\n"
#define VID_PORT_RTP "35421"
#define VID_PORT_RTCP "35422"
#define AUD_PORT_RTP "18324"
#define AUD_PORT_RTCP "18325"
#endif /* __STNDRD_RTSP_CLIENT (LIVE555)__ */

#ifndef STNDRD_RTSP_CLIENT
#ifdef AUDIO_PCM
#define AUD_PORT_RTP "2049"
/* WAV Header fileds information */
#define WAV_SAMPLING_RATE 11025
#define WAV_BITS_PER_SAMPLE 16
#define WAV_NUMBER_OF_CHANNELS 1
#endif /* __AUDIO_PCM__ */

#ifdef AUDIO_AAC
#define AUD_PORT_RTP "2049"
#endif /* __AUDIO_AAC__ */
#endif
#define BUF_SIZE 1536
#define LOW_BYTE 0x00ff
#define HIGH_BYTE 0xff00
#define RTP_HEADER_SIZE 16

/**************************************************************************************
 *
 *  @structure	:   rtsp_s
 *  @mem1		:   host
 *  @mem2		:   path
 *  @mem3		:   port
 *  @mem4		:   fd
 *  @mem5		:   vtrackid
 *  @mem6		:   atrackid
 *  @mem7		:   transport
 *  @mem8		:   session
 *  @mem9		:	client_state
 *  @mem10		:	cseq
 *  @mem11		:	outbuff
 *  @mem12		:	inbuff
 *
***************************************************************************************/

typedef struct rtsp_s
{
	int			a_fd;
#ifdef STNDRD_RTSP_CLIENT
    char		*host;
    char		*path;
    int			port;
    int			fd;
    char		vtrackid[16];
    char		atrackid[16];
    char		transport[16];
    char		session[16];
    int	client_state;
    unsigned int	cseq;
    int video_enable;
    int audio_enable;
    char		outbuff[BUF_SIZE];
#endif
    char		inbuff[BUF_SIZE];
	BOOL Timeout_Flag;
} rtsp_t;

int rtspc_init();
int Handl_Get_Data();
void rtsp_close();
#ifdef STNDRD_RTSP_CLIENT
int rtsp_request_options();
int rtsp_request_describe();
int rtsp_request_setup();
int rtsp_request_play();
int rtsp_connect(const char *url, unsigned int port);
int send_options();
int send_describe();
int send_setup();
int send_play();
int send_teardown();
int rtsp_get_response();
int get_sdp_details();
int get_session_id();
#endif


/**************************************************************************************
 *
 *  @structure  :   wav_Hdr
 *  @mem1       :   File_desc_header:	"RIFF"
 *  @mem2       :   File_size:	total_file_size - 8
 *  @mem3       :   Wave_desc_header:	"WAVE"
 *  @mem4       :   Format_desc_header:	"fmt "
 *  @mem5       :   Wave_chunk_size:	always 16
 *  @mem6       :   Num_channels:	01-mono, 02-steoreo
 *  @mem7       :   Samples_per_sec:	8K, 16K,...etc
 *  @mem8       :   Bytes_per_sec
 *  @mem9       :   Block_alignment
 *  @mem10      :   Bits_per_sample
 *  @mem11      :   Data_desc_header:	"data"
 *  @mem12      :   Data_len:	length of the file excluding wav header
 *
***************************************************************************************/

struct wav_Hdr
{
    char			File_desc_header[4];
    unsigned int	File_size;
    char			Wave_desc_header[4];
    char			Format_desc_header[4];
    unsigned int	Wave_chunk_size;
    short int		Wave_format_type;
    short int		Num_channels;
    unsigned int	Samples_per_sec;
    unsigned int	Bytes_per_sec;
    short int		Block_alignment;
    short int		Bits_per_sample;
    char			Data_desc_header[4];
    unsigned int	Data_len;
};

/**************************************************************************************
 *
 * @function        :   build_wav_header
 * @param           :   None
 * @return          :   int, on sucess 0, otherwise -1
 * @brief           :   Creates WAV header.
 *
 **************************************************************************************/

//int build_wav_header (unsigned char *buff, unsigned int sampling_rate, int no_of_channels, int bitspersample);
int build_wav_header();
#endif
