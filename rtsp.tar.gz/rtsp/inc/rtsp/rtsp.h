/******************************************************************************
*
*               COPYRIGHT (c) 2015-2016 GainSpan Corporation
*                         All Rights Reserved
*
* The source code contained or described herein and all documents
* related to the source code ("Material") are owned by GainSpan
* Corporation or its licensors.  Title to the Material remains
* with GainSpan Corporation or its suppliers and licensors.
*
* The Material is protected by worldwide copyright and trade secret
* laws and treaty provisions. No part of the Material may be used,
* copied, reproduced, modified, published, uploaded, posted, transmitted,
* distributed, or disclosed in any way except in accordance with the
* applicable license agreement.
*
* No license under any patent, copyright, trade secret or other
* intellectual property right is granted to or conferred upon you by
* disclosure or delivery of the Materials, either expressly, by
* implication, inducement, estoppel, except in accordance with the
* applicable license agreement.
*
* Unless otherwise agreed by GainSpan in writing, you may not remove or
* alter this notice or any other notice embedded in Materials by GainSpan
* or GainSpan's suppliers or licensors in any way.
*  @file        :  rtsp.h
*  @brief       :  This file contains function prototypes , structures and
*                    macros used in the whole code.
********************************************************************************/

#ifndef _RTSP_RTSP_H
#define _RTSP_RTSP_H

//#define WLAN_STATS

/***
 * To get RTSP Audio & Video Streaming This macro should be enabled,
 * NOTE: TO get Video streaming only comment this macro.
 ***/
//#define symbol RTSP_AUD_EN - As compile time flag

/****
 * provides SDP for AAC related audio media type - Geo
 ****/
//#define symbol AUDIO_AAC - As compile time flag

/****
 * provides SDP for PCM related audio media type - OV
 ****/
//#define symbol AUDIO_PCM - As compile time flag
#define RTSP_DEBUG
#ifdef RTSP_DEBUG
#define RTSP_DEBUG_PRINT AppDbg_Printf
#else
#define RTSP_DEBUG_PRINT(...)
#endif


#include "comm/type.h"
#include "comm/version.h"
#include "gsn_types.h"
#include "nxd_bsd.h"
#include "gsn_includes.h"
//#include "include/trsocket.h"
#include "app_debug.h"
#define INET_INADDR_ANY	"0.0.0.0"
#define RTSP_DEFAULT_PORT	554
#define RTSP_SESSION_ID	12321
#define RTSP_EL "\r\n"
#define RTSP_VER "RTSP/1.0"
#define HDR_REQUIRE "Require"
#define HDR_ACCEPT "Accept"
#define PACKAGE "RtpRtspServer"

#define VERSION "1.0"
#define SDP_EL "\r\n"
#define HDR_TRANSPORT "Transport"
#define HDR_SESSION "Session"

#define RTSP_BUFFERSIZE 2048
#define MAX_DESCR_LENGTH 2048
#define DEFAULT_TTL 32
#define HDR_CSEQ "CSeq"
/* based on number of parallel connections, now only single connection at a time */
#define MAX_CONN 1
#define RTP_DEFAULT_PORT 2000
#define RTSP_SSRC 12345678
#define VIDEO_PAYLOAD_TYPE	96
#define AUDIO_PAYLOAD_TYPE	98

extern struct rtsp_buffer *rtsp[MAX_CONN];

/************************************************************
 * rtsp streaming status codes.
 ************************************************************/

typedef enum RTSP_STREAMING_STATUS
{
    STREAM_IDLE,
    STREAM_RUNNING,
    STREAM_PAUSE,
    STREAM_STOP,
} RTSP_STREAMING_STATUS_T;

/************************************************************
 * rtsp status codes.
 ************************************************************/

typedef enum RTSP_STATUS_CODES
{
    BAD_REQUEST=400,
    RESPONSE_OK=200,
    FORBIDDEN=403,
    NOT_ACCEPTABLE=406,
    UNSUPPORTED_MEDIA_TYPE=415,
    SESSION_NOT_FOUND=454,
    OPTION_UNSUPPORTED=551,
} RTSP_STATUS_CODES_T;

/************************************************************
 * track id's for video and audio
 ************************************************************/

typedef enum TRACK_ID_LIST
{
    AUDIO_TRACK=0x0a,
    VIDEO_TRACK,
} TRACK_ID_LIST_T;

/************************************************************
 * Methods supported by RTSP server
 ************************************************************/

typedef enum RTSP_SERVER_METHOD
{
    RTSP_METHOD_UNSUPPORTED,
    RTSP_OPTIONS,
    RTSP_DESCRIBE,
    RTSP_SETUP,
    RTSP_PLAY,
    RTSP_TEARDOWN,
	RTSP_PAUSE,
} RTSP_SERVER_METHOD_T;

/*************************************************************
 * rtspd server status codes
 *************************************************************/

typedef enum RTSP_SERVER_STATUS
{
    RTSP_CLIENT_CONNECTED,
    RTSP_OPTIONS_FAIL,
    RTSP_OPTIONS_SUCESS,
    RTSP_DESCRIBE_FAIL,
    RTSP_DESCRIBE_SUCESS,
    RTSP_SETUP_FAIL,
    RTSP_SETUP_SUCESS,
    RTSP_PLAY_FAIL,
    RTSP_PLAY_SUCESS,
    RTSP_VIDEO_SOCK_CREATE_FAIL,
    RTSP_VIDEO_SOCK_CREATE_SUCESS,
    RTSP_AUDIO_SOCK_CREATE_FAIL,
    RTSP_AUDIO_SOCK_CREATE_SUCESS,
    RTSP_RTCP_SOCK_CREATE_FAIL,
    RTSP_RTCP_SOCK_CREATE_SUCCESS,
    RTSP_TEARDOWN_FAIL,
    RTSP_TEARDOWN_SUCESS,
    RTSP_UDP_WRITE_FAIL,
} RTSP_SERVER_STATUS_T;

/*************************************************************
 *
 *  @structure  :   rtsp_port
 *  @mem1       :   rtp_cli_port
 *  @mem2       :   rtcp_cli_port
 *  @mem3       :   rtp_ser_port
 *  @mem4       :   rtcp_ser_port
 *  @mem5       :   ssrc
 *  @mem6       :   timestamp
 *  @mem7       :   frame_rate_step
 *  @mem8       :   seq
 *
**************************************************************/

struct rtsp_port
{
    S32 video_rtp_cli_port;
    S32 video_rtcp_cli_port;
    S32 video_rtp_ser_port;
    S32 video_rtcp_ser_port;
    S32 audio_rtp_cli_port;
    S32 audio_rtcp_cli_port;
    S32 audio_rtp_ser_port;
    S32 audio_rtcp_ser_port;
    U32 ssrc;
    U32 timestamp;
    U32 frame_rate_step;
    U16 seq;

};

/*************************************************************
 *
 *  @structure  :   rtsp_fd
 *  @mem1       :   rtspfd
 *  @mem2       :   video_rtp_fd
 *  @mem3       :   video_rtcp_fd
 *  @mem4       :   audio_rtp_fd
 *  @mem5       :   audio_rtcp_fd
 *
 *************************************************************/

struct rtsp_fd
{
    S32 rtspfd;
    S32 video_rtp_fd;
    S32 video_rtcp_fd;
    S32 audio_rtp_fd;
    S32 audio_rtcp_fd;
    S32 talkback_fd;

};

/*************************************************************
 *
 *  @structure  :   rtsp_cli
 *  @mem1       :   cli_fd
 *  @mem2       :   conn_num
 *  @mem3       :   cli_host
 *
 *************************************************************/

struct rtsp_cli
{
    S32 cli_fd;
    S32 conn_num;
    CHAR cli_host[128];

};

/*************************************************************
 *
 *  @structure  :   rtp_cli_seq
 *  @mem1       :   video_seq_num
 *  @mem2       :   audio_seq_num
 *
 *************************************************************/

struct rtp_cli_seq
{
    U16 video_seq_num;
    U16 audio_seq_num;

};

/*************************************************************
 *
 *  @structure  :   rtsp_buffer
 *  @mem1       :   payload_type
 *  @mem2       :   session_id
 *  @mem3       :   rtsp_cseq
 *  @mem4       :   is_runing
 *  @mem5       :   conn_status
 *  @mem6       :   rtspd_status
 *  @mem7       :   vist_type
 *  @mem8       :   cmd_port, structure rtsp_port type
 *  @mem9       :   fd, structure rtsp_fd type
 *  @mem10      :   cli_rtsp, structure rtsp_cli type
 *  @mem11      :   file_name
 *  @mem12      :   host_name
 *  @mem13      :   nalu_buffer
 *  @mem14      :   in_buffer
 *  @mem15      :   out_buffer
 *  @mem16      :   sdp_buffer
 *
 *************************************************************/

struct rtsp_buffer
{

    S32 payload_type; /* 96 h263/h264*/
    S32 session_id;
    U32 rtsp_cseq;
    U32 is_runing;
    U32 cur_conn;
    U32 conn_status;
    U32 rtspd_status;
    U32 vist_type;  /****0: H264 file vist  1: PS file vist  2: h264 stream vist ****/
    U32 trackID;

    struct rtsp_port cmd_port;
    struct rtsp_fd fd;
    struct rtsp_cli cli_rtsp;
    struct rtp_cli_seq cli_rtp;
    // Buffers
    CHAR file_name[128];
    CHAR host_name[128];
    U8 nalu_buffer[1460];
    CHAR in_buffer[RTSP_BUFFERSIZE];
    CHAR out_buffer[RTSP_BUFFERSIZE];
    CHAR sdp_buffer[MAX_DESCR_LENGTH];

};

S32 rtsp_options(S32);
S32 rtsp_describe(S32);
S32 rtsp_setup(S32);
S32 rtsp_play(S32);
S32 rtsp_teardown(S32);
S32 get_rtsp_method(S32);
S32 set_free_conn_status(S32, S32);
S32 rtp_send_packet(S32);
S32 send_error_reply(S32,S32);
S32 check_rtsp_url(S32);
S32 get_rtsp_CSeq(S32);
S32 check_rtsp_filename(S32);
UL64 get_random_seq(VOID);
S32 parse_url(const CHAR *, CHAR *, U16 *, CHAR *);
S32 get_stat(S32, char *buff);
S32 create_vrtp_socket(const CHAR *, S32,S32,S32);
S32 create_vrtcp_socket(const CHAR *, S32,S32,S32);
S32 tcp_write(S32, void *, S32);
void tcp_accept();
S32 create_sercmd_socket(const CHAR *, const CHAR *,S32);
int init_memory(void);
S32 rtsp_free(void);
int free_memory(void);
S32 is_supported_mediatype (CHAR *, S32);

#endif
