/******************************************************************************
*
*               COPYRIGHT (c) 2015-2016 GainSpan Corporation
*                         All Rights Reserved
*
* The source code contained or described herein and all documents
* related to the source code ("Material") are owned by GainSpan
* Corporation or its licensors.  Title to the Material remains
* with GainSpan Corporation or its suppliers and licensors.
*
* The Material is protected by worldwide copyright and trade secret
* laws and treaty provisions. No part of the Material may be used,
* copied, reproduced, modified, published, uploaded, posted, transmitted,
* distributed, or disclosed in any way except in accordance with the
* applicable license agreement.
*
* No license under any patent, copyright, trade secret or other
* intellectual property right is granted to or conferred upon you by
* disclosure or delivery of the Materials, either expressly, by
* implication, inducement, estoppel, except in accordance with the
* applicable license agreement.
*
* Unless otherwise agreed by GainSpan in writing, you may not remove or
* alter this notice or any other notice embedded in Materials by GainSpan
* or GainSpan's suppliers or licensors in any way.
*  @file			:	rtsp_client_thread.h
*  @brief			:	This file contains function prototypes
*						used in rtsp_client_thread.c file.
**************************************************************************************/

#ifndef HAVE_RTSP_CLIENT_THREAD_H
#define HAVE_RTSP_CLIENT_THREAD_H

#include "gsn_includes.h"
#include "osal/gsn_osal_threadx.h"
#include "app_debug.h"
#include "comm/type.h"

#define AVLB_RTSP_CLIENT_TASK_PRIORITY 11
#define AVLB_RTSP_CLIENT_STACK_SIZE	(1024*2)

/**********************************************************
 * Thread task control block for rtsp client task
 **********************************************************/

typedef struct _GSN_AVLB_RTSP_CLIENT_TCB
{
    GSN_OSAL_THREAD_TCB_T   rtspClientTask_tcb;
} GSN_AVLB_RTSP_CLIENT_TCB;

int RTSP_Client_ThreadStart ();
void client_rtsp_task(UINT32 arg);
int client_main ();

#endif
