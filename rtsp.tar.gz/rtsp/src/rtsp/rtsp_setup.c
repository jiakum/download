/******************************************************************************
*
*               COPYRIGHT (c) 2015-2016 GainSpan Corporation
*                         All Rights Reserved
*
* The source code contained or described herein and all documents
* related to the source code ("Material") are owned by GainSpan
* Corporation or its licensors.  Title to the Material remains
* with GainSpan Corporation or its suppliers and licensors.
*
* The Material is protected by worldwide copyright and trade secret
* laws and treaty provisions. No part of the Material may be used,
* copied, reproduced, modified, published, uploaded, posted, transmitted,
* distributed, or disclosed in any way except in accordance with the
* applicable license agreement.
*
* No license under any patent, copyright, trade secret or other
* intellectual property right is granted to or conferred upon you by
* disclosure or delivery of the Materials, either expressly, by
* implication, inducement, estoppel, except in accordance with the
* applicable license agreement.
*
* Unless otherwise agreed by GainSpan in writing, you may not remove or
* alter this notice or any other notice embedded in Materials by GainSpan
* or GainSpan's suppliers or licensors in any way.
*  @file        :  rtsp_setup.c
*  @brief       :  This file contains functions for handling setup method.
********************************************************************************/

#include "rtsp/rtsp.h"

/***************************************************************
 *
 * @function    :   get_server_port
 * @param1      :   cur_conn_num -> current connection number
 * @ret         :   S32, on SUCCESS returns 0, otherwise returns -1
 * @brief       :   according to client gets server port (rtp/rtcp).
 *
 ***************************************************************/

S32 get_server_port(S32 cur_conn_num)
{
    static S32 start_port=RTP_DEFAULT_PORT;

    if (rtsp[cur_conn_num]->trackID == AUDIO_TRACK)
    {
        rtsp[cur_conn_num]->cmd_port.audio_rtp_ser_port= start_port;
        rtsp[cur_conn_num]->cmd_port.audio_rtcp_ser_port=
            rtsp[cur_conn_num]->cmd_port.audio_rtp_ser_port+1;
    }
    else
    {
        rtsp[cur_conn_num]->cmd_port.video_rtp_ser_port = start_port;
        rtsp[cur_conn_num]->cmd_port.video_rtcp_ser_port=
            rtsp[cur_conn_num]->cmd_port.video_rtp_ser_port+1;
    }

    start_port += 2;

    return RTSP_SUCCESS;
}

/***************************************************************
 *
 * @function    :   send_setup_reply
 * @param1      :   status -> rtsp status
 * @param2      :   cur_conn_num -> current connection number
 * @ret         :   S32, on SUCCESS returns 0, otherwise returns -1
 * @brief       :   set describe command response buffer.
 *
 ***************************************************************/

S32 send_setup_reply(S32 status,S32 cur_conn_num)
{
    CHAR temp[30];

    memset(temp, 0, sizeof(temp));
    get_stat (status, temp);
    rtsp[cur_conn_num]->session_id = RTSP_SESSION_ID;

    if(!rtsp[cur_conn_num]->out_buffer)
    {
        return RTSP_FAILURE;
    }

    /* build a reply message */
    sprintf(rtsp[cur_conn_num]->out_buffer,
            "%s %d %s"RTSP_EL"CSeq: %d"RTSP_EL"Server: %s/%s"RTSP_EL, RTSP_VER, status,
            (CHAR *)temp, rtsp[cur_conn_num]->rtsp_cseq, PACKAGE,
            VERSION);
    strcat(rtsp[cur_conn_num]->out_buffer, "Session: ");
    sprintf(temp, "%d", rtsp[cur_conn_num]->session_id);
    strcat(rtsp[cur_conn_num]->out_buffer, temp);
    strcat(rtsp[cur_conn_num]->out_buffer, ";timeout=");
    sprintf(temp, "%d", 30);
    strcat(rtsp[cur_conn_num]->out_buffer, temp);
    strcat(rtsp[cur_conn_num]->out_buffer, RTSP_EL);
    /**** unicast  ****/
    strcat(rtsp[cur_conn_num]->out_buffer,
           "Transport: RTP/AVP/UDP;unicast;source=");
    strcat(rtsp[cur_conn_num]->out_buffer, rtsp[cur_conn_num]->host_name);

    if (rtsp[cur_conn_num]->trackID == AUDIO_TRACK)
    {
        strcat(rtsp[cur_conn_num]->out_buffer, ";client_port=");
        sprintf(temp, "%d", rtsp[cur_conn_num]->cmd_port.audio_rtp_cli_port);
        strcat(rtsp[cur_conn_num]->out_buffer, temp);
        strcat(rtsp[cur_conn_num]->out_buffer, "-");
        sprintf(temp, "%d", rtsp[cur_conn_num]->cmd_port.audio_rtcp_cli_port);
        strcat(rtsp[cur_conn_num]->out_buffer, temp);
        strcat(rtsp[cur_conn_num]->out_buffer, ";server_port=");
        sprintf(temp, "%d", rtsp[cur_conn_num]->cmd_port.audio_rtp_ser_port);
        strcat(rtsp[cur_conn_num]->out_buffer, temp);
        strcat(rtsp[cur_conn_num]->out_buffer, "-");
        sprintf(temp, "%d", rtsp[cur_conn_num]->cmd_port.audio_rtcp_ser_port);
        strcat(rtsp[cur_conn_num]->out_buffer, temp);
    }
    else
    {
        strcat(rtsp[cur_conn_num]->out_buffer, ";client_port=");
        sprintf(temp, "%d", rtsp[cur_conn_num]->cmd_port.video_rtp_cli_port);
        strcat(rtsp[cur_conn_num]->out_buffer, temp);
        strcat(rtsp[cur_conn_num]->out_buffer, "-");
        sprintf(temp, "%d", rtsp[cur_conn_num]->cmd_port.video_rtcp_cli_port);
        strcat(rtsp[cur_conn_num]->out_buffer, temp);
        strcat(rtsp[cur_conn_num]->out_buffer, ";server_port=");
        sprintf(temp, "%d", rtsp[cur_conn_num]->cmd_port.video_rtp_ser_port);
        strcat(rtsp[cur_conn_num]->out_buffer, temp);
        strcat(rtsp[cur_conn_num]->out_buffer, "-");
        sprintf(temp, "%d", rtsp[cur_conn_num]->cmd_port.video_rtcp_ser_port);
        strcat(rtsp[cur_conn_num]->out_buffer, temp);
    }

    strcat(rtsp[cur_conn_num]->out_buffer, RTSP_EL);
    strcat(rtsp[cur_conn_num]->out_buffer, "Cache-Control: no-cache");
    strcat(rtsp[cur_conn_num]->out_buffer, RTSP_EL);
    strcat(rtsp[cur_conn_num]->out_buffer, RTSP_EL);

    if(tcp_write(rtsp[cur_conn_num]->cli_rtsp.cli_fd,
                 rtsp[cur_conn_num]->out_buffer,
                 strlen(rtsp[cur_conn_num]->out_buffer)) < RTSP_SUCCESS)
    {
        RTSP_DEBUG_PRINT("\r\nsend_setup_reply error\n");
        return RTSP_FAILURE;
    }

    return RTSP_SUCCESS;
}

/***************************************************************
 *
 * @function    :   rtsp_setup
 * @param1      :   cur_conn_num -> current connection number
 * @ret         :   S32, on SUCCESS returns 0, otherwise returns -1
 * @brief       :   setup command processing functions.
 *
 ***************************************************************/

S32 rtsp_setup(S32 cur_conn_num)
{
    CHAR *p = NULL;
    CHAR trash[255], line[255];

    RTSP_DEBUG_PRINT ("\r\n*** SETUP ***\n");

    if(!rtsp[cur_conn_num]->in_buffer)
    {
        RTSP_DEBUG_PRINT("\r\nsetup: invalid in buffer\n");
        return RTSP_FAILURE;
    }

    if(check_rtsp_url(cur_conn_num) < RTSP_SUCCESS)
    {
        RTSP_DEBUG_PRINT("\r\nsetup: invalid url.\n");
        return RTSP_FAILURE;
    }

    if(check_rtsp_filename(cur_conn_num) < RTSP_SUCCESS)
    {
        RTSP_DEBUG_PRINT("\r\nsetup: invalid file name.\n");
        return RTSP_FAILURE;
    }

    if(get_rtsp_CSeq(cur_conn_num) < RTSP_SUCCESS)
    {
        RTSP_DEBUG_PRINT("\r\nsetup: rtsp cseg failed.\n");
        return RTSP_FAILURE;
    }

    if ((p = strstr(rtsp[cur_conn_num]->in_buffer, "client_port")) == NULL
            && strstr(rtsp[cur_conn_num]->in_buffer, "unicast") == NULL)
    {
        RTSP_DEBUG_PRINT("\r\nsetup: not aceeptable client port\n");
        send_error_reply(NOT_ACCEPTABLE,cur_conn_num); /* Not Acceptable */
        return RTSP_FAILURE;
    }

    /**** Start parsing the Transport header ****/
    if ((p = strstr(rtsp[cur_conn_num]->in_buffer, HDR_TRANSPORT)) == NULL)
    {
        RTSP_DEBUG_PRINT("\r\nsetup: not acceptable hdr transport\n");
        send_error_reply(NOT_ACCEPTABLE,cur_conn_num);	/* Not Acceptable */
        return RTSP_FAILURE;
    }

    if (sscanf(p, "%10s%255s", trash, line) != 2)
    {
        RTSP_DEBUG_PRINT("\r\nsetup: bad request.\n");
        send_error_reply(BAD_REQUEST,cur_conn_num);	/* Bad Request */
        return RTSP_FAILURE;
    }

    /****  get client rtp and rtcp port  ****/
    if(strstr(line, "client_port") != NULL)
    {
        p = strstr(line, "client_port");
        p = strstr(p, "=");
#ifdef RTSP_AUD_EN

        /*
         * extracting client rtp and rtcp ports based on track id
         * both video and audio streaming
         */
        if(rtsp[cur_conn_num]->trackID == AUDIO_TRACK)
        {
            sscanf(p + 1, "%d", &(rtsp[cur_conn_num]->cmd_port.audio_rtp_cli_port));
            p = strstr(p, "-");
            sscanf(p + 1, "%d", &(rtsp[cur_conn_num]->cmd_port.audio_rtcp_cli_port));
        }
        else  	/* Video track */
        {
            sscanf(p + 1, "%d", &(rtsp[cur_conn_num]->cmd_port.video_rtp_cli_port));
            p = strstr(p, "-");
            sscanf(p + 1, "%d", &(rtsp[cur_conn_num]->cmd_port.video_rtcp_cli_port));
        }

#else
        /*
         * extract client video rtp and rtcp ports
         * video streaming only
         */
        sscanf(p + 1, "%d", &(rtsp[cur_conn_num]->cmd_port.video_rtp_cli_port));
        p = strstr(p, "-");
        sscanf(p + 1, "%d", &(rtsp[cur_conn_num]->cmd_port.video_rtcp_cli_port));
#endif
    }

    /* gets server ports */
    get_server_port(cur_conn_num);
    rtsp[cur_conn_num]->cmd_port.seq=get_random_seq();
    rtsp[cur_conn_num]->cmd_port.ssrc = RTSP_SSRC;
    rtsp[cur_conn_num]->cmd_port.timestamp=0;

    if(send_setup_reply(RESPONSE_OK,cur_conn_num)!=RTSP_FAILURE)
    {
        return 1;
    }

    return RTSP_SUCCESS;
}
