/******************************************************************************
*
*               COPYRIGHT (c) 2015-2016 GainSpan Corporation
*                         All Rights Reserved
*
* The source code contained or described herein and all documents
* related to the source code ("Material") are owned by GainSpan
* Corporation or its licensors.  Title to the Material remains
* with GainSpan Corporation or its suppliers and licensors.
*
* The Material is protected by worldwide copyright and trade secret
* laws and treaty provisions. No part of the Material may be used,
* copied, reproduced, modified, published, uploaded, posted, transmitted,
* distributed, or disclosed in any way except in accordance with the
* applicable license agreement.
*
* No license under any patent, copyright, trade secret or other
* intellectual property right is granted to or conferred upon you by
* disclosure or delivery of the Materials, either expressly, by
* implication, inducement, estoppel, except in accordance with the
* applicable license agreement.
*
* Unless otherwise agreed by GainSpan in writing, you may not remove or
* alter this notice or any other notice embedded in Materials by GainSpan
* or GainSpan's suppliers or licensors in any way.
*  @file        :  rtsp_describe.c
*  @brief       :  This file contains functions for handling describe method.
********************************************************************************/

#include "rtsp/rtsp.h"

/***************************************************************
 *
 * @function    :   is_supported_mediatype
 * @param1      :   pointer holding the given file type
 * @param2      :   cur_conn_num -> current connection number
 * @ret         :   S32, on SUCCESS returns 0, otherwise -1
 * @brief       :   check the mediatype is supported or not.
 *
 ***************************************************************/

S32 is_supported_mediatype(CHAR *p,S32 cur_conn_num)
{
    /* Add supported format extensions here*/
    if (strcasecmp(p,".264")==0)
    {
        rtsp[cur_conn_num]->vist_type=0;
        return 1;
    }

    if (strcasecmp(p,".H264")==0)
    {
        rtsp[cur_conn_num]->vist_type=0;
        return 1;
    }

    if (strstr(p,"h264stream"))
    {
        rtsp[cur_conn_num]->vist_type=2;
        return 1;
    }

    if (strcasecmp(p,".ps")==0)
    {
        rtsp[cur_conn_num]->vist_type=1;
        return 1;
    }

    if (strstr(p,"stream0"))
    {
        rtsp[cur_conn_num]->vist_type=0;
        return 1;
    }

    return RTSP_SUCCESS;
}

/***************************************************************
 *
 * @function    :   parse_url
 * @param1      :   url -> url
 * @param2      :   server -> server ip address
 * @param3      :   port -> server port
 * @param4      ;   file_name -> visit filename
 * @ret         :   S32, on SUCCESS returns 1 if url is valid, otherwise 0
 * @brief       :   checks the given url is valid or not.
 *
 ***************************************************************/

S32 parse_url(const CHAR *url, CHAR *server, U16 *port, CHAR *file_name)
{
    /* expects format '[rtsp://server[:port/]]filename' */
    S32 valid_url = 0;
    CHAR *token,*port_str;
    CHAR temp_url[128]="";

    /* copy url */
    strcpy(temp_url, url);

    if (strncmp(temp_url, "rtsp://", 7) == 0)
    {
        token = strtok(&temp_url[7], " :/\t\n");

        if (token == NULL)
        {
            return RTSP_FAILURE;
        }

        strcpy(server, token);
        port_str = strtok(&temp_url[strlen(server) + 7 + 1], " /\t\n");

        if (port_str)
        {
            *port = (U16) atol(port_str);

            if (*port)
            {
                token = strtok(&temp_url[7+strlen(server)+1+strlen(port_str)+1], " ");
            }
            else
            {
                strcpy (token, port_str);
            }
        }
        else
        {
            *port = RTSP_DEFAULT_PORT;
            token = strtok(&temp_url[7+strlen(server)+1], " ");
        }

        valid_url = 1;

        if (token)
        {
            strcpy(file_name, token);
        }
        else
        {
            file_name[0] = '\0';
        }
    }
    else
    {
        /* try just to extract a file name */
    }

    return valid_url;
}

/***************************************************************
 *
 * @function    :   send_describe_reply
 * @param1      :   status -> rtsp status
 * @param2      :   cur_conn_num -> current connection number
 * @ret         :   S32, on SUCCESS returns 1 if url is valid, otherwise 0
 * @brief       :   set describe command response buffer.
 *
 ***************************************************************/

S32 send_describe_reply(S32 status,S32 cur_conn_num)
{
    CHAR temp[64]="";
    memset(rtsp[cur_conn_num]->out_buffer, 0,
           sizeof(rtsp[cur_conn_num]->out_buffer));

    if(!rtsp[cur_conn_num]->out_buffer)
    {
        return RTSP_FAILURE;
    }

    get_stat (status, temp);
    /*describe*/
    sprintf(rtsp[cur_conn_num]->out_buffer,
            "%s %d %s"RTSP_EL"CSeq: %d"RTSP_EL"Server: %s/%s"RTSP_EL, RTSP_VER, status,
            (CHAR *)temp, rtsp[cur_conn_num]->rtsp_cseq, PACKAGE, VERSION);
    strcat(rtsp[cur_conn_num]->out_buffer, "Content-Type: application/sdp"RTSP_EL);
    sprintf(rtsp[cur_conn_num]->out_buffer + strlen(rtsp[cur_conn_num]->out_buffer),
            "Content-Length: %d"RTSP_EL, strlen(rtsp[cur_conn_num]->sdp_buffer));
    sprintf(rtsp[cur_conn_num]->out_buffer + strlen(rtsp[cur_conn_num]->out_buffer),
            "Cache-Control: no-cache"RTSP_EL);
    strcat(rtsp[cur_conn_num]->out_buffer, RTSP_EL);
    /**** concatenate description ****/
    strcat(rtsp[cur_conn_num]->out_buffer, rtsp[cur_conn_num]->sdp_buffer);

    if(tcp_write(rtsp[cur_conn_num]->cli_rtsp.cli_fd,
                 rtsp[cur_conn_num]->out_buffer,
                 strlen(rtsp[cur_conn_num]->out_buffer)) < RTSP_SUCCESS)
    {
        return RTSP_FAILURE;
    }

    return RTSP_SUCCESS;
}

/***************************************************************
 *
 * @function    :   get_SDP_user_name
 * @param1      :   buffer -> where the sdp user message is to copied.
 * @ret         :   char * -> returns buffer after copying sdp message.
 * @brief       :   gives user name for sdp.
 *
 ***************************************************************/

CHAR *get_SDP_user_name(CHAR *buffer)
{
    strcpy(buffer,PACKAGE);
    return buffer;
}

float NTP_time(time_t t)
{
    return (float)t+2208988800U;
}

/***************************************************************
 *
 * @function    :   get_SDP_session_id
 * @param1      :   buffer -> where the sdp session id is to be copied.
 * @ret         :   char * -> returns buffer after copying done.
 * @brief       :   gives session id for sdp.
 *
 ***************************************************************/

CHAR *get_SDP_session_id(CHAR *buffer)
{
    buffer[0]='\0';
    sprintf(buffer,"%.0f",NTP_time(0));
    return buffer;
}

/***************************************************************
 *
 * @function    :   get_SDP_version
 * @param1      :   buffer -> where the sdp version is to be copied.
 * @ret         :   char * -> returns buffer after copying done.
 * @brief       :   gives the version number for sdp.
 *
 ***************************************************************/

CHAR *get_SDP_version(CHAR *buffer)
{
    buffer[0]='\0';
    sprintf(buffer,"%.0f",NTP_time(time(NULL)));
    return buffer;
}

/***************************************************************
 *
 * @function    :   get_describe_sdp
 * @param1      :   sdp_buff -> buffer where to store sdp info
 * @param2      :   cur_conn_num -> current connection number
 * @ret         :   S32 -> on SUCCESS returns 0, otherwise -1
 * @brief       :   get describe sdp message.
 *
 ***************************************************************/

S32 get_describe_sdp(CHAR *sdp_buff,S32 cur_conn_num)
{
    CHAR s[64];

    if(!sdp_buff)
    {
        return RTSP_FAILURE;
    }

    strcpy(sdp_buff, "v=0"SDP_EL);
    strcat(sdp_buff, "o=");
    strcat(sdp_buff,get_SDP_user_name(s));
    strcat(sdp_buff," ");
    strcat(sdp_buff, get_SDP_session_id(s));
    strcat(sdp_buff," ");
    strcat(sdp_buff, get_SDP_version(s));
    strcat(sdp_buff, SDP_EL);
    strcat (sdp_buff, "a=range:npt=0- ");
    strcat(sdp_buff, SDP_EL);
    strcat(sdp_buff, "c=");
    strcat(sdp_buff, "IN ");		/* Network type: Internet. */
    strcat(sdp_buff, "IP4 ");		/* Address type: IP4. */
    strcat(sdp_buff, rtsp[cur_conn_num]->host_name);
    strcat(sdp_buff, SDP_EL);
    strcat(sdp_buff, "s=RTSP Session"SDP_EL);
    sprintf(sdp_buff + strlen(sdp_buff), "i=%s %s Streaming Server"SDP_EL, PACKAGE,
            VERSION);
    sprintf(sdp_buff + strlen(sdp_buff), "u=%s"SDP_EL,
            rtsp[cur_conn_num]->file_name);
    strcat(sdp_buff, "t=0 0"SDP_EL);
    /**** media specific ****/
    strcat(sdp_buff,"m=");
    strcat(sdp_buff,"video 0");
    strcat(sdp_buff," RTP/AVP "); /* Use UDP */
    rtsp[cur_conn_num]->payload_type=VIDEO_PAYLOAD_TYPE;
    sprintf(sdp_buff + strlen(sdp_buff), "%d"SDP_EL,
            rtsp[cur_conn_num]->payload_type);

    if (rtsp[cur_conn_num]->payload_type>=VIDEO_PAYLOAD_TYPE)
    {
        /**** Dynamically defined payload ****/
        strcat(sdp_buff,"a=rtpmap:");
        sprintf(sdp_buff + strlen(sdp_buff), "%d", rtsp[cur_conn_num]->payload_type);
        strcat(sdp_buff," ");
        strcat(sdp_buff,"H264/90000");
        strcat(sdp_buff, SDP_EL);
        sprintf (s, "a=fmtp:%d ", rtsp[cur_conn_num]->payload_type);
        strcat (sdp_buff, s);
#ifdef AUDIO_AAC
		strcat(sdp_buff,"packetization-mode=1;profile-level-id=4D400C;");
#endif
#ifdef AUDIO_PCM
		strcat(sdp_buff,"packetization-mode=1;profile-level-id=420028;sprop-parameter-sets=Z0IAKOkBQHsg,aM44gA==");
		strcat(sdp_buff, SDP_EL);
		strcat(sdp_buff,"a=control:");
		sprintf(sdp_buff + strlen(sdp_buff),"rtsp://%s/%s/trackID=1",rtsp[cur_conn_num]->host_name,rtsp[cur_conn_num]->file_name);
#endif
        strcat(sdp_buff, SDP_EL);
    }

    strcat(sdp_buff, SDP_EL);
    return RTSP_SUCCESS;
}

/***************************************************************
 *
 * @function    :   get_describe_sdp_audio_video
 * @param1      :   sdp_buff -> buffer where to store sdp info
 * @param2      :   cur_conn_num -> current connection number
 * @ret         :   S32 -> on SUCCESS returns 0, otherwise -1
 * @brief       :   get describe sdp message for audio and video.
 *
 ***************************************************************/

S32 get_describe_sdp_audio_video(CHAR *sdp_buff,S32 cur_conn_num)
{
    CHAR s[64];

    if(!sdp_buff)
    {
        return RTSP_FAILURE;
    }

    strcpy(sdp_buff, "v=0"SDP_EL);
    strcat(sdp_buff, "o=");
    strcat(sdp_buff,get_SDP_user_name(s));
    strcat(sdp_buff," ");
    strcat(sdp_buff, get_SDP_session_id(s));
    strcat(sdp_buff," ");
    strcat(sdp_buff, get_SDP_version(s));
    strcat(sdp_buff, SDP_EL);
    strcat(sdp_buff, "c=");
    strcat(sdp_buff, "IN ");		/* Network type: Internet. */
    strcat(sdp_buff, "IP4 ");		/* Address type: IP4. */
    strcat(sdp_buff, rtsp[cur_conn_num]->host_name);
    strcat(sdp_buff, SDP_EL);
    strcat(sdp_buff, "a=range:npt=0-"SDP_EL);
    /**** media specific ****/

    strcat(sdp_buff,"m=");
    strcat(sdp_buff,"audio 0");
    strcat(sdp_buff," RTP/AVP "); /* Use UDP */
    rtsp[cur_conn_num]->payload_type=AUDIO_PAYLOAD_TYPE;
    sprintf(sdp_buff + strlen(sdp_buff), "%d"SDP_EL,
            rtsp[cur_conn_num]->payload_type);
    strcat(sdp_buff, "c=IN IP4 0.0.0.0"SDP_EL);
    strcat(sdp_buff, "b=AS:64"SDP_EL);

    if (rtsp[cur_conn_num]->payload_type>=VIDEO_PAYLOAD_TYPE)
    {
        /**** Dynamically defined payload ****/
        strcat(sdp_buff,"a=rtpmap:");
        sprintf(sdp_buff + strlen(sdp_buff), "%d", rtsp[cur_conn_num]->payload_type);
        strcat(sdp_buff," ");
#ifdef AUDIO_AAC
        strcat(sdp_buff,"mpeg4-generic/16000/1");
        strcat(sdp_buff, SDP_EL);
        sprintf (s, "a=fmtp:%d streamtype=5; ", rtsp[cur_conn_num]->payload_type);
        strcat (sdp_buff, s);
        strcat (sdp_buff,
                "profile-level-id=1; mode=AAC-hbr; config=1408; sizeLength=13; indexLength=3; indexDeltaLength=3");
#endif
#ifdef AUDIO_PCM
		strcat(sdp_buff,"L16/8000");
#endif
		strcat(sdp_buff, SDP_EL);
		strcat(sdp_buff,"a=control:");
		sprintf(sdp_buff + strlen(sdp_buff),"rtsp://%s/%s/trackID=0",rtsp[0]->host_name,rtsp[0]->file_name);
		strcat(sdp_buff, SDP_EL);
	}
#ifndef AUDIO_ONLY
	strcat(sdp_buff,"m=");
	strcat(sdp_buff,"video 0");
	strcat(sdp_buff," RTP/AVP "); /* Use UDP */
	rtsp[cur_conn_num]->payload_type=VIDEO_PAYLOAD_TYPE;
	sprintf(sdp_buff + strlen(sdp_buff), "%d"SDP_EL, rtsp[cur_conn_num]->payload_type);
	strcat(sdp_buff, "c=IN IP4 0.0.0.0"SDP_EL);
	strcat(sdp_buff, "b=AS:500"SDP_EL);
	if (rtsp[cur_conn_num]->payload_type>=VIDEO_PAYLOAD_TYPE) {
		/**** Dynamically defined payload ****/
		strcat(sdp_buff,"a=rtpmap:");
		sprintf(sdp_buff + strlen(sdp_buff), "%d", rtsp[cur_conn_num]->payload_type);
		strcat(sdp_buff," ");
		strcat(sdp_buff,"H264/90000");
		strcat(sdp_buff, SDP_EL);
		sprintf (s, "a=fmtp:%d ", rtsp[cur_conn_num]->payload_type);
		strcat (sdp_buff, s);
#ifdef AUDIO_PCM
		strcat(sdp_buff,"packetization-mode=1;profile-level-id=420028;sprop-parameter-sets=Z0IAKOkBQHsg,aM44gA==");
#endif
#ifdef AUDIO_AAC
		strcat(sdp_buff,"packetization-mode=1;profile-level-id=4D400C");
#endif
		strcat(sdp_buff, SDP_EL);
		strcat(sdp_buff,"a=control:");
		sprintf(sdp_buff + strlen(sdp_buff),"rtsp://%s/%s/trackID=1",rtsp[cur_conn_num]->host_name,rtsp[cur_conn_num]->file_name);
		strcat(sdp_buff, SDP_EL);
	}
#endif
    strcat(sdp_buff, SDP_EL);
#ifdef SDP_DEBUG
    RTSP_DEBUG_PRINT("-----SDP----------------------\n");
    RTSP_DEBUG_PRINT("%s",sdp_buff);
    RTSP_DEBUG_PRINT("\n------------------------------\n");
#endif
    return RTSP_SUCCESS;

}

/***************************************************************
 *
 * @function    :   rtsp_describe
 * @param1      :   cur_conn_num -> current connection number
 * @ret         :   S32 -> on SUCCESS returns 0, otherwise -1
 * @brief       :   describe command processing functions.
 *
 ***************************************************************/

S32 rtsp_describe(S32 cur_conn_num)
{
    RTSP_DEBUG_PRINT ("\r\n*** DESCRIBE ***\n");

    if(!rtsp[cur_conn_num]->in_buffer)
    {
        return RTSP_FAILURE;
    }

    if(check_rtsp_url(cur_conn_num) < RTSP_SUCCESS)
    {
        return RTSP_FAILURE;
    }

    if(check_rtsp_filename(cur_conn_num) < RTSP_SUCCESS)
    {
        return RTSP_FAILURE;
    }

    // Disallow Header REQUIRE
    if (strstr(rtsp[cur_conn_num]->in_buffer, HDR_REQUIRE))
    {
        send_error_reply(OPTION_UNSUPPORTED,cur_conn_num);	/* Option not supported */
        return RTSP_FAILURE;
    }

    /* Get the description format. SDP is recomended */
    if (strstr(rtsp[cur_conn_num]->in_buffer, HDR_ACCEPT) != NULL)
    {
        if (strstr(rtsp[cur_conn_num]->in_buffer, "application/sdp") != NULL)
        {
            //descr_format = df_SDP_format;
        }
        else
        {
            // Add here new description formats
            send_error_reply(OPTION_UNSUPPORTED,cur_conn_num);	/* Option not supported */
            return RTSP_FAILURE;
        }
    }

    if(get_rtsp_CSeq(cur_conn_num) < RTSP_SUCCESS)
    {
        return RTSP_FAILURE;
    }

#ifdef RTSP_AUD_EN

    /* Add SDP with both Audio & Video media types */
    if (get_describe_sdp_audio_video(rtsp[cur_conn_num]->sdp_buffer,
                                     cur_conn_num) < RTSP_SUCCESS)
    {
        return RTSP_FAILURE;
    }

#else

    /* Add SDP with video media type */
    if(get_describe_sdp(rtsp[cur_conn_num]->sdp_buffer,
                        cur_conn_num) < RTSP_SUCCESS)
    {
        return RTSP_FAILURE;
    }

#endif

    if(send_describe_reply(RESPONSE_OK,cur_conn_num) != RTSP_FAILURE)
    {
        return 1;
    }

    return RTSP_SUCCESS;
}
