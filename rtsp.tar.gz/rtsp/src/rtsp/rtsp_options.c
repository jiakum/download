/******************************************************************************
*
*               COPYRIGHT (c) 2015-2016 GainSpan Corporation
*                         All Rights Reserved
*
* The source code contained or described herein and all documents
* related to the source code ("Material") are owned by GainSpan
* Corporation or its licensors.  Title to the Material remains
* with GainSpan Corporation or its suppliers and licensors.
*
* The Material is protected by worldwide copyright and trade secret
* laws and treaty provisions. No part of the Material may be used,
* copied, reproduced, modified, published, uploaded, posted, transmitted,
* distributed, or disclosed in any way except in accordance with the
* applicable license agreement.
*
* No license under any patent, copyright, trade secret or other
* intellectual property right is granted to or conferred upon you by
* disclosure or delivery of the Materials, either expressly, by
* implication, inducement, estoppel, except in accordance with the
* applicable license agreement.
*
* Unless otherwise agreed by GainSpan in writing, you may not remove or
* alter this notice or any other notice embedded in Materials by GainSpan
* or GainSpan's suppliers or licensors in any way.
*  @file        :  rtsp_options.c
*  @brief       :  This file contains functions for handling OPTIONS method.
********************************************************************************/

#include "rtsp/rtsp.h"
#include "comm/type.h"

/***************************************************************
 *
 * @function    :   rtsp_options
 * @param1      ;   status -> rtsp status code
 * @param2      :   cur_conn_num -> current connection number
 * @ret         :   S32, on SUCCESS returns 0, otherwise -1
 * @brief       :   set options command response buffer.
 *
 ***************************************************************/

S32 set_options_reply(S32 status,S32 cur_conn_num)
{
    CHAR temp[64]="";

    if(!rtsp[cur_conn_num]->out_buffer)
    {
        return RTSP_FAILURE;
    }

    get_stat (status, temp);
    sprintf(rtsp[cur_conn_num]->out_buffer, "%s %d %s"RTSP_EL"CSeq: %d"RTSP_EL,
            RTSP_VER, status, (CHAR *)temp, rtsp[cur_conn_num]->rtsp_cseq);
    strcat(rtsp[cur_conn_num]->out_buffer,
           "Public: OPTIONS,DESCRIBE,SETUP,PLAY,TEARDOWN"RTSP_EL);
    strcat(rtsp[cur_conn_num]->out_buffer, RTSP_EL);

    if(tcp_write(rtsp[cur_conn_num]->cli_rtsp.cli_fd,
                 rtsp[cur_conn_num]->out_buffer,
                 strlen(rtsp[cur_conn_num]->out_buffer)) != RTSP_SUCCESS)
    {
        return RTSP_FAILURE;
    }

    return RTSP_SUCCESS;
}

/***************************************************************
 *
 * @function    :   rtsp_options
 * @param1      :   cur_conn_num -> current connection number
 * @ret         :   S32, on SUCCESS returns 0, otherwise -1
 * @brief       :   processing the options request.
 *
 ***************************************************************/

S32 rtsp_options(S32 cur_conn_num)
{
    RTSP_DEBUG_PRINT ("\r\n*** OPTIONS ***\n");

    if(!rtsp[cur_conn_num]->in_buffer)
    {
        return RTSP_FAILURE;
    }

    if(get_rtsp_CSeq(cur_conn_num) != RTSP_FAILURE)
    {
        set_options_reply(RESPONSE_OK,cur_conn_num);
        return 1;
    }

    return RTSP_SUCCESS;
}
