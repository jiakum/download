/******************************************************************************
*
*               COPYRIGHT (c) 2015-2016 GainSpan Corporation
*                         All Rights Reserved
*
* The source code contained or described herein and all documents
* related to the source code ("Material") are owned by GainSpan
* Corporation or its licensors.  Title to the Material remains
* with GainSpan Corporation or its suppliers and licensors.
*
* The Material is protected by worldwide copyright and trade secret
* laws and treaty provisions. No part of the Material may be used,
* copied, reproduced, modified, published, uploaded, posted, transmitted,
* distributed, or disclosed in any way except in accordance with the
* applicable license agreement.
*
* No license under any patent, copyright, trade secret or other
* intellectual property right is granted to or conferred upon you by
* disclosure or delivery of the Materials, either expressly, by
* implication, inducement, estoppel, except in accordance with the
* applicable license agreement.
*
* Unless otherwise agreed by GainSpan in writing, you may not remove or
* alter this notice or any other notice embedded in Materials by GainSpan
* or GainSpan's suppliers or licensors in any way.
*	@file			:	rtsp_client.c
*	@brief			:	This file contains function definitions
*						related to simple client client
**************************************************************************************/
#ifdef STNDRD_RTSP_CLIENT
#include "rtsp/rtsp_client.h"
#include "rtsp/rtsp.h"
#ifndef STNDRD_RTSP_CLIENT
#define G711_DECODE
#endif
#ifdef G711_DECODE
#include "g711dec.h"
#endif
#include "api/api_safe.h"
rtsp_t client;

/**************************************************************************************
 *
 * @function		:	rtspc_init
 * @param1			:	None
 * @return type		:	int, on sucess 0, otherwise -1
 * @brief			:	allocating memory for client structure.
 *
 **************************************************************************************/

int rtspc_init()
{
    memset (&client, 0, sizeof(rtsp_t));
	client.Timeout_Flag = FALSE;

    return 0;
}

/**************************************************************************************
 *
 * @function		:	rtsp_close
 * @param			:	None
 * @return			:	int, on sucess 0, otherwise -1
 * @brief			:	closes client connection
 *
 **************************************************************************************/

void rtsp_close()
{
#ifdef STNDRD_RTSP_CLIENT
	int status;
	if( client.client_state == RTSP_PLAYING)
	{
		RTSP_CLIENT_DEBUG_INFO ("\r\nclosing connection...\n");
		status = send_teardown();
		if (status != RTSP_CLIENT_SUCCESS) {
			RTSP_CLIENT_DEBUG_FAIL ("\r\nsend_teardown failed:%d\n", status);
		}
	}
#endif
	RTSP_CLIENT_DEBUG_INFO ("\r\nclosing connection...\n");
	soc_close (client.a_fd);
	memset (&client, 0, sizeof(rtsp_t));
	client.Timeout_Flag = FALSE;
#ifndef DOOR_BELL
	ADEC_Status (AD_Stop);
#endif
#ifdef STNDRD_RTSP_CLIENT
	client.audio_enable = 0;
	client.video_enable = 0;
#endif
}

#ifdef STNDRD_RTSP_CLIENT

/**************************************************************************************
 *
 * @function		:	rtsp_send_request
 * @param			:	None
 * @return			:	int, on sucess 0, otherwise -1
 * @brief			:	sending request to server
 *
 **************************************************************************************/

int rtsp_send_request ()
{
    int status;
    int len;

    if (client.outbuff == NULL)
    {
        return RTSP_CLIENT_FAILURE;
    }

    len = strlen(client.outbuff);
    status = send(client.fd, client.outbuff, len, 0);

    if (status != len)
    {
        RTSP_CLIENT_DEBUG_FAIL("\r\nsend failed:%d\n",status);
    }

    RTSP_CLIENT_DEBUG_INFO ("\r\nsent %d Bytes.\n", status);

    return RTSP_CLIENT_SUCCESS;
}

/**************************************************************************************
 *
 * @function		:	get_server_status_code
 * @param			:	None
 * @return			:	int, on sucess 0, otherwise -1
 * @brief			:	extract server status code
 *
 **************************************************************************************/

int get_server_status_code()
{
    int code;
    char tmp[4];

    if (!strncmp (client.inbuff, RTSP_Version, sizeof(RTSP_Version) -1))
    {
        memcpy (tmp, client.inbuff + sizeof(RTSP_Version), 3);
        tmp[3] = 0;
        code = atoi(tmp);
    }

    if (code != 200)
    {
        RTSP_CLIENT_DEBUG_INFO("\r\nInvalid status code:%d\n", code);
    }

    return code;
}

/**************************************************************************************
 *
 * @function		:	rtsp_recv
 * @param			:	None
 * @return			:	int, on sucess 0, otherwise -1
 * @brief			:	receiving response from server
 *
 **************************************************************************************/

int rtsp_recv ()
{
    int status;
    int len;

    memset (client.inbuff, 0, BUF_SIZE);
    len = BUF_SIZE;
    status = recv(client.fd, client.inbuff, len, MSG_DONTWAIT);

    if (status <= 0)
    {
        RTSP_CLIENT_DEBUG_FAIL("\r\nrecv failed:%d\n",status);
        return status;
    }

    RTSP_CLIENT_DEBUG_INFO ("\r\nreceived %d Bytes.\n", status);

    return RTSP_CLIENT_SUCCESS;
}

/**************************************************************************************
 *
 * @function		:	get_sdp_details
 * @param			:	None
 * @return			:	int, on sucess 0, otherwise -1
 * @brief			:	extract audio and video details from sdp
 *
 **************************************************************************************/

int get_sdp_details()
{
    char *ptr = NULL, *tmp = NULL;
    char *buf = client.inbuff;

#ifndef DOOR_BELL
    ptr = strstr(buf, "m=video");

    if (ptr != NULL)
    {
        ptr += strlen("m=video 0 ");
        tmp = strtok(ptr, " ");
        strcpy (client.transport, tmp);
        RTSP_CLIENT_DEBUG_INFO ("\r\nrequested:%s\n", client.transport);
        ptr += 10;
        ptr = strstr (ptr, "a=control:");

        if (ptr != NULL)
        {
            ptr += strlen ("a=control:");
            tmp = strtok(ptr, "\n");
            strcpy (client.vtrackid, tmp);
            client.atrackid[strlen(tmp)-1] = '\0';
            RTSP_CLIENT_DEBUG_INFO ("\r\nrequested:%s\n", client.vtrackid);
        }

        client.video_enable = 1;
    }

#endif
    ptr = strstr(buf, "m=audio");

    if (ptr != NULL)
    {
        ptr += strlen("m=audio 0 ");
        tmp = strtok(ptr, " ");
        strncpy (client.transport, tmp, strlen(tmp));
        RTSP_CLIENT_DEBUG_INFO ("\r\nrequested:%s\n", client.transport);
        ptr += 10;
        ptr = strstr (ptr, "a=control:");

        if (ptr != NULL)
        {
            ptr += strlen("a=control:");
            tmp = strtok(ptr, " ");
            strcpy (client.atrackid, tmp);
            client.atrackid[strlen(tmp)-2] = '\0';
			RTSP_CLIENT_DEBUG_INFO ("\r\nrequested:%s\n", client.atrackid);
        }

        client.audio_enable = 1;
    } else {
		RTSP_CLIENT_DEBUG_INFO ("\r\nAudio track not available\n");
		return RTSP_CLIENT_FAILURE;
	}

    return RTSP_CLIENT_SUCCESS;
}

/**************************************************************************************
 *
 * @function		:	get_session_id
 * @param			:	None
 * @return			:	int, on sucess 0, otherwise -1
 * @brief			:	extract session id
 *
 **************************************************************************************/

int get_session_id()
{
    char *tmp = NULL, *ptr = NULL;

    ptr = strstr(client.inbuff, "Session: ");

    if (ptr != NULL)
    {
        ptr += strlen("Session: ");
        ptr = strtok(ptr, "\n");
        tmp = strtok(ptr, ";");
        strcpy (client.session, tmp);
        RTSP_CLIENT_DEBUG_INFO ("\r\nsession: %s\n", client.session);
    }
    else
    {
        RTSP_CLIENT_DEBUG_FAIL ("\r\nsession id not found.\n");
        return RTSP_CLIENT_FAILURE;
    }

    return RTSP_CLIENT_SUCCESS;
}

/**************************************************************************************
 *
 * @function		:	rtsp_get_response
 * @param			:	None
 * @return			:	int, on sucess 0, otherwise -1
 * @brief			:	gets client response
 *
 **************************************************************************************/

int rtsp_get_response()
{
    int status;

    status = rtsp_recv();

    if (status != RTSP_CLIENT_SUCCESS)
    {
        RTSP_CLIENT_DEBUG_FAIL("\r\nrtsp_recv failed:%d\n", status);
    }
    else
    {
        status = get_server_status_code();

        if (status != 200)
        {
            RTSP_CLIENT_DEBUG_FAIL ("\r\nserver status failed:%d\n", status);
        }
        else
        {
            RTSP_CLIENT_DEBUG_INFO ("\r\nserver status:%d OK\n", status);
            status = RTSP_CLIENT_SUCCESS;
        }

        client.cseq++;
    }

    return status;
}

/**************************************************************************************
 *
 * @function		:	rtsp_request_options
 * @param			:	None
 * @return			:	int, on sucess 0, otherwise -1
 * @brief			:	framing options request
 *
 **************************************************************************************/

int rtsp_request_options ()
{
#ifdef DOOR_BELL
    client.cseq = 1;
    memset (client.outbuff, 0, BUF_SIZE);

	sprintf(client.outbuff,"OPTIONS %s %s\r\nCSeq: %d\r\nUser-Agent: LibVLC/2.0.8 (LIVE555 Streaming Media v2011.12.23)\r\n\r\n", server_url, RTSP_Version, client.cseq);
#else
    char tmp[128];

	sprintf (client.outbuff, "OPTIONS %s %s", Server_URL, RTSP_Version);
	strcat (client.outbuff, RTSP_EL);
	client.cseq = 1;
	sprintf (tmp, "Cseq: %d", client.cseq);
	strcat (client.outbuff, tmp);
    strcat (client.outbuff, RTSP_EL);
    strcat (client.outbuff,
			"User-Agent: LibVLC/2.1.6 (LIVE555 Streaming Media v2014.01.13)");
    strcat (client.outbuff, RTSP_EL);
    strcat (client.outbuff, RTSP_EL);
#endif

    return RTSP_CLIENT_SUCCESS;
}

/**************************************************************************************
 *
 * @function		:	rtsp_request_describe
 * @param			:	None
 * @return			:	int, on sucess 0, otherwise -1
 * @brief			:	framing describe request
 *
 **************************************************************************************/

int rtsp_request_describe ()
{
#ifdef DOOR_BELL
	memset (client.outbuff, 0, BUF_SIZE);
	sprintf(client.outbuff,"DESCRIBE %s %s\r\nCSeq: %d\r\nUser-Agent: LibVLC/2.0.8 (LIVE555 Streaming Media v2011.12.23)\r\nAccept: application/sdp\r\n\r\n", server_url, RTSP_Version, client.cseq);
#else
    char tmp[128];

    sprintf (client.outbuff, "DESCRIBE %s %s", Server_URL, RTSP_Version);
    strcat (client.outbuff, RTSP_EL);
    sprintf (tmp, "Cseq: %d", client.cseq);
    strcat (client.outbuff, tmp);
    strcat (client.outbuff, RTSP_EL);
    strcat (client.outbuff,
            "User-Agent: LibVLC/2.1.6 (LIVE555 Streaming Media v2014.01.13)");
    strcat (client.outbuff, RTSP_EL);
    strcat (client.outbuff, "Accept: application/sdp");
    strcat (client.outbuff, RTSP_EL);
    strcat (client.outbuff, RTSP_EL);
#endif

    return RTSP_CLIENT_SUCCESS;
}

/**************************************************************************************
 *
 * @function		:	rtsp_request_setup
 * @param			:	None
 * @return			:	int, on sucess 0, otherwise -1
 * @brief			:	framing setup response
 *
 **************************************************************************************/

int rtsp_request_setup ()
{
#ifdef DOOR_BELL
	memset (client.outbuff, 0, BUF_SIZE);
	sprintf(client.outbuff,"SETUP %s/%s %s\r\nCSeq: %d\r\nUser-Agent: LibVLC/2.0.8 (LIVE555 Streaming Media v2011.12.23)\r\nTransport: %s;unicast;client_port=%s-%s\r\n\r\n", server_url, client.atrackid, RTSP_Version, client.cseq, client.transport, AUD_PORT_RTP, AUD_PORT_RTCP);
#else
    char tmp[128];

    sprintf (client.outbuff, "SETUP %s/%s %s", Server_URL, client.atrackid,
             RTSP_Version);
    strcat (client.outbuff, RTSP_EL);
    sprintf (tmp, "Cseq: %d", client.cseq);
    strcat (client.outbuff, tmp);
    strcat (client.outbuff, RTSP_EL);
    strcat (client.outbuff,
            "User-Agent: LibVLC/2.1.6 (LIVE555 Streaming Media v2014.01.13)");
    strcat (client.outbuff, RTSP_EL);
    sprintf (tmp, "Transport: %s;unicast;client_port=%s-%s",client.transport,
             AUD_PORT_RTP, AUD_PORT_RTCP);
    strcat (client.outbuff, tmp);
    strcat (client.outbuff, RTSP_EL);
    strcat (client.outbuff, RTSP_EL);
#endif

    return RTSP_CLIENT_SUCCESS;
}

/**************************************************************************************
 *
 * @function		:	rtsp_request_play
 * @param			:	None
 * @return			:	int, on sucess 0, otherwise -1
 * @brief			:	framing play request
 *
 **************************************************************************************/

int rtsp_request_play ()
{
#ifdef DOOR_BELL
	memset (client.outbuff, 0, BUF_SIZE);
	sprintf(client.outbuff, "PLAY %s %s\r\nCSeq: %d\r\nUser-Agent: LibVLC/2.0.8 (LIVE555 Streaming Media v2011.12.23)\r\nSession: %s\r\nRange: npt=0.000-\r\n\r\n", server_url, RTSP_Version, client.cseq, client.session);
#else
    char tmp[128];

    sprintf (client.outbuff, "PLAY %s %s", Server_URL, RTSP_Version);
    strcat (client.outbuff, RTSP_EL);
    sprintf (tmp, "Cseq: %d", client.cseq);
    strcat (client.outbuff, tmp);
    strcat (client.outbuff, RTSP_EL);
    strcat (client.outbuff,
            "User-Agent: LibVLC/2.1.6 (LIVE555 Streaming Media v2014.01.13)");
    strcat (client.outbuff, RTSP_EL);
    sprintf (tmp, "Session: %s", client.session);
    strcat (client.outbuff, tmp);
    strcat (client.outbuff, RTSP_EL);
    strcat (client.outbuff, "Range: npt=0.000-");
    strcat (client.outbuff, RTSP_EL);
    strcat (client.outbuff, RTSP_EL);
#endif

    return RTSP_CLIENT_SUCCESS;
}

/**************************************************************************************
 *
 * @function		:	rtsp_request_teardown
 * @param			:	None
 * @return			:	int, on sucess 0, otherwise -1
 * @brief			:	framing teardown request
 *
 **************************************************************************************/

int rtsp_request_teardown ()
{
#ifdef DOOR_BELL
	memset (client.outbuff, 0, BUF_SIZE);
	sprintf(client.outbuff, "TEARDOWN %s %s\r\nCSeq: %d\r\nUser-Agent: LibVLC/2.0.8 (LIVE555 Streaming Media v2011.12.23)\r\nSession: %s\r\n\r\n", server_url, RTSP_Version, client.cseq, client.session);
#else
    char tmp[128];

    sprintf (client.outbuff, "TEARDOWN %s %s", Server_URL, RTSP_Version);
    strcat (client.outbuff, RTSP_EL);
    sprintf (tmp, "Cseq: %d", client.cseq);
    strcat (client.outbuff, tmp);
    strcat (client.outbuff, RTSP_EL);
    strcat (client.outbuff,
            "User-Agent: LibVLC/2.1.6 (LIVE555 Streaming Media v2014.01.13)");
    strcat (client.outbuff, RTSP_EL);
    sprintf (tmp, "Session: %s", client.session);
    strcat (client.outbuff, tmp);
    strcat (client.outbuff, RTSP_EL);
    strcat (client.outbuff, RTSP_EL);
#endif

    return RTSP_CLIENT_SUCCESS;
}

/**************************************************************************************
 *
 * @function		:	rtsp_connect
 * @param			:	None
 * @return			:	int, on sucess 0, otherwise -1
 * @brief			:	connects client to a server
 *
 **************************************************************************************/

int rtsp_connect(const char *url, unsigned int port)
{
    struct sockaddr_in srv_addr;
    char temp_url[32];
    int status;

    client.fd = socket(AF_INET, SOCK_STREAM, 0);

    if (client.fd < 0)
    {
        RTSP_CLIENT_DEBUG_FAIL ("\r\nsocket failed:%d\n", client.fd);
        return -1;
    }

#ifndef DOOR_BELL
    if(port < 2000 || port == 554)
    {
        port = RTSP_CLIENT_PORT;
    }
#endif

	RTSP_CLIENT_DEBUG_INFO ("\r\nsock-fd:%d\tport:%d\n", client.fd, port);
    client.port=port;
    strcpy(temp_url, url);
#ifndef DOOR_BELL
    client.host = strtok(&temp_url[7], " /\t\n");
#else
    client.host = strtok(&temp_url[7], " :\t\n");
#endif
    client.path = strtok(NULL, " ");
    RTSP_CLIENT_DEBUG_INFO ("\r\nConnecting to host:%s: port :%d: filename:%s\n", client.host, port, client.path);
    memset(&srv_addr, 0, sizeof(srv_addr));
    srv_addr.sin_family = AF_INET;
    srv_addr.sin_port = htons(port);
    srv_addr.sin_addr.s_addr = inet_addr(client.host);

    status  = connect(client.fd,(struct sockaddr *)&srv_addr,sizeof(srv_addr));

    if (status != RTSP_CLIENT_SUCCESS)
    {
        RTSP_CLIENT_DEBUG_FAIL("\r\nconnect failed:%d\n", status);
		soc_close(client.fd);
		return status;
    }
    else
    {
        RTSP_CLIENT_DEBUG_INFO ("\r\nconnected to server.\n");
        client.client_state = RTSP_CONNECTED;
    }

    return status;
}



/**************************************************************************************
 *
 * @function		:	send_options
 * @param			:	None
 * @return			:	int, on sucess 0, otherwise -1
 * @brief			:	sending options request
 *
 **************************************************************************************/

int send_options()
{
    int status;

    status = rtsp_request_options ();

    if (status != RTSP_CLIENT_SUCCESS)
    {
        RTSP_CLIENT_DEBUG_FAIL ("\r\nrtsp_request_options failed:%d\n", status);
    }
    else
    {
        RTSP_CLIENT_DEBUG_INFO ("\r\nOPTIONS \n");
        status = rtsp_send_request ();

        if (status != RTSP_CLIENT_SUCCESS)
        {
            RTSP_CLIENT_DEBUG_FAIL ("\r\nrtsp_send_request options failed:%d\n", status);
            return status;
        }
        else
        {
            RTSP_CLIENT_DEBUG_INFO ("\r\nDone!.\n");
        }
    }

    return status;
}

/**************************************************************************************
 *
 * @function		:	send_describe
 * @param			:	None
 * @return			:	int, on sucess 0, otherwise -1
 * @brief			:	sending describe request
 *
 **************************************************************************************/

int send_describe()
{
    int status;

    status = rtsp_request_describe();

    if (status != RTSP_CLIENT_SUCCESS)
    {
        RTSP_CLIENT_DEBUG_FAIL ("\r\nrtsp_request_decribe failed:%d\n", status);
    }
    else
    {
        RTSP_CLIENT_DEBUG_INFO ("\r\nDESCRIBSE \n");
        status = rtsp_send_request();

        if (status != RTSP_CLIENT_SUCCESS)
        {
            RTSP_CLIENT_DEBUG_FAIL ("\r\nrtsp_send_request describe failed:%d\n", status);
            return status;
        }
        else
        {
            RTSP_CLIENT_DEBUG_INFO ("\r\nDone!.\n");
        }
    }

    return status;
}

/**************************************************************************************
 *
 * @function		:	send_setup
 * @param			:	None
 * @return			:	int, on sucess 0, otherwise -1
 * @brief			:	sending setup request
 *
 **************************************************************************************/

int send_setup()
{
    int status;

    status = rtsp_request_setup();

    if (status != RTSP_CLIENT_SUCCESS)
    {
        RTSP_CLIENT_DEBUG_FAIL ("\r\nrtsp_request_setup failed:%d\n", status);
    }
    else
    {
        RTSP_CLIENT_DEBUG_INFO ("\r\nSETUP \n");
        status = rtsp_send_request();

        if (status != RTSP_CLIENT_SUCCESS)
        {
            RTSP_CLIENT_DEBUG_FAIL ("\r\nrtsp_send_request setup failed:%d\n", status);
            return status;
        }
        else
        {
            RTSP_CLIENT_DEBUG_INFO ("\r\nDone!.\n");
        }
    }

    return status;
}

/**************************************************************************************
 *
 * @function		:	send_play
 * @param			:	None
 * @return			:	int, on sucess 0, otherwise -1
 * @brief			:	sending play request
 *
 **************************************************************************************/

int send_play()
{
    int status;

    status = rtsp_request_play();

    if (status != RTSP_CLIENT_SUCCESS)
    {
        RTSP_CLIENT_DEBUG_FAIL ("\r\nrtsp_request_play failed:%d\n", status);
    }
    else
    {
        RTSP_CLIENT_DEBUG_INFO ("\r\nPLAY \n");
        status = rtsp_send_request();

        if (status != RTSP_CLIENT_SUCCESS)
        {
            RTSP_CLIENT_DEBUG_FAIL ("\r\nrtsp_send_request play failed:%d\n", status);
            return status;
        }
        else
        {
            RTSP_CLIENT_DEBUG_INFO ("\r\nDone!.\n");
        }

        status = rtsp_get_response();

        if (status != RTSP_CLIENT_SUCCESS)
        {
            RTSP_CLIENT_DEBUG_FAIL ("\r\nplay response get failed:%d\n", status);
            return status;
        }
        else
        {
            client.client_state = RTSP_PLAYING;
        }
    }

    return status;
}

/**************************************************************************************
 *
 * @function		:	send_teardown
 * @param			:	None
 * @return			:	int, on sucess 0, otherwise -1
 * @brief			:	sending teardown request
 *
 **************************************************************************************/

int send_teardown ()
{
    int status;

    status = rtsp_request_teardown();

    if (status != RTSP_CLIENT_SUCCESS)
    {
        RTSP_CLIENT_DEBUG_FAIL ("\r\nrtsp_request_teardown failed:%d\n", status);
    }
    else
    {
        RTSP_CLIENT_DEBUG_INFO ("\r\nTEARDOWN \n");
        status = rtsp_send_request();

        if (status != RTSP_CLIENT_SUCCESS)
        {
            RTSP_CLIENT_DEBUG_FAIL ("\r\nrtsp_send_request tearrdown failed:%d\n", status);
            return status;
        }
        else
        {
            RTSP_CLIENT_DEBUG_INFO ("\r\nDone!.\n");
        }

        status = rtsp_get_response();

        if (status != RTSP_CLIENT_SUCCESS)
        {
            RTSP_CLIENT_DEBUG_FAIL ("\r\nteardown response get failed:%d\n", status);
            return status;
        }
        else
        {
            client.client_state = RTSP_DISCONNECTED;
        }
    }

    return status;
}
#endif
/**************************************************************************************
 *
 * @function		:	serv_socket
 * @param			:	None
 * @return			:	int, on sucess 0, otherwise -1
 * @brief			:	creates socket and listening on aud port
 *
 **************************************************************************************/

int serv_socket (char *host, char *port)
{
	int status;
	int data_len, a_len;
#ifndef DOOR_BELL
	static int len;
	static struct sockaddr_in cliaddr, srvaddr;
#else
	static struct sockaddr_in cliaddr;
#endif
	unsigned char *ptr=NULL;
	int optval = 1;
#ifdef STNDRD_RTSP_CLIENT
	unsigned short int *sample_temp=NULL;
	int nth_sample;
#endif
#ifdef RTSP_CLIENT_TIMEOUT
	struct timeval tv;
#endif
#ifdef G711_DECODE
	UINT32 dataRcvd = 0;
	INT32 packetLen = BUF_SIZE/4;
#else
	INT32 packetLen = BUF_SIZE;
#endif

	if (!host)
	{
		return RTSP_CLIENT_FAILURE;
	}
	if (client.Timeout_Flag == FALSE) 
	{
		RTSP_CLIENT_DEBUG_INFO ("\r\nserv_socket: host:%s,port:%s\n", host, port);
		client.a_fd = socket(AF_INET, SOCK_DGRAM, 0);
		if (client.a_fd < RTSP_CLIENT_SUCCESS) 
		{
			RTSP_CLIENT_DEBUG_FAIL ("\r\nsocket failed @ serv_socket:%d, %d\n", client.a_fd, errno);
			return client.a_fd;
		} 
		else 
		{
			RTSP_CLIENT_DEBUG_INFO ("\r\nsocket success.fd:%d\n", client.a_fd);
		}
		memset (&cliaddr, 0, sizeof (struct sockaddr_in));
		cliaddr.sin_family = AF_INET;
		cliaddr.sin_addr.s_addr = inet_addr(host);
		cliaddr.sin_port = htons (atoi(port));
		status = bind(client.a_fd, (struct sockaddr *)&cliaddr, sizeof (struct sockaddr_in));
		if (status < RTSP_CLIENT_SUCCESS) 
		{
			RTSP_CLIENT_DEBUG_FAIL ("\r\nbind ERROR @ serv_socket:%d\n", status);
			soc_close(client.a_fd);
			return status;
		} 
#ifndef DOOR_BELL
		else 
		{
			RTSP_CLIENT_DEBUG_INFO ("\r\nbind success.\n");
			len = sizeof (srvaddr);
		}
#endif
		setsockopt (client.a_fd, SOL_SOCKET, SO_REUSEADDR, &optval, sizeof(int));
		UINT32 rcv_buff_len = packetLen;
		setsockopt(client.a_fd,SOL_SOCKET,SO_RCVBUF,&rcv_buff_len, sizeof(rcv_buff_len));
#ifdef RTSP_CLIENT_TIMEOUT
		tv.tv_sec = TIMEOUT_VAL_SEC;		/* 1 Sec Timeout */
		tv.tv_usec = TIMEOUT_VAL_USEC;		/* Not init'ing this can cause strange errors */

		status = setsockopt(client.a_fd, SOL_SOCKET, SO_RCVTIMEO, (char *)&tv,sizeof(struct timeval));
		if (status != RTSP_CLIENT_SUCCESS) 
		{
			RTSP_CLIENT_DEBUG_FAIL ("\r\nsockopt failed.\n");
			soc_close(client.a_fd);
			return status;
		}
#endif
		/* starting the audio decoder */
#ifndef DOOR_BELL
		status = ADEC_SetSamplerate (3);
		if (status < RTSP_CLIENT_SUCCESS)
		{
			RTSP_CLIENT_DEBUG_FAIL ("\r\nADEC_SetSamplerate failed:%d\n", status);
			return status;
		}
		status = ADEC_Status (AD_Start);
		if (status < RTSP_CLIENT_SUCCESS) 
		{
			RTSP_CLIENT_DEBUG_FAIL ("\r\nADEC_Status failed:%d\n", status);
			return status;
		}
		
#else
		status = Talk_Back(TLK_START);
		if (status != AVLB_SUCCESS) {
			return status;
		}
#endif
	}
	/* Processing data receiving from server */
	while (1)
	{
		if (rtsp[0]->is_runing != STREAM_RUNNING)
			break;
		memset (client.inbuff, 0, BUF_SIZE);
#ifdef G711_DECODE
		dataRcvd = 0;
#endif
		if (client.a_fd <= 0) 
		{
			status = RTSP_DISCONNECTED;
			break;
		}
#ifndef DOOR_BELL
		data_len = recvfrom (client.a_fd, client.inbuff, packetLen, 0, (struct sockaddr *)&srvaddr, &len);
#else
		data_len = recv(client.a_fd, client.inbuff, packetLen, MSG_WAITALL);
#endif
		if (data_len <= 0)
		{
#ifndef DOOR_BELL
			if (client.Timeout_Flag == FALSE)
			{
				ADEC_Status (AD_Stop);
			}
#endif
			client.Timeout_Flag = TRUE;
			status = RTSP_TIMEOUT;
			break;
		}
#ifndef DOOR_BELL
		if (client.Timeout_Flag == TRUE)
		{
			ADEC_Status (AD_Start);
			client.Timeout_Flag = FALSE;
		}
#endif
#ifdef STNDRD_RTSP_CLIENT
		a_len = data_len - RTP_HEADER_SIZE;
#else
		if (data_len > BUF_SIZE) 
		{
			AppDbg_Printf ("\rIt shouldn't print.;(\n");
			a_len = BUF_SIZE;
		} 
		else 
		{
			a_len = data_len;
		}
#endif /* __STNDRD_RTSP_CLIENT__ */
#ifdef G711_DECODE
		UINT8 *g711DecodePtr = (UINT8 *)MALLOC(BUF_SIZE/2);
		if (NULL == g711DecodePtr) 
		{
			break;
		}
#endif

#ifdef G711_DECODE
		Gsn_g711decode((INT8 *)&client.inbuff[0], (INT16 *)(&(g711DecodePtr[dataRcvd])), G711_ALAW, a_len);
		dataRcvd = (a_len*2);
		ptr = g711DecodePtr;
		a_len = dataRcvd;
#else
		ptr = (unsigned char *)&client.inbuff[RTP_HEADER_SIZE];
#endif /* __G711_DECODE__ */

		while (a_len)
		{
			data_len = a_len;
#ifndef DOORBELL
#ifdef STNDRD_RTSP_CLIENT
			/* we are getting each sample in data as big endian order, as each sample is represented by 16 bits */
			/* so we are reverting data in to little endian order */
			sample_temp = (unsigned short int *)ptr;
			for (nth_sample = 0; nth_sample < (data_len/2); nth_sample++)
			{
				sample_temp[nth_sample] = ((sample_temp[nth_sample]&HIGH_BYTE) >> 8) | ((sample_temp[nth_sample]&LOW_BYTE) << 8);
			}
#endif
#endif
#ifdef OV788_GS2000
			/* sending audio data to Nuvoton */
			status = Send_AStream (ptr, data_len);
			if (status < RTSP_CLIENT_SUCCESS) 
			{
				RTSP_CLIENT_DEBUG_FAIL ("\r\nsend_astream failed:%d\n", status);
			}
#endif
			a_len -= data_len;
			if (a_len <= 0) 
			{
				break;
			}
			ptr += data_len;
		}
#ifdef G711_DECODE
		gsn_free(g711DecodePtr);
#endif
	}
#if 0
	status = Talk_Back(TLK_STOP);
	if (status != AVLB_SUCCESS) {
		return status;
	}
#endif
	return status;
}

/**************************************************************************************
 *
 * @function		:	Handl_Get_Data
 * @param			:	None
 * @return			:	int, on sucess 0, otherwise -1
 * @brief			:	handling the data received from the server
 *
 **************************************************************************************/

int Handl_Get_Data()
{
#ifdef DOOR_BELL
	if (rtsp[0]->is_runing == STREAM_RUNNING) {
		serv_socket("0.0.0.0", AUD_PORT_RTP);
		RTSP_CLIENT_DEBUG_INFO("\r\nserv_socket status\r\n");
	}
	return RTSP_CLIENT_SUCCESS;
#else
	int status;

	while (1) 
	{
		if (rtsp[0]->is_runing == STREAM_RUNNING) 
		{
			status = serv_socket("0.0.0.0", AUD_PORT_RTP);
#ifdef AUDIO_AAC
			if (status != RTSP_CLIENT_SUCCESS) 
			{
				RTSP_CLIENT_DEBUG_FAIL ("\r\nserv_socket failed:%d\n", status);
				return status;
			} 
			else 
			{
				RTSP_CLIENT_DEBUG_INFO ("\r\nrtp connection done!.\n");
                                return status;
			}
#endif
#ifdef AUDIO_PCM
			if (status < RTSP_CLIENT_SUCCESS) 
			{
				RTSP_CLIENT_DEBUG_FAIL ("\r\nserv_socket failed:%d\n", status);
				break;
			}
#endif
		} 
		else 
		{
			GsnTaskSleep(1);
		}
	}
#ifdef AUDIO_PCM
        return status;
#endif
#endif
}

/**************************************************************************************
 *
 * @function		:	client_main
 * @param			:	None
 * @return			:	int, on sucess 0, otherwise -1
 * @brief			:	Do handshaking with server and gives control to handle data.
 *
 **************************************************************************************/

int client_main()
{
	int status;

	status = rtspc_init();
	if (status != 0) 
	{
		RTSP_CLIENT_DEBUG_FAIL ("\r\nrtspc_init failed:%d\n", status);
		return status;
	} 
	else 
	{
		RTSP_CLIENT_DEBUG_INFO ("\r\nrtspc_init success.\n");
	}

#ifdef STNDRD_RTSP_CLIENT
	if (rtsp[0]->is_runing == STREAM_RUNNING) {
		RTSP_CLIENT_DEBUG_INFO("\r\nStream Running\r\n");
		memset(server_url, 0, SERVER_URL_LEN);
		{
			GsnTaskSleep(5000); /* Remove when cloud talkback is done */
			return RTSP_CLIENT_FAILURE;
		}
		if (status != RTSP_CLIENT_SUCCESS) 
		{
			RTSP_CLIENT_DEBUG_FAIL ("\r\nrtsp_connect failed:%d\n", status);
			return status;

		} 
		else 
		{
			RTSP_CLIENT_DEBUG_INFO ("\r\nconnected to server.\n");
		}
#endif
		status = send_options();
		if (status != RTSP_CLIENT_SUCCESS) 
		{
			RTSP_CLIENT_DEBUG_FAIL ("\r\nsend options failed:%d\n", status);
			return status;
		} 
		else 
		{
			status = rtsp_get_response();
			if (status != RTSP_CLIENT_SUCCESS) 
			{
				RTSP_CLIENT_DEBUG_FAIL ("\r\noptions response failed:%d\n", status);
				return status;
			}
		}

		status = send_describe();
		if (status != RTSP_CLIENT_SUCCESS) 
		{
			RTSP_CLIENT_DEBUG_FAIL ("\r\nsend describe failed:%d\n", status);
			return status;
		} 
		else 
		{
			status = rtsp_get_response();
			if (status != RTSP_CLIENT_SUCCESS) 
			{
				RTSP_CLIENT_DEBUG_FAIL ("\r\ndescribe response get failed:%d\n", status);
				return status;
			}
			status = get_sdp_details();
			if (status != RTSP_CLIENT_SUCCESS) 
			{
				RTSP_CLIENT_DEBUG_FAIL ("\r\nget_sdp_details failed:%d\n", status);
				return status;
			}
		}

#ifndef DOOR_BELL
		if (client.video_enable == 1) 
		{
			status = send_setup(0);
			if (status != RTSP_CLIENT_SUCCESS) 
			{
				RTSP_CLIENT_DEBUG_FAIL ("\r\nsend video setup failed:%d\n", status);
				return status;
			}
			else
			{
				status = rtsp_get_response();
				if (status != RTSP_CLIENT_SUCCESS) 
				{
					RTSP_CLIENT_DEBUG_FAIL ("\r\nsetup response get failed:%d\n", status);
					return status;
				}
			}
		}
#endif
		if (client.audio_enable == 1) 
		{
			status = send_setup();
			if (status != RTSP_CLIENT_SUCCESS) 
			{
				RTSP_CLIENT_DEBUG_FAIL ("\r\nsend audio setup failed:%d\n", status);
				return status;
			}
			else
			{
				status = rtsp_get_response();
				if (status != RTSP_CLIENT_SUCCESS) 
				{
					RTSP_CLIENT_DEBUG_FAIL ("\r\nsetup response get failed:%d\n", status);
					return status;
				}
				status = get_session_id();
				if (status != RTSP_CLIENT_SUCCESS) 
				{
					RTSP_CLIENT_DEBUG_FAIL ("\r\nget_session_id failed:%d\n", status);
					return status;
				}
			}
		}

		status = send_play();
		if (status != RTSP_CLIENT_SUCCESS) 
		{
			RTSP_CLIENT_DEBUG_FAIL ("\r\nsend play failed:%d\n", status);
			return status;
		}
		/* handle the data received from server */
		status = Handl_Get_Data();
		if (status != RTSP_CLIENT_SUCCESS) 
		{
			RTSP_CLIENT_DEBUG_FAIL ("\r\nHandl_Get_Data failed:%d\n", status);
			return status;
		}
	} else
		return RTSP_CLIENT_FAILURE;
	return status;
}
#endif
