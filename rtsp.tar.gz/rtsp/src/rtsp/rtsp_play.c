/******************************************************************************
*
*               COPYRIGHT (c) 2015-2016 GainSpan Corporation
*                         All Rights Reserved
*
* The source code contained or described herein and all documents
* related to the source code ("Material") are owned by GainSpan
* Corporation or its licensors.  Title to the Material remains
* with GainSpan Corporation or its suppliers and licensors.
*
* The Material is protected by worldwide copyright and trade secret
* laws and treaty provisions. No part of the Material may be used,
* copied, reproduced, modified, published, uploaded, posted, transmitted,
* distributed, or disclosed in any way except in accordance with the
* applicable license agreement.
*
* No license under any patent, copyright, trade secret or other
* intellectual property right is granted to or conferred upon you by
* disclosure or delivery of the Materials, either expressly, by
* implication, inducement, estoppel, except in accordance with the
* applicable license agreement.
*
* Unless otherwise agreed by GainSpan in writing, you may not remove or
* alter this notice or any other notice embedded in Materials by GainSpan
* or GainSpan's suppliers or licensors in any way.
*  @file        :  rtsp_play.c
*  @brief       :  This file contains functions for handling play method.
********************************************************************************/

#include "rtsp/rtsp.h"
#include "comm/type.h"

/***************************************************************
 *
 * @function    :   send_play_reply
 * @param1      :   status -> rtsp status
 * @param2      :   cur_conn_num -> current connection number
 * @ret         :   S32 -> on SUCCESS retruns 0, otherwise -1
 * @brief       :   set play command response buffer.
 *
 ***************************************************************/
ULONG64 playrcvtime;
S32 send_play_reply(S32 status,S32 cur_conn_num)
{
    CHAR temp[255];

    memset(temp, 0, sizeof(temp));

    if(!rtsp[cur_conn_num]->out_buffer)
    {
        return RTSP_FAILURE;
    }

    get_stat (status, temp);

    /* build a reply message */
    sprintf(rtsp[cur_conn_num]->out_buffer,
            "%s %d %s"RTSP_EL"CSeq: %d"RTSP_EL"Server: %s/%s"RTSP_EL, RTSP_VER, status,
            (CHAR *)temp, rtsp[cur_conn_num]->rtsp_cseq, PACKAGE,
            VERSION);
    strcat(rtsp[cur_conn_num]->out_buffer, "RTP-Info: ");
    sprintf(temp, "url=rtsp://%s/%s;seq=1;rtptime=%d",
            rtsp[cur_conn_num]->host_name, rtsp[cur_conn_num]->file_name,
            rtsp[cur_conn_num]->cmd_port.timestamp);
    strcat(rtsp[cur_conn_num]->out_buffer, temp);
    strcat(rtsp[cur_conn_num]->out_buffer, RTSP_EL);
    strcat(rtsp[cur_conn_num]->out_buffer, "Content-Length: ");
    sprintf(temp, "%d", 0);
    strcat(rtsp[cur_conn_num]->out_buffer, temp);
    strcat(rtsp[cur_conn_num]->out_buffer, RTSP_EL);
    strcat(rtsp[cur_conn_num]->out_buffer, "Cache-Control: no-cache");
    strcat(rtsp[cur_conn_num]->out_buffer, RTSP_EL);
    strcat(rtsp[cur_conn_num]->out_buffer, "Session: ");
    sprintf(temp, "%d", rtsp[cur_conn_num]->session_id);
    strcat(rtsp[cur_conn_num]->out_buffer, temp);
    strcat(rtsp[cur_conn_num]->out_buffer, RTSP_EL);
    strcat(rtsp[cur_conn_num]->out_buffer, RTSP_EL);

    if(tcp_write(rtsp[cur_conn_num]->cli_rtsp.cli_fd,
                 rtsp[cur_conn_num]->out_buffer,
                 strlen(rtsp[cur_conn_num]->out_buffer)) < RTSP_SUCCESS)
    {
        RTSP_DEBUG_PRINT("\r\nsend_play_reply error\n");
        return RTSP_FAILURE;
    }

    playrcvtime = GsnSoftTmr_CurrentSystemTime();
    return RTSP_SUCCESS;

}

/***************************************************************
 *
 * @function    :   rtsp_play
 * @param1      :   cur_conn_num -> current connection number
 * @ret         :   S32 -> on SUCCESS retruns 0, otherwise -1
 * @brief       :   set play command response buffer.
 *
 ***************************************************************/

S32 rtsp_play(S32 cur_conn_num)
{
    CHAR *p = NULL;
    CHAR  trash[255];

    RTSP_DEBUG_PRINT ("\r\n*** PLAY ***\n");

    if(!rtsp[cur_conn_num]->in_buffer)
    {
        RTSP_DEBUG_PRINT ("\r\nplay: invalid in buffer.\n");
        return RTSP_FAILURE;
    }

    /**** Parse the input message ****/
    if(check_rtsp_url(cur_conn_num) < RTSP_SUCCESS)
    {
        RTSP_DEBUG_PRINT ("\r\nplay: invalid url.\n");
        return RTSP_FAILURE;
    }

    if(get_rtsp_CSeq(cur_conn_num) < RTSP_SUCCESS)
    {
        RTSP_DEBUG_PRINT ("\r\nplay: rtsp cseg failed.\n");
        return RTSP_FAILURE;
    }

    if(check_rtsp_filename(cur_conn_num) < RTSP_SUCCESS)
    {
        return RTSP_FAILURE;
    }

    // If we get a Session hdr, then we have an aggregate control
    if ((p = strstr(rtsp[cur_conn_num]->in_buffer, HDR_SESSION)) != NULL)
    {
        if (sscanf(p, "%254s %d", trash, &rtsp[cur_conn_num]->session_id) != 2)
        {
            send_error_reply(SESSION_NOT_FOUND,cur_conn_num);	/* Session Not Found */
            RTSP_DEBUG_PRINT ("\r\n play: session not found.\n");
            return RTSP_FAILURE;
        }
    }
    else
    {
        send_error_reply(BAD_REQUEST,cur_conn_num);	/* bad request */
        RTSP_DEBUG_PRINT ("\r\n play: bad request.\n");
        return RTSP_FAILURE;
    }

    if(send_play_reply(RESPONSE_OK,cur_conn_num)!=RTSP_FAILURE)
    {
        return 1;
    }

    return RTSP_SUCCESS;
}
