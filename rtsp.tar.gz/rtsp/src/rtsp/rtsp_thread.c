/******************************************************************************
*
*               COPYRIGHT (c) 2015-2016 GainSpan Corporation
*                         All Rights Reserved
*
* The source code contained or described herein and all documents
* related to the source code ("Material") are owned by GainSpan
* Corporation or its licensors.  Title to the Material remains
* with GainSpan Corporation or its suppliers and licensors.
*
* The Material is protected by worldwide copyright and trade secret
* laws and treaty provisions. No part of the Material may be used,
* copied, reproduced, modified, published, uploaded, posted, transmitted,
* distributed, or disclosed in any way except in accordance with the
* applicable license agreement.
*
* No license under any patent, copyright, trade secret or other
* intellectual property right is granted to or conferred upon you by
* disclosure or delivery of the Materials, either expressly, by
* implication, inducement, estoppel, except in accordance with the
* applicable license agreement.
*
* Unless otherwise agreed by GainSpan in writing, you may not remove or
* alter this notice or any other notice embedded in Materials by GainSpan
* or GainSpan's suppliers or licensors in any way.
*  @file        :  rtsp_thread.c
*  @brief       :  This file contains functions definitions for
********************************************************************************/

#include "rtsp/rtsp_thread.h"
#include "rtsp/rtsp.h"

PRIVATE GSN_AVLB_RTSP_SERVER_TCB RTSPServerTcb;
PRIVATE UINT8  RTSPServerTask_Stack[AVLB_RTSP_SERVER_STACK_SIZE];

/***************************************************************
 *
 * @function    :   RTSPThreadStart
 * @param       :   none(void)
 * @ret         :   S32, on SUCCESS returns 0 otherwise -1
 * @brief       :   Creaates a thread for RTSP server task.
 *
 ***************************************************************/

S32 RTSPThreadStart ()
{
    int ret;

    ret = GsnOsal_ThreadCreate(rtsp_server_task,
                               0,
                               &RTSPServerTcb.rtspServerTask_tcb,
                               "RTSP Task",
                               AVLB_RTSP_SERVER_TASK_PRIORITY,
                               RTSPServerTask_Stack,
                               sizeof(RTSPServerTask_Stack),
                               GSN_OSAL_THREAD_INITIAL_READY
                              );

    if (ret != RTSP_SUCCESS)
    {
        RTSP_DEBUG_PRINT ("\r\nThread creation failed in RTSPThreadStart.\n");
    }
    else
    {
        RTSP_DEBUG_PRINT ("\r\nRTSP task thread created successfully.\n");
    }

    return RTSP_SUCCESS;
}

/***************************************************************
 *
 * @function    :   rtsp_server_task
 * @param       :   S32, connection number
 * @ret         :   S32, on SUCCESS returns 0 otherwise -1
 * @brief       :   rtsp server task.
 *
 ***************************************************************/

VOID rtsp_server_task (UINT32 arg)
{
    rtsp_main();

    while (1)
    {
        GsnTaskSleep (30000);
    }
}
