/******************************************************************************
*
*               COPYRIGHT (c) 2015-2016 GainSpan Corporation
*                         All Rights Reserved
*
* The source code contained or described herein and all documents
* related to the source code ("Material") are owned by GainSpan
* Corporation or its licensors.  Title to the Material remains
* with GainSpan Corporation or its suppliers and licensors.
*
* The Material is protected by worldwide copyright and trade secret
* laws and treaty provisions. No part of the Material may be used,
* copied, reproduced, modified, published, uploaded, posted, transmitted,
* distributed, or disclosed in any way except in accordance with the
* applicable license agreement.
*
* No license under any patent, copyright, trade secret or other
* intellectual property right is granted to or conferred upon you by
* disclosure or delivery of the Materials, either expressly, by
* implication, inducement, estoppel, except in accordance with the
* applicable license agreement.
*
* Unless otherwise agreed by GainSpan in writing, you may not remove or
* alter this notice or any other notice embedded in Materials by GainSpan
* or GainSpan's suppliers or licensors in any way.
*  @file        :  rtsp.c
*  @brief       :  This file contains functions which are allocating and
*                  deallocating memory and entrance for rtsp server.
********************************************************************************/

#include "rtsp/rtsp.h"
#include "osal/gsn_osal_threadx.h"
#include "net/socket.h"
#include "mediapush.h"
S32 rtp_free (S32 free_chn);

/***************************************************************
 *
 * @function    :   getrtspd_version
 * @param1      :   char pointer which points to version number.
 * @ret         :   S32, on SUCCESS returns 0, otherwise -1.
 * @brief       :   gets the current rtsp version.
 *
 ***************************************************************/

S32 getrtspd_version(CHAR *version)
{
    if(!version)
    {
        return RTSP_FAILURE;
    }

    if(convert_iver_2str(version)<0)
    {
        return RTSP_FAILURE;
    }

    return RTSP_SUCCESS;
}

/***************************************************************
 *
 * @function    :   rtspd_init
 * @param       :   none(void)
 * @ret         :   S32, on SUCCESS returns 0, otherwise -1
 * @brief       :   initialize memory.
 *
 ***************************************************************/

S32 rtspd_init()
{
    if(init_memory()<0)
    {
        RTSP_DEBUG_PRINT("\r\ninit rtspd memory error\n");
        return RTSP_FAILURE;
    }

    return RTSP_SUCCESS;
}

/***************************************************************
 *
 * @function    :   rtspd_freechn
 * @param       :   none(void)
 * @ret         :   S32, on SUCCESS returns free channel,
 *                  otherwise -1
 * @brief       :   checking the current free channel.
 *
 ***************************************************************/

S32 rtspd_freechn()
{
    S32 cur_conn;

    for(cur_conn=0; cur_conn<MAX_CONN; cur_conn++)
    {
        if(rtsp[cur_conn]->conn_status==0)
        {
            return cur_conn;
        }
    }

    return RTSP_FAILURE;
}

/***************************************************************
 *
 * @function    :   rtcp_free
 * @param       :   S32, current channel
 * @ret         :   S32, on SUCCESS returns 0 otherwise -1
 * @brief       :   freeing the rtcp connection status.
 *
 ***************************************************************/

S32 rtcp_free(S32 free_chn)
{

    soc_close(rtsp[free_chn]->fd.video_rtcp_fd);
    rtsp[free_chn]->is_runing=STREAM_IDLE;
    return RTSP_SUCCESS;
}

/***************************************************************
 *
 * @function    :   rtsp_freeall
 * @param       :   none(void)
 * @ret         :   S32, on SUCCESS returns 0 otherwise -1
 * @brief       :   freeing all resources.
 *
 ***************************************************************/

S32 rtsp_freeall()
{
    S32 free_chn, cur_conn;

    for(cur_conn=0; cur_conn<MAX_CONN; cur_conn++)
    {
        if(rtsp[free_chn]->is_runing)
        {
            rtp_free(free_chn);
            rtcp_free(free_chn);
        }
    }

    return RTSP_SUCCESS;
}

/***************************************************************
 *
 * @function    :   rtsp_main
 * @param       :   None, void
 * @ret         :   None, void
 * @brief       :   start of rtsp server flow..
 *
 ***************************************************************/

VOID rtsp_main ()
{
    //char port[32];
    CHAR version[32];
    int ret;

    ret = getrtspd_version(version);

    if (ret < 0)
    {
        RTSP_DEBUG_PRINT ("\r\nUnable to get the rtsp version.\n");
    }
    else
    {
        RTSP_DEBUG_PRINT ("\r\nrtspd version is %s\n",version);
    }
    avPush();
#if 0
    /* init rtsp - memory initialization */
    rtspd_init();
    RTSP_DEBUG_PRINT ("\r\ninitialising rtsp...\n");
    /* can accept connection from any client */
    strcpy (rtsp[0]->host_name, INET_INADDR_ANY);
    memset(port,0,sizeof(port));
    strcpy (port, "554");
    /* Creates socket connection with the client */
    ret = create_sercmd_socket(rtsp[0]->host_name,port,SOCK_STREAM);

    if (ret < 0)
    {
        RTSP_DEBUG_PRINT ("\r\nERROR: failed in rtsp_task.\n");
    }
    else
    {
        RTSP_DEBUG_PRINT ("\r\n***Done***\n");
    }
#endif
}

/***************************************************************
 *
 * @function    :   init_memory
 * @param       :   none(void)
 * @ret         :   S32, on SUCCESS returns 0, otherwise -1
 * @brief       :   initialize rtsp struct memory.
 *
 ***************************************************************/

S32 init_memory()
{
    S32 cur_conn;

    for(cur_conn=0; cur_conn<MAX_CONN; cur_conn++)
    {
        rtsp[cur_conn]= malloc(sizeof(struct rtsp_buffer));

        if(!rtsp[cur_conn])
        {
            RTSP_DEBUG_PRINT ("\r\n malloc failed at :%d \n", cur_conn);
            return RTSP_FAILURE;
        }

        memset(rtsp[cur_conn], 0, sizeof(struct rtsp_buffer));
        rtsp[cur_conn]->cli_rtp.video_seq_num = 1;
        rtsp[cur_conn]->cli_rtp.audio_seq_num = 1;
    }

    return RTSP_SUCCESS;
}
