/******************************************************************************
*
*               COPYRIGHT (c) 2015-2016 GainSpan Corporation
*                         All Rights Reserved
*
* The source code contained or described herein and all documents
* related to the source code ("Material") are owned by GainSpan
* Corporation or its licensors.  Title to the Material remains
* with GainSpan Corporation or its suppliers and licensors.
*
* The Material is protected by worldwide copyright and trade secret
* laws and treaty provisions. No part of the Material may be used,
* copied, reproduced, modified, published, uploaded, posted, transmitted,
* distributed, or disclosed in any way except in accordance with the
* applicable license agreement.
*
* No license under any patent, copyright, trade secret or other
* intellectual property right is granted to or conferred upon you by
* disclosure or delivery of the Materials, either expressly, by
* implication, inducement, estoppel, except in accordance with the
* applicable license agreement.
*
* Unless otherwise agreed by GainSpan in writing, you may not remove or
* alter this notice or any other notice embedded in Materials by GainSpan
* or GainSpan's suppliers or licensors in any way.
*  @file        :  rtsp_status.c
*  @brief       :  This file contains functions for getting status from status table.
********************************************************************************/

#include "rtsp/rtsp.h"

/***************************************************************
 *
 * @function    :   get_stat
 * @param1      :   err -> error number
 * @param2		:	buff ponter pointing to corresponding token.
 * @ret         :   S32, on success returns 0, otherwise -1.
 * @brief       :   get rtsp status tables.
 *
 ***************************************************************/

S32 get_stat(S32 err, char *buff)
{
    struct
    {
        CHAR *token;
        S32 code;
    } tmp_status[] =
    {
        {
            "Continue", 100
        }, {
            "OK", 200
        }, {
            "Created", 201
        }, {
            "Accepted", 202
        }, {
            "Non-Authoritative Information", 203
        }, {
            "No Content", 204
        }, {
            "Reset Content", 205
        }, {
            "Partial Content", 206
        }, {
            "Multiple Choices", 300
        }, {
            "Moved Permanently", 301
        }, {
            "Moved Temporarily", 302
        }, {
            "Bad Request", 400
        }, {
            "Unauthorized", 401
        }, {
            "Payment Required", 402
        }, {
            "Forbidden", 403
        }, {
            "Not Found", 404
        }, {
            "Method Not Allowed", 405
        }, {
            "Not Acceptable", 406
        }, {
            "Proxy Authentication Required", 407
        }, {
            "Request Time-out", 408
        }, {
            "Conflict", 409
        }, {
            "Gone", 410
        }, {
            "Length Required", 411
        }, {
            "Precondition Failed", 412
        }, {
            "Request Entity Too Large", 413
        }, {
            "Request-URI Too Large", 414
        }, {
            "Unsupported Media Type", 415
        }, {
            "Bad Extension", 420
        }, {
            "Invalid Parameter", 450
        }, {
            "Parameter Not Understood", 451
        }, {
            "Conference Not Found", 452
        }, {
            "Not Enough Bandwidth", 453
        }, {
            "Session Not Found", 454
        }, {
            "Method Not Valid In This State", 455
        }, {
            "Header Field Not Valid for Resource", 456
        }, {
            "Invalid Range", 457
        }, {
            "Parameter Is Read-Only", 458
        }, {
            "Unsupported transport", 461
        }, {
            "Internal Server Error", 500
        }, {
            "Not Implemented", 501
        }, {
            "Bad Gateway", 502
        }, {
            "Service Unavailable", 503
        }, {
            "Gateway Time-out", 504
        }, {
            "RTSP Version Not Supported", 505
        }, {
            "Option not supported", 551
        }, {
            "Extended Error:", 911
        }, {
            NULL, -1
        }
    };
    S32 i;

    for (i = 0; tmp_status[i].code != err && tmp_status[i].code != -1; ++i);

    memcpy (buff, tmp_status[i].token, sizeof (tmp_status[i].token));
    return RTSP_SUCCESS;
}

/***************************************************************
 *
 * @function    :   send_reply
 * @param1      :   errornumber -> rtsp command error number
 * @param2      :   cur_conn_num -> current connection number
 * @ret         :   S32 -> on SUCCESS retruns 0 otherwise -1
 * @brief       :   send rtsp error message respponse.
 *
 ***************************************************************/

S32 send_error_reply(S32 errornumber,S32 cur_conn_num)
{
    CHAR error_buff[1024]="";
    CHAR temp[64]="";

    get_stat (errornumber, temp);
    sprintf(error_buff, "%s %d %s"RTSP_EL"CSeq: %d"RTSP_EL, RTSP_VER, errornumber,
            (CHAR *)temp, rtsp[cur_conn_num]->rtsp_cseq);
    strcat(error_buff, RTSP_EL);

    if(tcp_write(rtsp[cur_conn_num]->cli_rtsp.cli_fd, error_buff,
                 strlen(error_buff))<0)
    {
        RTSP_DEBUG_PRINT ("\r\nsend rtspd reply packet error\n");
        return RTSP_FAILURE;
    }

    return RTSP_SUCCESS;
}

/***************************************************************
 *
 * @function    :   get_rtsp_method
 * @param1      :   cur_conn_num -> current connection numnber
 * @ret         :   S32 -> if method is valid
 *                  returns corresponding method type, otherwise -1.
 * @brief       :   obtain RTSP command type.
 *
 ***************************************************************/

S32 get_rtsp_method(S32 cur_conn_num)
{
    CHAR method[32];

    memset(method, 0, sizeof(method));

    if(!rtsp[cur_conn_num]->in_buffer)
        return RTSP_FAILURE;

    sscanf(rtsp[cur_conn_num]->in_buffer, "%31s", method);

    if (strcmp(method, "OPTIONS") == 0)
    {
        return RTSP_OPTIONS;
    }

    if (strcmp(method, "DESCRIBE") == 0)
    {
        return RTSP_DESCRIBE;
    }

    if (strcmp(method, "SETUP") == 0)
    {
        return RTSP_SETUP;
    }

    if (strcmp(method, "PLAY") == 0)
    {
        return RTSP_PLAY;
    }

    if (strcmp(method, "TEARDOWN") == 0)
    {
        return RTSP_TEARDOWN;
    }

	if (strcmp(method, "PAUSE") == 0)
	{
		return RTSP_PAUSE;
	}

    return RTSP_METHOD_UNSUPPORTED;
}
