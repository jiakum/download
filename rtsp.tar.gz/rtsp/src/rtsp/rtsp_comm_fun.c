/******************************************************************************
*
*               COPYRIGHT (c) 2015-2016 GainSpan Corporation
*                         All Rights Reserved
*
* The source code contained or described herein and all documents
* related to the source code ("Material") are owned by GainSpan
* Corporation or its licensors.  Title to the Material remains
* with GainSpan Corporation or its suppliers and licensors.
*
* The Material is protected by worldwide copyright and trade secret
* laws and treaty provisions. No part of the Material may be used,
* copied, reproduced, modified, published, uploaded, posted, transmitted,
* distributed, or disclosed in any way except in accordance with the
* applicable license agreement.
*
* No license under any patent, copyright, trade secret or other
* intellectual property right is granted to or conferred upon you by
* disclosure or delivery of the Materials, either expressly, by
* implication, inducement, estoppel, except in accordance with the
* applicable license agreement.
*
* Unless otherwise agreed by GainSpan in writing, you may not remove or
* alter this notice or any other notice embedded in Materials by GainSpan
* or GainSpan's suppliers or licensors in any way.
*  @file        :  rtsp_comm_fun.c
*  @brief       :  This file contains function definitions for checking
*                    Url, filename and cseq number.
********************************************************************************/

#include "rtsp/rtsp.h"

struct rtsp_buffer *rtsp[MAX_CONN];

/***************************************************************
 *
 * @function    :   get_rtsp_CSeq
 * @param1      :   cur_conn_num -> current connection number
 * @ret         :   S32, on SUCCESS returns 0, otherwise -1
 * @brief       :   get rtsp cseq functions.
 *
 ***************************************************************/

S32 get_rtsp_CSeq(S32 cur_conn_num)
{
    CHAR *p;
    CHAR trash[255];

    /****check  CSeq****/
    if ((p = strstr(rtsp[cur_conn_num]->in_buffer, "CSeq")) == NULL)
    {
        /**** not find CSeq send 400 error ****/
        send_error_reply(BAD_REQUEST,cur_conn_num);
        return RTSP_FAILURE;
    }
    else
    {
        if(sscanf(p, "%254s %d", trash, &(rtsp[cur_conn_num]->rtsp_cseq))!=2)
        {
            /**** not find CSeq value send 400 error ****/
            send_error_reply(BAD_REQUEST,cur_conn_num);
            return RTSP_FAILURE;
        }
    }

    return RTSP_SUCCESS;
}

/***************************************************************
 *
 * @function    :   check_rtsp_url
 * @param1      :   cur_conn_num -> current connection number
 * @ret         :   S32, on SUCCESS returns 0, otherwise -1
 * @brief       :   check rtsp url functions.
 *
 ***************************************************************/

S32 check_rtsp_url(S32 cur_conn_num)
{
    U16 port;
    CHAR url[128];
    CHAR object[128], server[128];

    if (!sscanf(rtsp[cur_conn_num]->in_buffer, " %*s %254s ", url))
    {
        send_error_reply(BAD_REQUEST,cur_conn_num);	/* bad request */
        return RTSP_FAILURE;
    }

    /* Validate the URL */
    if (!parse_url(url, server, &port, object))
    {
        send_error_reply(BAD_REQUEST,cur_conn_num);	/* bad request */
        return RTSP_FAILURE;
    }

    if(strstr(url,"trackID=0"))
    {
        rtsp[cur_conn_num]->trackID = AUDIO_TRACK;
    }

    if(strstr(url,"trackID=1"))
    {
        rtsp[cur_conn_num]->trackID = VIDEO_TRACK;
    }

    strcpy(rtsp[cur_conn_num]->host_name,server);

    /****  get media file name   ****/
    if(strstr(object,"trackID"))
    {
        strcpy(object,rtsp[cur_conn_num]->file_name);
    }
    else
    {
        if(strcmp(object,"")==0)
        {
            strcpy(object,rtsp[cur_conn_num]->file_name);
        }

        strcpy(rtsp[cur_conn_num]->file_name,object);
    }

    return RTSP_SUCCESS;
}

/***************************************************************
 *
 * @function    :   check_rtsp_filename
 * @param1      :   cur_conn_num -> current connection number
 * @ret         :   S32, on SUCCESS returns 0, otherwise -1
 * @brief       :   check rtsp filename functions.
 *
 ***************************************************************/

S32 check_rtsp_filename(S32 cur_conn_num)
{
    CHAR *p;
    S32 valid_url;

    if (strstr(rtsp[cur_conn_num]->file_name, "../"))
    {
        /* disallow relative paths outside of current directory. */
        send_error_reply(FORBIDDEN,cur_conn_num);	 /* Forbidden */
        return RTSP_FAILURE;
    }

    if (strstr(rtsp[cur_conn_num]->file_name, "./"))
    {
        /* Disallow ./ */
        send_error_reply(FORBIDDEN,cur_conn_num);	 /* Forbidden */
        return RTSP_FAILURE;
    }

    p = strrchr(rtsp[cur_conn_num]->file_name, '.');
    valid_url = 0;

    if (p == NULL)
    {
        send_error_reply(UNSUPPORTED_MEDIA_TYPE,
                         cur_conn_num);	 /* Unsupported media type */
        return RTSP_FAILURE;
    }
    else
    {
        valid_url = is_supported_mediatype(p,cur_conn_num);
    }

    if (!valid_url)
    {
        send_error_reply(UNSUPPORTED_MEDIA_TYPE,
                         cur_conn_num);	 /* Unsupported media type */
        return RTSP_FAILURE;
    }

    return RTSP_SUCCESS;
}
