/******************************************************************************
*
*               COPYRIGHT (c) 2015-2016 GainSpan Corporation
*                         All Rights Reserved
*
* The source code contained or described herein and all documents
* related to the source code ("Material") are owned by GainSpan
* Corporation or its licensors.  Title to the Material remains
* with GainSpan Corporation or its suppliers and licensors.
*
* The Material is protected by worldwide copyright and trade secret
* laws and treaty provisions. No part of the Material may be used,
* copied, reproduced, modified, published, uploaded, posted, transmitted,
* distributed, or disclosed in any way except in accordance with the
* applicable license agreement.
*
* No license under any patent, copyright, trade secret or other
* intellectual property right is granted to or conferred upon you by
* disclosure or delivery of the Materials, either expressly, by
* implication, inducement, estoppel, except in accordance with the
* applicable license agreement.
*
* Unless otherwise agreed by GainSpan in writing, you may not remove or
* alter this notice or any other notice embedded in Materials by GainSpan
* or GainSpan's suppliers or licensors in any way.
*  @file			:	rtsp_client_thread.c
*  @brief			:	This file contains thread creation for rtsp client task.
**************************************************************************************/

#include "rtsp/rtsp_client_thread.h"
#include "rtsp/rtsp_client.h"

PRIVATE GSN_AVLB_RTSP_CLIENT_TCB rtsp_cli_tcb;
PRIVATE UINT8 rtsp_cli_Tsk_Stack[AVLB_RTSP_CLIENT_STACK_SIZE];
void rtsp_close();

/**************************************************************************************
 *
 * @function		:	client_rtsp_task
 * @param			:	arg
 * @return			:	None, void
 * @brief			:	calls client main routine.
 *
 **************************************************************************************/

void client_rtsp_task(UINT32 arg)
{
    int status;

    while (1)
    {
        status = client_main();

        if (status < 0)
		{
#ifdef STNDRD_RTSP_CLIENT
            RTSP_CLIENT_DEBUG_INFO("\r\nRetry after 2 secs...\n");
            GsnTaskSleep (2000);
#endif
		} 
		else 
		{
            rtsp_close();
			GsnTaskSleep(1000);
        }
    }
}

/**************************************************************************************
 *
 * @function		:	RTSP_Client_ThreadStart
 * @param			:	None
 * @return			:	int, on sucess 0, otherwise -1
 * @brief			:	creates a thread for rtsp client.
 *
 **************************************************************************************/

int RTSP_Client_ThreadStart ()
{
    int ret;

    /*Create rtsp client task*/
    ret = GsnOsal_ThreadCreate(client_rtsp_task, 0,
                               &rtsp_cli_tcb.rtspClientTask_tcb,
                               "RTSP client task", AVLB_RTSP_CLIENT_TASK_PRIORITY,
                               rtsp_cli_Tsk_Stack, sizeof(rtsp_cli_Tsk_Stack),
                               GSN_OSAL_THREAD_INITIAL_READY  );
#ifdef DEBUG_STATS_LOCAL
    if (ret != GSN_SUCCESS)
    {
        AppDbg_Printf ("\r\nThread creation failed in rtsp_client.\n");

    }
    else
    {
        AppDbg_Printf ("\r\nclient_rtsp_task thread created successfully.\n");
    }
#endif
    return ret;
}
