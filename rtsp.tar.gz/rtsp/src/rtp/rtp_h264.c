/******************************************************************************
*
*               COPYRIGHT (c) 2015-2016 GainSpan Corporation
*                         All Rights Reserved
*
* The source code contained or described herein and all documents
* related to the source code ("Material") are owned by GainSpan
* Corporation or its licensors.  Title to the Material remains
* with GainSpan Corporation or its suppliers and licensors.
*
* The Material is protected by worldwide copyright and trade secret
* laws and treaty provisions. No part of the Material may be used,
* copied, reproduced, modified, published, uploaded, posted, transmitted,
* distributed, or disclosed in any way except in accordance with the
* applicable license agreement.
*
* No license under any patent, copyright, trade secret or other
* intellectual property right is granted to or conferred upon you by
* disclosure or delivery of the Materials, either expressly, by
* implication, inducement, estoppel, except in accordance with the
* applicable license agreement.
*
* Unless otherwise agreed by GainSpan in writing, you may not remove or
* alter this notice or any other notice embedded in Materials by GainSpan
* or GainSpan's suppliers or licensors in any way.
*	@file        :  rtp_h264.c
*	@brief       :  This file contains functions which are forming
*					RTP packets and sending through the network.
********************************************************************************/
#include "rtp/rtp.h"
#include "rtsp/rtsp.h"
#include "nxd_bsd.h"

/*****************************************************************************
 * Global variable - Used for local debugging
 ****************************************************************************/
/* GeoSemi stats debug variables */
RTP_DEBUG_STATS_T rtpStats;
/* OV stats debug variables */
ULONG64 start_time_udp = 0,end_time_udp= 0,diff_time_udp = 0;
ULONG64 playtosendtime = 0;
extern UINT32 first_frame_flag;
extern ULONG64 playrcvtime;
/******************************************************************************
 *
 * @function    :   get_random_seq
 * @param       :   void
 * @ret         :   UL64 -> unsigned long 64bit random seq number
 * @brief       :   returns random seq number
 *
 ******************************************************************************/

UL64 get_random_seq (void)
{
    UL64 seed;

    srand(123456);
    seed = 1 + (U32) (rand()%(0xFFFF));

    return seed;
}

/******************************************************************************
 *
 * @function    :   build_rtp_header
 * @param1      :   RTP_header pointer
 * @param2      :   cur_conn_num -> current connection number
 * @param3      :   audio_flag
 * @param4		:	timestamp
 * @ret         :   S32 -> on success returns 0, otherwise -1
 * @brief       :   builds rtp header
 *
 ******************************************************************************/

S32 build_rtp_header(RTP_header *r,S32 cur_conn_num, int audio_flag,
                     unsigned int timestamp)
{
    r->magic = 0x24;
    r->version = 2;
    r->padding = 0;
    r->extension = 0;
    r->csrc_len = 0;
    r->marker=0;

    if(audio_flag == 1)
    {
        r->payload=AUDIO_PAYLOAD_TYPE;
    }
    else
    {
        r->payload=VIDEO_PAYLOAD_TYPE;
    }

    r->seq_no=htons(rtsp[cur_conn_num]->cmd_port.seq);

    if(audio_flag == 1)
    {
#ifdef AUDIO_ONLY
		r->timestamp = htonl (timestamp);
#else
#ifdef AUDIO_AAC
        r->timestamp = htonl ((timestamp/90)*16);
#endif
#ifdef AUDIO_PCM
		r->timestamp = htonl ((timestamp));
#endif
#endif
        r->ssrc = htonl((U32)(10000000));
    }
    else
    {
        r->timestamp = htonl (timestamp);
        r->ssrc = htonl(rtsp[cur_conn_num]->cmd_port.ssrc);
    }

    return RTSP_SUCCESS;
}

/******************************************************************************
 *
 * @function    :   udp_write
 * @param1      :   len -> length of Bytes to write
 * @param2      :   cur_conn_num -> current connection number
 * @param3      :   audio_flag ->whether data has audio or not
 * @ret         :   S32 -> on Success retruns 0, otherwise -1
 * brief        :   write to the destination file descriptor
 *
 ******************************************************************************/
S32 udp_write(S32 len,S32 cur_conn_num, int audio_flag)
{
    S32 result;

    start_time_udp = GsnSoftTmr_CurrentSystemTime();
    if(audio_flag == 1)
    {
        /* Sends Audio data to the client's listening Audio file descriptor */
        result=tcp_write(rtsp[cur_conn_num]->fd.audio_rtp_fd,
				         rtsp[cur_conn_num]->nalu_buffer,len);
        if(result == -1)
          rtsp[cur_conn_num]->fd.audio_rtp_fd = 0;
	}
	else
	{
		/* Sends Video data to the client's listening Video file descriptor */
        result=tcp_write(rtsp[cur_conn_num]->fd.video_rtp_fd,
                         rtsp[cur_conn_num]->nalu_buffer,len);
        
        if(result == -1)
          rtsp[cur_conn_num]->fd.video_rtp_fd = 0;

        end_time_udp = GsnSoftTmr_CurrentSystemTime();
        diff_time_udp = SYSTIME_TO_USEC((end_time_udp-start_time_udp));

        if(first_frame_flag)
        {
            playtosendtime = SYSTIME_TO_USEC((end_time_udp-playrcvtime));

            //AppDbg_Printf(" PtoS=%lld",playtosendtime);

            first_frame_flag=0;
        }

	if (diff_time_udp<10)
            rtpStats.udpPktTxIn10uSec++;
	else if(diff_time_udp<1000)
            rtpStats.udpPktTxIn1mSec++;
	else if(diff_time_udp<10000)
            rtpStats.udpPktTxIn1to10mSec++;
	else if(diff_time_udp<50000)
            rtpStats.udpPktTxIn10to50mSec++;
	else
            rtpStats.udpPktTxIn50plusmSec++;
	rtpStats.totalUdpLen+=len;
        diff_time_udp = SYSTIME_TO_MSEC((end_time_udp-start_time_udp));
        if( diff_time_udp > rtpStats.maxUdpSendTime)
        {
            rtpStats.maxUdpSendTime = diff_time_udp;
        }

    }
	if(result<=0){
		rtsp[cur_conn_num]->rtspd_status=RTSP_UDP_WRITE_FAIL;
	}
	return RTSP_SUCCESS;
}

/*******************************************************************************
 * RTP Packet:
 * 1. NALU length small than 1460-sizeof(RTP header):
 *    (RTP Header) + (NALU without Start Code)
 * 2. NALU length larger than MTU:
 *    (RTP Header) + (FU Indicator) + (FU Header) + (NALU Slice)
 *                 + (FU Indicator) + (FU Header) + (NALU Slice)
 *                 + ...
 *
 * inbuffer--NALU: 00 00 00 01      1 Byte     XX XX XX
 *                | Start Code| |NALU Header| |NALU Data|
 *
 * NALU Slice: Cut NALU Data into Slice.
 *
 * NALU Header: F|NRI|TYPE
 *              F: 1 bit,
 *              NRI: 2 bits,
 *              Type: 5 bits
 *
 * FU Indicator: Like NALU Header, Type is FU-A(28)
 *
 * FU Header: S|E|R|Type
 *            S: 1 bit, Start, First Slice should set
 *            E: 1 bit, End, Last Slice should set
 *            R: 1 bit, Reserved
 *            Type: 5 bits, Same with NALU Header's Type.
 ******************************************************************************/


S32 send_frame_on_rtp_nw(unsigned char *inbuffer, S32 frame_size,
                         int audio_flag, int marker, unsigned int timestamp)
{
    S32 cur_conn_num = 0;
    S32 free_chn = 0;

    if(!inbuffer)
    {
        return RTSP_FAILURE;
    }

    U16 temp_seq_number = 0;
    U16 temp_audio_seq_number = 0;

    for(cur_conn_num = free_chn; cur_conn_num < MAX_CONN;
            cur_conn_num=cur_conn_num+1)
	{
		if (rtsp[cur_conn_num]->is_runing == STREAM_RUNNING) {
			if(audio_flag == 1)
			{
				/* Restoring Audio sequence number */
				temp_audio_seq_number = rtsp[cur_conn_num]->cli_rtp.audio_seq_num;
				rtpStats.audioSeqNo = rtsp[cur_conn_num]->cli_rtp.audio_seq_num;
			}
			else
			{
				/* Restoring Video sequence number */
				temp_seq_number = rtsp[cur_conn_num]->cli_rtp.video_seq_num;
				rtpStats.videoSeqNo = rtsp[cur_conn_num]->cli_rtp.video_seq_num;
			}

			RTP_header rtp_header;
			S32 data_left;
			static U8 nalu_header;
			U8 fu_indic;
			U8 fu_header;
			U8 *p_nalu_data;
			U8 *nalu_buffer;
			char NAL_String[] = {0x00, 0x00, 0x00, 0x01};
			char no_nalu = 0;
			static S32 fu_start = 1;
			S32 fu_end	= 0;

			/* This will check the frame has NALU header start code or not.*/
			if (memcmp (inbuffer, NAL_String, 4))
			{
				//RTSP_DEBUG_PRINT ("\r\nno nal len:%u\n", frame_size);
				//no_nalu = 1; removed to avoid extra sof sps
			}

			nalu_buffer = rtsp[cur_conn_num]->nalu_buffer;
			/* Frames RTP header for Video/Audio, based on the audio flag */
			build_rtp_header(&rtp_header,cur_conn_num, audio_flag, timestamp);
      
      if(audio_flag == 1)
          rtp_header.channel = 2;
			else
          rtp_header.channel = 0;

			if (no_nalu == 0 && audio_flag == 0)
			{
				data_left = frame_size - NALU_INDIC_SIZE;
				p_nalu_data = inbuffer + NALU_INDIC_SIZE;
			}
			else
			{
				data_left = frame_size;
				p_nalu_data = inbuffer;
			}
#ifdef SEND_SPS_PPS
			if (data_left <= SINGLE_NALU_DATA_MAX && audio_flag == 0) {
				rtp_header.seq_no=htons(temp_seq_number);
				temp_seq_number += 1;
				rtp_header.marker = marker;
				memcpy(nalu_buffer,&rtp_header,sizeof(rtp_header));
				memcpy(nalu_buffer + RTP_HEADER_SIZE, p_nalu_data, data_left);
				udp_write(data_left + RTP_HEADER_SIZE, cur_conn_num, audio_flag);
				break;
			}
#endif
			/* This case forms RTP packes for all Audio frames only and send to the client */
			if(data_left <= SINGLE_NALU_DATA_MAX && audio_flag && marker)
			{
				rtp_header.seq_no=htons(temp_audio_seq_number);
				temp_audio_seq_number += 1;
				rtp_header.marker = marker;
        rtp_header.embedlen = htons(data_left + 12);
				memcpy(nalu_buffer,&rtp_header,sizeof(rtp_header));
				memcpy(nalu_buffer + RTP_HEADER_SIZE, p_nalu_data, data_left);
				udp_write(data_left + RTP_HEADER_SIZE, cur_conn_num, audio_flag);
			}
			else if(audio_flag == 0)
			{
				/* This case forms FU-A RTP Packet for all video frames only and send to the client */
				if (no_nalu == 0)
				{
					nalu_header = inbuffer[4];
					data_left   -= NALU_HEAD_SIZE;
					p_nalu_data += NALU_HEAD_SIZE;
				}

				S32 rtp_size;

				while(data_left > 0)
				{
					S32 proc_size = MIN(data_left,SLICE_NALU_DATA_MAX);
					rtp_size = proc_size +
						RTP_HEADER_SIZE  +
						FU_A_HEAD_SIZE   +
						FU_A_INDI_SIZE;
					fu_end = (proc_size==data_left);
					/* FU-indicator */
					fu_indic = (nalu_header&0xE0)|28;
					/* FU-header */
					fu_header = nalu_header&0x1F;

					/* first RTP packet per frame S bit will be set, fu_start=1 */
					if(fu_start)
					{
						fu_header |= 0x80;
					}
					/* last RTP packet per frame E bit will be set */
					else if(fu_end && marker)
					{
						fu_header |= 0x40;
					}

					rtp_header.seq_no=htons(temp_seq_number);
					temp_seq_number += 1;

					/* If the last packet per frame (fu_end) and marker variable is set,
					 * then marker bit will be set in rtp header */
					if (fu_end && marker)
					{
						rtp_header.marker = 1;
					}
          
          rtp_header.embedlen = htons(rtp_size - 4);
					memset(nalu_buffer, 0, sizeof( rtsp[cur_conn_num]->nalu_buffer));
					memcpy(nalu_buffer,&rtp_header,sizeof(rtp_header));
					memcpy(nalu_buffer + 18, p_nalu_data, proc_size);
					nalu_buffer[16] = fu_indic;
					nalu_buffer[17] = fu_header;
					udp_write(rtp_size, cur_conn_num, audio_flag);
					data_left -= proc_size;
					p_nalu_data += proc_size;
					/* resetting the S bit once first RTP packet sent, fu_start=0 */
					fu_start = 0;

					/*
					 * If the last RTP packet per frame (complete frame) sent,
					 * making fu_start=1, (which will set S bit for first RTP packet of next frame)
					 */
					if (fu_end && marker)
					{
						fu_start = 1;
					}
				}
			}
		}
	}

    if(audio_flag == 1)
    {
        /* Creating backup for Audio sequnece number */
        rtsp[free_chn]->cli_rtp.audio_seq_num = temp_audio_seq_number;
    }
    else
    {
        /* Creating backup for Video sequence number */
        rtsp[free_chn]->cli_rtp.video_seq_num = temp_seq_number;
    }

    return RTSP_SUCCESS;
}
