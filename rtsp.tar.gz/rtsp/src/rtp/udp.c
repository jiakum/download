/******************************************************************************
*
*               COPYRIGHT (c) 2015-2016 GainSpan Corporation
*                         All Rights Reserved
*
* The source code contained or described herein and all documents
* related to the source code ("Material") are owned by GainSpan
* Corporation or its licensors.  Title to the Material remains
* with GainSpan Corporation or its suppliers and licensors.
*
* The Material is protected by worldwide copyright and trade secret
* laws and treaty provisions. No part of the Material may be used,
* copied, reproduced, modified, published, uploaded, posted, transmitted,
* distributed, or disclosed in any way except in accordance with the
* applicable license agreement.
*
* No license under any patent, copyright, trade secret or other
* intellectual property right is granted to or conferred upon you by
* disclosure or delivery of the Materials, either expressly, by
* implication, inducement, estoppel, except in accordance with the
* applicable license agreement.
*
* Unless otherwise agreed by GainSpan in writing, you may not remove or
* alter this notice or any other notice embedded in Materials by GainSpan
* or GainSpan's suppliers or licensors in any way.
*  @file        :  udp.c
*  @brief       :  This file contains function definitions for creating
*                    UDP sockets for video & audio streaming.
********************************************************************************/

#include "rtsp/rtsp.h"

/******************************************************************************
 *
 * @function    :   create_vrtp_socket
 * @param1      :   host -> name of host to which connection is desired
 * @param2      :   port -> port associated with desired port
 * @param3      :   type -> SOCK_STREAM or SOCK_DGRAM
 * @param4      :   cur_conn_num -> current connection number
 * @ret         :   S32 -> on success returns 0, otherwise -1
 * @brief       :   creates video rtp socket.
 *
 *******************************************************************************/

S32 create_vrtp_socket(const CHAR *host, S32 port,S32 type,S32 cur_conn_num)
{
    /*  Create a socket for the client.	*/
    S32 len;
    S32 reuse = 1;
    struct sockaddr_in rtp_address, rtp_bind;
    S32 result;
    rtsp[cur_conn_num]->fd.video_rtp_fd = socket(AF_INET, type, 0);

    if (rtsp[cur_conn_num]->fd.video_rtp_fd < 0)
    {
        return RTSP_FAILURE;
    }

    /*bind local port*/
    
    memset(&rtp_bind, 0, sizeof(rtp_bind));
    rtp_bind.sin_family = AF_INET;
    rtp_bind.sin_addr.s_addr = htonl(INADDR_ANY);
    rtp_bind.sin_port = htons(rtsp[cur_conn_num]->cmd_port.video_rtp_ser_port);
    result = bind(rtsp[cur_conn_num]->fd.video_rtp_fd,
                  (struct sockaddr *) &rtp_bind, sizeof(rtp_bind));

    if (result < RTSP_SUCCESS)
    {
        RTSP_DEBUG_PRINT("\r\nbind rtsp server port error\n");
        return RTSP_FAILURE;
    }
    
    /*set address reuse*/    
    result = setsockopt(rtsp[cur_conn_num]->fd.video_rtp_fd, SOL_SOCKET,
                        SO_REUSEADDR, &reuse,sizeof(reuse));

    if (result < RTSP_SUCCESS)
    {
        return RTSP_FAILURE;
    }    
    
    UINT32 optionValue = 160; 
    result = setsockopt(rtsp[cur_conn_num]->fd.video_rtp_fd, IPPROTO_IP, IP_DSCP,
                        (INT8 *) &optionValue, sizeof(optionValue));

    if (result < RTSP_SUCCESS)
    {
        return RTSP_FAILURE;
    }
    
    /*  Name the socket, as agreed with the server.  */
    memset(&rtp_address, 0, sizeof(rtp_address));
    rtp_address.sin_family = AF_INET;
    rtp_address.sin_addr.s_addr = inet_addr(host);
    rtp_address.sin_port = htons(port);
    len = sizeof(rtp_address);
    /*  Now connect our socket to the server's socket.  */
    RTSP_DEBUG_PRINT ("\r\n connecting to client with video fd: %d ...\n",
                      rtsp[cur_conn_num]->fd.video_rtp_fd);
    result = connect(rtsp[cur_conn_num]->fd.video_rtp_fd,
                     (struct sockaddr *)&rtp_address, len);

    if(result == RTSP_FAILURE)
    {
        RTSP_DEBUG_PRINT("\r\nconnect vrtp socket error\n");
        return RTSP_FAILURE;
    }

    RTSP_DEBUG_PRINT ( "\r\n video rtp connection sucess:%s, %d\n", host, port);

    return RTSP_SUCCESS;
}

/******************************************************************************
 *
 * @function    :   create_artp_socket
 * @param1      :   host -> name of host to which connection is desired
 * @param2      :   port -> port associated with desired port
 * @param3      :   type -> SOCK_STREAM or SOCK_DGRAM
 * @param4      :   cur_conn_num -> current connection number
 * @ret         :   S32 -> on success returns 0, otherwise -1
 * @brief       :   creates audio rtp socket.
 *
 *******************************************************************************/

S32 create_artp_socket(const CHAR *host, S32 port,S32 type,S32 cur_conn_num)
{
    /*  Create a socket for the client.	*/
    S32 len,reuse =1;
    struct sockaddr_in rtp_address,rtp_bind;
    S32 result;

    rtsp[cur_conn_num]->fd.audio_rtp_fd = socket(AF_INET, type, 0);

    if (rtsp[cur_conn_num]->fd.audio_rtp_fd < 0)
    {
        return RTSP_FAILURE;
    }

    /*set address reuse*/    
    result = setsockopt(rtsp[cur_conn_num]->fd.audio_rtp_fd, SOL_SOCKET,
                        SO_REUSEADDR, &reuse,sizeof(reuse));

    if (result != 0)
    {
        return RTSP_FAILURE;
    }    
    
    UINT32 optionValue = 224; 
    result = setsockopt(rtsp[cur_conn_num]->fd.audio_rtp_fd, IPPROTO_IP, IP_DSCP,
                        (INT8 *) &optionValue, sizeof(optionValue));

    if (result != 0)
    {
        return RTSP_FAILURE;
    }
    
    /*bind local port*/
    
    rtp_bind.sin_family = AF_INET;
    rtp_bind.sin_addr.s_addr = htonl(INADDR_ANY);
    rtp_bind.sin_port = htons(rtsp[cur_conn_num]->cmd_port.audio_rtp_ser_port);

    if ((bind(rtsp[cur_conn_num]->fd.audio_rtp_fd, (struct sockaddr *) &rtp_bind,
              sizeof(rtp_bind))) <0)
    {
        RTSP_DEBUG_PRINT ("\r\nbind rtsp server audio port error\n");
        return RTSP_FAILURE;
    }
   
    /*  Name the socket, as agreed with the server.  */
    rtp_address.sin_family = AF_INET;
    rtp_address.sin_addr.s_addr = inet_addr(host);
    rtp_address.sin_port = htons(port);
    len = sizeof(rtp_address);
    /*  Now connect our socket to the server's socket.  */

    RTSP_DEBUG_PRINT ("\r\n connecting to client with audio fd: %d ...\n",
                      rtsp[cur_conn_num]->fd.audio_rtp_fd);
    result = connect(rtsp[cur_conn_num]->fd.audio_rtp_fd,
                     (struct sockaddr *)&rtp_address, len);

    if(result == RTSP_FAILURE)
    {
        RTSP_DEBUG_PRINT("\r\nconnect artp socket error\n");
        return RTSP_FAILURE;
    }

    RTSP_DEBUG_PRINT ("\r\naudio rtp connection sucess��%s, %d\n", host, port);

    return RTSP_SUCCESS;
}
#ifdef RTCP_REPORT
S32 create_vrtcp_socket(const CHAR *host, S32 port,S32 type,S32 cur_conn_num)
{
    /*  Create a socket for the client.	*/
    S32 len;
    S32 reuse = 1;
    struct sockaddr_in rtcp_address, rtcp_bind;
    S32 result;
    rtsp[cur_conn_num]->fd.video_rtcp_fd = socket(AF_INET, type, 0);

    if (rtsp[cur_conn_num]->fd.video_rtcp_fd < 0)
    {
        return RTSP_FAILURE;
    }

    /*bind local port*/
    
    memset(&rtcp_bind, 0, sizeof(rtcp_bind));
    rtcp_bind.sin_family = AF_INET;
    rtcp_bind.sin_addr.s_addr = htonl(INADDR_ANY);
    rtcp_bind.sin_port = htons(rtsp[cur_conn_num]->cmd_port.video_rtcp_ser_port);
    result = bind(rtsp[cur_conn_num]->fd.video_rtcp_fd,
                  (struct sockaddr *) &rtcp_bind, sizeof(rtcp_bind));

    if (result < RTSP_SUCCESS)
    {
        AppDbg_Printf("\r\nbind rtsp server port error\n");
        return RTSP_FAILURE;
    }
    
    /*set address reuse*/
    result = setsockopt(rtsp[cur_conn_num]->fd.video_rtcp_fd, SOL_SOCKET,
                        SO_REUSEADDR, &reuse,sizeof(reuse));

    if (result < RTSP_SUCCESS)
    {
        return RTSP_FAILURE;
    }
    /*  Name the socket, as agreed with the server.  */
    memset(&rtcp_address, 0, sizeof(rtcp_address));
    rtcp_address.sin_family = AF_INET;
    rtcp_address.sin_addr.s_addr = inet_addr(host);
    rtcp_address.sin_port = htons(port);
    len = sizeof(rtcp_address);
    /*  Now connect our socket to the server's socket.  */
    //printf_Dbg ("\r\n connecting to client with video fd: %d ...\n",rtsp[cur_conn_num]->fd.video_rtp_fd);
    result = connect(rtsp[cur_conn_num]->fd.video_rtcp_fd,
                     (struct sockaddr *)&rtcp_address, len);

    if(result == RTSP_FAILURE)
    {
        AppDbg_Printf("\r\nconnect vrtcp socket error\n");
        return RTSP_FAILURE;
    }

    AppDbg_Printf ( "\r\n video rtcp connection sucess:%s, %d\n", host, port);

    return RTSP_SUCCESS;
}
#endif

