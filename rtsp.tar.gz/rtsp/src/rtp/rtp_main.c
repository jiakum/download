/******************************************************************************
*
*               COPYRIGHT (c) 2015-2016 GainSpan Corporation
*                         All Rights Reserved
*
* The source code contained or described herein and all documents
* related to the source code ("Material") are owned by GainSpan
* Corporation or its licensors.  Title to the Material remains
* with GainSpan Corporation or its suppliers and licensors.
*
* The Material is protected by worldwide copyright and trade secret
* laws and treaty provisions. No part of the Material may be used,
* copied, reproduced, modified, published, uploaded, posted, transmitted,
* distributed, or disclosed in any way except in accordance with the
* applicable license agreement.
*
* No license under any patent, copyright, trade secret or other
* intellectual property right is granted to or conferred upon you by
* disclosure or delivery of the Materials, either expressly, by
* implication, inducement, estoppel, except in accordance with the
* applicable license agreement.
*
* Unless otherwise agreed by GainSpan in writing, you may not remove or
* alter this notice or any other notice embedded in Materials by GainSpan
* or GainSpan's suppliers or licensors in any way.
*  @file        :  rtp_main.c
*  @brief       :  This file contains function definitions related to network
*                    such as creating sockets and reading/sending data from/to client.
********************************************************************************/
#include "rtp/rtp_thread.h"
#include "rtp/rtp.h"
#include "rtsp/rtsp.h"
#include "rtsp/rtsp_client.h"
#ifdef DOOR_BELL
#include "nano/nano.h"
extern VOID	App_RebootSoc(UINT32 ctx);
extern UINT32 curr_timestamp32;
#endif

UINT32
AppVideo_RTPTimestampGet(VOID);
S32 rtsp_freeall();

BOOL Init_timeFlag = 1;
UINT32 init_time = 0;
UINT32 prev_time = 0;
UINT32 AV_Sync = 1;
BOOL VA_Sync = 0;
#define ZERO_LENGTH_DELAY               100      // delay before getting video from encoder in ms
#define AUD_ZERO_LENGTH_DELAY           1000    // delay before getting audio from encoder in ms
#define ENC_STOP_DELAY                  2000    // delay after encoder stop in ms

extern GSN_OSAL_SEM_T SocketSyncSem;
extern UINT8 AVSync;

UINT32 AppAudio_RTPTimestampGet(U32 frame_no)
{
    UINT32 rtp_time = 0;
    UINT32 cur_time = 0;
    curr_timestamp32 = ((GsnTod_Get() * 8000) >> 15) & 0xFFFFFFFF;
    /*
    if (frame_no == 1) {
	init_time = curr_timestamp32;
        rtp_time = 0;
        Init_timeFlag = 1;
    }
    else {
    cur_time = curr_timestamp32;
        if((prev_time != 0) && (prev_time > cur_time) && (Init_timeFlag))
        {
            Init_timeFlag = FALSE;
        }

        if(Init_timeFlag)
        {
            rtp_time = (cur_time - init_time);
        }
        else
        {
            rtp_time = cur_time;
        }
        prev_time = cur_time;
    }
    */
    rtp_time = curr_timestamp32;
    //AppDbg_Printf("0-rtp_time:%u\r\n", rtp_time); 
    return rtp_time;
}

/***************************************************************
 *
 * @function    :   rtp_init
 * @param       :   S32, current free channel
 * @ret         :   S32, on SUCCESS returns 0, otherwise -1
 * @brief       :   initialize rtp(video/audio socket creation).
 *
 ***************************************************************/
extern UINT32 empty_data_flag;

S32 rtp_init(S32 free_chn)
{
    S32 returnVal;
    /*
     * Creates a socket for video which was received in setup for video
     * and connects to it.
     */
    returnVal = create_vrtp_socket(rtsp[free_chn]->cli_rtsp.cli_host,
                                   rtsp[free_chn]->cmd_port.video_rtp_cli_port,
                                   SOCK_STREAM,
                                   free_chn);

    if (returnVal < RTSP_SUCCESS)
    {
        RTSP_DEBUG_PRINT("\r\nCreate vrtp socket error! %s-%u\n",
                         rtsp[free_chn]->cli_rtsp.cli_host,
                         rtsp[free_chn]->cmd_port.video_rtp_cli_port);
        rtsp[free_chn]->rtspd_status=RTSP_VIDEO_SOCK_CREATE_FAIL;
        return RTSP_FAILURE;
    }

    rtsp[free_chn]->rtspd_status=RTSP_VIDEO_SOCK_CREATE_SUCESS;
#ifdef RTSP_AUD_EN
    /*
     * Creates a socket for audio which was received in setup for audio
     * and connects to it.
     */
    returnVal = create_artp_socket(rtsp[free_chn]->cli_rtsp.cli_host,
                                   rtsp[free_chn]->cmd_port.audio_rtp_cli_port,
                                   SOCK_STREAM,
                                   free_chn);

    if (returnVal < RTSP_SUCCESS)
    {
        RTSP_DEBUG_PRINT("\r\nCreate artp socket error! %s-%u\n",
                         rtsp[free_chn]->cli_rtsp.cli_host,
                         rtsp[free_chn]->cmd_port.audio_rtp_cli_port);
        rtsp[free_chn]->rtspd_status=RTSP_AUDIO_SOCK_CREATE_FAIL;
        return RTSP_FAILURE;
    }

    rtsp[free_chn]->rtspd_status=RTSP_AUDIO_SOCK_CREATE_SUCESS;
#endif
#ifdef RTCP_REPORT
    returnVal = create_vrtcp_socket(rtsp[free_chn]->cli_rtsp.cli_host,
                                    rtsp[free_chn]->cmd_port.video_rtcp_cli_port,
                                    SOCK_STREAM,free_chn);
    AppDbg_Printf("\r\nCreate vrtcp socket success! \n");

    if (returnVal < RTSP_SUCCESS)
    {
        AppDbg_Printf("\r\nCreate vrtcp socket error! %s-%u\n",
                      rtsp[free_chn]->cli_rtsp.cli_host,
                      rtsp[free_chn]->cmd_port.video_rtcp_cli_port);
        rtsp[free_chn]->rtspd_status=RTSP_RTCP_SOCK_CREATE_FAIL;
        return RTSP_FAILURE;
    }

    rtsp[free_chn]->rtspd_status=RTSP_RTCP_SOCK_CREATE_SUCCESS;

#endif
    return RTSP_SUCCESS;
}

/***************************************************************
 *
 * @function    :   rtp_free
 * @param       :   S32, current channel
 * @ret         :   S32, on SUCCESS returns 0 otherwise -1
 * @brief       :   closing the rtp connection.
 *
 ***************************************************************/

S32 rtp_free(S32 free_chn)
{
    soc_close(rtsp[free_chn]->fd.video_rtp_fd);

    if(rtsp[free_chn]->fd.audio_rtp_fd != 0)
    {
        soc_close(rtsp[free_chn]->fd.audio_rtp_fd);
    }

    return RTSP_SUCCESS;
}

/***************************************************************
 *
 * @function    :   RTP_Stream
 * @param1      :   None, void
 * @ret         :   void
 * @brief       :	Gets video&audio data from encoder and
					starts sending to the client.
 *
 ***************************************************************/
ULONG64 ovrd_starttime=0,ovrd_endtime,ovstrt_end,ovend_start;
UINT32 TE10us,TE1ms,TE10ms,TE100ms,TE100plusms;
UINT32 TS1ms,TS10ms,TS30ms,TS100ms,TS100plusms;
UINT32 goodpackets,badpackets,goodpackets_zer0;
UINT32 totalstreamlen;
UINT32 timestamp = 0;
#ifdef OV788_GS2000
extern AVLB_Context_t AVLB_Ctx;
#endif
extern UINT32 	initTime32 ;
extern UINT32 	prevTime32 ;
extern UINT32 	currTime32 ;
extern BOOL 	InitialFlag ;
extern BOOL 	InitialTimeFlag ;
extern ULONG64 playrcvtime;
ULONG64 difftimestream;

#ifdef OV788_GS2000
PUBLIC UINT32
AppVideo_RTPTimestampGetOV(VOID)
{

    UINT32	rtp_time = 0;
#if 1

    /* Calculate Timestamp: Provide free flowing 90K Clock */
    if (InitialFlag)
    {
        /* This case should be entered just ONCE. Just the first time. First timestamp should go ZERO. Second should be incremental difference from now ON.
        	So measuring the Initial timestamp here which will be used subsequently */

        InitialFlag = FALSE;
        rtp_time = 0;
        initTime32 = (AVLB_Ctx.timestamp);
        //AppDbg_Printf("\r\nT=[%d/%d]",AVLB_Ctx.timestamp,initTime32);
    }
    else
    {

        currTime32 = (AVLB_Ctx.timestamp);

        //AppDbg_Printf("\r\nT1=[%d/%d]",AVLB_Ctx.timestamp,currTime32);
        if((prevTime32 != 0) && (prevTime32 > currTime32) && (InitialTimeFlag))
        {
            /* This case will enter ONCE during the first rollover of LSB 32 bits of RTC time. After that the timestamp has to go as is without incremental difference.
            	*/
            InitialTimeFlag = FALSE;
        }

        if(InitialTimeFlag)
        {
            /* This case enters before and till the first rollover of LSB 32 bits of RTC time happens. We need to provide incremental difference till that time*/
            rtp_time = (currTime32 - initTime32);
        }
        else
        {
            /* This  case enters after first rollover of 32 bits after which there is no need to substract the Initial timestamp */
            rtp_time = currTime32;
        }

        prevTime32 = currTime32;

    }

#else
    rtp_time = (AVLB_Ctx.timestamp);
#endif
    //AppDbg_Printf("\r\nR=%d",rtp_time*90);
    //return (((rtp_time*1000)/11));
    return (((rtp_time/11)*1000));


}
#endif

UINT32 first_frame_flag;
#define DROP_OV_FRAMES_HIGH 0
#define DROP_OV_FRAMES_LOW  0

int framecount_drop =0 ;
#ifdef RTCP_REPORT

uint32_t sntpNsecToFraction( uint32_t
                             nsecs )  /* nanoseconds to convert to binary fraction */
{
    uint32_t factor   = 294967296;  /* Partial conversion factor from base 10 */
    uint32_t divisor  = 10;         /* Initial exponent for mantissa. */
    uint32_t mask     = 100000000;  /* Pulls digits of factor from left to right. */
    uint32_t fraction = 0;
    uint8_t     shift    = 0;      /* Shifted to avoid overflow? */
    int32_t  loop;

    /*
     * Adjust large values so that no intermediate calculation exceeds
     * 32 bits. (This test is overkill, since the fourth MSB can be set
     * sometimes, but it's fast).
     */
    if (nsecs & 0xF0000000)
    {
        nsecs >>= 4;     /* Exclude rightmost hex digit. */
        shift = TRUE;
    }

    /*
     * In order to increase portability, the following conversion avoids
     * floating point operations, so it is somewhat obscure.
     *
     * A one nanosecond increase corresponds to increasing the NTP fractional
     * part by (2^32)/1E9. Multiplying the number of nanoseconds by that value
     * (4.294967286) produces the NTP fractional part.
     *
     * The above constant is separated into integer and decimal parts to avoid
     * overflow. The mask variable selects each digit from the decimal part
     * sequentially, and the divisor shifts the digit the appropriate number
     * of decimal places.
     */
    fraction += nsecs * 4;              /* Handle integer part of conversion */

    for (loop = 0; loop < 9; loop++)    /* Nine digits in mantissa */
    {
        fraction += nsecs * (factor/mask)/divisor;
        factor %= mask;    /* Remove most significant digit from the factor. */
        mask /= 10;        /* Reduce length of mask by one. */
        divisor *= 10;     /* Increase shift by one decimal place. */
    }

    /* Scale result upwards if value was adjusted before processing. */
    if (shift)
        fraction <<= 4;

    return (fraction);
}

enum
{
    /* RTCP packets use no more than 0.5% of the bandwidth */
    rtcpTxRatioNum       = 5,
    rtcpTxRatioDen       = 1000,
    rtcpSenderReportSize = 28,
    rtcTicks5Seconds     = 655308,
    rtpVersion           = 2,
    rtpMaxHeaderLength   = 24,
    rtpDataSize          = 1408//1450 - rtpMaxHeaderLength//rtpMaxPacketLength - rtpMaxHeaderLength
};

typedef enum
{
    rtcpPacketType_fir      = 192,
    rtcpPacketType_nack,   // 193
    rtcpPacketType_smptetc,// 194
    rtcpPacketType_ij,     // 195
    rtcpPacketType_sr       = 200,
    rtcpPacketType_rr,     // 201
    rtcpPacketType_sdes,   // 202
    rtcpPacketType_bye,    // 203
    rtcpPacketType_app,    // 204
    rtcpPacketType_rtpfb,  // 205
    rtcpPacketType_psfb,   // 206
    rtcpPacketType_xr,     // 207
    rtcpPacketType_avb,    // 208
    rtcpPacketType_rsi,    // 209
    rtcpPacketType_token,  // 210
} RtcpPacketType;

typedef enum
{
    rtpHeader_bitOffset_version     = 30,
    rtpHeader_bitOffset_padToken    = 29,
    rtpHeader_bitOffset_extenToken  = 28,
    rtpHeader_bitOffset_csrcCount   = 24,
    rtpHeader_bitOffset_marker      = 23,
    rtpHeader_bitOffset_payloadType = 16,
    rtpHeader_bitOffset_sequence    = 0,
    rtpHeader_bitOffset_timestamp   = 0,
    rtpHeader_bitOffset_ssrc        = 0,
    rtpHeader_bitOffset_csrc        = 0,
    rtpHeader_bitOffset_extenId     = 16,
    rtpHeader_bitOffset_extenLength = 0,
    rtpHeader_bitOffset_extenData   = 0,
} RtpHeader_bitOffset;

typedef enum
{
    rtpHeader_wordOffset_version        = 0,
    rtpHeader_wordOffset_padToken       = 0,
    rtpHeader_wordOffset_extenToken     = 0,
    rtpHeader_wordOffset_csrcCount      = 0,
    rtpHeader_wordOffset_marker         = 0,
    rtpHeader_wordOffset_payloadType    = 0,
    rtpHeader_wordOffset_sequence       = 0,
    rtpHeader_wordOffset_timestamp      = 1,
    rtpHeader_wordOffset_ssrc           = 2,
    rtpHeader_wordOffset_csrc           = 3,
    rtpHeader_wordOffset_extenId        = 4,
    rtpHeader_wordOffset_extenLength    = 4,
    rtpHeader_wordOffset_extenData      = 5,
    rtpHeader_wordOffset_numWords,
} RtpHeader_wordOffset;

typedef enum
{
    rtcpHeader_bitOffset_version         = 30,
    rtcpHeader_bitOffset_padToken        = 29,
    rtcpHeader_bitOffset_recReportCount  = 24,
    rtcpHeader_bitOffset_sourceCount     = 24,
    rtcpHeader_bitOffset_packetType      = 16,
    rtcpHeader_bitOffset_length          = 0,
    rtcpHeader_bitOffset_ssrc            = 0,
    rtcpHeader_bitOffset_ntpTimestampMsw = 0,
    rtcpHeader_bitOffset_ntpTimestampLsw = 0,
    rtcpHeader_bitOffset_rtpTimestamp    = 0,
    rtcpHeader_bitOffset_packetCount     = 0,
    rtcpHeader_bitOffset_octetCount      = 0,
} RtcpHeader_bitOffset;

typedef enum
{
    rtcpHeader_wordOffset_version         = 0,
    rtcpHeader_wordOffset_padToken        = 0,
    rtcpHeader_wordOffset_recReportCount  = 0,
    rtcpHeader_wordOffset_sourceCount     = 0,
    rtcpHeader_wordOffset_packetType      = 0,
    rtcpHeader_wordOffset_length          = 0,
    rtcpHeader_wordOffset_ssrc            = 1,
    rtcpHeader_wordOffset_ntpTimestampMsw = 2,
    rtcpHeader_wordOffset_ntpTimestampLsw = 3,
    rtcpHeader_wordOffset_rtpTimestamp    = 4,
    rtcpHeader_wordOffset_packetCount     = 5,
    rtcpHeader_wordOffset_octetCount      = 6,
    rtcpHeader_wordOffset_numWords,
} RtcpHeaderSR_wordOffset;
typedef struct Rtp_RtcpInfo_
{
    uint64_t             lastRtcTime;
    uint32_t             packetCount;
    uint32_t             octetCount;
    uint32_t             lastOctetCount;
    BOOL                 firstPacket;
} Rtp_RtcpInfo;

void rtcpSendSenderReport(S32 cur_conn_num)
{

    enum
    {
        padToken	   = 0,
        recReportCount = 0,
        rtcpPacketBit  = 1,
        epochTimeAdj   = 2208988800,
        nanoSecToSec   = 1000000000
    };

    UINT16	   		i;
    uint32_t	   ntpMsw;
    uint32_t	   ntpLsw;
    ULONG64	   		rtcTicksInSeconds;
    uint32_t	   rtcSeconds;
    uint32_t	   rtcNanoSeconds;
    uint32_t	   senderReport[rtcpHeader_wordOffset_numWords] = { 0 };
    uint32_t	   senderReportBE[rtcpHeader_wordOffset_numWords] = { 0 };
    Rtp_RtcpInfo   rtcpInfo;
    rtcTicksInSeconds = 0;//tbp84 (double)rtcTicks * rtcTicksToNanoSeconds;
    rtcSeconds		  = rtcTicksInSeconds / nanoSecToSec;
    rtcNanoSeconds	  = rtcTicksInSeconds - (rtcSeconds * nanoSecToSec);

    ntpMsw = rtcSeconds + epochTimeAdj;
    ntpLsw = sntpNsecToFraction(rtcNanoSeconds);
    AVLB_Ctx.ssrc = rand();
    rtcpInfo.lastRtcTime = timestamp;

    senderReport[rtcpHeader_wordOffset_version] 		|= rtpVersion							  <<
            rtcpHeader_bitOffset_version;
    senderReport[rtcpHeader_wordOffset_padToken]		|= padToken 							  <<
            rtcpHeader_bitOffset_padToken;
    senderReport[rtcpHeader_wordOffset_recReportCount]	|= recReportCount						  <<
            rtcpHeader_bitOffset_recReportCount;
    senderReport[rtcpHeader_wordOffset_packetType]		|= rtcpPacketType_sr					  <<
            rtcpHeader_bitOffset_packetType;
    senderReport[rtcpHeader_wordOffset_length]			|= (rtcpHeader_wordOffset_numWords
            - 1) << rtcpHeader_bitOffset_length;
    senderReport[rtcpHeader_wordOffset_ssrc]			|= AVLB_Ctx.ssrc						  <<
            rtcpHeader_bitOffset_ssrc;
    senderReport[rtcpHeader_wordOffset_ntpTimestampMsw] |= ntpMsw								  <<
            rtcpHeader_bitOffset_ntpTimestampMsw;
    senderReport[rtcpHeader_wordOffset_ntpTimestampLsw] |= ntpLsw								  <<
            rtcpHeader_bitOffset_ntpTimestampLsw;
    senderReport[rtcpHeader_wordOffset_rtpTimestamp]	|= timestamp 					<<
            rtcpHeader_bitOffset_rtpTimestamp;
    //	senderReport[rtcpHeader_wordOffset_packetCount] 	|= rtpStream->rtcpInfo.packetCount		  << rtcpHeader_bitOffset_packetCount;
    //	senderReport[rtcpHeader_wordOffset_octetCount]		|= rtpStream->rtcpInfo.octetCount		  << rtcpHeader_bitOffset_octetCount;

    for( i = 0; i < rtcpHeader_wordOffset_numWords; ++i )
    {
        senderReportBE[i] = htonl(senderReport[i]);
    }

    //	AppDbg_Printf("senderReportBuffer: buflen %u", sizeof(senderReportBE));
    //rtsp[cur_conn_num]->nalu_buffer;
    if ((tcp_write(rtsp[cur_conn_num]->fd.video_rtcp_fd,senderReportBE,
                   sizeof(senderReportBE)))< RTSP_SUCCESS)
    {
        AppDbg_Printf("\r\nRTCPSend failed = %d\n",
                      rtsp[cur_conn_num]->fd.video_rtcp_fd);
    }

    return;
}

#endif

#ifdef DOOR_BELL
VOID
RTP_VStream ()
{
	S32 cur_conn_num = 0;
	UINT32 streamLen = 0, video_timestamp = 0;
	unsigned char *streamPtr;
	int status, marker = 0;
	UINT8 Teardown = 0;
	char pkt_type;
	unsigned int v_cnt = 0, v_num = 0;
#ifdef SEND_SPS_PPS
	int firstFlag = 1;
#endif
#ifdef DEBUG_INFO_PRINT_LOCAL
	AppDbg_Printf ("\r\n waiting for client play request...\n");
#endif
	while (1)
	{
		if (Teardown == 1 && rtsp[cur_conn_num]->is_runing == STREAM_IDLE) {
			GsnTaskSleep (100);
		} else {
			if((rtsp[cur_conn_num]->is_runing == STREAM_IDLE) && (rtsp[cur_conn_num]->fd.video_rtp_fd == 0)) {
				GsnTaskSleep (100);
				continue;
			}      
			Teardown = 0;
			first_frame_flag=1;
#ifndef DOOR_BELL
/*			status = VENC_SetResolution (0);
			status = VENC_SetBitrate (1);
			status = VENC_SetFramerate (0);*/
#endif
      status = VENC_SetFramerate(FR_15);
			if (status != AVLB_SUCCESS)
			{
				AppDbg_Printf ("\r\nVENC Start failed.\n");
				rtsp[cur_conn_num]->fd.video_rtp_fd = 0;
				return;
			}
      status = VENC_SetBitrate(BR_512K);
			if (status != AVLB_SUCCESS)
			{
				AppDbg_Printf ("\r\nVENC Start failed.\n");
				rtsp[cur_conn_num]->fd.video_rtp_fd = 0;
				return;
			}
			status = VENC_Status(VE_Start);
			if (status != AVLB_SUCCESS)
			{
				AppDbg_Printf ("\r\nVENC Start failed.\n");
				rtsp[cur_conn_num]->fd.video_rtp_fd = 0;
				return;
			}
			else
				AppDbg_Printf ("\r\nVENC Start success.\n");
			/* This sleep is to avoid initial zero length frames from encoder */

			GsnTaskSleep (ZERO_LENGTH_DELAY);

#ifdef DEBUG_INFO_PRINT_LOCAL
			AppDbg_Printf ("\r\nVideo Info: Video init Passed.\n");
#endif
			while (1) {
				if((rtsp[cur_conn_num]->is_runing == STREAM_IDLE)) {
#ifdef DEBUG_STATS_LOCAL
					AppDbg_Printf ("\r\n Teardown received..\n");

					AppDbg_Printf ("\r\n************ Video Statistics************\n");
					AppDbg_Printf ("\r\nvalid length video frames:%u\n", v_num);
					AppDbg_Printf ("\r\nzero  lenth video frames:%u\n", v_cnt);
					AppDbg_Printf ("\r\n****************************************\n");
#endif
					v_num = v_cnt = 0;
					Teardown = 1;
					framecount_drop =0;
					VA_Sync = 1;
#ifdef SEND_SPS_PPS
					firstFlag = 1;
#endif
					break;
				}
				if (VA_Sync) {
					GsnTaskSleep (1);
					continue;
				}
				VA_Sync = 1;
#if 0
				// Get Video Data
				//TE10us,TE1ms,TE10ms,TE100ms,TE100plusms
				if(ovrd_starttime==0)
				{
					ovrd_starttime = GsnSoftTmr_CurrentSystemTime();
					if (first_frame_flag)
					{
						difftimestream =  SYSTIME_TO_USEC((ovrd_starttime - playrcvtime));
#ifdef DEBUG_STATS_LOCAL
						AppDbg_Printf("DT=%lld",difftimestream);
#endif
					}

				}
#endif
				status = Get_VStream(&streamPtr, &streamLen, &pkt_type);
#if 0
				//TS1ms,TS10ms,TS50ms,TS100ms,TS100plusms
				if (status==0)
				{
					if (streamLen)
					{
						totalstreamlen+=streamLen;
						goodpackets++;
						ovrd_endtime = GsnSoftTmr_CurrentSystemTime();

						ovstrt_end = SYSTIME_TO_USEC((ovrd_endtime-ovrd_starttime));
						if (first_frame_flag)
						{
						//	AppDbg_Printf("\r\nTR =%lld ",ovstrt_end);
#ifdef RTCP_REPORT
							rtcpSendSenderReport(cur_conn_num);
#endif
						}
						ovrd_starttime=0;
						if(ovstrt_end<1000)
							TS1ms++;
						else if(ovstrt_end<10000)
							TS10ms++;
						else if(ovstrt_end<30000)
							TS30ms++;
						else if(ovstrt_end<100000)
							TS100ms++;
						else
							TS100plusms++;
					}

				}
				else
				{

					if (empty_data_flag)
					{
						empty_data_flag =0;
						//GsnTaskSleep(5);
						goodpackets_zer0++;
					}
					else
					{
						badpackets++;
					}
				}

#endif
				if (status < AVLB_SUCCESS || status == 1)
				{
					AppDbg_Printf ("\r\nVideo Debug: GetVideo Failed = %d ", status);
					v_cnt += 1;
					continue;
				}

				/* If the packet is single packet/ end packet set marker bit */
				if ((pkt_type == SINGLE_PKT) || (pkt_type == END_PKT)) {
					marker = 1;
					v_num += 1;
				} else {
					marker = 0;
					AV_Sync = 1;
				}
				/* Reading timestamp only if the video packet is single packet
				 * (or) start packet for big frame.
				 */
				if ((pkt_type == SINGLE_PKT) || (pkt_type == START_PKT))
				{
					video_timestamp = AppVideo_RTPTimestampGet();
					AV_Sync = 0;
				}

				/* Frames RTP packets and send to the client.*/
				if (rtsp[cur_conn_num]->fd.video_rtp_fd != 0)
				{
					framecount_drop++;
#ifdef SEND_SPS_PPS
					if (firstFlag == 1) {
						UINT8 ov_sps[] = {0x00, 0x00, 0x00, 0x01, 0x67, 0x4d, 0x00, 0x28, 0xa9, 0x50, 0x0a, 0x00, 0xb7, 0x20, 0x00, 0x00};
						UINT8 ov_pps[] = {0x00, 0x00, 0x00, 0x01, 0x68, 0xee, 0x3c, 0x80, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00};
						send_frame_on_rtp_nw (ov_sps, sizeof(ov_sps), 0, marker, video_timestamp);
						send_frame_on_rtp_nw (ov_pps, sizeof(ov_pps), 0, marker, video_timestamp);
						firstFlag = 0;
					}
					if (streamPtr[4] == 0x67) {
						streamPtr += 32;
						streamLen -= 32;
					}
#endif
					if((framecount_drop>DROP_OV_FRAMES_HIGH) || (framecount_drop<DROP_OV_FRAMES_LOW))
					{
            GsnOsal_SemAcquire(&SocketSyncSem, GSN_OSAL_WAIT_FOREVER);
						status = send_frame_on_rtp_nw(streamPtr, streamLen, 0, marker,video_timestamp);
            GsnOsal_SemRelease(&SocketSyncSem);
						if (status != 0)
						{
							AppDbg_Printf ("\r\nsending frame on nw failed = %d ", status);
							break ;
						}
					}
				}
			}
			//rtsp_freeall();
			status = VENC_Status (VE_Stop);
            GsnTaskSleep (ENC_STOP_DELAY);
			if (status != AVLB_SUCCESS) {
				AppDbg_Printf ("\r\nVENC_Status stop failed.\n");
			}
      else {
        AppDbg_Printf ("\r\nVENC_Status stop success.\n");
      }
		}
	} /* __While__*/
}

#ifdef RTSP_AUD_EN
VOID RTP_AStream ()
{
	S32 cur_conn_num = 0;
	UINT32 streamLen = 0, audio_timestamp = 0;
	unsigned char *streamPtr;
	int status, marker = 1;
	UINT8 Teardown = 0;
	unsigned int a_cnt = 0, a_num = 0;
	unsigned short int *sample_temp;
	int nth_sample;
#ifdef DEBUG_INFO_PRINT_LOCAL
	AppDbg_Printf ("\r\n waiting for client audio play request...\n");
#endif
	while (1)
	{
		if (Teardown == 1 && rtsp[cur_conn_num]->is_runing == STREAM_IDLE) {
      GsnTaskSleep (100);
		} else {
			if((rtsp[cur_conn_num]->is_runing == STREAM_IDLE) && (rtsp[cur_conn_num]->fd.audio_rtp_fd == 0)) {
				GsnTaskSleep (100);
				continue;
			}      
			Teardown = 0;
			first_frame_flag=1;
      
			status = AENC_Status(AE_Start);
			if (status != AVLB_SUCCESS) {
				AppDbg_Printf ("\r\nAENC Start failed.\n");
				rtsp[cur_conn_num]->fd.audio_rtp_fd = 0;
				return;
			}
			else
				AppDbg_Printf ("\r\nAENC Start success\n");

			/* This sleep is to avoid initial zero length frames from encoder */
			GsnTaskSleep (AUD_ZERO_LENGTH_DELAY);
#ifdef DEBUG_INFO_PRINT_LOCAL
			AppDbg_Printf ("\r\nAudio Info: Audio init Passed.\n");
#endif
			while (1) {
				if((rtsp[cur_conn_num]->is_runing == STREAM_IDLE)) {
#ifdef DEBUG_STATS_LOCAL
					AppDbg_Printf ("\r\n Teardown received..\n");

					AppDbg_Printf ("\r\n************ Audio Statistics************\n");
					AppDbg_Printf ("\r\nvalid length audio frames:%u\n", a_num);
					AppDbg_Printf ("\r\nzero  lenth audio frames:%u\n", a_cnt);
					AppDbg_Printf ("\r\n****************************************\n");
#endif
					a_num = a_cnt = 0;
					Teardown = 1;
					if (Teardown == 1) {
					  //rtsp_freeall();            
					  status = AENC_Status (AE_Stop);
            GsnTaskSleep (ENC_STOP_DELAY);
					  if (status != AVLB_SUCCESS) {
					    AppDbg_Printf ("\r\nAENC_Status stop failed.\n");
					  } else {
              AppDbg_Printf ("\r\nAENC_Status stop success.\n");
            }            
					}
					framecount_drop =0;
					break;
				}
				if (AV_Sync) {
					GsnTaskSleep (1);
					continue;
				}
				/* Gets Audio data */
				status = Get_AStream (&streamPtr, &streamLen);
				if (status < AVLB_SUCCESS || status == 1) {
					AppDbg_Printf ("\r\nAudio Debug:Get_audio failed:%d\n", status);
					a_cnt = a_cnt + 1;
					continue;
				}
				a_num = a_num+1;
				audio_timestamp = AppAudio_RTPTimestampGet(a_num);
				AV_Sync = 1;
				VA_Sync = 0;
#ifdef AUDIO_PCM
				/* Framing each sample is in network Byte order
				 * In this Audio data one sample is represented by 2Bytes (16bits)
				 * Converting the entire frame in to network Byte order samples
				 */
				sample_temp = (unsigned short int *)streamPtr;
				for (nth_sample = 0; nth_sample < (streamLen/2); nth_sample++)
				{
					sample_temp[nth_sample] = ((sample_temp[nth_sample]&HIGH_BYTE) >> 8) | ((sample_temp[nth_sample]&LOW_BYTE) << 8);
				}
#endif
				/* Sending to the client by framing as RTP packets */
        GsnOsal_SemAcquire(&SocketSyncSem, GSN_OSAL_WAIT_FOREVER);
				status = send_frame_on_rtp_nw(streamPtr, streamLen, 1, marker, audio_timestamp);
        GsnOsal_SemRelease(&SocketSyncSem);
				if (status != 0) {
					AppDbg_Printf ("\r\nsending frame on nw failed = %d ", status);
					break ;
				}
			}
		}
	}
}
#endif
#endif
