/******************************************************************************
*
*               COPYRIGHT (c) 2015-2016 GainSpan Corporation
*                         All Rights Reserved
*
* The source code contained or described herein and all documents
* related to the source code ("Material") are owned by GainSpan
* Corporation or its licensors.  Title to the Material remains
* with GainSpan Corporation or its suppliers and licensors.
*
* The Material is protected by worldwide copyright and trade secret
* laws and treaty provisions. No part of the Material may be used,
* copied, reproduced, modified, published, uploaded, posted, transmitted,
* distributed, or disclosed in any way except in accordance with the
* applicable license agreement.
*
* No license under any patent, copyright, trade secret or other
* intellectual property right is granted to or conferred upon you by
* disclosure or delivery of the Materials, either expressly, by
* implication, inducement, estoppel, except in accordance with the
* applicable license agreement.
*
* Unless otherwise agreed by GainSpan in writing, you may not remove or
* alter this notice or any other notice embedded in Materials by GainSpan
* or GainSpan's suppliers or licensors in any way.
*  @file        :  rtp_thread.c
*  @brief       :  This file contains functions definitions for
*					creating a thread for rtp section.
********************************************************************************/

#include "AVLB/AVLB_def.h"
#include "rtp/rtp_thread.h"

PRIVATE GSN_AVLB_RTP_SERVER_TCB V_RTPServerTcb;
PRIVATE UINT8  V_RTPServerTask_Stack[AVLB_RTP_SERVER_STACK_SIZE];
#ifdef RTSP_AUD_EN
PRIVATE GSN_AVLB_RTP_SERVER_TCB A_RTPServerTcb;
PRIVATE UINT8  A_RTPServerTask_Stack[AVLB_RTP_SERVER_STACK_SIZE];

/***************************************************************
 *
 * @function    :   AudioRTPThreadStart
 * @param       :   none(void)
 * @ret         :   S32, on SUCCESS returns 0 otherwise -1
 * @brief       :   Creaates a thread for RTP server task.
 *
 ***************************************************************/

S32 AudioRTPThreadStart ()
{
	int ret;

	ret = GsnOsal_ThreadCreate(rtp_server_task_Audio,
			0 ,
			&A_RTPServerTcb.rtpServerTask_tcb,
			"RTP Task",
			19,//AVLB_RTP_SERVER_TASK_PRIORITY,
			A_RTPServerTask_Stack,
			sizeof(A_RTPServerTask_Stack),
			GSN_OSAL_THREAD_INITIAL_READY
			);
	if (ret != RTSP_SUCCESS) {
		AppDbg_Printf ("\r\nAudio Thread creation failed in RTPThreadStart.\n");
	} else {
#ifdef DEBUG_INFO_PRINT_LOCAL
		AppDbg_Printf ("\r\n Audio RTP task thread created successfully.\n");
#endif
	}

	return RTSP_SUCCESS;
}

/***************************************************************
 *
 * @function    :   rtp_server_task_Audio
 * @param       :   None, void
 * @ret         :   S32, on SUCCESS returns 0 otherwise -1
 * @brief       :   rtp server task.
 *
 ***************************************************************/

VOID rtp_server_task_Audio (UINT32 arg)
{
	RTP_AStream();

	while (1) {
		GsnTaskSleep (30000);
	}
}
#endif

/***************************************************************
 *
 * @function    :   VideoRTPThreadStart
 * @param       :   none(void)
 * @ret         :   S32, on SUCCESS returns 0 otherwise -1
 * @brief       :   Creaates a thread for RTP server task.
 *
 ***************************************************************/

S32 VideoRTPThreadStart ()
{
	int ret;

	ret = GsnOsal_ThreadCreate(rtp_server_task_Video,
			0 ,
			&V_RTPServerTcb.rtpServerTask_tcb,
			"RTP Task",
			20,//AVLB_RTP_SERVER_TASK_PRIORITY,
			V_RTPServerTask_Stack,
			sizeof(V_RTPServerTask_Stack),
			GSN_OSAL_THREAD_INITIAL_READY
			);
	if (ret != RTSP_SUCCESS) {
		AppDbg_Printf ("\r\nThread creation failed in RTPThreadStart.\n");
	} else {
#ifdef DEBUG_INFO_PRINT_LOCAL
        AppDbg_Printf ("\r\nRTP task thread created successfully.\n");
#endif
    }

    return RTSP_SUCCESS;
}

/***************************************************************
 *
 * @function    :   rtp_server_task_Video
 * @param       :   None, void
 * @ret         :   S32, on SUCCESS returns 0 otherwise -1
 * @brief       :   rtp server task.
 *
 ***************************************************************/

VOID rtp_server_task_Video (UINT32 arg)
{
	RTP_VStream();

    while (1)
    {
        GsnTaskSleep (30000);
    }
}