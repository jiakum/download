/******************************************************************************
*
*               COPYRIGHT (c) 2015-2016 GainSpan Corporation
*                         All Rights Reserved
*
* The source code contained or described herein and all documents
* related to the source code ("Material") are owned by GainSpan
* Corporation or its licensors.  Title to the Material remains
* with GainSpan Corporation or its suppliers and licensors.
*
* The Material is protected by worldwide copyright and trade secret
* laws and treaty provisions. No part of the Material may be used,
* copied, reproduced, modified, published, uploaded, posted, transmitted,
* distributed, or disclosed in any way except in accordance with the
* applicable license agreement.
*
* No license under any patent, copyright, trade secret or other
* intellectual property right is granted to or conferred upon you by
* disclosure or delivery of the Materials, either expressly, by
* implication, inducement, estoppel, except in accordance with the
* applicable license agreement.
*
* Unless otherwise agreed by GainSpan in writing, you may not remove or
* alter this notice or any other notice embedded in Materials by GainSpan
* or GainSpan's suppliers or licensors in any way.
*  @file        :  socket.c
*  @brief       :  This file contains function definitions related to network
*                    such as creating sockets and reading/sending data from/to client.
********************************************************************************/

#include "AVLB/AVLB_def.h"
#include "rtp/rtp_thread.h"
#include "rtsp/rtsp.h"
#include "osal/gsn_osal_threadx.h"
#include "app_events.h"
#include "net/socket.h"
#ifdef DOOR_BELL
#include "nano/nano.h"
#ifdef DBEL_PW_MODE
#include "power_mode/power_mode.h"
#endif
#endif

#define SOCK_RXTOUT_MSI 3000

PUBLIC VOID
AppMainCtx_TaskNotify(INT32 msgId, UINT32 msgInfo);
S32 rtp_init(S32 free_chn);
extern uint8_t SPI_BUSY_FLAG ;
/***************************************************************
 *
 * @function    :   create_sercmd_socket
 * @param1      :   host-> name of host to which connection is desired.
 * @param2      :   port-> port associated with the desired port.
 * @param3      :   type-> SOCK_STREAM or SOCK_DGRAM
 * @ret         :   S32, on SUCCESS returns 0, otherwise -1
 * @brief       :   creates socket for server.
 *
 ***************************************************************/

S32 create_sercmd_socket(const CHAR *host, const CHAR *port,S32 type)
{
    /*  Create a socket for the server.  */
    S32  reuse=1;
    int ret;
    struct sockaddr_in server_address;

    if(!host)
    {
        return RTSP_FAILURE;
    }

    /* create a socket and collect descriptor */
    RTSP_DEBUG_PRINT("\r\nSocket.c : Host name is : %s, port:%s\n",host, port);

    rtsp[0]->fd.rtspfd = socket(AF_INET, type, 0);

    if(rtsp[0]->fd.rtspfd<0)
    {
        RTSP_DEBUG_PRINT("\r\nsocket() error in create_sercmd_socket.\n" );
        return RTSP_FAILURE;
    }
    else
    {
        RTSP_DEBUG_PRINT ("\r\nsocket success with fd:%d\n",rtsp[0]->fd.rtspfd);
    }

    /* bind the socket with INET addr */
    memset(&server_address, 0, sizeof(server_address));
    server_address.sin_family = AF_INET;
    server_address.sin_addr.s_addr = inet_addr(host);
    server_address.sin_port = htons(atoi(port));
    ret = bind(rtsp[0]->fd.rtspfd,(struct sockaddr *)&server_address,
               sizeof (struct sockaddr_in));

    if (ret < RTSP_SUCCESS)
    {
        RTSP_DEBUG_PRINT("\r\nSocket.c : Bind ERR value = %d\n",ret);
        return RTSP_FAILURE;
    }
    else
    {
        RTSP_DEBUG_PRINT ("\r\nbind Success.\n");
    }

    /* listen for any client - connection request */
    ret = listen(rtsp[0]->fd.rtspfd,5);

    if (ret < RTSP_SUCCESS)
    {
        RTSP_DEBUG_PRINT ("\r\nlisten failed: %d\n", ret);
        return RTSP_FAILURE;
    }
    else
    {
        RTSP_DEBUG_PRINT ("\r\nlisten Success.\n");
    }

    /* set address reuse */
    (void) setsockopt(rtsp[0]->fd.rtspfd, SOL_SOCKET, SO_REUSEADDR, &reuse,
                      sizeof(reuse));
    /* accept the client request */
    tcp_accept();
    return RTSP_SUCCESS;
}

/***************************************************************
 *
 * @function    :   rtsp_cmd_match
 * @param1      :   method -> the method which is going to handle.
 * @param2      :   cur_conn_num -> current connection number
 * @ret         :   S32, on SUCCESS returns 0, otherwise -1
 * @brief       :   Handling the corresponding requested method.
 *
 ***************************************************************/

S32 rtsp_cmd_match(S32 method, S32 cur_conn_num)
{
    memset(rtsp[cur_conn_num]->out_buffer, 0,
           sizeof(rtsp[cur_conn_num]->out_buffer));

    switch(method)
    {
        case RTSP_OPTIONS:
            if(rtsp_options(cur_conn_num)<=RTSP_SUCCESS)
            {
                RTSP_DEBUG_PRINT("\r\nOPTIONS response not sucessfull(:\n");
                soc_close(rtsp[cur_conn_num]->cli_rtsp.cli_fd);
                rtsp[cur_conn_num]->rtspd_status=RTSP_OPTIONS_FAIL;
                rtsp[cur_conn_num]->is_runing=STREAM_IDLE;
                return RTSP_FAILURE;
            }
            else
            {
                RTSP_DEBUG_PRINT ("\r\nOPTIONS response  sucessfull. :)\n");
                rtsp[cur_conn_num]->rtspd_status=RTSP_OPTIONS_SUCESS;
            }

            break;

        case RTSP_DESCRIBE:
            if(rtsp_describe(cur_conn_num)<=RTSP_SUCCESS)
            {
                RTSP_DEBUG_PRINT("\r\nDESCRIBE response not sucessfull(:\n");
                soc_close(rtsp[cur_conn_num]->cli_rtsp.cli_fd);
                rtsp[cur_conn_num]->rtspd_status=RTSP_DESCRIBE_FAIL;
                rtsp[cur_conn_num]->is_runing=STREAM_IDLE;
                return RTSP_FAILURE;
            }
            else
            {
                RTSP_DEBUG_PRINT ("\r\nDESCRIBE response sucessfull:)\n");
                rtsp[cur_conn_num]->rtspd_status=RTSP_DESCRIBE_SUCESS;
            }

            break;

        case RTSP_SETUP:
            if(rtsp_setup(cur_conn_num)<=RTSP_SUCCESS)
            {
                RTSP_DEBUG_PRINT("\r\nSETUP response not sucessfull(:\n");
                soc_close(rtsp[cur_conn_num]->cli_rtsp.cli_fd);
                rtsp[cur_conn_num]->rtspd_status=RTSP_SETUP_FAIL;
                rtsp[cur_conn_num]->is_runing=STREAM_IDLE;
                return RTSP_FAILURE;
            }
            else
            {
                RTSP_DEBUG_PRINT ("\r\nSETUP response  sucessfull:)\n");
                rtsp[cur_conn_num]->rtspd_status=RTSP_SETUP_SUCESS;
            }

            break;

        case RTSP_PLAY:
            if(rtsp_play(cur_conn_num)<=RTSP_SUCCESS)
            {
                RTSP_DEBUG_PRINT("\r\nPLAY response not sucessfull(:\n");
                soc_close(rtsp[cur_conn_num]->cli_rtsp.cli_fd);
                rtsp[cur_conn_num]->rtspd_status=RTSP_PLAY_FAIL;
                rtsp[cur_conn_num]->is_runing=STREAM_IDLE;
                return RTSP_FAILURE;
            }
            else
            {
                RTSP_DEBUG_PRINT ("\r\nPLAY response sucessfull :)\n");
#ifdef OV788_HIDESSID
                AppMainCtx_TaskNotify (APP_EVENT_HIDESSID, 0);
#endif
                rtsp[cur_conn_num]->rtspd_status = RTSP_PLAY_SUCESS;
#ifdef DOOR_BELL
		//nano_issue_command(CMD_GS_LIVE_STRM_START);
#ifdef DBEL_PW_MODE
		PW_cntrl_TaskNotify(ON_DEMAND_STRM_START, cur_conn_num);
#else
				if( SPI_BUSY_FLAG  == TRUE)
					GsnTaskSleep(300);
				SPI_BUSY_FLAG = TRUE;
                /* Initialisinng the rtp section */
				if(rtsp[cur_conn_num]->is_runing == STREAM_IDLE) {
					RTSP_DEBUG_PRINT ("\r\nRTP Initialise ....\n");
					rtp_init(cur_conn_num);
				}
                /* updating rtsp server state from idle to running state */
                rtsp[cur_conn_num]->is_runing = STREAM_RUNNING;
#endif
#endif
#ifdef GEO_SPI_READ_CLOSE
                AppMainCtx_TaskNotify (APP_EVENT_SPI_READ, 0);
#endif
            }

            break;

        case RTSP_TEARDOWN:
            if(rtsp_teardown(cur_conn_num)<=RTSP_SUCCESS)
            {
                SPI_BUSY_FLAG = FALSE;
                RTSP_DEBUG_PRINT("\r\nTEARDOWN response not sucessfull(:\n");
                soc_close(rtsp[cur_conn_num]->cli_rtsp.cli_fd);
                soc_close(rtsp[cur_conn_num]->fd.video_rtp_fd);
                rtsp[cur_conn_num]->fd.video_rtp_fd=0;
#ifdef DOOR_BELL
                //nano_issue_command(CMD_GS_LIVE_STRM_STOP);
#endif
                if(rtsp[cur_conn_num]->fd.audio_rtp_fd != 0)
                {
                    soc_close(rtsp[cur_conn_num]->fd.audio_rtp_fd);
                    rtsp[cur_conn_num]->fd.audio_rtp_fd=0;
                }

                rtsp[cur_conn_num]->rtspd_status=RTSP_TEARDOWN_FAIL;
                rtsp[cur_conn_num]->is_runing=STREAM_IDLE;
#ifdef DBEL_PW_MODE
		PW_cntrl_TaskNotify(STRM_STOP, 0);
#endif
                return RTSP_FAILURE;
            }
            else
            {
                SPI_BUSY_FLAG = FALSE;
                RTSP_DEBUG_PRINT ("\r\nTEARDOWN response sucessfull:)\n");
                rtsp[cur_conn_num]->is_runing=STREAM_IDLE;
                soc_close(rtsp[cur_conn_num]->cli_rtsp.cli_fd);
                soc_close(rtsp[cur_conn_num]->fd.video_rtp_fd);
                rtsp[cur_conn_num]->fd.video_rtp_fd=0;
#ifdef DOOR_BELL
		//nano_issue_command(CMD_GS_LIVE_STRM_STOP);
#endif
                if(rtsp[cur_conn_num]->fd.audio_rtp_fd != 0)
                {
                    soc_close(rtsp[cur_conn_num]->fd.audio_rtp_fd);
                    rtsp[cur_conn_num]->fd.audio_rtp_fd=0;
                }
#ifdef OV788_HIDESSID
                AppMainCtx_TaskNotify (APP_EVENT_SHOWSSID, 0);
#endif
#ifdef GEO_SPI_READ_CLOSE
                AppMainCtx_TaskNotify(APP_EVENT_SPI_CLOSE, 0);
#endif
                //App_AudioTransmissionStop();
                rtsp[cur_conn_num]->rtspd_status=RTSP_TEARDOWN_SUCESS;
#ifdef DBEL_PW_MODE
		PW_cntrl_TaskNotify(STRM_STOP, 0);
#endif
                return RTSP_FAILURE;
            }

            break;

		case RTSP_PAUSE:
			/* Currently proxyserver sends TEARDOWN to doorbell, if it sends PAUSE
			 * command then from system side need to take care LED indication
			 * and snapshot scheme */
			RTSP_DEBUG_PRINT("\r\nPAUSE response successfull\n");
			rtsp[cur_conn_num]->is_runing = STREAM_PAUSE;

			break;

        default:
            RTSP_DEBUG_PRINT("\r\nNO MATCH RTSP command Found!!!\n");
            break;
    }
    
    return RTSP_SUCCESS;
}

/***************************************************************
 *
 * @function    :   vd_rtsp_proc
 * @param1      :   arg -> pointing to the current connection number.
 * @ret         :   VOID -> returns NULL
 * @brief       :   which reads data from client and
 *                  gets the method and send to method handler.
 *
 ***************************************************************/

void *vd_rtsp_proc(void *arg)
{
    S32 method,free_conn=0;
    S32 tcp_readlen = 0;

    free_conn=(S32)arg;

    int i;

    /*
     * Receive data from the current socket connection, in loop till data available
     * socket connection number should not exceed the max connection number
     */
    for(i = free_conn; i<MAX_CONN;)
    {
        memset(rtsp[i]->in_buffer,0,sizeof(rtsp[i]->in_buffer));
        tcp_readlen = recv (rtsp[i]->cli_rtsp.cli_fd, rtsp[i]->in_buffer,
                            sizeof(rtsp[i]->in_buffer),MSG_DONTWAIT);
        RTSP_DEBUG_PRINT ("\r\nclient connected with fd is:%d\n", rtsp[i]->cli_rtsp.cli_fd);

        /*
         * If no data available to read,
         * break the connection,
         * free the connection number and other resources
         */
        if(tcp_readlen <= 0)
        {
            set_free_conn_status(i,0);
            soc_close(rtsp[i]->cli_rtsp.cli_fd);
            rtsp[i]->cli_rtsp.cli_fd = 0;

            rtsp[i]->is_runing=STREAM_IDLE;
            soc_close(rtsp[i]->fd.video_rtp_fd);
            rtsp[i]->fd.video_rtp_fd=0;

            if(rtsp[i]->fd.audio_rtp_fd != 0)
            {
                soc_close(rtsp[i]->fd.audio_rtp_fd);
                rtsp[i]->fd.audio_rtp_fd=0;
            }
#ifdef DOOR_BELL
            //nano_issue_command(CMD_GS_LIVE_STRM_STOP);
#endif
            RTSP_DEBUG_PRINT("\r\nError on socket, breaking here\n");
            break;
        }

        //RTSP_DEBUG_PRINT ("\r\ntcp read_length:%d\n", tcp_readlen);
        /* Get the received RTSP command - Eg: OPTIONS, DESCRIBE, SETUP, PLAY and TEARDOWN */
        method=get_rtsp_method(i);

        /*
         * If any unsupported method requested by the client, ignores it.
         */
        if(method == RTSP_METHOD_UNSUPPORTED)
        {
            continue;
        }

        /* Match and verify the received RTSP response and handle it */
        if(rtsp_cmd_match(method,i) < 0)
        {
            break;
        }
    }

    return NULL;
}

/***************************************************************
 *
 * @function    :   set_free_conn_status
 * @param1      :   cur_conn_num -> current connection number
 * @param2      :   cur_status -> status which is going to be set
 * @ret         :   S32, on SUCCESS returns 0, otherwise -1
 * @brief       :   set the given status to the corresponding channel.
 *
 ***************************************************************/

S32 set_free_conn_status(S32 cur_conn, S32 cur_status)
{
    S32 i;

    for(i=0; i<MAX_CONN; i++)
    {
        if((i==cur_conn))
        {
            rtsp[i]->conn_status=cur_status;
        }
    }

    return RTSP_SUCCESS;
}

/***************************************************************
 *
 * @function    :   get_free_conn_status
 * @param1      :   void
 * @ret         :   S32 -> on SUCCESS returns free channel number,
 *                  otherwise -1
 * @brief       :   gets free connection status.
 *
 ***************************************************************/

S32 get_free_conn_status()
{
    S32 i;

    for(i=0; i<MAX_CONN; i++)
    {
        if(rtsp[i]->conn_status==0)
        {
            return i;
        }
    }

    return RTSP_SUCCESS;
}

/***************************************************************
 *
 * @function    :   tcp_accept
 * @param1      :   void
 * @ret         :   None, void
 * @brief       :   accepts client connection request.
 *
 ***************************************************************/

void tcp_accept()
{
    S32 client_len,free_conn=0;
    struct sockaddr_in client_address;
	fd_set fdSet;
	struct timeval timeout;

	timeout.tv_sec = (long)SOCK_RXTOUT_MSI/1000;
	timeout.tv_usec = ((long)SOCK_RXTOUT_MSI - timeout.tv_sec*1000)*1000;

    /* Check for the new connection availability */
    free_conn = get_free_conn_status();

    if(free_conn == RTSP_FAILURE)
    {
        RTSP_DEBUG_PRINT("\r\nwaring: maximum number of connections\n");
        return;
    }

    rtsp[free_conn]->cli_rtsp.conn_num=free_conn;
    client_len = sizeof(client_address);

    while (1)
    {
        RTSP_DEBUG_PRINT("\r\nAbout to accept connection  FD = %d\n",
                         rtsp[0]->fd.rtspfd);

		free_conn = get_free_conn_status();
        /* Accept the connection until it succeed */
        while(1)
        {
			GsnTaskSleep(100);
			{
				FD_ZERO(&fdSet);
				FD_SET(rtsp[0]->fd.rtspfd, &fdSet);
				if(select(rtsp[0]->fd.rtspfd + 1, &fdSet, NULL, NULL, &timeout) > 0) {
					if(FD_ISSET((unsigned int)rtsp[0]->fd.rtspfd, &fdSet)) {
						rtsp[free_conn]->cli_rtsp.cli_fd=
							accept(rtsp[0]->fd.rtspfd,(struct sockaddr *) &client_address, &client_len);
							if(rtsp[free_conn]->cli_rtsp.cli_fd > 0) {
								RTSP_DEBUG_PRINT("\r\n*** local socket *** \n");
								break;
							}
					}
				}
			}
        }

        RTSP_DEBUG_PRINT ("\r\nSocket.c : Accept return value = %d\n",
                          rtsp[free_conn]->cli_rtsp.cli_fd);
        /* Decrement the number of available connections by 1 */
        set_free_conn_status(free_conn,1);
        /* update the client address after accepting the connection */
		{
			strcpy(rtsp[free_conn]->cli_rtsp.cli_host,inet_ntoa(client_address.sin_addr));
		}
		rtsp[free_conn]->rtspd_status = RTSP_CLIENT_CONNECTED;
        /* RTSP communication process */
        vd_rtsp_proc ((void *)free_conn);
    }
}

/***************************************************************
 *
 * @function    :   tcp_write
 * @param1      :   fd -> the data which is going to send to fd.
 * @param2      :   buf -> Holds the starting address of the data
 *                  which is going to send.
 * @param3      :   length -> the length of the data going to send.
 * @ret         :   S32 -> returns total no of Bytes written.
 * @brief       :   accepts client connection request.
 *
 ***************************************************************/

S32 tcp_write(S32 fd, void *buf, S32 length)
{
    S32 bytes_write;
    S32 bytes_left = length;
    CHAR *ptr = buf;

    while(bytes_left>0)
    {
        if(fd == 0)
        {
            break;
        }

        bytes_write = send(fd, ptr, bytes_left, 0);

        if(bytes_write<0)
        {
            RTSP_DEBUG_PRINT("\r\nERROR :  ***** socket.c : fd = %d  , Bytes_write = %d \n",
                             fd,bytes_write);
            return -1;
        }

        bytes_left -= bytes_write;
        ptr += bytes_write;
    }

    return (length - bytes_left);
}
