#include <linux/init.h>
#include <linux/module.h>
#include <linux/fs.h>
#include <linux/delay.h>
#include <linux/kernel.h>
#include <linux/utsname.h>
#include <linux/platform_device.h>

#include <linux/usb/ch9.h>
#include <linux/usb/composite.h>
#include <linux/usb/gadget.h>

#include <mach/sunxi-chip.h>

#include <asm/cputype.h>
#include "gadget_chips.h"

#include "usbstring.c"
#include "config.c"
#include "epautoconf.c"
#include "composite.c"

#include "f_mfi.c"


static const char longname[] = "GADGET ST10C";

#define VENDOR_ID		0x2EA9
#define PRODUCT_ID		0x0001

struct st10c_dev {
    struct usb_composite_dev *cdev;

    struct device *dev;

    bool connected;
    bool sw_connected;

    uint set_alt;

    struct work_struct work;
} *_st10c_dev;

static struct class *st10c_class;

/* string IDs are assigned dynamically */
#define STRING_MANUFACTURER_IDX		0
#define STRING_PRODUCT_IDX		1
#define STRING_SERIAL_IDX		2

static char manufacturer_string[] = "yuneec";
static char product_string[] = "st10c";
static char serial_string[] = "1234567890";

/* String Table */
static struct usb_string strings_dev[] = {
    [STRING_MANUFACTURER_IDX].s = manufacturer_string,
    [STRING_PRODUCT_IDX].s = product_string,
    [STRING_SERIAL_IDX].s = serial_string,
    {  }			/* end of list */
};

static struct usb_gadget_strings stringtab_dev = {
    .language	= 0x0409,	/* en-us */
    .strings	= strings_dev,
};

static struct usb_gadget_strings *dev_strings[] = {
    &stringtab_dev,
    NULL,
};

static struct usb_device_descriptor device_desc = {
    .bLength              = sizeof(device_desc),
    .bDescriptorType      = USB_DT_DEVICE,
    .bcdUSB               = __constant_cpu_to_le16(0x0200),
    .bDeviceClass         = USB_CLASS_PER_INTERFACE,
    .bDeviceSubClass      = 0,
    .bDeviceProtocol      = 0,
    .idVendor             = __constant_cpu_to_le16(VENDOR_ID),
    .idProduct            = __constant_cpu_to_le16(PRODUCT_ID),
    .bcdDevice            = __constant_cpu_to_le16(0xffff),
    .bNumConfigurations   = 1,
};

static struct usb_configuration st10c_config_driver = {
    .label		= "st10c",
    .bConfigurationValue = 1,
    .bmAttributes	= USB_CONFIG_ATT_ONE | USB_CONFIG_ATT_SELFPOWER,
    .bMaxPower	= 0x0,
};


static void st10c_work(struct work_struct *data)
{
    struct st10c_dev *dev = container_of(data, struct st10c_dev, work);
    struct usb_composite_dev *cdev = dev->cdev;
    char *disconnected[2] = { "USB_STATE=DISCONNECTED", NULL };
    char *connected[2]    = { "USB_STATE=CONNECTED", NULL };
    char *configured[2]   = { "USB_STATE=CONFIGURED", NULL };
    char alt_env[16];
    char *set_alt[2]      = { alt_env, NULL };
    char **uevent_envp = NULL;
    unsigned long flags;
    
    spin_lock_irqsave(&cdev->lock, flags);
    if (dev->connected != dev->sw_connected) {
        uevent_envp = dev->connected ? connected : disconnected;
        dev->sw_connected = dev->connected;
    } else if (dev->set_alt) {
        snprintf(alt_env, sizeof(alt_env), "SET_ALT=%d", dev->set_alt & 0x0ffff);
        dev->set_alt = 0;
        uevent_envp = set_alt;
    } else if (cdev->config)
        uevent_envp = configured;
    spin_unlock_irqrestore(&cdev->lock, flags);

    if (uevent_envp) {
        kobject_uevent_env(&dev->dev->kobj, KOBJ_CHANGE, uevent_envp);
    }
}

/*-------------------------------------------------------------------------*/
/* Composite driver */
static int st10c_setup(struct usb_gadget *gadget, const struct usb_ctrlrequest *c)
{
    struct st10c_dev      *dev = _st10c_dev;
    struct usb_composite_dev    *cdev = get_gadget_data(gadget);
    struct usb_request      *req = cdev->req;

    int value = -EOPNOTSUPP;
    unsigned long flags;

    req->zero = 0;
    req->complete = composite_setup_complete;
    req->length = 0;
    gadget->ep0->driver_data = cdev;

    value = composite_setup(gadget, c);

    spin_lock_irqsave(&cdev->lock, flags);
    if (!dev->connected) {
        dev->connected = 1;
        schedule_work(&dev->work);
    } else if (c->bRequest == USB_REQ_SET_CONFIGURATION && cdev->config) {
        schedule_work(&dev->work);
    } else if (c->bRequest == USB_REQ_SET_INTERFACE && le16_to_cpu(c->wIndex) == 1) {
        dev->set_alt = le16_to_cpu(c->wValue) | (1 << 16);
        schedule_work(&dev->work);
    }
    spin_unlock_irqrestore(&cdev->lock, flags);

    return value;
}

static void st10c_disconnect(struct usb_gadget *gadget)
{
    struct st10c_dev *dev = _st10c_dev;
    struct usb_composite_dev *cdev = get_gadget_data(gadget);
    unsigned long flags;

    composite_disconnect(gadget);
 
    spin_lock_irqsave(&cdev->lock, flags);
    dev->set_alt = 0;
    dev->connected = 0;
    schedule_work(&dev->work);
    spin_unlock_irqrestore(&cdev->lock, flags);
}


static int st10c_bind(struct usb_composite_dev *cdev)
{
    struct st10c_dev *dev = _st10c_dev;
    struct usb_gadget	*gadget = cdev->gadget;
    int	gcnum, id;

    printk("%s, %d, enter\n", __func__, __LINE__);
    /*
     * Start disconnected. Userspace will connect the gadget once
     * it is done configuring the functions.
     */
    usb_gadget_disconnect(gadget);

    mfi_setup();

    /* Allocate string descriptor numbers ... note that string
     * contents can be overridden by the composite_dev glue.
     */
    id = usb_string_id(cdev);
    if (id < 0)
        return id;
    strings_dev[STRING_MANUFACTURER_IDX].id = id;
    device_desc.iManufacturer = id;

    id = usb_string_id(cdev);
    if (id < 0)
        return id;
    strings_dev[STRING_PRODUCT_IDX].id = id;
    device_desc.iProduct = id;

    id = usb_string_id(cdev);
    if (id < 0)
        return id;
    strings_dev[STRING_SERIAL_IDX].id = id;
    device_desc.iSerialNumber = id;

    usb_add_config(cdev, &st10c_config_driver, mfi_bind_config);

    gcnum = usb_gadget_controller_number(gadget);
    if (gcnum >= 0)
        device_desc.bcdDevice = cpu_to_le16(0x0200 + gcnum);
    else {
        printk("%s: controller '%s' not recognized\n", longname, gadget->name);
        device_desc.bcdDevice = __constant_cpu_to_le16(0x9999);
    }

    usb_gadget_set_selfpowered(gadget);
    dev->cdev = cdev;

    usb_gadget_connect(gadget);
    printk("%s, %d, exit\n", __func__, __LINE__);
    return 0;
}

static int st10c_usb_unbind(struct usb_composite_dev *cdev)
{
    struct st10c_dev *dev = _st10c_dev;

    printk("%s, %d, enter\n", __func__, __LINE__);

    cancel_work_sync(&dev->work);
    mfi_cleanup();
    return 0;
}

static struct usb_composite_driver st10c_usb_driver = {
    .name		= "st10c_usb",
    .dev		= &device_desc,
    .strings	= dev_strings,
    .unbind		= st10c_usb_unbind,
    .max_speed	= USB_SPEED_HIGH,
};

static int __init st10c_init(void)
{
    printk("%s, %d, enter\n", __func__, __LINE__);
    _st10c_dev = kzalloc(sizeof(*_st10c_dev), GFP_KERNEL);
    if (!_st10c_dev)
        return -ENOMEM;

    st10c_class = class_create(THIS_MODULE, "st10c_usb");                                                                                                        
    if (IS_ERR(st10c_class))
        return PTR_ERR(st10c_class);

    _st10c_dev->dev = device_create(st10c_class, NULL, MKDEV(0, 0), NULL, "mfi");
    if (IS_ERR(_st10c_dev->dev))
        return PTR_ERR(_st10c_dev->dev);

    INIT_WORK(&_st10c_dev->work, st10c_work);

    composite_driver.setup = st10c_setup;
    composite_driver.disconnect = st10c_disconnect;

    return usb_composite_probe(&st10c_usb_driver, st10c_bind);
}
module_init(st10c_init);

static void __exit st10c_exit(void)
{
    printk("%s, %d, enter\n", __func__, __LINE__);
    usb_composite_unregister(&st10c_usb_driver);

    device_destroy(st10c_class, _st10c_dev->dev->devt);
    class_destroy(st10c_class);
    
    kfree(_st10c_dev);
    _st10c_dev = NULL;
    printk("%s, %d, exit\n", __func__, __LINE__);
}
module_exit(st10c_exit);


MODULE_AUTHOR("wei.gu@yuneec.com");
MODULE_DESCRIPTION("ST10C usb device driver");
MODULE_LICENSE("GPL");
MODULE_VERSION("1.0");
