#ifndef _IAP2_WAKEFD_H__
#define _IAP2_WAKEFD_H__

#include <unistd.h>
#include <fcntl.h>
#include <sys/types.h>
#include "internal.h"

static inline int read_all(int fd)
{
    char buf[64];
    int  ret;

    do {
        ret = read(fd, buf, sizeof(buf));
        if(ret < 0 && errno != EAGAIN && errno != EINTR)
            return -1;
        else if(ret == 0)
            return -1;
    } while(ret > 0);

    return 0;
}

static inline int init_wakeup(struct io_task *task)
{
    if(pipe(task->pipe) < 0) {
        printf("pipe return failed!!!\n");
        return -1;
    }
    fcntl(task->pipe[0], F_SETFL, fcntl(task->pipe[0], F_GETFL) | O_NONBLOCK);
    fcntl(task->pipe[1], F_SETFL, fcntl(task->pipe[1], F_GETFL) | O_NONBLOCK);

    return 0;
}

static inline void close_wakeup(struct io_task *task)
{
    close(task->pipe[0]);
    close(task->pipe[1]);
}

static inline void wakeup_io(struct io_task *task)
{
     write(task->pipe[1], "W", 1);
}

static inline int wait_for_io(struct io_task *task, int delay)
{
    struct pollfd poll_entry;
    int    ret;

    poll_entry.events = POLLIN;
    poll_entry.fd = task->pipe[0];

    do {
        ret = poll(&poll_entry, 1, delay);
        if (ret < 0 && EINTR != errno && errno != EAGAIN) {
            printf("%s poll error!\n", __func__);
            return -1;
        }
    } while (ret < 0);

    if(poll_entry.revents & POLLIN)
        read_all(task->pipe[0]);
    return 0;
}

static inline int handle_wakeup_io(struct epoll_event *ev, struct epoll_context *epctx)
{
    struct io_task      *task = epctx->data;

    if(ev->events & EPOLLIN) {
        read_all(task->pipe[0]);
    }

    return 0;
}

static struct epoll_context* epoll_add_wakeup(struct io_task *task, int epfd)
{
    struct epoll_context *epctx = malloc(sizeof(*epctx));
    struct epoll_event   ev;

    if(!epctx) {
        printf("%s malloc failed!!!\n", __func__);
        return NULL;
    }
    epctx->data     = task;
    epctx->callback = handle_wakeup_io;

    ev.events   = EPOLLIN;
    ev.data.ptr = epctx;

    if(epoll_ctl(epfd, EPOLL_CTL_ADD, task->pipe[0], &ev) < 0) {
        printf("%s epoll ctl failed:%s!!!\n", __func__, strerror(errno));
        free(epctx);
        return NULL;
    }

    return NULL;
}

static inline void epoll_del_wakeup(struct io_task *task, int epfd, struct epoll_context *epctx)
{
    if(epoll_ctl(epfd, EPOLL_CTL_ADD, task->pipe[0], NULL) < 0) {
        printf("%s epoll ctl failed:%s!!!\n", __func__, strerror(errno));
    }

    free(epctx);
}

#endif
