
#include <stdlib.h>
#include <stdio.h>
#include <stdint.h>
#include <sys/time.h>

#include <list.h>
#include <rctimer.h>
#include "internal.h"
#include "iAP2TimeImplementation.h"

static int iap2_timer_fn(RcTimer *timer)
{
    iAP2Timer_t *it = timer->p;
    struct iAP2Link_st *link = it->link;
    struct iap2_context *ctx = link->context;

    if(ctx->timercb)
        ctx->timercb(it, iAP2TimeGetCurTimeMs());

    stop_rctimer(timer);

    return 0;
}

BOOL _iAP2TimeCallbackAfter(iAP2Timer_t* timer, uint32_t delayMs, iAP2TimeCB_t callback)
{
    struct iAP2Link_st *link = timer->link;
    struct iap2_context *ctx = link->context;
    RcTimer *pos;

    if(!ctx->timer) {
        pos = add_rctimer(timer, iap2_timer_fn, delayMs);
        ctx->timer = pos;
        ctx->timercb = callback;

        if(!pos) {
            printf("%s malloc failed!\n", __func__);
            return FALSE;
        }
    } else {
        ctx->timer->p = timer;
        ctx->timercb = callback;
        refresh_rctimer(ctx->timer, delayMs);
    }

    return TRUE;
}

void _iAP2TimeCancelCallback (iAP2Timer_t* timer)
{
    struct iAP2Link_st *link = timer->link;
    struct iap2_context *ctx = link->context;

    if(ctx->timer)
        stop_rctimer(ctx->timer);
}

void _iAP2TimeCleanupCallback(iAP2Timer_t* timer)
{
    struct iAP2Link_st *link = timer->link;
    struct iap2_context *ctx = link->context;

    if(ctx->timer) {
        del_rctimer(ctx->timer);
        ctx->timer = NULL;
    }
}
