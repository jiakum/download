
#include <stdlib.h>
#include <stdint.h>
#include <stdio.h>
#include <ctype.h>
#include <string.h>

#include <unistd.h>
#include <sys/types.h>
#include <fcntl.h>
#include <pthread.h>
#include <errno.h>
#include <sys/poll.h>
#include <sys/ioctl.h>
#include <netinet/in.h>
#include <linux/netlink.h>
#include <linux/usb/ch9.h>
#include <linux/usbdevice_fs.h>
#include <signal.h>
#include <dirent.h>

#include "internal.h"
#include "rctimer.h"
#include "iAP2TimeImplementation.h"
#include <epoll_context.h>

#define IOCTL_USBFS_CONTROL	_IOWR('U', 0, struct usbdevfs_ctrltransfer)

#define UEVENT_MSG_LEN 4096

#define MSG_ACTION_ADD              0x00000001U
#define MSG_ACTION_REMOVE           0x00000002U
#define MSG_ACTION_CHANGE           0x00000004U

#define MSG_SUBSYSTEM_USB           0x00000010U
#define MSG_SUBSYSTEM_ST10C_USB     0x00000020U

#define MSG_DEVTYPE_USB_DEVICE      0x00000100U
#define MSG_PRODUCT_APPLE           0x00001000U

#define MSG_USB_STATE_CONFIGURED    0x00010000U
#define MSG_USB_STATE_DISCONNECTED  0x00020000U

#define MSG_USB_STATE_SET_ALT       0x00100000U

#define MSG_USB_HOST_DISCONNECTED   (MSG_ACTION_REMOVE | MSG_SUBSYSTEM_USB | MSG_DEVTYPE_USB_DEVICE | MSG_PRODUCT_APPLE)
#define MSG_USB_HOST_CONNECTED      (MSG_ACTION_ADD | MSG_SUBSYSTEM_USB | MSG_DEVTYPE_USB_DEVICE | MSG_PRODUCT_APPLE)
#define MSG_USB_DEVICE_DISCONNECTED (MSG_ACTION_CHANGE | MSG_SUBSYSTEM_ST10C_USB | MSG_USB_STATE_DISCONNECTED)
#define MSG_USB_DEVICE_CONFIGURED   (MSG_ACTION_CHANGE | MSG_SUBSYSTEM_ST10C_USB | MSG_USB_STATE_CONFIGURED)


int uevent_init(void)
{
    struct sockaddr_nl addr;
    int sz = 64 * 1024;
    int fd, ret;
                
    memset(&addr, 0, sizeof(addr));
    addr.nl_family = AF_NETLINK;
    addr.nl_pid = getpid();
    addr.nl_groups = 0xffffffff;

    fd = socket(PF_NETLINK, SOCK_DGRAM, NETLINK_KOBJECT_UEVENT);
    if (fd < 0) {
        return -1;
    }

    ret = setsockopt(fd, SOL_SOCKET, SO_RCVBUFFORCE, &sz, sizeof(sz));
    if (ret < 0) {
        printf("set socket recv buf size failed:%d\n", errno);
    }

    ret = bind(fd, (struct sockaddr *) &addr, sizeof(addr));
    if (ret < 0) {
        close(fd);
        return -1;
    }
    fcntl(fd, F_SETFL, fcntl(fd, F_GETFL) | O_NONBLOCK);

    return fd;
}

static inline int badname(const char *name)                                                                                                             
{
    while(*name) {
        if(!isdigit(*name++)) 
            return 1;
    }   
    return 0;
}

static int role_switch(char *bus, char *dev)
{
    int ret = -1;
    char cap[4];
    char apple_device[64];
    struct usbdevfs_ctrltransfer ctrltransfer;

    if (badname(bus) || badname(dev)) {
        return -1;
    }
    snprintf(apple_device, sizeof(apple_device), "%s/%s/%s", "/dev/bus/usb", bus, dev);
	int fd = open(apple_device, O_RDWR);
    if (fd < 0) {
        return -1;
    }

    memset(&ctrltransfer, 0x00, sizeof(ctrltransfer));
    ctrltransfer.bRequestType = 0xC0;
    ctrltransfer.bRequest = 0x53;
    ctrltransfer.wValue = 0x00;
    ctrltransfer.wIndex = 0x00;
    ctrltransfer.wLength = 0x04;
    ctrltransfer.timeout = 1000;
    ctrltransfer.data = (void *)cap;
	ret = ioctl(fd, IOCTL_USBFS_CONTROL, &ctrltransfer);
    if (ret != 4) {
        close(fd);
        return -1;
    }

    memset(&ctrltransfer, 0x00, sizeof(ctrltransfer));
    ctrltransfer.bRequestType = 0x40;
    ctrltransfer.bRequest = 0x51;
    ctrltransfer.wValue = (uint16_t)cap[0];
    ctrltransfer.wIndex = 0x00;
    ctrltransfer.wLength = 0x00;
    ctrltransfer.timeout = 1000;
    ctrltransfer.data = NULL;
    ret = ioctl(fd, IOCTL_USBFS_CONTROL, &ctrltransfer);
    if (ret < 0) {
        close(fd);
        return -1;
    }

	close(fd);
    return 0;
}

static void uevent_parse_msg(struct iAP2Link_st* link, char *msg)
{
    struct iap2_context *ctx = link->context;
    while (*msg) {
        if (!strncmp(msg, "ACTION=add", 10)) {
            ctx->usb_state |= MSG_ACTION_ADD;
        } else if (!strncmp(msg, "ACTION=remove", 13)) {
            ctx->usb_state |= MSG_ACTION_REMOVE;
        } else if (!strncmp(msg, "ACTION=change", 13)) {
            ctx->usb_state |= MSG_ACTION_CHANGE;
        } else if (!strncmp(msg, "SUBSYSTEM=usb", 13)) {
            ctx->usb_state |= MSG_SUBSYSTEM_USB;
        } else if (!strncmp(msg, "DEVTYPE=usb_device", 18)) {
            ctx->usb_state |= MSG_DEVTYPE_USB_DEVICE;
        } else if (!strncmp(msg, "PRODUCT=5ac", 11)) {
            ctx->usb_state |= MSG_PRODUCT_APPLE;
        } else if (!strncmp(msg, "SUBSYSTEM=st10c_usb", 19)) {
            ctx->usb_state |= MSG_SUBSYSTEM_ST10C_USB;
        } else if (!strncmp(msg, "USB_STATE=CONFIGURED", 20)) {
            ctx->usb_state |= MSG_USB_STATE_CONFIGURED;
        } else if (!strncmp(msg, "USB_STATE=DISCONNECTED", 22)) {
            ctx->usb_state |= MSG_USB_STATE_DISCONNECTED;
        } else if (!strncmp(msg, "SET_ALT=", 8)) {
            ctx->alt = strtol(msg + 8, NULL, 0);
            ctx->usb_state |= MSG_USB_STATE_SET_ALT;
        } else if (!strncmp(msg, "BUSNUM=", 7)) {
            strncpy(ctx->busnum, msg + 7, 4);
        } else if (!strncmp(msg, "DEVNUM=", 7)) {
            strncpy(ctx->devnum, msg + 7, 4);
        } else if (!strncmp(msg, "SEQNUM=", 7)) {
            if (ctx->usb_state == MSG_USB_HOST_CONNECTED) {
                //usb host connected
                role_switch(ctx->busnum, ctx->devnum);
                system("echo 0 > /sys/bus/platform/devices/sunxi_usb_udc/otg_role");
                system("cat /sys/bus/platform/devices/sunxi_usb_udc/usb_device");
            } else if (ctx->usb_state == MSG_USB_DEVICE_CONFIGURED) {
                //usb device configured
                printf("usb device configured!\n");
                start_iap2(link, 1);
            } else if (ctx->usb_state == MSG_USB_DEVICE_DISCONNECTED) {
                //usb device disconnected
                printf("usb device disconnected!\n");
                start_iap2(link, 0);
                if(ctx->earunning){
                    ctx->earunning = 0;
                    pthread_kill(ctx->eaid, SIGCONT);
                    pthread_join(ctx->eaid, NULL);
                }
                system("echo 1 > /sys/bus/platform/devices/sunxi_usb_udc/otg_role");
                system("cat /sys/bus/platform/devices/sunxi_usb_udc/usb_null");

                system("echo 2 > /sys/bus/platform/devices/sunxi_usb_udc/otg_role");
                system("cat /sys/bus/platform/devices/sunxi_usb_udc/usb_null");
                
                system("cat /sys/bus/platform/devices/sunxi_usb_udc/usb_host");
            } else if (ctx->usb_state & MSG_USB_STATE_SET_ALT) {
                if(ctx->alt && !iAP2LinkIsDetached(link) && !ctx->earunning) {
                    ctx->earunning = 1;
                    if(pthread_create(&ctx->eaid, NULL, ea_native_thread, link) < 0)
                        printf("create ea native thread failed!!\n");
                } else if(ctx->earunning){
                    ctx->earunning = 0;
                    pthread_kill(ctx->eaid, SIGCONT);
                    pthread_join(ctx->eaid, NULL);
                }
            }
            ctx->usb_state = 0;
        }

        /* advance to after the next \0 */
        while(*msg++);
    }
}

static void uevent_recv_msg(struct iAP2Link_st* link)
{
    struct iap2_context *ctx = link->context;
    char uevent_msg[UEVENT_MSG_LEN + 2];
    int n;
    while ((n = recv(ctx->nl_fd, uevent_msg, UEVENT_MSG_LEN, 0)) > 0) {
        if (n == UEVENT_MSG_LEN) {
            continue;
        }

        uevent_msg[n] = '\0';
        uevent_msg[n+1] = '\0';
        uevent_parse_msg(link, uevent_msg);
    }
}

static int find_apple_device(char *bus, char *dev)
{
    char busname[32], devname[32];
    DIR *busdir, *devdir ;
    struct dirent *de;
    int fd; 

    busdir = opendir("/dev/bus/usb");
    if(busdir == 0) 
        return -1;
                                                                
    while((de = readdir(busdir)) != 0) {
        if(badname(de->d_name)) 
            continue;
        
        snprintf(busname, sizeof busname, "%s/%s", "/dev/bus/usb", de->d_name);
        devdir = opendir(busname);
        if(devdir == 0) 
            continue;
        
        while((de = readdir(devdir))) {
            unsigned char devdesc[4096];
            struct usb_device_descriptor* device;
            size_t desclength;
            
            if(badname(de->d_name)) 
                continue;

            snprintf(devname, sizeof devname, "%s/%s", busname, de->d_name);
            if((fd = open(devname, O_RDONLY)) < 0) {
                continue;
            }   

            desclength = read(fd, devdesc, sizeof(devdesc));
            if (desclength < USB_DT_DEVICE_SIZE) {
                close(fd);
                continue;
            }

            device = (struct usb_device_descriptor*)devdesc;
            if((device->bLength != USB_DT_DEVICE_SIZE) || (device->bDescriptorType != USB_DT_DEVICE)) {
                close(fd);
                continue;
            }

            if (device->idVendor == 0x05AC) {
                strncpy(dev, devname + strlen(devname) - 3, 3);
                strncpy(bus, devname + strlen(devname) - 7, 3);
                close(fd);
                closedir(devdir);
                closedir(busdir);
                return 1;
            }
            close(fd);
        }
        closedir(devdir);
    }
    closedir(busdir);
    
    return 0;
}

int uevent_loop(struct iAP2Link_st* link)
{
    struct iap2_context *ctx = link->context;
    struct pollfd entry;
    int ret;

    system("echo 1 > /sys/bus/platform/devices/sunxi_usb_udc/otg_role");
    system("cat /sys/bus/platform/devices/sunxi_usb_udc/usb_null");

    system("echo 2 > /sys/bus/platform/devices/sunxi_usb_udc/otg_role");
    system("cat /sys/bus/platform/devices/sunxi_usb_udc/usb_null");

    system("cat /sys/bus/platform/devices/sunxi_usb_udc/usb_host");
    if (find_apple_device(ctx->busnum, ctx->devnum) == 1) {
        printf("find apple device :%s, %s\n", ctx->busnum, ctx->devnum);
        role_switch(ctx->busnum, ctx->devnum);
        system("echo 0 > /sys/bus/platform/devices/sunxi_usb_udc/otg_role");
        system("cat /sys/bus/platform/devices/sunxi_usb_udc/usb_device");
    }
    for(;;) {
        entry.events   = POLLIN;
        entry.fd       = ctx->nl_fd;

        ret = poll(&entry, 1, -1);
        if (ret < 0) {
            if (errno == EINTR) {
                continue;
            }
            break;
        } else if (ret > 0) {
            uevent_recv_msg(link);
        }
    }

    return 0;
}
