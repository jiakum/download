
#include <stdlib.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>

#include <unistd.h>
#include <sys/types.h>
#include <fcntl.h>
#include <pthread.h>
#include <errno.h>
#include <sys/poll.h>

#include "internal.h"
#define AAC20C_MAX_REGSIZE (128)

static int read_reg(int fd, int reg, unsigned char *buf, int len)
{
    char data[4];
    int ret;

    lseek(fd, 0, SEEK_SET);
rewrite:
    data[0] = reg;
    ret = write(fd, data, 1);
    if(ret < 0) {
        if(errno == EINTR)
            goto rewrite;
        printf("write register to file failed!\n");
        return -1;
    }

    lseek(fd, 0, SEEK_SET);
reread:
    ret = read(fd, buf, len);
    if(ret < 0) {
        if(errno == EINTR)
            goto reread;
        printf("read register failed!\n");
        return -1;
    }

    return ret;
}

static int write_reg(int fd, unsigned char *buf, int len)
{
    int ret;

    lseek(fd, 0, SEEK_SET);
rewrite:
    ret = write(fd, buf, len);
    if(ret < 0) {
        if(errno == EINTR)
            goto rewrite;
        printf("write register to file failed!\n");
        return -1;
    }

    return len;
}

int aac_challege_response(int fd, unsigned char *challege, int clen, 
                                        unsigned char *response, unsigned int *rlen)
{
    unsigned char buf[128 + 16];
    int ret, try = 100;
    unsigned int len;

    *rlen = 0;
    /* write challege lengh */
    buf[0] = 0x20; 
    buf[1] = (clen >> 8) & 0x0ff;
    buf[2] = clen & 0x0ff;
    ret = write_reg(fd, buf, 3);
    if(ret < 0) {
        printf("write register:0x20 failed \n");
        return -1;
    }

    /* write challege data */
    buf[0] = 0x21;
    memcpy(buf + 1, challege, clen);
    ret = write_reg(fd, buf, 128 + 1);
    if(ret < 0) {
        printf("write register:0x21 failed \n");
        return -1;
    }

    /* start new challege-response generation process */
    buf[0] = 0x10; 
    buf[1] = 0x01;
    ret = write_reg(fd, buf, 2);
    if(ret < 0) {
        printf("write register:0x20 failed \n");
        return -1;
    }

    do {
        ret = read_reg(fd, 0x10, buf, 2);
        if(ret < 0) {
            printf("%s,read reg!!!\n", __func__);
            return -1;
        }
        if(--try == 0) {
            printf("challenge-response generation process failed, buf:0x%x!!!\n", buf[0]);
            return -1;
        }
    } while(((buf[0] >> 4) & 0x07) != 0x01);

    /* read challege response lengh */
    ret = read_reg(fd, 0x11, buf, 2);
    if(ret < 0) {
        printf("%s,read reg!!!\n", __func__);
        return -1;
    }

    len = (buf[0] << 8) | buf[1];
    if(len > 128) {
        printf("get challege response lenght :%d > 128\n", len);
        return -1;
    }

    *rlen = len;

    /* read challege response data */
    ret = read_reg(fd, 0x12, response, 128);
    if(ret < 0) {
        printf("%s,read reg!!!\n", __func__);
        return -1;
    }

    printf("%s success\n", __func__);

    return 0;
}

int get_aac_certificate_data(int fd, unsigned char *buf, int *cdlen)
{
    int len, ret, left, reg;

    buf[0] = 0x40; buf[1] = 0x01;
    ret = write_reg(fd, buf, 2);
    ret = read_reg(fd, 0x40, buf, 1);
    printf("%s, 0x40:0x%x, ret:%d\n", __func__, buf[0], ret);

    ret = read_reg(fd, 0x04, buf, 4);
    printf("read 0x04:0x%02x%02x%02x%02x\n", buf[0], buf[1], buf[2], buf[3]);

    ret = read_reg(fd, 0x30, buf, 2);
    if(ret < 0) {
        printf("%s,read reg!!!\n", __func__);
        return -1;
    }

    len = buf[1] | (buf[0] << 8);
    if(len == 0 || len > 1280) {
        printf("%s,return length:%d beyond 1280!!!\n",__func__, len);
        return -1;
    }

    left = len; reg = 0x31;
    while(left > 0) {
        ret = read_reg(fd, reg, buf + len - left, 128);
        if(ret < 0) {
            printf("%s,read reg!!!\n", __func__);
            return -1;
        } else if(ret != 128)  {
            printf("%s,read reg ret :%d != 128!!!\n", __func__, ret);
            return -1;
        }
        left -= ret; reg++;
    }

    *cdlen = len;

    printf("%s:%d\n", __func__, len);
 
    return len;
}

#define FILL_SESSION_HEADER(buf, id, len)  do {                             \
                                            buf[0] = 0x40;                  \
                                            buf[1] = 0x40;                  \
                                            buf[2] = ((len) >> 8) & 0x0FF;  \
                                            buf[3] = (len)  & 0x0FF;         \
                                            buf[4] = ((id)  >> 8) & 0x0FF;   \
                                            buf[5] = (id)   & 0x0FF;          \
                                            buf   += 6;                     \
                                        } while(0)

#define ADD_SESSION_DATA(buf, param, len, id) do {                                        \
                                                    *buf++ = (((len) + 4)  >> 8) & 0x0FF;  \
                                                    *buf++ = ((len)  + 4)  & 0x0FF;         \
                                                    *buf++ = ((id)   >> 8) & 0x0FF;         \
                                                    *buf++ = (id)    & 0x0FF;                \
                                                    memcpy(buf, param, len);              \
                                                    buf    += len;                         \
                                                } while(0)

struct ctrl_session_msg {
    char *name;
    unsigned int format, id;

    union {
        unsigned char *ptr;
        unsigned int  value;
    } data; 
    unsigned int len;
    unsigned int (*get_data) (struct iap2_context *ctx, unsigned char *buf, const struct ctrl_session_msg *msg);
};

static unsigned int get_serial_number(struct iap2_context *ctx, unsigned char *buf, const struct ctrl_session_msg *msg)
{
    char sn[64];
    int len, got = 0;
    int fd;

    if((fd = open("/home/sn.ini", O_RDONLY)) > 0) {
        do {
            len = read(fd, sn, sizeof(sn) - 1);
            if(len < 0) {
                if(errno == EINTR)
                    continue;
                break;
            } else if(len == 0) {
                break;
            }

            if(sn[len - 1] != '\0')
                sn[len] = '\0';
            len = strlen(sn) + 1;
        } while(len < 0);
        close(fd);

        if(len > 4)
            got = 1;
    }

    if(!got) {
        if((fd = open("/dev/random", O_RDONLY)) > 0) {
            int left, ret;
            unsigned int value;

            left = len = sizeof(value);
            while(left > 0) {
                ret = read(fd, (char*)&value, left);
                if(ret < 0) {
                    if(errno == EINTR)
                        continue;
                    break;
                }

                left -= ret;
            }

            close(fd);
            
            len = snprintf(sn, sizeof(sn), "%X", value);

            if(len > 0) {
                sn[len++] = '\0';
                len = strlen(sn) + 1;

                if((fd = open("/home/sn.ini", O_RDWR | O_TRUNC | O_CREAT, 
                                S_IRUSR | S_IWUSR | S_IRGRP | S_IWGRP | S_IROTH)) > 0) {

                    left = len;
                    while(left > 0) {
                        ret = write(fd, sn + len - left, left);
                        if(ret < 0) {
                            if(errno == EINTR)
                                continue;
                            break;
                        }

                        left -= ret;
                    }

                    close(fd);
                } else
                    printf("create /home/sn.ini to store serail number failed!\n");

                got = 1;
            }
        }
    }

    if(!got) {
        strncpy(sn, "1526489222", sizeof(sn));
        len = strlen(sn) + 1;
    }

    printf("%s got serail number:%s\n", __func__, sn);
    UNUSED(ctx);
    ADD_SESSION_DATA(buf, sn, len, msg->id);

    return len + 4;
}

static unsigned int get_uhtc(struct iap2_context *ctx, unsigned char *buf, const struct ctrl_session_msg *msg)
{
    unsigned char *start = buf;
    unsigned int len, total = 0;
    char data[4];

    UNUSED(ctx);
    buf += 4;
    data[0] = 0; data[1] = 0xa0;
    ADD_SESSION_DATA(buf, data, 2, 0);

    len = strlen("usb.iap2") + 1;
    ADD_SESSION_DATA(buf, "usb.iap2", len, 1);

    ADD_SESSION_DATA(buf, data, 0, 2);

    len = buf - start;
    buf = start;
    *buf++ = (len >> 8) & 0x0FF;
    *buf++ = len & 0x0FF;
    *buf++ = (msg->id >> 8) & 0x0FF;
    *buf++ = msg->id & 0x0FF;
    total += len;

    start += len;
    buf    = start;
    buf   += 4;
    data[0] = 0; data[1] = 0xa1;
    ADD_SESSION_DATA(buf, data, 2, 0);

    len = strlen("com.yuneec.video") + 1;
    ADD_SESSION_DATA(buf, "com.yuneec.video", len, 1);
    ADD_SESSION_DATA(buf, data, 0, 2);

    len = buf - start;
    buf = start;
    *buf++ = (len >> 8) & 0x0FF;
    *buf++ = len & 0x0FF;
    *buf++ = (msg->id >> 8) & 0x0FF;
    *buf++ = msg->id & 0x0FF;
    total += len;

    return total;
}

struct data_session_info {
    char *protocol;
    int id, len, action;
};

#define IAP2_DATA_SESSION_INFO(Protocol, Id)  .protocol = Protocol,                       \
                                              .id       = Id,                         \
                                              .len      = __builtin_strlen(Protocol) + 1, \
                                              .action   = 1

static const struct data_session_info data_session_infos[] = {
    {
        IAP2_DATA_SESSION_INFO("com.yuneec.video", 0)
    },
    {
        IAP2_DATA_SESSION_INFO("com.yuneec.control", 1)
    },
    {
        IAP2_DATA_SESSION_INFO("com.yuneec.camera", 2)
    },
    {
        IAP2_DATA_SESSION_INFO("com.yuneec.recovery", 3)
    },
};

static unsigned int get_exap(struct iap2_context *ctx, unsigned char *buf, const struct ctrl_session_msg *msg)
{
    unsigned char *start;
    unsigned int len, i, total = 0;
    char data[4];

    UNUSED(ctx);

    start = buf;
    for(i = 0;i < MFI_DATA_SESSION_NUM;i++) {
        const struct data_session_info *info = &data_session_infos[i];
    
        buf = start;
        buf += 4;
    
        data[0] = info->id;
        ADD_SESSION_DATA(buf, data, 1, 0);

        len = info->len;
        ADD_SESSION_DATA(buf, info->protocol, len, 1);

        data[0] = info->action;
        ADD_SESSION_DATA(buf, data, 1, 2);

        if(i == 0) {
            /* video use the EA Native transport */
            data[0] = 0x0;
            data[1] = 0xa1;
            ADD_SESSION_DATA(buf, data, 2, 3);
        }

        len    = buf - start;
        buf    = start;
        *buf++ = (len >> 8) & 0x0FF;
        *buf++ = len & 0x0FF;
        *buf++ = (msg->id >> 8) & 0x0FF;
        *buf++ = msg->id & 0x0FF;

        start += len;
        total += len;
    }

    return total;
}

static unsigned char msg_sent_by_accessary[] = {0xEA, 0x02, 0xEA, 0x03};
static unsigned char msg_recv_from_ios[]     = {0xEA, 0x00, 0xEA, 0x01};

enum {
    IAP2_MSG_STRING = 1,
    IAP2_MSG_BLOB ,
    IAP2_MSG_UINT8 ,
    IAP2_MSG_BOOL ,
    IAP2_MSG_UINT16 ,
    IAP2_MSG_UINT32 ,
    IAP2_MSG_GROUP ,
};
#define IAP2_CTRL_STRING(Name, Id, Data)      .name     = Name,                       \
                                              .id       = Id,                         \
                                              .format   = IAP2_MSG_STRING,            \
                                              .data.ptr = (unsigned char *)Data,      \
                                              .len      = __builtin_strlen(Data) + 1, \
                                              .get_data = NULL

/* read Accessary Interface Specification (provided by apple.com) for more information */
static const struct ctrl_session_msg identification_msgs[] =  {
    {
        IAP2_CTRL_STRING("Name",            0, "AutoPilot Remote Controller")
    },
    {
        IAP2_CTRL_STRING("ModelIdentifier", 1, "ST10C")
    },
    {
        IAP2_CTRL_STRING("Manufacturer",    2, "YUNEEC")
    },
    {
        .name    = "SerailNumber",
        .format  = IAP2_MSG_STRING, 
        .id      = 3,
        .get_data= get_serial_number,
    },
    {
        IAP2_CTRL_STRING("FirmwareVersion", 4, "ST10C_1.00v")
    },
    {
        IAP2_CTRL_STRING("HardwareVersion", 5, "ST10C_0.30v")
    },
    {
        .name     = "MessagesSentByAccessary", 
        .id       = 6,
        .format   = IAP2_MSG_BLOB, 
        .data.ptr = msg_sent_by_accessary,
        .len      = sizeof(msg_sent_by_accessary),
    },
    {
        .name     = "MessagesReceivedFromDevice", 
        .id       = 7,
        .format   = IAP2_MSG_BLOB, 
        .data.ptr = msg_recv_from_ios,
        .len      = sizeof(msg_recv_from_ios),
    },
    {
        .name       = "PowerProvidingCapacity", 
        .id         = 8,
        .format     = IAP2_MSG_UINT8, 
        .data.value = 0,
        .len        = 1,
    },
    {
        .name       = "MinimumCurrentDrawnFromDevice", 
        .id         = 9,
        .format     = IAP2_MSG_UINT16, 
        .data.value = 0,
        .len        = 2,
    },
    {
        .name       = "SupportedExternalAccessaryProtocol", 
        .id         = 10,
        .format     = IAP2_MSG_GROUP, 
        .get_data   = get_exap,
    },
    {
        IAP2_CTRL_STRING("AppMatchTeamId",    11, "7TWV6233J9")
    },
    {
        IAP2_CTRL_STRING("CurrentLanguage",   12, "en")
    },
    {
        IAP2_CTRL_STRING("SupportedLanguage", 13, "en")
    },
    {
        .name       = "USBHostTransportComponent", 
        .id         = 16,
        .format     = IAP2_MSG_GROUP, 
        .get_data   = get_uhtc,
    },
};

BOOL handle_control_session(struct iAP2Link_st* link, uint8_t* data, uint32_t dataLen)
{
    struct iap2_context *ctx = link->context;
    iAP2Packet_t *packet;
    unsigned char *buf;
    unsigned int len, mid;

    len = data[3] | (data[2] << 8);
    if(len < 6 || dataLen != len || data[0] != 0x40 || data[1] != 0x40) {
        printf("%s unrecognized session\n", __func__);
        return TRUE;
    }
    mid = data[5] | (data[4] << 8);

    printf("%s:%d, id:0x%x\n", __func__, len, mid);
    switch(mid)
    {
        case 0xAA00:
        {
            get_aac_certificate_data(ctx->cdfd, ctx->certificate_data, &ctx->cdlen);
            buf = ctx->buf + 6;
            ADD_SESSION_DATA(buf, ctx->certificate_data, ctx->cdlen, 0x0);

            len = buf - ctx->buf;
            buf = ctx->buf;
            FILL_SESSION_HEADER(buf, 0xAA01, len);

            packet = iAP2PacketCreateACKPacket(link, link->sentSeq, link->recvSeq, ctx->buf, len, MFI_CONTROL_SESSIONID);
            iAP2LinkQueueSendDataPacket(link, packet, MFI_CONTROL_SESSIONID, NULL, NULL);
        }
            break;
        case 0xAA02:
        {
            len = data[7] | (data[6] << 8);
            if(len > 128) {
                printf("request challenge response packet data lengh too short:%d\n", len);
                break;
            }
            len -= 4;
            aac_challege_response(ctx->cdfd, data + 10, len, ctx->buf + 10, &len);

            buf = ctx->buf;
            FILL_SESSION_HEADER(buf, 0xAA03, len + 10);

            *buf++ = ((len + 4) >> 8) & 0x0FF;
            *buf++ = (len + 4) & 0x0FF;
            *buf++ = 0x0;
            *buf++ = 0x0;

            packet = iAP2PacketCreateACKPacket(link, link->sentSeq, link->recvSeq, ctx->buf, len + 10, 0x0A);
            iAP2LinkQueueSendDataPacket(link, packet, 0x0a, NULL, NULL);
        }
            break;
        case 0xAA04:
            printf("authentication failed!!!\n");
            break;
        case 0xAA05:
            printf("authentication successed! start identification!\n");
            break;
        case 0x1D00:
        {
            unsigned int i;

            buf = ctx->buf + 6;
            for(i = 0;i < sizeof(identification_msgs)/sizeof(identification_msgs[0]);i++) {
                const struct ctrl_session_msg *msg = &identification_msgs[i];
                unsigned int mlen = msg->len;
                switch(msg->format)
                {
                case IAP2_MSG_STRING:
                case IAP2_MSG_GROUP: 
                case IAP2_MSG_BLOB: 
                    if(msg->data.ptr && mlen)
                        ADD_SESSION_DATA(buf, msg->data.ptr, mlen, msg->id);
                    else if(msg->get_data)
                        buf += msg->get_data(ctx, buf, msg);
                    else
                        printf("Invalid message:%s, id:%d!!!\n", msg->name, msg->id);

                    break;
                case IAP2_MSG_UINT8:
                case IAP2_MSG_BOOL:
                case IAP2_MSG_UINT16:
                case IAP2_MSG_UINT32: 
                {
                    int j;

                    if(msg->len && mlen <= sizeof(msg->data.value)) {
                        char data[4];

                        for(j = mlen - 1;j >= 0;j--)
                            data[mlen - j - 1] = (msg->data.value >> (i * 8)) & 0x0FF;

                        ADD_SESSION_DATA(buf, data, mlen, msg->id);
                    } else if(msg->get_data)
                        buf += msg->get_data(ctx, buf, msg);
                    else
                        printf("Invalid message:%s, id:%d, len:%d!!!\n", msg->name, msg->id, msg->len);
                }
                    break;
                }
            }

            len = buf - ctx->buf;
            buf = ctx->buf;
            FILL_SESSION_HEADER(buf, 0x1D01, len);
            packet = iAP2PacketCreateACKPacket(link, link->sentSeq, link->recvSeq, ctx->buf, len, MFI_CONTROL_SESSIONID);
            iAP2LinkQueueSendDataPacket(link, packet, MFI_CONTROL_SESSIONID, NULL, NULL);

        }
            break;
        case 0x1D02:
        {
            unsigned char data[4];
            printf("identification success!!! Ready to transfer data!\n");

            buf = ctx->buf + 6;
            len = strlen("com.yuneec.MFIDemo") + 1;
            ADD_SESSION_DATA(buf, "com.yuneec.MFIDemo", len, 0);

            data[0] = 0;
            ADD_SESSION_DATA(buf, data, 1, 0);

            len = buf - ctx->buf;
            buf = ctx->buf;
            FILL_SESSION_HEADER(buf, 0xEA02, len);

            packet = iAP2PacketCreateACKPacket(link, link->sentSeq, link->recvSeq, ctx->buf, len, MFI_CONTROL_SESSIONID);
            iAP2LinkQueueSendDataPacket(link, packet, MFI_CONTROL_SESSIONID, NULL, NULL);
        }
            break;
        case 0x1D03:
        {
            unsigned int id, i;
            unsigned char *end;
            const struct ctrl_session_msg *msg;

            buf = data;
            len = buf[3] | (buf[2] << 8);
            id  = buf[5] | (buf[4] << 8);
            printf("identification failed!!!len:%d, id:0x%x\n", len, id);

            end = buf + len;

            buf += 6;
            while(buf < end) {
                len = buf[1] | (buf[0] << 8);
                id  = buf[3] | (buf[2] << 8);
                for(i = 0;i < sizeof(identification_msgs)/sizeof(identification_msgs[0]);i++) {
                    msg = &identification_msgs[i];

                    if(msg->id == id)
                        break;
                }

                if(i == sizeof(identification_msgs)/sizeof(identification_msgs[0])) {
                    printf("can not find match id:0x%x, len:%d!!\n current buf:%p, start:%p", id, len, buf, ctx->buf);
                    break;
                }

                printf("got msg name:%s, len:%d\n", msg->name, len);
                buf += len;
            }
        }
            break;

        case 0xEA00:
        {
            unsigned int id, eapsi = 0, seid = 0;
            unsigned char *end;

            printf("start external accessary protocol\n");
            buf = data;
            len = buf[3] | (buf[2] << 8);
            id  = buf[5] | (buf[4] << 8);

            end = buf + len;
            buf += 6;

            while(buf < end) {
                len = buf[1] | (buf[0] << 8);
                id  = buf[3] | (buf[2] << 8);

                if(id == 0) {
                    seid = buf[4];
                } else if(id == 1) {
                    eapsi = buf[5] | (buf[4] << 8);
                }
                buf += len;
            }

            printf("get external accessary protocol session identifier:0x%x, seid:%d\n", eapsi, seid);
            new_data_session(link, eapsi, seid);
        }
            break;

        case 0xEA01:
        {
            unsigned int id, eapsi = 0;
            unsigned char *end;

            buf = data;
            len = buf[3] | (buf[2] << 8);
            id  = buf[5] | (buf[4] << 8);

            end = buf + len;
            buf += 6;

            while(buf < end) {
                len = buf[1] | (buf[0] << 8);
                id  = buf[3] | (buf[2] << 8);

                if(id == 0) {
                    eapsi = buf[5] | (buf[4] << 8);
                }
                buf += len;
            }

            printf("stop  external accessary protocol:0x%x\n", eapsi);
            close_data_session(link, eapsi);
        }
            break;
    }

    return TRUE;
}

