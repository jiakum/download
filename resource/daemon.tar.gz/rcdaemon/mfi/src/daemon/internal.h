#ifndef _AP2_INTERNAL_H__
#define _AP2_INTERNAL_H__

#include <pthread.h>
#include <rctimer.h>
#include <iAP2Link.h>
#include <list.h>
#include "epoll_context.h"

#define iap2_init_lock(lock, attr) pthread_spin_init(lock, 0)
#define iap2_destroy_lock(lock) pthread_spin_destroy(lock)
#define iap2_lock(lock) pthread_spin_lock(lock)
#define iap2_unlock(lock) pthread_spin_unlock(lock)
#define iap2_lock_t pthread_spinlock_t

struct io_task {
    pthread_t        id;
    iap2_lock_t  lock;

    struct list_head list, idle;

    int running;
    int fd;
    int pipe[2];
};

struct data_session_st {
    struct iAP2Link_st*   link;
    struct iAP2Packet_st* packet;
    struct epoll_context* epctx;
    int    fd, index, eafd;
    uint16_t      eapsi;
};

struct iap2_context {
    struct iAP2Link_st* link;
    struct io_task      txq, rxq;
    pthread_t           mainid, eaid;
    unsigned char mainrunning, earunning, signal_tx;

    int           epfd, nl_fd;

    char busnum[4], devnum[4];
    unsigned int usb_state, alt;

    RcTimer   *timer;
    iAP2TimeCB_t  timercb;

    int           cdlen, cdfd;
    struct data_session_st* data[MFI_DATA_SESSION_NUM];
    unsigned char certificate_data[1280];

    /* temp buffer! Only use it in main_thread!!! */
    unsigned char buf[MFI_BULK_BUFFER_SIZE];
};


BOOL handle_control_session(struct iAP2Link_st* link, uint8_t* data, uint32_t dataLen);
BOOL handle_data_session(struct iAP2Link_st* link, uint8_t* data, uint32_t dataLen);
int new_data_session(iAP2Link_t *link, uint16_t eapsi, uint8_t id);
int close_data_session(struct iAP2Link_st* link, uint16_t eapsi);
void *ea_native_thread(void *arg);
int uevent_init(void);
int uevent_loop(struct iAP2Link_st* link);
int start_iap2(struct iAP2Link_st* link, int start);

#endif // _AP2_INTERNAL_H__
