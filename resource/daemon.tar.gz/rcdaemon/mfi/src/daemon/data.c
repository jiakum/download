
#include <stdlib.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>

#include <unistd.h>
#include <sys/types.h>
#include <fcntl.h>
#include <pthread.h>
#include <errno.h>
#include <sys/poll.h>
#include <sys/un.h>
#include <assert.h>
#include <signal.h>

#include "internal.h"
#include "list.h"
#include "utils.h"
#include <epoll_context.h>

static iAP2Packet_t* fillIAP2PacketHeader ( struct iAP2Link_st* link,
                                            iAP2Packet_t* pck,
                                            uint32_t        payloadLen)
{
    uint16_t checkSumLen = (payloadLen > 0 ? kIAP2PacketChksumLen : 0);

    pck->packetLen       = kIAP2PacketHeaderLen + payloadLen + checkSumLen;
    pck->pckData->sop1   = kIAP2PacketSYNC;
    pck->pckData->sop2   = kIAP2PacketSOP;
    pck->pckData->len1   = IAP2_HI_BYTE(pck->packetLen);
    pck->pckData->len2   = IAP2_LO_BYTE(pck->packetLen);
    pck->pckData->ctl    = kIAP2PacketControlMaskACK;
    pck->pckData->seq    = link->sentSeq;
    pck->pckData->ack    = link->sentAck;
    pck->pckData->sess   = MFI_DATA_SESSIONID;
    pck->pckData->chk    = 0;
    pck->seqPlus         = 0;
    pck->sendPacket      = TRUE;
    pck->debugData       = 0;

    pck->bufferLen  = pck->packetLen;
    pck->dataCurLen = iAP2PacketGetPayloadLen (pck);
    pck->dataChecksum = 0;

    pck->state = kiAP2PacketParseStateFINISH;
    pck->recvEAK = FALSE;
    pck->retransmitCount = 0;
    pck->timer = INVALID_TIMEOUT_ID;

    pck->cbContext = NULL;
    pck->callbackOnSend = NULL;

    return pck;
}

static int disconnect_data_session(struct data_session_st *snode)
{
    struct iAP2Link_st*  link = snode->link;
    struct iap2_context* ctx  = link->context;

    if(snode->fd <= 0)
        return 0;
    if(epoll_ctl(ctx->epfd, EPOLL_CTL_DEL, snode->fd, NULL) < 0) {
        printf("%s epoll ctl failed!!!\n", __func__);
        return -1;
    }
    close(snode->fd);
    snode->fd = -1;

    return 0;
}

int close_data_session(struct iAP2Link_st* link, uint16_t eapsi)
{
    struct iap2_context*  ctx  = link->context;
    struct data_session_st *snode;
    int index;

    for(index = 0;index < MFI_DATA_SESSION_NUM;index++) {
        snode = ctx->data[index];
        if(snode && snode->eapsi == eapsi)
            break;
    }

    if(index == MFI_DATA_SESSION_NUM) {
        printf("eapsi:0x%x, already closed ?\n", eapsi);
        return -EINVAL;
    }

    if(snode->fd > 0) {
        if(epoll_ctl(ctx->epfd, EPOLL_CTL_DEL, snode->fd, NULL) < 0) {
            printf("%s epoll ctl failed!!!\n", __func__);
        }
        close(snode->fd);
    }

    if(snode->packet)
        iAP2PacketDelete(snode->packet);
    free(snode->epctx);
    free(snode);
    ctx->data[index] = NULL;

    return 0;
}

static int handle_local_data(struct epoll_event *ev, struct epoll_context *epctx)
{
    struct data_session_st* snode = epctx->data;
    struct iAP2Link_st*   link    = snode->link;
    struct iAP2Packet_st* packet;
    unsigned char* buf;
    int    ret;

    if(ev->events & (EPOLLHUP | EPOLLERR))
        return disconnect_data_session(snode);

    if(ev->events & EPOLLIN) {

        while(1) {
            packet = snode->packet;
            buf    = packet->pckData->data + 2;
        
            ret = recv(snode->fd, buf, LOCAL_MAX_PAYLOAD_SIZE, 0);
            if(ret < 0) {
                if(errno == EINTR)
                    continue;
                else if(errno == EAGAIN)
                    break;
                else
                    return disconnect_data_session(snode);
            } else if(ret == 0)
                return disconnect_data_session(snode);

            buf    = packet->pckData->data;
            buf[0] = (snode->eapsi >> 8) & 0x0ff;
            buf[1] = snode->eapsi & 0x0ff;

            ret = iAP2LinkQueueSendDataPacket(link, fillIAP2PacketHeader(link, packet, ret + 2), 
                                        MFI_DATA_SESSIONID, NULL, NULL);
            if(ret) {
                snode->packet = iAP2PacketCreateEmptySendPacket(link);
                if(!snode->packet) {
                    printf("%s malloc failed!!!\n", __func__);
                    disconnect_data_session(snode);
                    return 0;
                }
            } else {
                /* remote die ? */
                disconnect_data_session(snode);
            }
        }

        return 0;
    }

    return 0;
}

static int connect_local(iAP2Link_t *link, struct data_session_st* pos)
{
    static int port[4] = {554, 1108, 66666, 12345};
    struct iap2_context*  ctx   = link->context;
    struct epoll_context* epctx = pos->epctx;
    struct sockaddr_un    addr;
    struct epoll_event    ev;
    int    fd;

    fd = socket(AF_UNIX, SOCK_STREAM, 0);
    addr.sun_family      = AF_UNIX;
    snprintf(addr.sun_path, sizeof(addr.sun_path), "/var/run/usb_proxy_svr_%d", port[pos->index]);

    if(connect(fd, (struct sockaddr *) &addr, sizeof(addr)) < 0) {
        close(fd);
        return -1;
    }
    fcntl(fd, F_SETFL, fcntl(fd, F_GETFL) | O_NONBLOCK);

    epctx->callback = handle_local_data;
    epctx->data     = pos;
    ev.events       = EPOLLIN;
    ev.data.ptr     = epctx;

    if(epoll_ctl(ctx->epfd, EPOLL_CTL_ADD, fd, &ev) < 0) {
        printf("%s epoll ctl failed!!!\n", __func__);
        close(fd);
        return -1;
    }

    return fd;
}

BOOL handle_data_session(struct iAP2Link_st* link, uint8_t* data, uint32_t dataLen)
{
    struct iap2_context*    ctx = link->context;
    struct data_session_st* session;;
    int    fd, left, index;
    int    try = 3, ret;
    uint16_t eapsi;

    eapsi = data[1] | (data[0] << 8);
    for(index = 0;index < MFI_DATA_SESSION_NUM;index++) {
        session = ctx->data[index];
        if(session && session->eapsi == eapsi)
            break;
    }

    if(index >= MFI_DATA_SESSION_NUM) {
        printf("session:%d not connected before!!!\n", index);
        return TRUE;
    }

    if(session->fd < 0 && connect_local(link, session) < 0) {
        printf("%s,try to connect index:%d failed!!\n", __func__, index);
        return TRUE;
    }

    data    += 2;
    dataLen -= 2;
    left     = dataLen;
    fd       = session->fd;
    while(left > 0) {
        ret = send(fd, data + dataLen - left, left, 0);

        if(ret < 0) {
            if(errno == EINTR) {
                continue;
            } else if(errno == EAGAIN) {
                if(--try)
                    continue;
                /* remote may be busy, close it ? */
            }

            disconnect_data_session(session);
            return TRUE;
        } else {
            left -= ret;
        }
    }

    return TRUE;
}

int new_data_session(iAP2Link_t *link, uint16_t eapsi, uint8_t id)
{
    struct iap2_context*    ctx    = link->context;
    struct data_session_st* pos    = malloc(sizeof(*pos));
    struct epoll_context*   epctx  = malloc(sizeof(*epctx));
    struct iAP2Packet_st*   packet = iAP2PacketCreateEmptySendPacket(link);
    int    index = id;

    if(index < 0 || index >= MFI_DATA_SESSION_NUM) {
        printf("%s,illegal index:%d\n", __func__, index);
        return -EINVAL;
    }

    if(ctx->data[index]) {
        printf("%s previous session:%d not closed!!!\n", __func__, index);
        close_data_session(link ,ctx->data[index]->eapsi);
        ctx->data[index] = NULL;
    }

    if(!pos || !epctx || !packet) {
        printf("%s malloc failed!!!\n", __func__);
        return -ENOMEM;
    }

    pos->packet = packet;
    pos->link   = link;
    pos->index  = index;
    pos->epctx  = epctx;
    pos->eapsi  = eapsi;

    ctx->data[index] = pos;

    if((pos->fd = connect_local(link, pos)) < 0) {
        printf("try to connect to port:%d failed\n", id);
    }

    printf("%s, add new port:%d\n", __func__, id);

    return 0;
}

static void *ea_native_send_thread(void *arg)
{
    iAP2Link_t *link = arg;
    struct iap2_context*    ctx    = link->context;
    struct data_session_st* pos    = ctx->data[0];
    unsigned char buf[USB_BULK_SIZE];
    int eafd = pos->eafd, fd = pos->fd;
    int ret, left, len;

    printf("%s, %d\n", __func__, __LINE__);
    while(ctx->earunning) {
        ret = recv(fd, buf, sizeof(buf), 0);
        if(ret < 0) {
            if(errno == EINTR)
                continue;
            goto end;
        } else if(ret == 0)
            goto end;
        
        len = left = ret;
        while(left > 0) {
            ret = write(eafd, buf + len - left, left);
            if(ret < 0) {
                if(errno == EINTR)
                    continue;
                goto end;
            } else if(ret == 0)
                goto end;

            left -= ret;
        }
    }

end:
    ctx->earunning = 0;
    printf("%s exit\n", __func__);

    return NULL;
}

void *ea_native_thread(void *arg)
{
    static struct data_session_st video_session;
    iAP2Link_t *link = arg;
    struct iap2_context*    ctx    = link->context;
    struct data_session_st* pos    = &video_session;
    unsigned char buf[USB_BULK_SIZE];
    int eafd, fd;
    struct sockaddr_un addr;
    int ret, left, len;
    pthread_t id;

    if(!pos) {
        printf("%s malloc failed!\n", __func__);
        return NULL;
    }

    ctx->data[0] = pos;
    eafd = open("/dev/ea_mdev", O_RDWR);
    if(eafd < 0) {
        printf("open ea driver failed!!!\n");
        return NULL;
    }
    pos->eafd = eafd;
    fd = socket(AF_UNIX, SOCK_STREAM, 0);
    addr.sun_family      = AF_UNIX;
    snprintf(addr.sun_path, sizeof(addr.sun_path), "/var/run/usb_proxy_svr_%d", 554);

    if(connect(fd, (struct sockaddr *) &addr, sizeof(addr)) < 0) {
        printf("connect %s failed:%s\n", addr.sun_path, strerror(errno));
        close(fd);
        goto end;
    }
    fcntl(fd, F_SETFL, fcntl(fd, F_GETFL) & ~O_NONBLOCK);
    pos->fd = fd;

    if(pthread_create(&id, NULL, ea_native_send_thread, link) < 0) {
        printf("%s pthread create return failed\n", __func__);
        return NULL;
    }

    while(ctx->earunning) {
        ret = read(eafd, buf, sizeof(buf));
        if(ret < 0) {
            if(errno == EINTR)
                continue;
            goto end;
        } else if(ret == 0)
            goto end;
        
        len = left = ret;
        while(left > 0) {
            ret = send(fd, buf + len - left, left, 0);
            if(ret < 0) {
                if(errno == EINTR)
                    continue;
                goto end;
            } else if(ret == 0)
                goto end;

            left -= ret;
        }
    }

end:
    close(eafd);
    close(fd);

    ctx->earunning = 0;
    pthread_join(id, NULL);
    ctx->data[0] = NULL;
    printf("%s exit:%s\n", __func__, strerror(errno));

    return NULL;
}
