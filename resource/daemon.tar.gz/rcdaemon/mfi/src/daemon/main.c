
#include <stdlib.h>
#include <stdint.h>
#include <stdio.h>
#include <ctype.h>
#include <string.h>

#include <unistd.h>
#include <sys/types.h>
#include <fcntl.h>
#include <pthread.h>
#include <errno.h>
#include <sys/poll.h>
#include <sys/ioctl.h>
#include <netinet/in.h>
#include <linux/netlink.h>
#include <linux/usb/ch9.h>
#include <linux/usbdevice_fs.h>
#include <signal.h>

#include "internal.h"
#include "rctimer.h"
#include "iAP2TimeImplementation.h"
#include <epoll_context.h>
#include <assert.h>
#include "wakeio.h"

struct buffer_queue {
    struct list_head list;
    unsigned char    *buf;
    int len;
};

static iAP2PacketSYNData_t synparam = 
{
    .version = 0x01,
    .maxOutstandingPackets = 0x05,
    .maxRetransmissions = 0x03,
    .maxCumAck = 0x03,
    .maxPacketSize = MFI_BULK_BUFFER_SIZE,
    .retransmitTimeout = 0x040B,
    .cumAckTimeout = 0x17,
    .numSessionInfo = 0x02, 
    .peerMaxOutstandingPackets = 0,
    .peerMaxPacketSize = 0,
    .sessionInfo[0] = 
        {
            .id = MFI_CONTROL_SESSIONID,
            .type = 0x0,
            .version = 0x01,
        },
    .sessionInfo[1] = 
        {
            .id = MFI_DATA_SESSIONID,
            .type = 0x2,
            .version = 0x01,
        },
};


static void *write_thread (void *data)
{
    struct io_task      *task = data;
    struct buffer_queue *bq;
    struct list_head    *list, *n, head;
    int ret, left, len;

    INIT_LIST_HEAD(&head);
    iap2_lock(&task->lock);
    while((volatile int)task->running) {
        if(list_empty(&task->list)) {
            iap2_unlock(&task->lock);
            wait_for_io(task, -1);
            iap2_lock(&task->lock);
            continue;
        }
        list_for_each_safe(list, n, &task->list) {
            list_del(list);
            list_add_tail(list, &head);
        }
        iap2_unlock(&task->lock);

        list_for_each(list, &head) {
            bq = list_entry(list, struct buffer_queue, list);

            left = bq->len;
            retry:
            while(left > 0) {
                len = left > USB_BULK_SIZE ? USB_BULK_SIZE : left;
                ret = write(task->fd, bq->buf + bq->len - left, len);
                if(ret < 0) {
                    if(errno == EINTR)
                        goto retry;
                    goto end;
                } else if(ret == 0)
                    goto end;

                left -= ret;
            }
        }

        iap2_lock(&task->lock);
        list_for_each_safe(list, n, &head) {
            list_del(list);
            list_add_tail(list, &task->idle);
        }
    }
    iap2_unlock(&task->lock);

end:
    printf("%s exit\n", __func__);

    return NULL;
}

static void *read_thread (void *data)
{
    struct io_task      *task = data;
    struct buffer_queue *bq;
    struct list_head    *list;
    unsigned char       *buf;
    int    ret = 0;

    iap2_lock(&task->lock);
    while((volatile int)task->running) {
        if(list_empty(&task->idle)) {
            iap2_unlock(&task->lock);
            bq = malloc(sizeof(*bq));
            buf = malloc(USB_BULK_SIZE);

            if(!bq || !buf) {
                printf("%s, malloc buffer failed!\n", __func__);
                goto end;
            }
            bq->buf = buf;
            iap2_lock(&task->lock);
            list_add_tail(&bq->list, &task->idle);
        }
        list = task->idle.next;
        list_del(list);
        iap2_unlock(&task->lock);

        bq = list_entry(list, struct buffer_queue, list);

        retry:
        ret = read(task->fd, bq->buf, USB_BULK_SIZE);
        if(ret < 0) {
            if(errno == EINTR || errno == EAGAIN)
                goto retry;
            goto end;
        } else if(ret == 0)
            goto end;

        bq->len = ret;

        iap2_lock(&task->lock);
        list_add_tail(list, &task->list);
        wakeup_io(task);
    }
    iap2_unlock(&task->lock);

end:
    printf("%s exit, ret:%d,error:%s\n", __func__, ret, strerror(errno));

    return NULL;
}

static void iap2_send_packet(struct iAP2Link_st* link, iAP2Packet_t* packet)
{
    struct iap2_context *ctx = link->context;
    struct io_task      *task = &ctx->txq;
    struct buffer_queue *bq;
    struct list_head    *list;
    unsigned char       *buf;

    if(packet->bufferLen > MFI_BULK_BUFFER_SIZE) {
        printf("emergency error!!! request buffer len:%d > %d\n", packet->bufferLen, MFI_BULK_BUFFER_SIZE);
        return;
    }

    iap2_lock(&task->lock);
    if(list_empty(&task->idle)) {
        iap2_unlock(&task->lock);
        bq = malloc(sizeof(*bq));
        buf = malloc(MFI_BULK_BUFFER_SIZE);

        if(!bq || !buf) {
            printf("%s, malloc buffer failed!\n", __func__);
            return;
        }
        bq->buf = buf;
        iap2_lock(&task->lock);
        list_add_tail(&bq->list, &task->idle);
    }
    list = task->idle.next;
    list_del(list);
    iap2_unlock(&task->lock);

    bq = list_entry(list, struct buffer_queue, list);
    bq->len = packet->bufferLen;

    iAP2PacketCalcHeaderChecksum(packet);

    memcpy(bq->buf, packet->pckData, bq->len);
    if(iAP2PacketGetPayloadLen(packet) > 0) {
        bq->buf[bq->len - 1] = iAP2PacketCalcPayloadChecksum(packet);
    }

    iap2_lock(&task->lock);
    list_add_tail(&bq->list, &task->list);
    iap2_unlock(&task->lock);
    wakeup_io(task);

    return;
}

static void iap2_send_packet_sync(struct iAP2Link_st* link, iAP2Packet_t* packet)
{
    struct iap2_context *ctx = link->context;
    struct io_task      *task = &ctx->txq;

    iap2_send_packet(link, packet);

    while(1) {
        usleep(1000);
        if(list_empty(&task->list)) {
            break;
        }
    }

    return;
}

static BOOL iap2_recv_session_data (struct iAP2Link_st* link, uint8_t* data, uint32_t dataLen, uint8_t session)
{
    switch(session)
    {
        case MFI_DATA_SESSIONID:
            return handle_data_session(link, data, dataLen);
        case MFI_CONTROL_SESSIONID:
            return handle_control_session(link, data, dataLen);
        default:
            printf("%s, Unrecognised session:%d!!!!\n", __func__, session);
            break;
    }

    return TRUE;
}

static void *main_thread(void *data)
{
    struct iAP2Link_st  *link = data;
    struct iap2_context *ctx  = link->context;
    struct io_task      *task = &ctx->rxq;
    struct list_head    *list, *n, head;
    struct buffer_queue *bq;
    iAP2Packet_t        *packet;
    struct epoll_context *epctx;
    unsigned char       *buf;
    int    ret, len, i;
    int    delay = 10, epfd = ctx->epfd;
    BOOL   got;

    INIT_LIST_HEAD(&head);
    epctx = epoll_add_wakeup(task, ctx->epfd);
    packet = iAP2PacketCreateEmptyRecvPacket(link);
    while(ctx->mainrunning) {
        struct epoll_event events[16];

        if(delay > 20)
            delay = 20;
        do {
            ret = epoll_wait(epfd, events, sizeof(events)/sizeof(events[0]), delay);
            if (ret < 0 && errno != EAGAIN && errno != EINTR) {
                printf("epoll return error:%d! This should never happen!!!\n",ret);
                return NULL;
            }
        } while (ret < 0);

        for ( i = 0; i < ret; i++ ) {
            struct epoll_context *epctx = events[i].data.ptr;

            if(epctx && epctx->callback)
                epctx->callback(&events[i], epctx);
            else
                printf("Illegal data! %p,%p\n", epctx, epctx ? epctx->callback : NULL);
        }

        iap2_lock(&task->lock);
        while(!list_empty(&task->list)) {
            list_for_each_safe(list, n, &task->list) {
                list_del(list);
                list_add_tail(list, &head);
            }
            iap2_unlock(&task->lock);

            list_for_each(list, &head) {
                bq = list_entry(list, struct buffer_queue, list);
                buf = bq->buf; len = bq->len;

                while(len > 0) {
                    ret = iAP2PacketParseBuffer((const uint8_t*)buf, len, packet, MFI_BULK_BUFFER_SIZE, &got, NULL, NULL);
                    if(packet->state >= kiAP2PacketParseStateFINISH) {
                        iAP2LinkHandleReadyPacket(link, packet);
                        packet = iAP2PacketCreateEmptyRecvPacket(link);
                    }

                    buf += ret; len -= ret;
                }
            }

            iap2_lock(&task->lock);
            list_for_each_safe(list, n, &head) {
                list_del(list);
                list_add_tail(list, &task->idle);
            }
        }
        iap2_unlock(&task->lock);

        while((volatile unsigned char)ctx->signal_tx) {
            ctx->signal_tx = 0;
            iAP2LinkProcessSendBuff(link);
        }

        delay = process_rctimer();
    }

    iAP2PacketDelete(packet);
    epoll_del_wakeup(task, epfd, epctx);

    return NULL;
}

static inline void free_bq(struct list_head *head) 
{
    struct buffer_queue *pos, *n;

    list_for_each_entry_safe(pos, n, head, list) {
        list_del(&pos->list);
        free(pos->buf);
        free(pos);
    }
}

int start_iap2(struct iAP2Link_st* link, int start)
{
    struct iap2_context *ctx = link->context;
    struct io_task      *txq = &ctx->txq, *rxq = &ctx->rxq;
    int fd;

    if(start) {
        if(txq->running && rxq->running && ctx->mainrunning) {
            printf("already started!\n");
            return 0;
        }
        if((fd = open("/dev/iap2_mdev", O_RDWR)) < 0) {
            printf("open file /dev/st10c_mfi failed!!! reason:%s\n", strerror(errno));
            return -1;
        }

        iap2_init_lock(&txq->lock, NULL);
        iap2_init_lock(&rxq->lock, NULL);
        init_wakeup(txq);
        init_wakeup(rxq);

        INIT_LIST_HEAD(&txq->list);
        INIT_LIST_HEAD(&txq->idle);
        INIT_LIST_HEAD(&rxq->list);
        INIT_LIST_HEAD(&rxq->idle);

        txq->running = 1;
        rxq->running = 1;
        ctx->mainrunning = 1;

        txq->fd = fd;
        rxq->fd = fd;

        if(pthread_create(&txq->id, NULL, write_thread, txq) < 0) {
            printf("pthread create return failed!!!\n");
            return -1;
        }

        if(pthread_create(&rxq->id, NULL, read_thread, rxq) < 0) {
            printf("pthread create return failed!!!\n");
            return -1;
        }

        if(pthread_create(&ctx->mainid, NULL, main_thread, link) < 0) {
            printf("pthread create return failed!!!\n");
            return -1;
        }

        iAP2LinkAttached(link);
        return 0;
    } else {

        if(!txq->running && !rxq->running && !ctx->mainrunning) {
            printf("already stopped!\n");
            return 0;
        }

        txq->running = 0;
        rxq->running = 0;
        ctx->mainrunning = 0;

        wakeup_io(txq);
        wakeup_io(rxq);

        pthread_join(txq->id, NULL);
        pthread_join(rxq->id, NULL);
        pthread_join(ctx->mainid, NULL);

        iap2_lock(&txq->lock);
        iap2_lock(&rxq->lock);

        free_bq(&txq->list);
        free_bq(&txq->idle);
        free_bq(&rxq->list);
        free_bq(&rxq->idle);

        iap2_unlock(&txq->lock);
        iap2_unlock(&rxq->lock);

        close(txq->fd);

        iap2_destroy_lock(&txq->lock);
        iap2_destroy_lock(&rxq->lock);

        close_wakeup(txq);
        close_wakeup(rxq);

        iAP2LinkDetached(link);
        iAP2LinkResetSend(link);
        return 0;
    }
}

static void iap2_connected_callback(struct iAP2Link_st* link, BOOL bConnected)
{
    printf("%s detect %s, peer max out standing packet:%d, cumAckTimeout:%d\n",__func__, 
            bConnected ? "connected": "disconnected", link->param.peerMaxOutstandingPackets, link->param.cumAckTimeout);
}

static void iap2_send_detect_data(struct iAP2Link_st* link, BOOL bBad)
{
    static char detect_ipa2[] = {0xff, 0x55, 0x02, 0x00, 0xEE, 0x10};
    static char detect_ipa1[] = {0xff, 0x55, 0x0E, 0x13, 0xFF, 0xFF, 0xFF, 0xFF, 
                                 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xEB};
    struct iap2_context *ctx = link->context;
    char  *buf = bBad ? detect_ipa1: detect_ipa2;
    int    ret, len = bBad ? sizeof(detect_ipa1) : sizeof(detect_ipa2);

    printf("%s, bBad:%d\n", __func__, bBad);
retry:
    ret = write(ctx->txq.fd, buf, len);
    if(ret < 0) {
        if(errno == EINTR)
            goto retry;
    }

    return;
}

/* call iAP2LinkProcessSendBuff later */
static void iap2_signal_process_buff(struct iAP2Link_st* link)
{
    struct iap2_context *ctx  = link->context;
    ctx->signal_tx = 1;
}

int main()
{
    struct iap2_context *ctx = malloc(sizeof(*ctx));
    int    fd = open("/sys/bus/i2c/devices/0-0011/acc20c", O_RDWR);
    iAP2Link_t          *link;

    if(fd < 0) {
        printf("%s,open file failed!!!\n", __func__);
        return -1;
    }

    if(!ctx) {
        printf("%s malloc failed\n", __func__);
        return -ENOMEM;
    }
    memset(ctx->data, 0, sizeof(ctx->data));
    ctx->cdlen = 0;
    ctx->cdfd  = fd;
    ctx->timer = NULL;
    ctx->epfd  = epoll_create1(EPOLL_CLOEXEC);
    if (ctx->epfd < 0) {
        printf("epoll create failed. err: %s\n", strerror(errno));
        return -1;
    }

    ctx->nl_fd = uevent_init();
    if (ctx->nl_fd < 0) {
        printf("open netlink socket failed. err: %s\n", strerror(errno));
        return -1;
    }
    
    link = iAP2LinkCreate(kiAP2LinkTypeAccessory, ctx, &synparam, 
                            iap2_send_packet, iap2_send_packet_sync, iap2_recv_session_data,
                            iap2_connected_callback, iap2_send_detect_data, iap2_signal_process_buff,
                            TRUE, 0x80, NULL);
    if(!link) {
        printf("iap2 link create failed!!!\n");
        return -ENOMEM;
    }
    ctx->link = link;
    iAP2LinkStart(link);

    uevent_loop(link);

    start_iap2(link, 0);
    close(fd);
    close(ctx->epfd);
    close(ctx->nl_fd);

    printf("iap2 daemon exit!\n");

    return 0;
}

#include <execinfo.h>
#include <sys/prctl.h>
void debug_exception_handler(void)
{
    time_t tmt = {0};
    char cur_time[16] = {0};

    size_t i,size = 0;
    void* address[32];
    char buf[17];

    char** data = NULL;
    struct tm *ptm = NULL;

    tmt = time(NULL);
    ptm = localtime(&tmt);
    strftime(cur_time, 32, "%Y-%m-%d %I:%M:%S", ptm);

    size = backtrace(address, 32);
    data = (char**)backtrace_symbols(address, size);

    prctl(PR_GET_NAME, buf);
    printf("-----------------------------exception occur------------------------------\n");
    printf("version :%s %s\n", __DATE__, __TIME__);
    printf("except time:%s\n", cur_time);
    printf("thread name:%s\n", buf);
    printf("stack size:%d,address:%p\n", size, address);
    for (i = 0 ; i < size ; ++ i)
    {
        printf("%d %s\n", i, data[i]);
    }
    printf("---------------------------------end--------------------------------------\n");
    printf("\n");
}
