#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/ip.h>
#include <arpa/inet.h>
#include <errno.h>

#define cbb_log(fmt, ...)  printf("%s %d:" fmt, __FUNCTION__, __LINE__, ##__VA_ARGS__)

/*
 * read data
 */
int cbb_read(int fd, void *buf, size_t len)
{
    int ret;

again:
    ret = read(fd, buf, len);
    if (ret < 0)
    {
        if (EAGAIN == errno)
        {
            goto again;
        }

        cbb_log("fd:%d read data failed, errno:%d\n", fd, errno);
        return -1;
    }

    if (0 == ret)
    {
        cbb_log("fd:%d read no data, maybe endof file\n", fd);
    }

    return ret;
}

/*
 * safe write
 */
int cbb_write(int fd, void *buf, int len)
{
    int ret;
    int size     = len;
    size_t offset   = 0;

repeat:
    ret = write(fd, buf + offset, size);
    if (ret < 0)
    {
        if (EINTR == errno)
        {
            goto repeat;
        }

        cbb_log("write falied, fd:%d,errno:%d\n", fd, errno);
        return -1;
    }
    else if (ret < size)
    {
        size    = size - ret;
        offset  = len - size;
        goto repeat;
    }

    return 0;
}

/*
 * safe send
 */
int cbb_send(int fd, void *buf, int len)
{
    int ret;
    int size     = len;
    size_t offset   = 0;

repeat:
    ret = send(fd, buf + offset, size, MSG_NOSIGNAL);
    if (ret < 0)
    {
        if (EINTR == errno)
        {
            goto repeat;
        }

        cbb_log("fd:%d send falied,errno:%d\n", fd, errno);
        return -1;
    }
    else if (ret < size)
    {
        size    = size - ret;
        offset  = len - size;
        goto repeat;
    }

    return 0;
}

/*
 * recv data
 */
int cbb_recv(int fd, void *buf, int len)
{
    int ret;

again:
    ret = recv(fd, buf, len, 0);
    if (ret < 0)
    {
        if (EAGAIN == errno)
        {
            goto again;
        }

        cbb_log("socket:%d recv data failed, errno:%d\n", fd, errno);
        return -1;
    }
    else if (0 == ret)
    {
        cbb_log("socket:%d recv no data, peer maybe shutdown\n", fd);
        return -1;
    }

    return ret;
}
