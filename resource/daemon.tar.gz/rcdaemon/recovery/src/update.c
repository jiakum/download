#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/ip.h>
#include <arpa/inet.h>
#include <errno.h>
#include <fcntl.h>

#include "common.h"
#include "update.h"

#define update_log(fmt, ...)  printf("%s %d:" fmt, __FUNCTION__, __LINE__, ##__VA_ARGS__)

/*
 * cp src to dst 
 */
int update_firmware(char *src, char *dst)
{
    int r_fd, w_fd;
    int ret;
    char *buf;
#define UPDATE_BUF_SIZE     4096 
    buf = malloc(UPDATE_BUF_SIZE);
    if (NULL == buf)
    {
        update_log("malloc failed\n");
        return -1;
    }
    
    r_fd = open(src, O_RDONLY, 0);
    if (r_fd < 0)
    {
        update_log("open file %s failed, errno:%d\n", src, errno);
        free(buf);
        return -1;
    }

    w_fd = open(dst, O_TRUNC | O_WRONLY, S_IRUSR | S_IWUSR | S_IRGRP | S_IWGRP | S_IROTH);
    if (-1 == w_fd)
    {
        update_log("open file %s failed, errno:%d\n", dst, errno);
        free(buf);
        close(r_fd);
        return -1;
    }

    for (;;)
    {
        ret = cbb_read(r_fd, buf, UPDATE_BUF_SIZE);
        if (ret < 0)
        {
            update_log("read data failed\n");
            ret = -1;
            break;
        }

        if (0 == ret)
        {
            update_log("data read to end\n");
            break;
        }

        ret = cbb_write(w_fd, buf, ret);
        if (ret < 0)
        {
            update_log("write data failed\n");
            ret = -1;
            break;
        }
    }

    // free resource
    free(buf);
    close(r_fd);
    close(w_fd);
    sync();

    update_log("src:%s-->dst:%s update result:%d\n", src, dst, ret);
    return ret;
}


/*
 * updata function
 */
int update_run()
{
    int ret;
    char   cmd[64] = {0};
    char   cmd2[32] = {0};
    char *argv1[] = {"/usr/bin/lzop", "-d", "/mnt/data/update.lzo", NULL};

int shell_execute(char *path, char *argv[]);

    ret = remove("/mnt/data/rootfs.fex");
    if (ret < 0)
    {
        update_log("remove rootfs.fex failed, errno:%d\n", errno);
    }

    ret = remove("/mnt/data/boot.img");
    if (ret < 0)
    {
        update_log("remove boot.img failed, errno:%d\n", errno);
    }
    sync();

    // decompress package
    ret = shell_execute("/usr/bin/lzop", argv1);
    if (ret < 0)
    {
        update_log("decompress update.lzo failed\n");
        return -1;
    }
    update_log("decompress file succeffsull\n");
    sync();

    // update boot
    ret = update_firmware("/mnt/data/boot.img", "/dev/mmcblk0p6");
    if (ret < 0)
    {
        update_log("update boot partition failed\n");
        return -1;
    }

    // update rootfs
    ret = update_firmware("/mnt/data/rootfs.ext4", "/dev/mmcblk0p7");
    if (ret < 0)
    {
        update_log("update rootfs partition failed\n");
        return -1;
    }
    sync();
    update_log("update system end\n");

    return 0;
}
