#include <linux/usbdevice_fs.h>
#include <linux/version.h>
#include <linux/usb/ch9.h>
#include <dirent.h>
#include <sys/wait.h>

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <unistd.h>
#include <sys/types.h>
#include <fcntl.h>
#include <pthread.h>
#include <errno.h>
#include <ctype.h>
#include <usbmuxd.h>
#include "common.h"
#include "utils.h"

#define DBGX(x...)
#define D(x...)

#define TAG     "device"

typedef struct {
    int         hasi;
    int         hasa;
    int         usbmux_handle;
    pthread_t   adb_thread_id;
    int         exit_scan_adb;
    int         rtsp_port;
    int         rc_port;
} DeviceContext;

static DeviceContext device_context = { 0 };

void scan_usbmuxd(const usbmuxd_event_t *event, void *arg)
{
    DeviceContext *p = (DeviceContext *)arg;
    usbmuxd_device_info_t *dev;

    dev = &(((usbmuxd_event_t *)event)->device);

    if(event->event == UE_DEVICE_ADD) {
        if(p->hasi) {
            loge(LOG_RCDAEMON, TAG, "two iphone connected ? Only the first is supported!!!\n");
            return;
        }

        logi(LOG_RCDAEMON, TAG, "iphone connected: device handle == %d (serial: %s)\n", dev->handle, dev->udid);
        p->hasi = 1;
        p->usbmux_handle = dev->handle;
    } else {
        p->hasi = 0;
        logi(LOG_RCDAEMON, TAG, "iphone disconnected\n");
    }
}

static int connect_iphone(DeviceContext *p, int port)
{
    int fd;

    if((fd = usbmuxd_connect(p->usbmux_handle, port)) < 0) {
        loge(LOG_RCDAEMON, TAG, "connect to iphone failed. port:%d\n", port);
        return -1;
    } else {
        logi(LOG_RCDAEMON, TAG, "connect to iphone success. port:%d\n", port);
        return fd;
    }
}

#define ADB_CLASS              0xff
#define ADB_SUBCLASS           0x42
#define ADB_PROTOCOL           0x1

static inline int is_adb_interface(int vid, int pid, int usb_class, int usb_subclass, int usb_protocol)
{
    vid = vid; pid = pid;
    if (usb_class == ADB_CLASS && usb_subclass == ADB_SUBCLASS &&
            usb_protocol == ADB_PROTOCOL) {
        return 1;
    }

    return 0;
}

static inline int badname(const char *name)
{
    while(*name) {
        if(!isdigit(*name++)) return 1;
    }
    return 0;
}

static int find_usb_device(const char *base)
{
    char   busname[32], devname[32];
    DIR   *busdir , *devdir ;
    struct dirent *de;
    int    fd ,found = 0;

    busdir = opendir(base);
    if(busdir == 0) return found;

    while((de = readdir(busdir)) != 0) {
        if(badname(de->d_name)) continue;

        snprintf(busname, sizeof busname, "%s/%s", base, de->d_name);
        devdir = opendir(busname);
        if(devdir == 0) continue;

        while((de = readdir(devdir))) {
            unsigned char  devdesc[4096];
            unsigned char* bufptr = devdesc;
            unsigned char* bufend;
            struct usb_device_descriptor*    device;
            struct usb_config_descriptor*    config;
            struct usb_interface_descriptor* interface;
            struct usb_endpoint_descriptor  *ep1, *ep2;
            unsigned vid, pid;
            size_t   desclength;

            if(badname(de->d_name)) continue;
            snprintf(devname, sizeof devname, "%s/%s", busname, de->d_name);

            if((fd = open(devname, O_RDONLY)) < 0) {
                continue;
            }

            desclength = read(fd, devdesc, sizeof(devdesc));
            bufend     = bufptr + desclength;

            // should have device and configuration descriptors, and atleast two endpoints
            if (desclength < USB_DT_DEVICE_SIZE + USB_DT_CONFIG_SIZE) {
                D("desclength %d is too small\n", desclength);
                close(fd);
                continue;
            }

            device  = (struct usb_device_descriptor*)bufptr;
            bufptr += USB_DT_DEVICE_SIZE;

            if((device->bLength != USB_DT_DEVICE_SIZE) || (device->bDescriptorType != USB_DT_DEVICE)) {
                close(fd);
                continue;
            }

            vid = device->idVendor;
            pid = device->idProduct;
            DBGX("[ %s is V:%04x P:%04x ]\n", devname, vid, pid);

            // should have config descriptor next
            config  = (struct usb_config_descriptor *)bufptr;
            bufptr += USB_DT_CONFIG_SIZE;
            if (config->bLength != USB_DT_CONFIG_SIZE || config->bDescriptorType != USB_DT_CONFIG) {
                D("usb_config_descriptor not found\n");
                close(fd);
                continue;
            }

            // loop through all the descriptors and look for the ADB interface
            while (bufptr < bufend) {
                unsigned char length = bufptr[0];
                unsigned char type = bufptr[1];

                if (type == USB_DT_INTERFACE) {
                    interface = (struct usb_interface_descriptor *)bufptr;
                    bufptr   += length;

                    if (length != USB_DT_INTERFACE_SIZE) {
                        D("interface descriptor has wrong size\n");
                        break;
                    }

                    DBGX("bInterfaceClass: %d,  bInterfaceSubClass: %d,"
                            "bInterfaceProtocol: %d, bNumEndpoints: %d\n",
                            interface->bInterfaceClass, interface->bInterfaceSubClass,
                            interface->bInterfaceProtocol, interface->bNumEndpoints);

                    if (interface->bNumEndpoints == 2 &&
                            is_adb_interface(vid, pid, interface->bInterfaceClass,
                                interface->bInterfaceSubClass, interface->bInterfaceProtocol))  {


                        DBGX("looking for bulk endpoints\n");
                        // looks like ADB...
                        ep1     = (struct usb_endpoint_descriptor *)bufptr;
                        bufptr += USB_DT_ENDPOINT_SIZE;
                        ep2     = (struct usb_endpoint_descriptor *)bufptr;
                        bufptr += USB_DT_ENDPOINT_SIZE;

                        if (bufptr > devdesc + desclength ||
                                ep1->bLength != USB_DT_ENDPOINT_SIZE ||
                                ep1->bDescriptorType != USB_DT_ENDPOINT ||
                                ep2->bLength != USB_DT_ENDPOINT_SIZE ||
                                ep2->bDescriptorType != USB_DT_ENDPOINT) {
                            D("endpoints not found\n");
                            break;
                        }

                        // both endpoints should be bulk
                        if (ep1->bmAttributes != USB_ENDPOINT_XFER_BULK ||
                                ep2->bmAttributes != USB_ENDPOINT_XFER_BULK) {
                            D("bulk endpoints not found\n");
                            continue;
                        }

                        found = 1;
                        break;
                    }
                } else {
                    bufptr += length;
                }
            } // end of while

            close(fd);
        } // end of devdir while
        closedir(devdir);
    } //end of busdir while
    closedir(busdir);

    return found;
}

void* scan_adb(void *arg)
{
    DeviceContext *p = (DeviceContext *)arg;
    int    hasa, changed;
    int64_t curtime;
    int sleeptime;
    int ret;

    usleep(1000 * 1000);
    while(p->exit_scan_adb == 0) {
        hasa    = find_usb_device("/dev/bus/usb");

        changed = (hasa != p->hasa);
        if(changed && hasa) {
            ret = adb_forward(p->rtsp_port);
            if (ret < 0)
            {
                loge(LOG_RCDAEMON, TAG, "adb_forward(%u) failed\n", p->rtsp_port);
                return NULL;
            }

            ret = adb_forward(p->rc_port);
            if (ret < 0)
            {
                loge(LOG_RCDAEMON, TAG, "adb_forward(%u) failed\n", p->rc_port);
                return NULL;
            }

            logi(LOG_RCDAEMON, TAG, "adb connected\n");
        }

        p->hasa = hasa;

        curtime = get_current_time();
        sync();
        sleeptime = get_current_time() - curtime;
        sleeptime = 1000 * 1000 - sleeptime;
        if(sleeptime > 0)
            usleep(sleeptime);
    }

    return NULL;
}


static int connect_adb(DeviceContext *p, int port)
{
    int    fd;
    struct sockaddr_un addr;
    int    hasa = p->hasa;
    int    ret;

    if(!hasa) {
        loge(LOG_RCDAEMON, TAG, "Please check data->hasa before call connect_adb!!!\n");
        return -1;
    }
    else
    {
        ret = adb_forward(port);
        if (ret < 0)
        {
            loge(LOG_RCDAEMON, TAG, "adb_forward(%u) failed\n", port);
            return -1;
        }

        fd = socket(AF_UNIX, SOCK_STREAM, 0);
        addr.sun_family      = AF_UNIX;
        snprintf(addr.sun_path, sizeof(addr.sun_path), LOCAL_SOCKET_FMT, port);

        if(connect(fd, (struct sockaddr *) &addr, sizeof(addr)) < 0) {
            loge(LOG_RCDAEMON, TAG, "connect to adb port:%d failed. adb disconneted?\n", port + 1);
            close(fd);
            return -1;
        }

        fcntl(fd, F_SETFL, fcntl(fd, F_GETFL) | O_NONBLOCK);
        if (port == 1108) {
            logi(LOG_RCDAEMON, TAG, "adb connect port:%d success .\n", port);
        }

        return fd;
    }
}

int device_has_iphone()
{
    DeviceContext *p = &device_context;

    return p->hasi;
}

int device_has_adb()
{
    DeviceContext *p = &device_context;

    return p->hasa;
}

int device_connect(int port)
{
    DeviceContext *p = &device_context;
    int fd = -1;

    if ( (p->hasa && (fd = connect_adb(p, port)) >= 0)
            || (p->hasi && (fd = connect_iphone(p, port)) >= 0) ) {
        logi(LOG_RCDAEMON, "phone", "connect port %d sucessfully\n", port);
    }

    return fd;
}

int device_init()
{
    DeviceContext *p = &device_context;

    memset(p, 0, sizeof(DeviceContext));

    p->rc_port = 1108;
    p->rtsp_port = 54540;

    usbmuxd_subscribe(scan_usbmuxd, p);
    pthread_create(&p->adb_thread_id, NULL, scan_adb, p);

    return 0;
}

void device_deinit()
{
    DeviceContext *p = &device_context;

    usbmuxd_unsubscribe();
    p->exit_scan_adb = 1;
    pthread_join(p->adb_thread_id, NULL);
}
