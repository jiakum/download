#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/ip.h>
#include <arpa/inet.h>
#include <pthread.h>
#include <sys/epoll.h>
#include <errno.h>
#include <fcntl.h>
#include <time.h>
#include <signal.h>

#include "recovery.h"
#include "analysis.h"
#include "socklinker.h"
#include "debug.h"


/*
 * safe send
 */
int m_send(void *context, void *buf, int len)
{
    return cbb_send((int)context, buf, len);
}

/*
 * recv data
 */
int m_recv(void *context, void *buf, int len)
{
    return cbb_recv((int)context, buf, len);
}

#define MAIN_RECV_BUF_LEN   1500
typedef struct tagRecoveryInfo
{
    HAnalysisHandle     analysis;                   /// analysis client
    HSockLinkHandle     link;                       /// socket linker & timer
    TSockEvTaskParam    link_param;                 /// link param
    TSockEpollCtx       ctx;                        /// link context
    uint8_t             m_buf[MAIN_RECV_BUF_LEN];   /// recv buf
    int                 end;
    int                 failed;
}TRecoveryInfo;
static TRecoveryInfo recovery;          /// recovery global data


void m_analysis_input_data(void *context, struct epoll_event *ev)
{
    TRecoveryInfo *rec  = context;
    int ret = m_recv(rec->link_param.fd, rec->m_buf, sizeof(rec->m_buf));
    if (ret > 0)
    {
        ret = analysis_input_data(rec->analysis, rec->m_buf, ret);
    }

    if (ret >= 0)
    {
        return;
    }

    // deal error,close current analysis handle & sock fd
    // close link & analysis
    ret = sock_del_ev_task(rec->link, &rec->link_param);
    if (ret < 0)
    {
        printf("sock del ev task failed\n");
    }
    close(rec->link_param.fd);
    recovery.failed = 1;
}

void *m_op_flash_task(void *arg)
{
    int ret;

    printf("operate flash task run now,arg:%p\n", arg);

    ret = update_run();
    if (ret < 0)
    {
        printf("update flash failed\n");
        ret = -1;
    }
    else
    {
        printf("update flash successfull\n");
        ret = 0;
    }

    // set recovery result
    ret = analysis_set_recovery_op_state(recovery.analysis, ret);
    if (ret < 0)
    {
        printf("analysis_set_recovery_op_state failed\n");
    }
}

/*
 * start to erase flash
 */
int m_start_op_flash()
{
    int ret;
    pthread_t pid;

    ret = pthread_create(&pid, NULL, m_op_flash_task, NULL);
    if (0 != ret)
    {
        printf("create operate flash task failed,errno:%d\n", errno);
        ret = -1;
    }

    return ret;
}

/*
 * deal analysis event
 */
int m_analysis_ev_deal(void *context, EAnalysiserEvent ev, void *buf, int len)
{
    int ret = -1;
    switch (ev)
    {
        case AE_END_FILE_TRANS:
            ret = m_start_op_flash();
            break;

        case AE_END_RECOVERY:
            recovery.end    = 1;
            ret = 0;
            break;

        default:
            break;
    }

    printf("deal analysis event:%d, ret:%d\n", ev, ret);
    return ret;
}

int m_start_recovery()
{
    int fd, ret;

    // connect adb fd
    fd = sock_connect_adb(12345);
    if (fd < 0)
    {
        printf("sock connect failed\n");
        return -1;
    }


    // create analysis client handle
    recovery.analysis = analysis_create(ANALYSIS_TYPE_CLIENT);
    if (ANALYSIS_INVALID_HANDLE == recovery.analysis)
    {
        printf("create handle failed\n");
        return -1;
    }

    // set callback
    ret = analysis_set_cb(recovery.analysis, m_send, (void *)fd, NULL, 0);
    if (ret < 0)
    {
        printf("set analysis callback failed\n");
        return -1;
    }

    ret = analysis_set_ev_cb(recovery.analysis, m_analysis_ev_deal, NULL);
    if (ret < 0)
    {
        printf("set analysis ev callback failed\n");
        return -1;
    }

    // create sock link
    recovery.link = sock_create_linker(10, 10);
    if (SOCKLINK_INVALID_HANDLE == recovery.link)
    {
        printf("create link failed\n");
        return -1;
    }

    recovery.ctx.func               = m_analysis_input_data;
    recovery.ctx.context            = &recovery;
    recovery.link_param.fd          = fd;
    recovery.link_param.op          = EPOLL_CTL_ADD;
    recovery.link_param.ev.events   = EPOLLIN;
    recovery.link_param.ev.data.ptr  = &recovery.ctx;
    ret = sock_add_ev_task(recovery.link, &recovery.link_param);
    if (ret < 0)
    {
        printf("add ev task failed\n");
        return -1;
    }

    ret = sock_add_timer_task(recovery.link, analysis_timer_routine, recovery.analysis);
    if (ret < 0)
    {
        printf("add timer task failed\n");
        return -1;
    }
    recovery.failed                 = 0;
    recovery.end                    = 0;
}

/*
 * stop recovery
 */
int m_stop_recovery()
{
    int ret;

    recovery.link_param.op          = EPOLL_CTL_DEL;
    ret = sock_del_ev_task(recovery.link, &recovery.link_param);
    if (ret < 0)
    {
        printf("del ev task failed\n");
    }

    analysis_destroy(recovery.analysis);
    if (-1 != recovery.link_param.fd)
    {
        close(recovery.link_param.fd);
        recovery.link_param.fd = -1;
    }

    printf("stop recovery\n");
    return 0;
}



/*
 * recovery entry
 */
int main(int argc, char *argv[])
{
    int ret, fd;

    if (argc > 2)
    {
        printf("Usage: [%s] more argument need\n", argv[0]);
        return -1;
    }

    // init debug
    ret = debug_init();
    if (ret < 0)
    {
        printf("debug init successfulled\n");
    }

    // start recovery
    ret = m_start_recovery();
    if (ret < 0)
    {
        printf("start recovery failed\n");
        return -1;
    }

    // start erase flash

    for(;;)
    {

        if (1 == recovery.failed)
        {
            printf("recovery failed,exit now\n");
            break;
        }

        if (1 == recovery.end)
        {
            printf("to stop recovery\n");
            ret = m_stop_recovery();

            if (ret < 0)
            {
                printf("stop recovery failed\n");
            }

int boot_normal(void);
            boot_normal();
            system("reboot -f");

            break;
        }
    }

    return 0;
}



