
#include <stdlib.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>

#include <unistd.h>
#include <sys/types.h>
#include <fcntl.h>
#include <errno.h>

#include "search.h"

#define CONFIG_ENV_SIZE (128 << 10)
#define ENV_HEADER_SIZE (sizeof(uint32_t))

typedef struct {
    uint32_t crc;
    unsigned char data[CONFIG_ENV_SIZE - ENV_HEADER_SIZE];
} env_t;

extern uint32_t crc32 (uint32_t crc, const unsigned char *p, unsigned int len);
static int read_env(int fd, env_t *env, struct hsearch_data *env_htab)
{
    int ret, left;
    uint32_t crc;

    left = sizeof(*env);
    lseek(fd, SEEK_SET, 0);

    while(left > 0) {
        char *buf = (char *)env;

        ret = read(fd, buf + sizeof(*env) - left, left);
        if(ret < 0) {
            if(errno != EAGAIN && errno != EINTR) {
                return -1;
            }
            continue;
        } else if(ret == 0) {
            printf("%s end of file reached!!! left:%d\n", __func__, left);
            return -1;
        } else
            left -= ret;
    }

    if((crc = crc32(0, env->data, sizeof(env->data))) != env->crc) {
        printf("crc error!!! file crc:0x%x, crc32 return:0x%x\n", env->crc, crc);
        return -1;
    }
    if(himport_r(env_htab, (char*)env->data, sizeof(env->data), '\0', 0) == 0) {
        printf("import env into hash table failed!!!\n");
        return -1;
    }
    printf("%s, crc:0x%x\n", __func__, env->crc);

    return 0;
}

static int write_env(int fd, env_t *env, struct hsearch_data *env_htab)
{
    char  *res = (char *)env->data;
    int ret, left;

    if(hexport_r(env_htab, '\0', &res, sizeof(env->data)) < 0) {
        printf("export hash table failed!\n");
        return -1;
    }
    env->crc = crc32(0, env->data, sizeof(env->data));
    printf("%s, crc:0x%x\n", __func__, env->crc);

    left = sizeof(*env);
    lseek(fd, SEEK_SET, 0);

    while(left > 0) {
        char *buf = (char *)env;

        ret = write(fd, buf + sizeof(*env) - left, left);
        if(ret < 0) {
            if(errno != EAGAIN && errno != EINTR) {
                return -1;
            }
            continue;
        } else
            left -= ret;
    }

    return 0;
}

static int replace_env_args_internal(struct hsearch_data *env_htab, char *name, char *src, char *dest)
{
    int max, slen, dlen;
    ENTRY e, *ep;
    char *buf, *p;

    e.key = name;
    e.data = NULL;
    hsearch_r(e, FIND, &ep, env_htab);
    if(!ep) {
        printf("can not find %s!!!\n", name);
        return -1;
    }

    max = strlen(ep->data) + strlen(dest) + 16;
    max = max & ~0x03;
    if(!(buf = malloc(max))) {
        printf("%s, malloc %d failed\n", __func__, max);
        return -ENOMEM;
    }

    strcpy(buf, ep->data);
    p = buf;
    slen = strlen(src);
    dlen = strlen(dest);
    while(*p) {
        if(!strncmp(p, src, slen)) {
            memmove(p + dlen, p + slen, strlen(buf) - (p - buf) - slen + /* include '\0' */ 1);
            strncpy(p, dest, dlen);
            break;
        }
        p++;
    }

    printf("%s, buf:%s\n", __func__, buf);

    e.key = name;
    e.data = buf;
    hsearch_r(e, ENTER, &ep, env_htab);
    if(!ep) {
        printf("error inserting %s, value:%s\n", name, buf);
        free(buf);
        return -1;
    }

    free(buf);
    return 0;
}

static int replace_uboot_args(char *name, char *src, char *dest)
{
    char *block = "/dev/mmcblk0p5";
    env_t *env = malloc(sizeof(*env));
    struct hsearch_data env_htab;
    int fd;

    if(!env || (fd = open(block, O_RDWR)) < 0) {
        printf("open %s error :%s\n", block, strerror(errno));
        return -1;
    }

    memset(&env_htab, 0, sizeof(env_htab));
    if(read_env(fd, env, &env_htab) < 0) {
        printf("read env error!\n");
        goto err;
    }

    if(replace_env_args_internal(&env_htab, name, src, dest) < 0) {
        printf("replace env args failed!!!\n");
        goto err;
    }

    if(write_env(fd, env, &env_htab) < 0) {
        printf("write env err!!!\n");
        goto err;
    }

    hdestroy_r(&env_htab);
    free(env);
    fsync(fd);
    close(fd);
    return 0;

err:
    hdestroy_r(&env_htab);
    free(env);
    close(fd);
    return -1;
}

int boot_recovery(void)
{
    return replace_uboot_args("bootcmd", "boot_normal", "boot_recovery");
}

int boot_normal(void)
{
    return replace_uboot_args("bootcmd", "boot_recovery", "boot_normal");
}

#ifdef TEST_BOOT_RECOVERY
int main(int argc, char *argv[])
{
    if(argc < 2) {
        printf("usage: %s boot_recovery(or boot_normal)\n", argv[0]);
        return 0;
    }

    if(!strncmp("boot_recovery", argv[1], strlen("boot_recovery")))
        boot_recovery();
    else if(!strncmp("boot_normal", argv[1], strlen("boot_normal")))
        boot_normal();
    else
        printf("usage: %s boot_recovery(or boot_normal)\n", argv[0]);

    return 0;
}
#endif
