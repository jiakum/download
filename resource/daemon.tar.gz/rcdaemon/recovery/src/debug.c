#include <stdio.h>
#include <errno.h>
#include <signal.h>
#include <time.h>
#include <execinfo.h>
#include <stdlib.h>
#include <string.h>
#include <sys/prctl.h>

#include <syslog.h>

#define LOG_EXCEPTION   LOG_LOCAL4

#define debug_log(format, ...)  \
    {                                                       \
        openlog("EXCEPTION", LOG_ODELAY, LOG_EXCEPTION);    \
        syslog(LOG_ERR, format, ##__VA_ARGS__);             \
    }

/*
 * deal exception, get stack
 */
void debug_exception_handler(int sig, siginfo_t *info, void *context)
{
    time_t tmt = {0};
    char cur_time[16] = {0};

    size_t i,size = 0;
    void* address[32];
    char buf[17];

    char** data = NULL;
    struct tm *ptm = NULL;
    int ret;

    tmt = time(NULL);
    ptm = localtime(&tmt);
    strftime(cur_time, 32, "%Y-%m-%d %I:%M:%S", ptm);


    signal(sig, SIG_DFL);
    size = backtrace(address, 32);
    data = (char**)backtrace_symbols(address, size);

    ret = prctl(PR_GET_NAME, buf);
    debug_log("-----------------------------exception occur------------------------------\n");
    debug_log("version :%s %s\n", __DATE__, __TIME__);
    debug_log("except time:%s signal:%d\n", cur_time, sig);
    debug_log("thread name:%s\n", buf);
    debug_log("stack size:%d,address:%p,siginfo:%p,context:%p\n", size, address, info, context);
    for (i = 0 ; i < size ; ++ i)
    {
        debug_log("%d %s\n", i, data[i]);
    }
    debug_log("---------------------------------end--------------------------------------\n");
    debug_log("\n");
}

/*
 * init debug module
 * now only with signal, need dynamic debuger later
 */
int debug_init()
{
    static int signal_to_capture[] = {SIGINT, SIGILL, SIGFPE, SIGSEGV, SIGTERM, SIGABRT, SIGPIPE};
    unsigned int i;
    int ret;
    struct sigaction act;
    memset(&act, 0, sizeof act);

    act.sa_sigaction = debug_exception_handler;
    act.sa_flags    = SA_RESETHAND | SA_SIGINFO;
    sigemptyset(&act.sa_mask);
    for (i = 0; i < sizeof(signal_to_capture) / sizeof(signal_to_capture[0]); i++)
    {
        ret = sigaction(signal_to_capture[i], &act, NULL);
        if (ret < 0)
        {
            printf("reg sig action failed,signal:%d,errno:%d\n", signal_to_capture[i], errno);
        }
    }

    // allways return ok
    return 0;
}
