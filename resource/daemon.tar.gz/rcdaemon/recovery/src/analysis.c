#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/ip.h>
#include <arpa/inet.h>
#include <pthread.h>
#include <sys/epoll.h>
#include <errno.h>
#include <fcntl.h>
#include <time.h>

#include "common.h"
#include "recovery.h"
#include "protocol.h"
#include "analysis.h"
#include "md5.h"


#define analysis_log(fmt, ...)  printf("%s %d:" fmt, __FUNCTION__, __LINE__, ##__VA_ARGS__)

#define ANALYSIS_RECV_BUF_LEN   1500
#define ANALYSIS_BUF_LEN        (128 * 1024)


/// client state
enum AnalysiserState{
    AS_UNREADY          = 0,

    AS_MACHINE_INFO     ,   // 1
    AS_START_RECOVERY   ,   // 2

    AS_REQUEST_NEWFILE  ,   // 3
    AS_TRANS_FILEDATA   ,   // 4

    AS_FILEDATA_MD5     ,   // 5

    AS_END_TRANSFILE    ,   // 6
    AS_END_RECOVERY     ,   // 7

    /// insert new state here
    AS_WAIT_REPLY,          // 8

    AS_EXIT             ,   // 9
};

/// dec
struct tagAnalysiser;

/// define statemachine function,if return non-zero,exit
typedef int (*FAnalysisStateFunc)(struct tagAnalysiser *analysis);


/// client/server define
typedef struct tagAnalysiser
{
    int                     type;
    enum AnalysiserState    state;
    int                     errors;
    int                     recovery_result;

    /// buf for store data
    uint8_t                 buf[ANALYSIS_BUF_LEN];
    int                     buf_len;
    uint8_t                 recv_buf[ANALYSIS_RECV_BUF_LEN];
    int                     recv_len;

    struct md5_state        md5_result;
	uint32_t                md5[MD5_HASH_WORDS];

    /// state deal function
    FAnalysisStateFunc      deal_func[AS_EXIT + 1];

    uint16_t                seq;
    struct RCPacket         recv_packet;
    struct RCPacket         send_packet;
    struct PackageInfo      pkg_info;
    struct MachineInfo      machine_info;

    int                     file_fd;
    struct RCFileInfo       file_info;
    struct RCFileInfo       send_file_info;
    struct RCFileInfo       latest_file_info;
    struct RCFileInfo       transferring_file_info;
    struct RCFileInfo       recv_file_info;
    int32_t                 cur_file_index;                         // from 0
    char                    cur_file_name[RCFILE_NAMES_MAX_LEN];

    /// all callback and context
    FAnalysisDataCb         send_cb;
    void                    *send_context;
    FAnalysisDataCb         recv_cb;
    void                    *recv_context;
    FAnalysisEvCb           ev_cb;
    void                    *ev_context;
}TAnalysiser;

/*
 * find one packet from buffer
 */
int analysis_protocol_head_check(TAnalysiser *analysis)
{
    int pos;
    struct RCPacket *packet;
    int packet_len;
    uint8_t crc[2];

    if (analysis->buf_len < RCPACKET_HEAD_LEN)
    {
        return -1;
    }

    // look for one command
    for (pos = 0; pos < analysis->buf_len - 1; pos++)
    {
        // match head falg "@$"
        if ( (analysis->buf[pos] == '@') && (analysis->buf[pos + 1] == '$') )
        {
            // maybe find one packet
            int valid_buf_len = analysis->buf_len - pos;
            if (valid_buf_len < RCPACKET_HEAD_LEN)
            {
                break;
            }
#define ANALYSIS_CRC_NOT_CMP(src, dst)  (!( (src[0] == dst[0]) && 1))// (src[1] == dst[1]) ))
            // cal crc
            packet = (struct RCPacket *)(analysis->buf + pos);
            crc[0] = calc_crc8(analysis->buf + pos, RCPACKET_HEAD_LEN - 2);
            crc[1] = ~crc[0];
            if ( ANALYSIS_CRC_NOT_CMP(crc, packet->crc) || (packet->len > RCPACKET_MAXPAYLOADSIZE) )
            {
                // crc not match or len not match
                analysis_log("crc[%u %u] not match or len invalid, len:%u,buf_len:%d,pos:%d\n",
                            crc[0], packet->crc[0], packet->len, analysis->buf_len, pos);

                analysis_log("buf:%u %u %u %u    %u %u %u %u    %u %u %u %u\n",
                            analysis->buf[0], analysis->buf[1], analysis->buf[2], analysis->buf[3],
                            analysis->buf[4], analysis->buf[5], analysis->buf[6], analysis->buf[7],
                            analysis->buf[8], analysis->buf[9], analysis->buf[10], analysis->buf[11]);
                continue;
            }

            /* crc check success , check the total pakcet length */
            packet_len = packet->len + RCPACKET_HEAD_LEN;
            if (packet_len <= analysis->buf_len - pos)
            {
                memcpy(&analysis->recv_packet, analysis->buf + pos, packet_len);
                analysis->buf_len = analysis->buf_len - pos - packet_len;

                if (0 != analysis->buf_len)
                {
                    memcpy(analysis->buf, analysis->buf + pos + packet_len, analysis->buf_len - pos - packet_len);
                }
                // analysis_log("client get one packet,pos:%d\n", pos);
                /* everything is ok ! return 0 for success */
                return 0;
            } else
                break;
        }
    }

    if(pos) {
        analysis->buf_len -= pos;
        memcpy(analysis->buf, analysis->buf + pos, analysis->buf_len);
    }

    // if not match,wait for coming data
    analysis_log("look for packet and no match flag\n");
    return -1;
}

/*
 * to recv GET_MACHINE_INFO from server
 */
int analysis_recv_cmd(TAnalysiser *analysis)
{
    int ret;

again:
    // recv from callback
    ret = analysis->recv_cb(analysis->recv_context, analysis->recv_buf, sizeof(analysis->recv_buf));
    if ( (ret < 0) || (ret > (int)sizeof(analysis->recv_buf)) )
    {
        analysis_log("callback recv data failed, ret:%d\n", ret);
        return -1;
    }
    else if (0 == ret)
    {
        /// here to complete
        /// to deal overtime
        analysis_log("run here is a fatal error\n");
        goto again;
    }

    // deal buffer data
    if (ret + analysis->buf_len <= (int)sizeof(analysis->buf))
    {
        memcpy(analysis->buf + analysis->buf_len, analysis->recv_buf, ret);
        analysis->buf_len   += ret;
    }
    else
    {
        // 保留最后一个字符
        analysis_log("there are data not dealed, buf data len:%d\n", analysis->buf_len);
        memcpy(analysis->buf, analysis->recv_buf, ret);
        analysis->buf_len   = ret;
    }

    // head check
    ret = analysis_protocol_head_check(analysis);
    if (ret < 0)
    {
        analysis_log("do not find head,again\n");
        goto again;
    }

    return 0;
}

/*
 * exit state
 */
int analysis_state_exit(TAnalysiser *analysis)
{
    int ret;
    analysis_log("%p state exit\n", analysis);

    if (NULL != analysis->ev_cb)
    {
        ret = analysis->ev_cb(analysis->ev_context, AE_END_RECOVERY, NULL, 0);
        if (ret < 0)
        {
            analysis_log("callback ev AE_END_RECOVERY failed\n");
        }
    }

    return -1;
}

/*
 * unready and exit
 */
int analysis_state_unready(TAnalysiser *analysis)
{
    if (NULL != analysis->send_cb)
    {
        analysis->state     = AS_MACHINE_INFO;
        analysis->errors    = 0;
        analysis_log("%p state change to AS_MACHINE_INFO\n", analysis);
        return 0;
    }

    analysis_log("%p state unready\n", analysis);
    return -1;
}

/*
 * send machine info to server
 */
int analysis_send_machine_info_reply(TAnalysiser *analysis)
{
    int ret;
    struct MachineInfo machine_info;
#define DL_MACHINE_ID       "ST10C"
#define DL_UBOOT_VER        "1.0.0"
#define DL_KERNEL_VER       "1.0.0"
#define DL_ROOTFS_VER       "1.0.0"
#define DL_RCDAEMON_VER     "1.0.0"
    // set machine info
    memset(&machine_info, 0, sizeof(machine_info));
    strncpy(machine_info.machineid, DL_MACHINE_ID, sizeof(machine_info.machineid));
    strncpy(machine_info.ubootversion, DL_UBOOT_VER, sizeof(machine_info.ubootversion));
    strncpy(machine_info.kernelversion, DL_KERNEL_VER, sizeof(machine_info.kernelversion));
    strncpy(machine_info.rootfsversion, DL_ROOTFS_VER, sizeof(machine_info.rootfsversion));
    strncpy(machine_info.rcdaemonversion, DL_RCDAEMON_VER, sizeof(machine_info.rcdaemonversion));

    protocol_construct_packet(&analysis->send_packet, analysis->seq, RCFLAGS_RESPONSE, RCCOMMAND_GET_MACHINEINFO,
                                (uint8_t *)&machine_info, sizeof(machine_info));

    analysis_log("to send machine info to server\n");
    ret = analysis->send_cb(analysis->send_context, (uint8_t *)&analysis->send_packet, sizeof(machine_info) + RCPACKET_HEAD_LEN);
    if (ret < 0)
    {
        analysis_log("send machine info to server failed, exit now\n");
        analysis->state = AS_EXIT;
        return -1;
    }

    if ((AS_MACHINE_INFO == analysis->state) || (analysis->state == AS_UNREADY))
    {
        analysis_log("state changed from AS_MACHINE_INFO to AS_START_RECOVERY\n");
        analysis->state = AS_START_RECOVERY;
    }

    return 0;
}

/*
 * reply START_RECOVERY cmd
 */
void analysis_send_start_recovery_reply(TAnalysiser *analysis)
{
    int ret;

#define DL_OK       "OK"
#define DL_NONOK    "FAILED"
    memcpy(&analysis->pkg_info, analysis->recv_packet.payload, sizeof(analysis->pkg_info));
    protocol_construct_packet(&analysis->send_packet, analysis->seq, RCFLAGS_RESPONSE, RCCOMMAND_START_RECOVERY,
                                (uint8_t *)DL_OK, sizeof(DL_OK));

    analysis_log("to send request START_RECOVERY reply\n");
    ret = analysis->send_cb(analysis->send_context, (uint8_t *)&analysis->send_packet, sizeof(DL_OK) + RCPACKET_HEAD_LEN);
    if (ret < 0)
    {
        analysis_log("send START_RECOVERY reply to server failed, exit now\n");
        analysis->state = AS_EXIT;
    }

    if (AS_START_RECOVERY == analysis->state)
    {
        analysis_log("state changed from AS_START_RECOVERY to AS_REQUEST_NEWFILE\n");
        analysis->state = AS_REQUEST_NEWFILE;
    }
}

/*
 * deal AS_REQUEST_NEWFILE reply
 */
void analysis_client_recv_request_file(TAnalysiser *analysis)
{
#define ANALYSIS_FILE_DIR   "/mnt/data/"
    uint16_t len = strlen(ANALYSIS_FILE_DIR);
    char buf[RCFILE_NAMES_MAX_LEN];

    memcpy(&analysis->transferring_file_info, analysis->recv_packet.payload, sizeof(analysis->transferring_file_info));
    if (analysis->transferring_file_info.fileid <= 0)
    {
        analysis_log("request new file,fileid less than0,state changed AS_EXIT\n");
        analysis->state = AS_EXIT;
        return;
    }

    analysis_log("recv REQUEST_NEWFILE reply now, file id:%d,file len:%d\n",
                analysis->transferring_file_info.fileid, analysis->transferring_file_info.len);

    // construct file name
    memcpy(buf, ANALYSIS_FILE_DIR, len);
    memcpy(buf + len, analysis->cur_file_name, strlen(analysis->cur_file_name));
    len += strlen(analysis->cur_file_name);
    buf[len] = 0;
    analysis->file_fd = open(buf, O_CREAT | O_TRUNC | O_WRONLY, S_IRUSR | S_IWUSR | S_IRGRP | S_IWGRP | S_IROTH);
    if (-1 == analysis->file_fd)
    {
        analysis_log("open file %s failed, errno:%d, to exit now\n", buf, errno);
        analysis->state = AS_EXIT;
        return;
    }
    memset(&analysis->latest_file_info, 0, sizeof(analysis->latest_file_info));
    analysis_log("open file %s succesfull, fd:%d\n", buf, analysis->file_fd);

    if ((AS_REQUEST_NEWFILE == analysis->state) || (AS_WAIT_REPLY == analysis->state))
    {
        analysis_log("state changed from AS_REQUEST_NEWFILE to AS_TRANS_FILEDATA\n");
        analysis->state = AS_TRANS_FILEDATA;
    }
}


/*
 * deal TRANS_FILEDATA reply
 */
void analysis_client_recv_trans_filedata(TAnalysiser *analysis)
{
    int ret, raw_data_len;

    // analysis_log("recv TRANS_FILEDATA reply\n");
    memcpy(&analysis->recv_file_info, analysis->recv_packet.payload, sizeof(analysis->recv_file_info));
    if (analysis->recv_file_info.fileid <= 0)
    {
        analysis_log("transfile data fileid %d less than 0,state changed AS_EXIT\n", analysis->recv_file_info.fileid);
        analysis->state = AS_EXIT;
        return;
    }

    // if len not match,again
    raw_data_len = analysis->recv_packet.len - sizeof(struct RCFileInfo);
    if (analysis->recv_file_info.len != raw_data_len)
    {
        analysis_log("transfile data fileid len error,continue,paylaod len:%d,data len:%d\n",
                        analysis->recv_packet.len, analysis->recv_file_info.len);
        return;
    }

    // write to file
    ret = cbb_write(analysis->file_fd, analysis->recv_packet.payload + sizeof(struct RCFileInfo), raw_data_len);
    if (ret < 0)
    {
        analysis_log("write data failed,fd:%d, len:%d,state changed AS_EXIT\n", analysis->file_fd, raw_data_len);
        analysis->state = AS_EXIT;
        return;
    }

    // update md5
    md5_update(&analysis->md5_result, analysis->recv_packet.payload + sizeof(struct RCFileInfo), raw_data_len);

    /// update latest file info
    if (analysis->transferring_file_info.len == analysis->recv_file_info.len + analysis->recv_file_info.offset)
    {
        ret = close(analysis->file_fd);
        if (ret < 0)
        {
            analysis_log("close fd:%d failed, errno:%d\n", analysis->file_fd, errno);
        }
        analysis_log("trans filedata finisthed, state:%d\n", analysis->state);

        // if end, get file md5
        if ((AS_TRANS_FILEDATA == analysis->state) || (AS_WAIT_REPLY == analysis->state))
        {
            analysis_log("state changed from AS_TRANS_FILEDATA to AS_FILEDATA_MD5\n");
            analysis->state = AS_FILEDATA_MD5;

            // update md5
            md5_final(&analysis->md5_result, (uint8_t *)analysis->md5);
        }
    }
    else if (analysis->transferring_file_info.len < analysis->recv_file_info.len + analysis->recv_file_info.offset)
    {
        analysis_log("transfile data len overrun,file len:%d, cur seg:%d, offset len:%d\n",
                        analysis->transferring_file_info.len, analysis->recv_file_info.len, analysis->recv_file_info.offset);
        analysis->state = AS_EXIT;
        return;
    }
    else
    {
        if (AS_WAIT_REPLY == analysis->state)
        {
            analysis->state = AS_TRANS_FILEDATA;
        }
        memcpy(&analysis->latest_file_info, &analysis->recv_file_info, sizeof(analysis->latest_file_info));
    }
}

/*
 * deal FILEDATA_MD5 cmd
 */
void analysis_client_send_filedata_md5_reply(TAnalysiser *analysis)
{
    int ret, len = 0, i;
    uint32_t md5_recv[MD5_HASH_WORDS] = {0};
    char *response = DL_OK;
    char *server_md5;
    uint8_t local_md5[33], *p;

    p = analysis->md5;
    snprintf(local_md5, sizeof(local_md5), "%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x",
                p[0], p[1], p[2], p[3], p[4], p[5], p[6], p[7],
                p[8], p[9], p[10], p[11], p[12], p[13], p[14], p[15]);

    analysis_log("to send request FILEDATA_MD5 reply,local md5:\n");
    print_buf(local_md5, 32);
    analysis_log("server md5:\n");
    print_buf(analysis->recv_packet.payload, analysis->recv_packet.len);

    // check md5 result
    if (analysis->recv_packet.len != sizeof(struct RCFileInfo) + 32)
    {
        analysis_log("deal FILEDATA_MD5, packket len error:%d\n", analysis->recv_packet.len);
        response = DL_NONOK;
    }
    else if (memcmp(analysis->recv_packet.payload + sizeof(struct RCFileInfo), local_md5, 32))
    {
        response = DL_NONOK;
        server_md5 = analysis->recv_packet.payload + sizeof(struct RCFileInfo);
        analysis_log("deal FILEDATA_MD5, md5 not match\n");
    }

    // send reply
    len = 0;
    memcpy(analysis->recv_buf + len, &analysis->transferring_file_info, len);
    len += sizeof(analysis->transferring_file_info);
    memcpy(analysis->recv_buf + len, response, strlen(response));
    len += strlen(response);
    protocol_construct_packet(&analysis->send_packet, analysis->seq, RCFLAGS_RESPONSE, RCCOMMAND_FILEDATA_MD5,
                                analysis->recv_buf, len);
    ret = analysis->send_cb(analysis->send_context, (uint8_t *)&analysis->send_packet, len + RCPACKET_HEAD_LEN);
    if (ret < 0)
    {
        analysis_log("send START_RECOVERY reply to server failed, exit now\n");
        analysis->state = AS_EXIT;
    }

    // if ok
    if (AS_FILEDATA_MD5 == analysis->state)
    {
        analysis_log("state changed from AS_FILEDATA_MD5 to AS_END_TRANSFILE\n");
        analysis->state = AS_END_TRANSFILE;
    }

}

#define ANALYSIS_RECOVERY_RESULT_INIT       1
#define ANALYSIS_RECOVERY_RESULT_WAIT       2
#define ANALYSIS_RECOVERY_RESULT_FAILED     3 
#define ANALYSIS_RECOVERY_RESULT_SUCCESS    4
/*
 * deal END_TRANSFILE reply
 */
void analysis_client_recv_end_transfile(TAnalysiser *analysis)
{
    analysis_log("recv END_TRANSFILE reply\n");

    print_buf(analysis->recv_packet.payload, analysis->recv_packet.len);

    // if ok
    if ((AS_END_TRANSFILE == analysis->state) || (AS_WAIT_REPLY == analysis->state))
    {
        analysis_log("state changed from AS_END_TRANSFILE to AS_END_RECOVERY\n");
        analysis->recovery_result = ANALYSIS_RECOVERY_RESULT_INIT;
        analysis->state = AS_END_RECOVERY;
    }
}

/*
 * deal END_RECOVERY reply
 */
void analysis_client_recv_end_recovery(TAnalysiser *analysis)
{
    analysis_log("recv END_RECOVERY reply\n");

    print_buf(analysis->recv_packet.payload, analysis->recv_packet.len);

    analysis_log("state changed from %d to AS_EXIT\n", analysis->state);
    analysis->errors    = 0;
    analysis->state     = AS_EXIT;

}

/*
 * client deal cmd
 */
int analysis_client_deal_cmd(TAnalysiser *analysis)
{
    switch (analysis->recv_packet.cmd)
    {
        case RCCOMMAND_GET_MACHINEINFO:
            analysis_log("recv GET_MACHINEINFO cmd\n");
            analysis_send_machine_info_reply(analysis);
            break;

        case RCCOMMAND_START_RECOVERY:
            analysis_log("recv START_RECOVERY cmd\n");
            analysis_send_start_recovery_reply(analysis);
            break;

        case RCCOMMAND_REQUEST_NEWFILE:
            analysis_log("recv REQUEST_NEWFILE reply\n");
            analysis_client_recv_request_file(analysis);
            break;

        case RCCOMMAND_TRANS_FILEDATA:
            // analysis_log("recv TRANS_FILEDATA reply\n");
            analysis_client_recv_trans_filedata(analysis);
            break;

        case RCCOMMAND_FILEDATA_MD5:
            analysis_log("recv FILEDATA_MD5 cmd\n");
            analysis_client_send_filedata_md5_reply(analysis);
            break;

        case RCCOMMAND_END_TRANSFILE:
            analysis_log("recv END_TRANSFILE reply\n");
            analysis_client_recv_end_transfile(analysis);
            break;

        case RCCOMMAND_END_RECOVERY:
            analysis_log("recv END_RECOVERY reply\n");
            analysis_client_recv_end_recovery(analysis);
            break;

        default:
            analysis_log("invalid cmd, exit\n");
            return -1;
    }

    return 0;
}

/*
 * client deal AS_MACHINE_INFO state
 */
int analysis_client_deal_common_state(TAnalysiser *analysis)
{
    int ret;

    if (NULL == analysis->recv_cb)
    {
        return 0;
    }

    // recv cmd from server
    ret = analysis_recv_cmd(analysis);
    if (ret < 0)
    {
        analysis_log("client deal machine info failed, ret:%d\n", ret);
        analysis->state = AS_EXIT;
        return -1;
    }

    /// deal cmd
    ret = analysis_client_deal_cmd(analysis);
    if (ret < 0)
    {
        analysis_log("client deal cmd:%d failed, ret:%d\n", analysis->recv_packet.cmd, ret);
        return -1;
    }

    return 0;
}

/*
 * analysis run fucntion, pull mode state enrty
 *@return if successfull,return 0. On error,other value is returned
 */
int analysis_run(HAnalysisHandle handle)
{
    int ret;

    TAnalysiser *analysis = (TAnalysiser *)handle;

    for (;;)
    {
        if (NULL == analysis->deal_func[analysis->state])
        {
            break;
        }

        ret = analysis->deal_func[analysis->state](analysis);
        if (ret < 0)
        {
            break;
        }
    }

    ret = (0 == analysis->errors) ? 0 : -1;
    analysis_log("exit with return:%d, state:%d, pf:%p\n", ret, analysis->state, analysis->deal_func[analysis->state]);

    return ret;
}

/*
 * client MACHINE_INFO state deal function
 */
int analysis_client_deal_machine_info(TAnalysiser *analysis)
{
    return analysis_client_deal_common_state(analysis);
}

/*
 * client AS_START_RECOVERY state deal function
 */
int analysis_client_deal_start_recovery(TAnalysiser *analysis)
{
    return analysis_client_deal_common_state(analysis);
}

/*
 * send AS_REQUEST_NEWFILE cmd to server
 */
int analysis_send_request_file_cmd(TAnalysiser *analysis)
{
    int ret;
    uint16_t len, name_len = 0;
    char *name;

    /// here to deal file num
    name = analysis->pkg_info.filenames;
    name_len += (strlen(name) + 1);
    if (name_len > RCFILE_NAMES_MAX_LEN)
    {
        analysis->state = AS_END_RECOVERY;
        analysis->errors++;
        analysis_log("file name check failed\n");
        return 1;
    }

    analysis_log("name:%s len:%d\n", name, name_len);

    // deal current file
    memcpy(analysis->cur_file_name, name, name_len);
    len = strlen(analysis->cur_file_name);
    protocol_construct_packet(&analysis->send_packet, analysis->seq, RCFLAGS_COMMAND, RCCOMMAND_REQUEST_NEWFILE,
                                (uint8_t *)analysis->cur_file_name, len);

    analysis_log("to send request REQUEST_NEWFILE cmd, file name:%s, name_len:%d\n",
                    analysis->cur_file_name, name_len);
    ret = analysis->send_cb(analysis->send_context, (uint8_t *)&analysis->send_packet, len + RCPACKET_HEAD_LEN);
    if (ret < 0)
    {
        analysis_log("send REQUEST_NEWFILE reply to server failed, exit now\n");
        analysis->state = AS_EXIT;
        return -1;
    }

    md5_init(&analysis->md5_result);

    return 0;
}

/*
 * client REQUEST_NEWFILE state deal function
 */
int analysis_client_deal_request_newfile(TAnalysiser *analysis)
{
    int ret;

    // send REQUEST_NEWFILE cmd to server
    ret = analysis_send_request_file_cmd(analysis);
    if (0 != ret)
    {
        analysis_log("send REQUEST_NEWFILE to server, check returned, ret:%d\n", ret);
        return ret;
    }

    if (NULL == analysis->recv_cb)
    {
        analysis->state = AS_WAIT_REPLY;

        return 0;
    }

    return analysis_client_deal_common_state(analysis);
}



/*
 * send TRANS_FILEDATA cmd to server
 */
int analysis_send_trans_filedata_cmd(TAnalysiser *analysis)
{
    int ret, offset, len;

#define analysis_len_get(off, len)   (((off + RCPACKET_MAX_FILEDATA_LEN) > len) ? (len - off) : RCPACKET_MAX_FILEDATA_LEN)
    offset = analysis->latest_file_info.len + analysis->latest_file_info.offset;
    analysis->send_file_info.fileid = analysis->transferring_file_info.fileid;
    analysis->send_file_info.offset = offset;
    analysis->send_file_info.len    = analysis_len_get(offset, analysis->transferring_file_info.len);
#if 0
    analysis_log("to send TRANS_FILEDATA cmd, offset:%d,len:%d\n",
                analysis->send_file_info.offset, analysis->send_file_info.len);
#endif
    len = sizeof(analysis->send_file_info);
    protocol_construct_packet(&analysis->send_packet, analysis->seq++, RCFLAGS_COMMAND, RCCOMMAND_TRANS_FILEDATA,
                                &analysis->send_file_info, len);
    ret = analysis->send_cb(analysis->send_context, (uint8_t *)&analysis->send_packet, len + RCPACKET_HEAD_LEN);
    if (ret < 0)
    {
        analysis_log("send REQUEST_NEWFILE reply to server failed, exit now\n");
        analysis->state = AS_EXIT;
        return -1;
    }

    return 0;
}

/*
 * client TRANS_FIELDATA state deal function
 */
int analysis_client_deal_trans_filedata(TAnalysiser *analysis)
{
    int ret;

    // send REQUEST_NEWFILE cmd to server
    ret = analysis_send_trans_filedata_cmd(analysis);
    if (ret < 0)
    {
        analysis_log("send REQUEST_NEWFILE to server failed\n");
        return ret;
    }

    if (NULL == analysis->recv_cb)
    {
        analysis->state = AS_WAIT_REPLY;

        return 0;
    }

    return analysis_client_deal_common_state(analysis);
}

/*
 * client FILEDATA_MD5 state deal function
 */
int analysis_client_deal_filedata_md5(TAnalysiser *analysis)
{
    return analysis_client_deal_common_state(analysis);
}

/*
 * send END_TRANSFILE cmd to server
 */
int analysis_send_end_transfile_cmd(TAnalysiser *analysis)
{
    int ret;
    uint16_t len;

    analysis_log("to send END_TRANSFILE cmd\n");
    len = strlen(DL_OK);
    protocol_construct_packet(&analysis->send_packet, analysis->seq++, RCFLAGS_COMMAND, RCCOMMAND_END_TRANSFILE,
                                (uint8_t *)DL_OK, len);
    ret = analysis->send_cb(analysis->send_context, (uint8_t *)&analysis->send_packet, len + RCPACKET_HEAD_LEN);
    if (ret < 0)
    {
        analysis_log("send END_TRANSFILE reply to server failed, exit now\n");
        analysis->state = AS_EXIT;
        return -1;
    }

    return 0;
}

/*
 * client END_TRANSFILE state deal function
 */
int analysis_client_deal_end_transfile(TAnalysiser *analysis)
{
    int ret;

    // send END_TRANSFILE cmd to server
    ret = analysis_send_end_transfile_cmd(analysis);
    if (ret < 0)
    {
        analysis_log("send END_TRANSFILE to server failed\n");
        return ret;
    }

    if (NULL == analysis->recv_cb)
    {
        analysis->state = AS_WAIT_REPLY;

        return 0;
    }

    return analysis_client_deal_common_state(analysis);
}

/*
 * send END_RECOVERY cmd to server
 */
int analysis_send_end_recovery_cmd(TAnalysiser *analysis)
{
    int ret;
    uint16_t len;
    char *result;


    // set result
    if (ANALYSIS_RECOVERY_RESULT_SUCCESS == analysis->recovery_result)
    {
        result = DL_OK;
    }
    else if (ANALYSIS_RECOVERY_RESULT_FAILED == analysis->recovery_result)
    {
        result = DL_NONOK;
    }

    analysis_log("to send END_RECOVERY cmd, result:%s\n", result);

    len = strlen(result);
    protocol_construct_packet(&analysis->send_packet, analysis->seq++, RCFLAGS_COMMAND, RCCOMMAND_END_RECOVERY,
                                (uint8_t *)result, len);
    ret = analysis->send_cb(analysis->send_context, (uint8_t *)&analysis->send_packet, len + RCPACKET_HEAD_LEN);
    if (ret < 0)
    {
        analysis_log("send END_TRANSFILE reply to server failed, exit now\n");
        return ret;
    }

    return 0;
}

/*
 * client END_RECOVERY state deal function
 */
int analysis_client_wait_reply(TAnalysiser *analysis)
{
    return 0;
}


/*
 * client END_RECOVERY state deal function
 */
int analysis_client_deal_end_recovery(TAnalysiser *analysis)
{
    int ret;

    // deal recovery result
    if (ANALYSIS_RECOVERY_RESULT_INIT == analysis->recovery_result)
    {
        if (NULL != analysis->ev_cb)
        {
            analysis->recovery_result = ANALYSIS_RECOVERY_RESULT_WAIT;
            ret = analysis->ev_cb(analysis->ev_context, AE_END_FILE_TRANS, NULL, 0);
            if (ret < 0)
            {
                analysis->recovery_result = ANALYSIS_RECOVERY_RESULT_FAILED;
            }
            else
            {
                return 0;
            }
        }
        else
        {
            analysis->recovery_result = ANALYSIS_RECOVERY_RESULT_FAILED;
        }
    }
    else if (ANALYSIS_RECOVERY_RESULT_WAIT == analysis->recovery_result)
    {
        return 0;
    }

    // send END_RECOVERY cmd to server
    ret = analysis_send_end_recovery_cmd(analysis);
    if (ret < 0)
    {
        analysis_log("send END_RECOVERY to server failed\n");
        return ret;
    }

    analysis_log("now wait reply\n");
    if (NULL == analysis->recv_cb)
    {
        analysis->state = AS_WAIT_REPLY;

        return 0;
    }

    return analysis_client_deal_common_state(analysis);
}

/*
 * create analysis client or server
 *@param type this param can either be ANALYSIS_TYPE_CLIENT or ANALYSIS_TYPE_SERVER
 *@return if successfull,return handle., On error @ANALYSIS_INVALID_HANDLE is returned
 */
HAnalysisHandle analysis_create(int type)
{
    TAnalysiser *handle;

    if ( (ANALYSIS_TYPE_CLIENT != type) && (ANALYSIS_TYPE_SERVER != type) )
    {
        analysis_log("error, invalid type:%d\n", type);
        return ANALYSIS_INVALID_HANDLE;
    }

    handle = malloc(sizeof(TAnalysiser));

    if (NULL == handle)
    {
        analysis_log("error, non mem\n");
        handle = ANALYSIS_INVALID_HANDLE;
    }
    else
    {
        memset(handle, 0, sizeof(TAnalysiser));
        handle->type    = type;
        handle->state   = AS_UNREADY;

        /// reg all state function
        handle->deal_func[AS_UNREADY]           = analysis_state_unready;
        handle->deal_func[AS_MACHINE_INFO]      = analysis_client_deal_machine_info;
        handle->deal_func[AS_START_RECOVERY]    = analysis_client_deal_start_recovery;
        handle->deal_func[AS_REQUEST_NEWFILE]   = analysis_client_deal_request_newfile;
        handle->deal_func[AS_TRANS_FILEDATA]    = analysis_client_deal_trans_filedata;
        handle->deal_func[AS_FILEDATA_MD5]      = analysis_client_deal_filedata_md5;
        handle->deal_func[AS_END_TRANSFILE]     = analysis_client_deal_end_transfile;
        handle->deal_func[AS_END_RECOVERY]      = analysis_client_deal_end_recovery;
        handle->deal_func[AS_WAIT_REPLY]        = analysis_client_wait_reply;

        handle->deal_func[AS_EXIT]              = analysis_state_exit;
    }

    analysis_log("create handle:%p\n", handle);
    return handle;
}


/*
 * destroy analysis client or server
 */
int analysis_destroy(HAnalysisHandle handle)
{
    TAnalysiser *analysis = handle;
    free(analysis);
    analysis_log("free handle:%p\n", handle);
    return 0;
}

/*
 * data send/recv for specified handle
 */
int analysis_set_cb(HAnalysisHandle handle, FAnalysisDataCb send_cb, void *send_context,
                        FAnalysisDataCb recv_cb, void *recv_context)
{
    TAnalysiser *analysis = (TAnalysiser *)handle;

    analysis->send_cb       = send_cb;
    analysis->send_context  = send_context;

    analysis->recv_cb       = recv_cb;
    analysis->recv_context  = recv_context;

    return 0;
}

/*
 * analysis data input,push mode
 */
int analysis_input_data(HAnalysisHandle handle, void *buf, int len)
{
    int ret = 0;
    TAnalysiser *analysis = (TAnalysiser *)handle;

    // deal buffer data
    if (len + analysis->buf_len <= (int)sizeof(analysis->buf))
    {
        memcpy(analysis->buf + analysis->buf_len, buf, len);
        analysis->buf_len   += len;
        // analysis_log("copy data to buf,cur len:%d, buf len:%d\n", len, analysis->buf_len);
    }
    else
    {
        // 保留最后一个字符
        analysis_log("there are data not dealed, buf data len:%d\n", analysis->buf_len);
        memcpy(analysis->buf, buf, len);
        analysis->buf_len   = len;
    }

    // head check
    ret = analysis_protocol_head_check(analysis);
    if (ret < 0)
    {
        analysis_log("do not find head,again\n");
        return 0;
    }

    /// deal cmd
    ret = analysis_client_deal_cmd(analysis);
    if (ret < 0)
    {
        analysis_log("client deal cmd:%d failed, ret:%d\n", analysis->recv_packet.cmd, ret);
    }

    return 0;
}

/*
 * deal timer task
 */
int analysis_timer_routine(HAnalysisHandle handle, struct timespec ts)
{
    int ret = -1;

    TAnalysiser *analysis = (TAnalysiser *)handle;

    if (NULL == analysis->deal_func[analysis->state])
    {
        analysis_log("state:%d deal func is null\n", analysis->state);
        return -1;
    }

    ret = analysis->deal_func[analysis->state](analysis);
    if (ret < 0)
    {
        ret = -1;
        analysis_log("exit with return:%d, state:%d, pf:%p\n", ret, analysis->state, analysis->deal_func[analysis->state]);
    }
    else
    {
        ret = (0 == analysis->errors) ? 0 : -1;
    }

    // analysis_log("exit with return:%d, state:%d, pf:%p\n", ret, analysis->state, analysis->deal_func[analysis->state]);

    return ret;
}

/*
 * set event callback
 */
int analysis_set_ev_cb(HAnalysisHandle handle, FAnalysisEvCb ev_cb, void *context)
{
    int ret = 0;

    TAnalysiser *analysis = (TAnalysiser *)handle;

    analysis->ev_cb         = ev_cb;
    analysis->ev_context    = context;

    return ret;
}

/*
 * set recovery operate state
 *@result on error result value is -1,other value means recovery successfully
 */
int analysis_set_recovery_op_state(HAnalysisHandle handle, int result)
{
    int ret = 0;

    TAnalysiser *analysis = (TAnalysiser *)handle;

    if (result < 0)
    {
        analysis->recovery_result = ANALYSIS_RECOVERY_RESULT_FAILED;
    }
    else
    {
        analysis->recovery_result = ANALYSIS_RECOVERY_RESULT_SUCCESS;
    }

    analysis_log("recovery result:%d, inter result:%d\n", result, analysis->recovery_result);
    return ret;
}
