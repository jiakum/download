#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/ip.h>
#include <pthread.h>
#include <sys/epoll.h>
#include <sys/stat.h>
#include <errno.h>
#include <fcntl.h>
#include <time.h>


#include "recovery.h"
#include "md5.h"
#include "common.c"

/// manx socket send/recv buf size
#define DL_SERVER_RECV_BUF_LEN     1500U
#define DL_SERVER_BUF_LEN          (128 * 1024)

/// dl server module lock/unlock define
#define DL_LOCK_CLIENT_LIST()   pthread_mutex_lock(&clent_list_mutex)
#define DL_UNLOCK_CLIENT_LIST() pthread_mutex_unlock(&clent_list_mutex)

/// max epoll size and client num
#define DL_RECOVERY_EPOLL_SIZE  5
#define DL_MAX_CLIENT_NUM       4

#define server_log(fmt, ...)  printf(fmt, ##__VA_ARGS__)

#define DL_CLIENT_OFFSET(type, member)  ((size_t)&((type *)0)->member)

enum ServerState{
    CLIENTSTATE_GET_MACHINE_INFO = 1,
    CLIENTSTATE_START_RECOVERY,
    CLIENTSTATE_REQUEST_NEWFILE,

    CLIENTSTATE_TRANS_FILEDATA,
    CLIENTSTATE_FILEDATA_MD5,
    CLIENTSTATE_END_TRANSFILE,
    CLIENTSTATE_END_RECOVERY,

    CLIENTSTATE_EXIT,
};

/// server info define
typedef struct DlServerMgrInfo
{
    int                 fd;
    struct sockaddr_in  addr;
    int                 epoll_fd;
    uint32_t            client_num;
    pthread_t           tid;
    int                 task_running;
    int                 task_exit;
}TDlServerMgrInfo;

/// epoll deal function
typedef void (*FDlEpollDealFun)(void *context, struct epoll_event *ev);

/// epoll data
typedef struct DlEpollData
{
    FDlEpollDealFun func;
    void            *context;
}TDlEpollData;

/// client list
typedef struct DlClientList
{
    int                     fd;
    struct sockaddr_in      addr;
    struct timespec         last_ts;
    TDlEpollData            epoll_data;
    uint8_t                 recv_buf[DL_SERVER_RECV_BUF_LEN];
    int                     recv_len;
    uint8_t                 buf[DL_SERVER_BUF_LEN];
    uint32_t                len;
    struct DlClientList     *next;
    // struct list_head        list;
}TDlClientList;

/// manx socket send/recv buf size
#define DL_SERVER_RECV_BUF_LEN     1500U
#define DL_SERVER_BUF_LEN          (128 * 1024)

/// server define
typedef struct DlServer
{
    int                     fd;
    struct sockaddr_in      addr;
    TDlEpollData            epoll_data;
    struct timespec         last_ts;

    struct md5_state        md5_result;
	uint32_t                md5[MD5_HASH_WORDS];

    // protocol data
    struct MachineInfo      machine_info;
    struct RCPacket         reply_packet;
    struct RCPacket         recv_packet;
    uint16_t                seq;
    enum ServerState        state;
    uint8_t                 recv_buf[DL_SERVER_RECV_BUF_LEN];
    int                     recv_len;
    uint8_t                 buf[DL_SERVER_BUF_LEN];
    int                     buf_len;

    struct RCFileInfo       transferring_file_info;
    struct RCFileInfo       file_info;
    uint8_t                 file_data_buf[DL_SERVER_RECV_BUF_LEN];
    uint32_t                file_data_len;
    int                     file_fd;
    struct RCFileInfo       send_file_info;
}TDlServer;


/*
 * client list
 */
static pthread_mutex_t clent_list_mutex = PTHREAD_MUTEX_INITIALIZER;
static TDlClientList *client_list = NULL;

/*
 * dl server info
 */
static TDlServerMgrInfo server_info;

void print_buf(uint8_t *buf, uint32_t len);
unsigned char calc_crc8(unsigned char *buf, int len);

/*
 * insert one client
 */
void dl_insert_client(TDlClientList *client)
{
    DL_LOCK_CLIENT_LIST();

    if (NULL == client_list)
    {
        client_list = client;
    }
    else
    {
        client->next = client_list;
        client_list = client;
    }

    DL_UNLOCK_CLIENT_LIST();
}

/*
 * del one client
 */
void dl_del_client(TDlClientList * const client)
{
    TDlClientList *tmp;
    DL_LOCK_CLIENT_LIST();

    if (NULL == client_list)
    {
        DL_UNLOCK_CLIENT_LIST();
        return;
    }

    // head match
    if (client == client_list)
    {
        client_list = client_list->next;
    }
    else
    {
        tmp = client_list;

        while (NULL != tmp->next)
        {
            // non-head match
            if (client == tmp->next)
            {
                tmp->next = tmp->next->next;
                break;
            }

            tmp = tmp->next;
        }
    }

    DL_UNLOCK_CLIENT_LIST();
}

/*
 * read data
 */
int dl_read(int fd, void *buf, size_t len)
{
    int ret;

again:
    ret = read(fd, buf, len);
    if (ret < 0)
    {
        if (EAGAIN == errno)
        {
            goto again;
        }

        server_log("socket recv data failed, errno:%d\n", errno);
        return -1;
    }
    else if (0 == ret)
    {
        server_log("read no data, peer maybe shutdown\n");
        return -1;
    }

    return ret;
}

/*
 * recv data
 */
int dl_recv(int fd, void *buf, size_t len, int flag)
{
    int ret;

again:
    ret = recv(fd, buf, len, flag);
    if (ret < 0)
    {
        if (EAGAIN == errno)
        {
            goto again;
        }

        server_log("socket recv data failed, errno:%d\n", errno);
        return -1;
    }
    else if (0 == ret)
    {
        server_log("socket recv no data, peer maybe shutdown\n");
        return -1;
    }

    return ret;
}

/*
 * deal incoming data
 */
void dl_deal_msg(void *context, struct epoll_event *ev)
{
    int ret;
    TDlClientList *client = context;

    if (ev->events & (EPOLLERR | EPOLLHUP))
    {
        server_log("client fd error event happened, to close it\n");
        return;
    }

    // recv msg
    client->recv_len = recv(client->fd, client->recv_buf, DL_SERVER_RECV_BUF_LEN, 0);
    if (client->recv_len < 0)
    {
        if ( (EAGAIN == errno) || (EINTR == errno) )
        {
            return;
        }

        server_log("recv data faile,errno:%d\n", errno);
        ret = epoll_ctl(server_info.epoll_fd, EPOLL_CTL_DEL, client->fd, NULL);
        if (ret < 0)
        {
            server_log("epoll del event failed,errno:%d\n", errno);
        }

        return;
    }

    // deal data
    /// ... to do

}

/*
 * construct reply packet
 */
void dl_server_construct_packet(struct DlServer *server, uint16_t cmd, void *buf, uint16_t len, uint16_t flags)
{
    server->reply_packet.header[0]  = '@';
    server->reply_packet.header[1]  = '$';
    server->reply_packet.seq        = server->seq;
    server->reply_packet.flags      = flags;
    server->reply_packet.cmd        = cmd;
    server->reply_packet.len        = len;
    server->reply_packet.crc[0]     = calc_crc8((unsigned char *)&server->reply_packet,
                                                    DL_CLIENT_OFFSET(struct RCPacket, crc[0]));
    server->reply_packet.crc[1]     = ~server->reply_packet.crc[0];
    if (NULL != buf)
    {
        memcpy(server->reply_packet.payload, buf, len);
    }
}


/*
 * safe send
 */
int dl_server_send(int fd, void *buf, int len)
{
    int ret;
    int size     = len;
    size_t offset   = 0;

repeat:
    ret = send(fd, buf + offset, size, 0);
    if (ret < 0)
    {
        if (EINTR == errno)
        {
            goto repeat;
        }

        server_log("send falied,errno:%d\n", errno);
        return -1;
    }
    else if (ret < size)
    {
        size    = size - ret;
        offset  = len - size;
        goto repeat;
    }

    return 0;
}

#define DL_FILE_ROOTFS      "update.lzo"

/*
 * start recovery
 */
void dl_server_start_recovery(struct DlServer *server)
{
    int ret;
    int len = 0;
    struct PackageInfo pkg_info;

    memcpy(&pkg_info.machine, &server->machine_info, sizeof(pkg_info.machine));
    pkg_info.type   = 0;
    pkg_info.num   = 1;
    strncpy(pkg_info.filenames + len, DL_FILE_ROOTFS, sizeof(pkg_info.filenames) - len);
    len += sizeof(DL_FILE_ROOTFS);
    dl_server_construct_packet(server, RCCOMMAND_START_RECOVERY, (uint8_t *)&pkg_info, sizeof(pkg_info), RCFLAGS_COMMAND);

    server_log("send command RCCOMMAND_START_RECOVERY\n");
    ret = dl_server_send(server->fd, &server->reply_packet, RCPACKET_HEAD_LEN + sizeof(pkg_info));
    if (ret < 0)
    {
        server_log("send machine info to server failed, state exit now\n");
        server->state = CLIENTSTATE_EXIT;
        return;
    }


    // wait for reply
    ret = dl_recv(server->fd, server->recv_buf, sizeof(server->recv_buf), 0);
    if (ret < 0)
    {
        server_log("recv machine info to server failed, state exit now\n");
        server->state = CLIENTSTATE_EXIT;
        return;
    }

    server_log("recv RCCOMMAND_START_RECOVERY reply,len:%u\n", ret);
    print_buf(server->recv_buf, ret);

    // now we get machine info
    server->state = CLIENTSTATE_REQUEST_NEWFILE;

    return;
}

/*
 * get machine info
 */
void dl_server_get_machine_info(struct DlServer *server)
{
    int ret;

    dl_server_construct_packet(server, RCCOMMAND_GET_MACHINEINFO, NULL, 0, RCFLAGS_COMMAND);

    server_log("send command GET_MACHINE_INFO\n");
    ret = dl_server_send(server->fd, &server->reply_packet, RCPACKET_HEAD_LEN);
    if (ret < 0)
    {
        server_log("send machine info to server failed, state exit now\n");
        server->state = CLIENTSTATE_EXIT;
        return;
    }


    // wait for reply
    ret = dl_recv(server->fd, server->recv_buf, sizeof(server->recv_buf), 0);
    if (ret < 0)
    {
        server_log("recv machine info to server failed, state exit now\n");
        server->state = CLIENTSTATE_EXIT;
        return;
    }

    server_log("recv machine info,len:%u\n", ret);
    print_buf(server->recv_buf, ret);

    // now we get machine info
    if (sizeof(server->machine_info) + RCPACKET_HEAD_LEN == ret)
    {
        memcpy(&server->machine_info, server->recv_buf + RCPACKET_HEAD_LEN, sizeof(server->machine_info));
    }

    server->state = CLIENTSTATE_START_RECOVERY;

    return;
}

/*
 * check file is or not exit
 */
int dl_server_get_file_len(const char *pchFileName)
{
    struct stat st;
    if (0 != stat(pchFileName , &st))
    {
        return -1;
    }

    return st.st_size;
}

int dl_server_send_newfile_reply(struct DlServer *server)
{
    int ret;
    char *file_name = (char *)server->recv_packet.payload;

    server->file_fd = open(file_name, O_RDONLY, 0);
    if (-1 == server->file_fd)
    {
        server_log("open file %s failed, errno:%d, to exit now\n", file_name, errno);
        server->state = CLIENTSTATE_EXIT;
        server->transferring_file_info.fileid    = -1;
    }
    else
    {
        server->transferring_file_info.fileid    = 1;
        server->state = CLIENTSTATE_TRANS_FILEDATA;
        server_log("open file %s sucessfull\n", file_name);
    }

    server_log("send REQUEST_NEWFILE reply\n");
    server->transferring_file_info.offset    = 0;
    server->transferring_file_info.len       = dl_server_get_file_len(file_name);

    md5_init(&server->md5_result);

    dl_server_construct_packet(server, RCCOMMAND_REQUEST_NEWFILE, (uint8_t *)&server->transferring_file_info,
                                sizeof(server->transferring_file_info), RCFLAGS_RESPONSE);

    server_log("send REQUEST_NEWFILE reply\n");
    ret = dl_server_send(server->fd, &server->reply_packet, RCPACKET_HEAD_LEN + sizeof(server->transferring_file_info));
    if (ret < 0)
    {
        server_log("send REQUEST_NEWFILE reply failed, state exit now\n");
        server->state = CLIENTSTATE_EXIT;
        return -1;
    }

    return 0;
}

/*
 * request new file
 */
void dl_server_request_newfile(struct DlServer *server)
{
    int ret;

    // wait for reply
    ret = dl_recv(server->fd, &server->recv_packet, sizeof(server->recv_packet), 0);
    if (ret < 0)
    {
        server_log("recv machine info to server failed, state exit now\n");
        server->state = CLIENTSTATE_EXIT;
        return;
    }

    server_log("recv REQUEST_NEWFILE cmd,len:%u\n", ret);
    print_buf(server->recv_buf, ret);
    dl_server_send_newfile_reply(server);
}


/*
 * request new file
 */
void dl_server_trans_filedata(struct DlServer *server)
{
    int ret;
    struct RCFileInfo file_info;
    uint8_t buf[sizeof(struct RCFileInfo) + RCPACKET_MAX_FILEDATA_LEN];
    uint16_t len    = strlen((char *)buf) + 1;

    // wait for cmd
    ret = dl_recv(server->fd, server->recv_buf, sizeof(server->recv_buf), 0);
    if (ret < 0)
    {
        server_log("recv machine info to server failed, state exit now\n");
        server->state = CLIENTSTATE_EXIT;
        return;
    }

    server_log("recv TRANS_FILEDATA cmd,len:%u\n", ret);
    print_buf(server->recv_buf, ret);

    // now we get machine info
    if (sizeof(file_info) + RCPACKET_HEAD_LEN == ret)
    {
        memcpy(&file_info, server->recv_buf + RCPACKET_HEAD_LEN, sizeof(file_info));
    }

    // read fata
    if (file_info.len <= (int32_t)RCPACKET_MAX_FILEDATA_LEN)
    {
        ret = lseek(server->file_fd, file_info.offset, SEEK_SET);
        if (ret < 0)
        {
            server_log("seek file failed, state exit now, offset%d, errno:%d\n", file_info.offset, errno);
            server->state = CLIENTSTATE_EXIT;
            return;
        }

        ret = dl_read(server->file_fd, buf + sizeof(struct RCFileInfo), RCPACKET_MAX_FILEDATA_LEN);
        if (ret < 0)
        {
            server_log("read data failed, state exit now,errno:%d\n", errno);
            server->state = CLIENTSTATE_EXIT;
            return;
        }
    }

    // construct packet
    file_info.len = ret;
    if (0 == len)
    {
        server_log("transfile data,read 0 data\n");
        dl_server_construct_packet(server, RCCOMMAND_TRANS_FILEDATA, &file_info, sizeof(file_info), RCFLAGS_RESPONSE);
        len = sizeof(file_info);
    }
    else
    {
        len = sizeof(file_info) + file_info.len;
        memcpy(buf, &file_info, sizeof(file_info));
        dl_server_construct_packet(server, RCCOMMAND_TRANS_FILEDATA, buf, len, RCFLAGS_RESPONSE);

        // update md5
        md5_update(&server->md5_result, buf + sizeof(struct RCFileInfo), ret);
    }

    server_log("send TRANS_FILEDATA reply, file_data_len:%d\n", file_info.len);
    ret = dl_server_send(server->fd, &server->reply_packet, len + RCPACKET_HEAD_LEN);
    if (ret < 0)
    {
        server_log("send REQUEST_NEWFILE reply failed, state exit now\n");
        server->state = CLIENTSTATE_EXIT;
        return;
    }

    if (server->transferring_file_info.len == (file_info.len + file_info.offset))
    {
        server_log("send TRANS_FILEDATA completed, state changned to FILEDATA_MD\n");
        ret = close(server->file_fd);
        if (ret < 0)
        {
            server_log("close fd:%d failed, errno:%d\n", server->file_fd, errno);
        }
        server->state = CLIENTSTATE_FILEDATA_MD5;
    }
}


/*
 * send md5
 */
void dl_server_filedata_md5(struct DlServer *server)
{
    int ret, len;
    struct RCFileInfo file_info;
    file_info.fileid    = 1;
    file_info.offset    = 0;
    file_info.len       = 0;

    // get md5
    md5_final(&server->md5_result, (uint8_t *)server->md5);

    memcpy(server->file_data_buf, &file_info, sizeof(file_info));
    memcpy(server->file_data_buf + sizeof(file_info), server->md5, sizeof(server->md5));
    len = sizeof(file_info) + sizeof(server->md5);
    dl_server_construct_packet(server, RCCOMMAND_FILEDATA_MD5, server->file_data_buf,
                len, RCFLAGS_COMMAND);

    server_log("send FILEDATA_MD5 cmd\n");
    ret = dl_server_send(server->fd, &server->reply_packet, len + RCPACKET_HEAD_LEN);
    if (ret < 0)
    {
        server_log("send REQUEST_NEWFILE reply failed, state exit now\n");
        server->state = CLIENTSTATE_EXIT;
        return;
    }

    // wait for reply
    ret = dl_recv(server->fd, server->recv_buf, sizeof(server->recv_buf), 0);
    if (ret < 0)
    {
        server_log("recv machine info to server failed, state exit now\n");
        server->state = CLIENTSTATE_EXIT;
        return;
    }

    server_log("recv FILEDATA_MD5 reply,len:%u\n", ret);
    print_buf(server->recv_buf, ret);

    server->state = CLIENTSTATE_END_TRANSFILE;
}


/*
 * deal END_TRANSFILE state
 */
void dl_server_end_transfile(struct DlServer *server)
{
    int ret;

    // wait for cmd
    ret = dl_recv(server->fd, server->recv_buf, sizeof(server->recv_buf), 0);
    if (ret < 0)
    {
        server_log("recv END_TRANSFILE to server failed, state exit now\n");
        server->state = CLIENTSTATE_EXIT;
        return;
    }

    server_log("recv END_TRANSFILE cmd,len:%u\n", ret);
    print_buf(server->recv_buf, ret);

    // now we get machine info
    dl_server_construct_packet(server, RCCOMMAND_END_TRANSFILE, NULL, 0, RCFLAGS_RESPONSE);

    server_log("send END_TRANSFILE reply\n");
    ret = dl_server_send(server->fd, &server->reply_packet, RCPACKET_HEAD_LEN);
    if (ret < 0)
    {
        server_log("send END_TRANSFILE reply failed, state exit now\n");
        server->state = CLIENTSTATE_EXIT;
        return;
    }

    server->state = CLIENTSTATE_END_RECOVERY;
}


/*
 * deal END_RECOVERY state
 */
void dl_server_end_recovery(struct DlServer *server)
{
    int ret;

    // wait for cmd
    ret = dl_recv(server->fd, &server->recv_packet, sizeof(server->recv_packet), 0);
    if (ret < 0)
    {
        server_log("recv END_RECOVERY to server failed, state exit now\n");
        server->state = CLIENTSTATE_EXIT;
        return;
    }

    if (server->recv_packet.cmd == RCCOMMAND_REQUEST_NEWFILE)
    {
        dl_server_send_newfile_reply(server);
        return;
    }

    server_log("recv END_RECOVERY cmd,len:%u\n", ret);
    print_buf(server->recv_buf, ret);

    // now we get machine info
    dl_server_construct_packet(server, RCCOMMAND_END_RECOVERY, NULL, 0, RCFLAGS_RESPONSE);

    server_log("send END_RECOVERY reply\n");
    ret = dl_server_send(server->fd, &server->reply_packet, RCPACKET_HEAD_LEN);
    if (ret < 0)
    {
        server_log("send END_RECOVERY reply failed, state exit now\n");
        server->state = CLIENTSTATE_EXIT;
        return;
    }

    server->state = CLIENTSTATE_EXIT;
}

/*
 * statemachine
 */
void dl_server_statemachine(struct DlServer *server)
{
    for (;;)
    {
        switch(server->state)
        {
            case CLIENTSTATE_GET_MACHINE_INFO:
                dl_server_get_machine_info(server);
                break;

            case CLIENTSTATE_START_RECOVERY:
                dl_server_start_recovery(server);
                break;

            case CLIENTSTATE_REQUEST_NEWFILE:
                dl_server_request_newfile(server);
                break;

            case CLIENTSTATE_TRANS_FILEDATA:
                dl_server_trans_filedata(server);
                break;

            case CLIENTSTATE_FILEDATA_MD5:
                dl_server_filedata_md5(server);
                break;

            case CLIENTSTATE_END_TRANSFILE:
                dl_server_end_transfile(server);
                break;

            case CLIENTSTATE_END_RECOVERY:
                dl_server_end_recovery(server);
                break;

            case CLIENTSTATE_EXIT:
                return;
        }
    }
}

void *dl_server_one_task(void *arg)
{
    TDlServer *server = arg;

    // deal request
    server->state   = CLIENTSTATE_GET_MACHINE_INFO;
    dl_server_statemachine(server);

    free(server);

    server_log("one server task exit\n");
    return NULL;
}


/*
 * accept new connection
 *@fd server listen fd
 */
void dl_accept_new(void *context, struct epoll_event * event)
{
    int ret, fd;
    socklen_t len;
    pthread_t           tid;
    int server_fd = (int)context;
    struct sockaddr_in addr;
    TDlServer *server;

    if (event->events & (EPOLLERR | EPOLLHUP))
    {
        server_log("server fd error happened\n");
        return;
    }

    len = sizeof(addr);
    fd = accept(server_fd, (struct sockaddr *)&addr, &len);
    if (fd < 0)
    {
        server_log("accept failed,errno:%d\n", errno);
        return;
    }

    server = malloc(sizeof(*server));
    if (NULL == server)
    {
        server_log("malloc client failed,no mem\n");
        close(fd);
        return;
    }

    server_log("accept one client, fd:%d\n", fd);
    memset(server, 0, sizeof(*server));
    server->fd      = fd;
    server->addr    = addr;
    ret = pthread_create(&tid, NULL, dl_server_one_task, (void *)server);
    if (0 != ret)
    {
        server_log("create server thread failed,errno:%d\n", ret);
        close(fd);
    }

    return;
}

#if 0
/*
 * accept new connection
 *@fd server listen fd
 */
void dl_accept_new(void *context, struct epoll_event * event)
{
    int ret, fd;
    socklen_t len;
    TDlClientList *client;
    struct epoll_event ev;
    int server_fd = (int)context;

    if (event->events & (EPOLLERR | EPOLLHUP))
    {
        server_log("server fd error happened\n");
        return;
    }

    client = malloc(sizeof(*client));
    if (NULL == client)
    {
        server_log("malloc client failed,no mem\n");
        return;
    }
    memset(client, 0, sizeof(*client));

    len = sizeof(client->addr);
    fd = accept(server_fd, (struct sockaddr *)&client->addr, &len);
    if (fd < 0)
    {
        server_log("accept failed,errno:%d\n", errno);
        free(client);
        return;
    }

    // if max,refuse
    if (server_info.client_num >= DL_MAX_CLIENT_NUM)
    {
        server_log("client too many, please again\n");
        close(fd);
        free(client);
        return;
    }

    // add server fd to epoll
    client->epoll_data.context  = client;
    client->epoll_data.func     = dl_deal_msg;
    ev.data.ptr = (void *)&client->epoll_data;
    ev.events   = EPOLLIN;
    ret = epoll_ctl(server_info.epoll_fd, EPOLL_CTL_ADD, fd, &ev);
    if (ret < 0)
    {
        server_log("epoll add event failed\n");
        free(client);
        close(fd);
        return;
    }

    ret = fcntl(fd, F_SETFL, fcntl(fd, F_GETFL) | O_NONBLOCK);
    if (ret < 0)
    {
        server_log("set nonblock failed\n");
    }

    server_log("accept one client, fd:%d\n", fd);
    client->fd = fd;
    ret = clock_gettime(CLOCK_MONOTONIC, &client->last_ts);
    if (ret < 0)
    {
        server_log("get time failed\n");
    }
    dl_insert_client(client);

    return;
}
#endif


/*
 * deal epoll events
 */
void dl_deal_events(struct epoll_event *ev, int num)
{
    int i;

    server_log("deal epoll events,num:%d\n", num);

    // deal come data
    for (i = 0; i < num; i++)
    {
        if (NULL != ev[i].data.ptr)
        {
            TDlEpollData *data = ev[i].data.ptr;
            data->func(data->context, ev + i);
        }
        else
        {
            server_log("fatal error happened\n");
        }
    }
}

/*
 * download service
 */
void *dl_server_task(void *arg)
{
    int ret, server_fd, timeout;
    struct epoll_event *ev, ev_tmp;
    TDlEpollData server_data;

    server_info.epoll_fd = epoll_create1(0);
    if (server_info.epoll_fd < 0)
    {
        server_log("create epolll fd fialed,errno:%d\n", errno);
        return (void *)-1;
    }

    ev = (struct epoll_event *)malloc(sizeof(struct epoll_event) * DL_RECOVERY_EPOLL_SIZE);
    if (NULL == ev)
    {
        server_log("epoll event malloc failed\n");
        return (void *)-1;
    }


    // add server fd to epoll
    server_fd = (int)arg;
    server_data.context = arg;
    server_data.func    = dl_accept_new;
    ev_tmp.data.ptr = (void *)&server_data;
    ev_tmp.events   = EPOLLIN;
    ret = epoll_ctl(server_info.epoll_fd, EPOLL_CTL_ADD, server_fd, &ev_tmp);
    if (ret < 0)
    {
        server_log("epoll add failed\n");
        return (void *)-1;
    }

    // start service
    server_info.task_running = 1;
    server_log("dl server task ready,epoll fd:%d,server fd:%d\n", server_info.epoll_fd, server_fd);
    timeout = 20;
    while(1)
    {
        if (1 != server_info.task_running)
        {
            server_log("dl server task is commanded to exit\n");
            break;
        }

        ret = epoll_wait(server_info.epoll_fd, ev, DL_RECOVERY_EPOLL_SIZE, timeout);
        if (ret < 0)
        {
            if (EINTR == errno)
            {
                continue;
            }

            server_log("epoll wait failed, program to exit, errno:%d\n", errno);
            break;
        }
        else if (0 == ret)
        {
            continue;
        }

        server_log("accept new connect\n");

        // deal event
        dl_deal_events(ev, ret);
    }

    // free resource
    ret = close(server_info.epoll_fd);
    if (ret < 0)
    {
        server_log("close epoll fd failed,errno:%d\n", errno);
    }
    free(ev);
    server_info.task_exit   = 1;

    return NULL;
}

int dl_server_start()
{
    int ret, fd, reuse;
    struct sockaddr_in addr;

    // create socket
    fd = socket(AF_INET, SOCK_STREAM, 0);
    if (fd < 0)
    {
        server_log("create socket fialed,errno:%d\n", errno);
        return -1;
    }

    // reusable
    reuse = 1;
    ret = setsockopt(fd, SOL_SOCKET, SO_REUSEADDR, &reuse, sizeof(reuse));
    if (ret < 0)
    {
        server_log("set sock addr reuse failed,errno:%d\n", errno);
    }

    addr.sin_family = AF_INET;
    addr.sin_port   = htons(12345);
    addr.sin_addr.s_addr = INADDR_ANY;
    ret = bind(fd, (struct sockaddr *)&addr, sizeof(addr));
    if (ret < 0)
    {
        server_log("bind failed,errno:%d\n", errno);
        return -1;
    }

    ret = listen(fd, 3);
    if (ret < 0)
    {
        server_log("listen failed,errno:%d\n", errno);
        return -1;
    }

    server_info.task_exit = 0;
    ret = pthread_create(&server_info.tid, NULL, dl_server_task, (void *)fd);
    if (0 != ret)
    {
        server_log("create thread failed,errno:%d\n", ret);
        close(fd);
        return -1;
    }


    // TDlClientList.list = LIST_HEAD_INIT(TDlClientList.list);

    server_log("start srever successfull\n");
    return 0;
}



/*
 * server app entry point
 */
int main(int argc, char *argv[])
{
    int ret;

    memset(&server_info, 0, sizeof(server_info));

    ret = dl_server_start();
    if (ret < 0)
    {
        server_log("dl server start failed\n");
    }

    for(;;)
    {
        sleep(10);
    }
    return 0;
}














