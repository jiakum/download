#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/ip.h>
#include <arpa/inet.h>
#include <pthread.h>
#include <sys/epoll.h>
#include <errno.h>
#include <fcntl.h>
#include <time.h>

#include "recovery.h"
#include "analysis.h"
#include "socklinker.h"

#include "common.c"

/*
 * safe send
 */
int m_send(void *context, void *buf, int len)
{
    int ret;
    int size     = len;
    size_t offset   = 0;
    int fd = (int)context;

repeat:
    ret = send(fd, buf + offset, size, 0);
    if (ret < 0)
    {
        if (EINTR == errno)
        {
            goto repeat;
        }

        printf("send falied,errno:%d\n", errno);
        return -1;
    }
    else if (ret < size)
    {
        size    = size - ret;
        offset  = len - size;
        goto repeat;
    }

    return 0;
}

/*
 * recv data
 */
int m_recv(void *context, void *buf, int len)
{
    int ret;
    int fd = (int)context;

again:
    ret = recv(fd, buf, len, 0);
    if (ret < 0)
    {
        if (EAGAIN == errno)
        {
            goto again;
        }

        printf("socket recv data failed, errno:%d\n", errno);
        return -1;
    }
    else if (0 == ret)
    {
        printf("socket recv no data, peer maybe shutdown\n");
        return -1;
    }

    return ret;
}

/*
 * create linker
 */
int m_create_sock()
{
    int fd, ret, reuse;
    socklen_t len;
    struct sockaddr_in addr, rmt_addr;

    // create socket
    fd = socket(AF_INET, SOCK_STREAM, 0);
    if (fd < 0)
    {
        printf("create socket fialed,errno:%d\n", errno);
        return -1;
    }

    // reusable
    reuse = 1;
    ret = setsockopt(fd, SOL_SOCKET, SO_REUSEADDR, &reuse, sizeof(reuse));
    if (ret < 0)
    {
        printf("set sock addr reuse failed,errno:%d\n", errno);
    }

    addr.sin_family = AF_INET;
    addr.sin_port   = htons(12000);
    addr.sin_addr.s_addr = INADDR_ANY;
    ret = bind(fd, (struct sockaddr *)&addr, sizeof(addr));
    if (ret < 0)
    {
        printf("bind failed,errno:%d\n", errno);
        return -1;
    }

    // connect
    rmt_addr.sin_family = AF_INET;
    rmt_addr.sin_port   = htons(12345);
    rmt_addr.sin_addr.s_addr = inet_addr("127.0.0.1");
    len = sizeof(rmt_addr);
    ret = connect(fd, (struct sockaddr *)&rmt_addr, len);
    if (ret < 0)
    {
        printf("connect failed,errno:%d\n", errno);
        return -1;
    }

    return fd;
}

HAnalysisHandle analysis;
uint8_t m_buf[1500];
void m_analysis_input_data(void *context, struct epoll_event *ev)
{
    printf("to recv data\n");
    int ret = m_recv(context, m_buf, sizeof(m_buf));
    if (ret > 0)
    {
        printf("call analysis_input_data, len:%d\n", ret);
        ret = analysis_input_data(analysis, m_buf, ret);
    }
    else if (0 == ret)
    {
        printf("peer may broken\n");
    }
    else
    {
        printf("recv failed\n");
    }
}

/*
 * recovery entry
 */
int main(int argc, char *argv[])
{
    int ret, fd;
    HSockLinkHandle link;
    TSockEvTaskParam link_param;
    TSockEpollCtx *ctx;

    if (argc > 2)
    {
        printf("Usage: [%s] more argument need\n", argv[0]);
        return -1;
    }

    // create analysis client handle
    analysis = analysis_create(ANALYSIS_TYPE_CLIENT);
    if (ANALYSIS_INVALID_HANDLE == analysis)
    {
        printf("create handle failed\n");
        return -1;
    }

    ret = m_create_sock();
    if (ret < 0)
    {
        printf("sock connect failed\n");
        return -1;
    }
    fd = ret;

    // set callback
    ret = analysis_set_cb(analysis, m_send, (void *)fd, NULL, 0);
    if (ret < 0)
    {
        printf("set analysis callback failed\n");
        return -1;
    }

    // create sock link
    link = sock_create_linker(10, 10);
    if (SOCKLINK_INVALID_HANDLE == link)
    {
        printf("create link failed\n");
        return -1;
    }

    ctx = malloc(sizeof(*ctx));
    if (NULL == ctx)
    {
        printf("mem not enough\n");
        return -1;
    }

    ctx->func       = m_analysis_input_data;
    ctx->context    = (void *)fd;
    link_param.fd           = fd;
    link_param.op           = EPOLL_CTL_ADD;
    link_param.ev.events    = EPOLLIN;
    link_param.ev.data.ptr  = ctx;
    ret = sock_add_ev_task(link, &link_param);
    if (ret < 0)
    {
        printf("add ev task failed\n");
        return -1;
    }

    ret = sock_add_timer_task(link, analysis_timer_routine, analysis);
    if (ret < 0)
    {
        printf("add timer task failed\n");
        return -1;
    }

    for(;;);

    return 0;
}

#if 0

/*
 * recovery entry
 */
int main(int argc, char *argv[])
{
    int ret, fd;
    hanalysishandle handle;

    if (argc > 2)
    {
        printf("usage: [%s] more argument need\n", argv[0]);
        return -1;
    }

    // create linker
    fd = m_create_sock();
    if (fd < 0)
    {
        printf("create linker failed\n");
        return -1;
    }

    // create analysis client handle
    handle = analysis_create(ANALYSIS_TYPE_CLIENT);
    if (ANALYSIS_INVALID_HANDLE == handle)
    {
        printf("create handle failed\n");
        return -1;
    }

    // set callback
    ret = analysis_set_cb(handle, m_send, (void *)fd, m_recv, (void *)fd);
    if (ret < 0)
    {
        printf("set analysis callback failed\n");
        return -1;
    }

    // run it to get recovery file
    ret = analysis_run(handle);
    if (ret < 0)
    {
        printf("run analysis failed\n");
        return -1;
    }


    for(;;);

    return 0;
}
#endif
