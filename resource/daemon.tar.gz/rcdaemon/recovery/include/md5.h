#ifndef _CRYPTO_MD5_H
#define _CRYPTO_MD5_H


#define MD5_DIGEST_SIZE		16
#define MD5_HMAC_BLOCK_SIZE	64
#define MD5_BLOCK_WORDS		16
#define MD5_HASH_WORDS		4

#define MD5_HASH_SIZE       (MD5_HASH_WORDS << 2)

struct md5_state {
	uint32_t hash[MD5_HASH_WORDS];
	uint32_t block[MD5_BLOCK_WORDS];
    uint64_t byte_count;
};


/*
 * init md5 state
 */
int md5_init(struct md5_state *mctx);

/*
 * update md5 check sum
 */
int md5_update(struct md5_state *mctx, const uint8_t *data, unsigned int len);

/*
 * get final md5 value,out is buf with len of 16 bytes
 */
int md5_final(struct md5_state *mctx, uint8_t *out);

#endif
