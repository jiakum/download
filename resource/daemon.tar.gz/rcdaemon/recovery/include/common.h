#ifndef __COMMON_H__
#define __COMMON_H__

/*
 * read data
 */
int cbb_read(int fd, void *buf, size_t len);

/*
 * safe write
 */
int cbb_write(int fd, void *buf, int len);



#endif // __COMMON_H__
