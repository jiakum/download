#ifndef __PROTOCOL_H__
#define __PROTOCOL_H__



#define ANALYSIS_OFFSET(type, member)  ((size_t)&((type *)0)->member)

/*
 * construct reply packet
 */
inline void protocol_construct_packet(struct RCPacket *packet, uint16_t seq, uint16_t flags,
                                        uint16_t cmd, void *buf, uint16_t len)
{
    packet->header[0]  = '@';
    packet->header[1]  = '$';
    packet->seq        = seq;
    packet->flags      = flags;
    packet->cmd        = cmd;
    packet->len        = len;
    packet->crc[0]     = calc_crc8((unsigned char *)packet, ANALYSIS_OFFSET(struct RCPacket, crc[0]));
    packet->crc[1]     = ~packet->crc[0];
    if (NULL != buf)
    {
        memcpy(packet->payload, buf, len);
    }
}


#endif  // __PROTOCOL_H__
