#ifndef __DEBUG_H__
#define __DEBUG_H__


/*
 * init debug module
 */
int debug_init();



#endif  // __DEBUG_H__
