
#ifndef __UPDATE_H__
#define __UPDATE_H__

/*
 * updata function
 */
int update_run();

#endif  // __UPDATE_H__
