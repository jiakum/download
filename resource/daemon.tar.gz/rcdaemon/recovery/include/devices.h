#ifndef __DEVICES_H__
#define __DEVICES_H__

int device_init();
void device_deinit();
int device_connect(int port);
int device_has_iphone();
int device_has_adb();

#endif /* __DEVICES_H__ */
