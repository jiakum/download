#ifndef __ANALYSISER_H__
#define __ANALYSISER_H__


#define ANALYSIS_TYPE_CLIENT    0x1
#define ANALYSIS_TYPE_SERVER    0x2

#define ANALYSIS_INVALID_HANDLE     NULL

typedef void *      HAnalysisHandle;

/// analysis event
typedef enum tagAnalysiserEvent{
    AE_END_FILE_TRANS   = 1,        /// means need to write new img to flash,async
    AE_END_RECOVERY     = 2,        /// means end recovery event happened
}EAnalysiserEvent;

/// analysis event callback
typedef int (*FAnalysisEvCb)(void *context, EAnalysiserEvent ev, void *buf, int len);

/// send/recv data call back function
typedef int (*FAnalysisDataCb)(void *context, void *buf, int len);

/// to implement
#if 0
typedef struct tagFileOps
{
    int (*open)(const char *name, int flags);
    int (*write)(int fd, const void *buf, int count);
    int (*read)(int fd, const void *buf, int count);

    int (*lseek)(int fd, int offset, int whence);
};
#endif

/*
 * create analysis client or server
 *@param type this param can either be ANALYSIS_TYPE_CLIENT or ANALYSIS_TYPE_SERVER
 *@return if successfull,return handle. On error @ANALYSIS_INVALID_HANDLE is returned
 */
HAnalysisHandle analysis_create(int type);

/*
 * destroy analysis client or server
 */
int analysis_destroy(HAnalysisHandle handle);

/*
 * data send/recv for specified handle, if recv_cb not NULL, this is for pull mode
 */
int analysis_set_cb(HAnalysisHandle handle, FAnalysisDataCb send_cb, void *send_context,
                        FAnalysisDataCb recv_cb, void *recv_context);

/*
 * set event callback
 */
int analysis_set_ev_cb(HAnalysisHandle handle, FAnalysisEvCb ev_cb, void *context);

/*
 * analysis run fucntion,pull mode
 *@return if successfull,return 0. On error,other value is returned
 */
int analysis_run(HAnalysisHandle handle);

/*
 * analysis data input,push mode
 */
int analysis_input_data(HAnalysisHandle handle, void *buf, int len);

/*
 * deal timer task
 */
int analysis_timer_routine(HAnalysisHandle handle, struct timespec ts);

/*
 * set recovery operate state
 *@result on error result value is -1,other value means recovery successfully
 */
int analysis_set_recovery_op_state(HAnalysisHandle handle, int result);

#endif  // __ANALYSISER_H__
