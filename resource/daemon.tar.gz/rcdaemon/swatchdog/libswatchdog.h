#ifndef __LIBSWATCHDOG_H__
#define __LIBSWATCHDOG_H__

/*
 * Feed the app watchdog
 *
 * Once this fuction called successfully, the watchdog deamon will arrange a dog to watch this process
 * If the process don't feed the dog in next timeout miliseconds, the dog will restart the process.
 *
 * Argument:
 *
 * timeout: the timeout happened in miliseconds
 *    name: the string to indentfy the thread
 *
 * Return:
 *  return the file descriptor, or -1 if an error occurred (in which case, errno is set appropriately)
 */
int feed_dog(int timeout, char *name);

#endif /* __LIBSWATCHDOG_H__ */
