#ifndef __SWATCHDOG_H__
#define __SWATCHDOG_H__

#include <stdint.h>
#include <sys/types.h>
#include <unistd.h>

#define SWATCHDOG_PATH      "/tmp/tmp_swatchdog"

#define NAME_LENGTH         32

#define FOOD_SIG_HEAD       0x5555
#define FOOD_SIG_FOOT       0xAAAA
#define MAX_TIMEOUT         2000

struct DogFood {
    uint16_t                sig_head;               // should be 0x5555
    pid_t                   pid;                    // the process id
    pthread_t               tid;                    // the thread id
    int                     timeout;                // in milseconds, should be < MAX_TIMEOUT
    char                    name[NAME_LENGTH];      // the identify name for the thread
    uint16_t                sig_foot;               // should be 0xAAAA
}  __attribute__((packed));

#endif /* __SWATCHDOG_H__ */
