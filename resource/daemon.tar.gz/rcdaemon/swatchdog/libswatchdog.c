#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <fcntl.h>
#include <sys/un.h>
#include <string.h>
#include <errno.h>
#include <pthread.h>

#include "log.h"

#include "swatchdog.h"

#define TAG "libswatchdog"

#define log(format, ...)        logw(LOG_LOCAL5, TAG, format, ##__VA_ARGS__)
//#define log(format, ...)        printf(format, ##__VA_ARGS__)

static inline int register_dog()
{
    int fd;

    fd = socket(AF_UNIX,SOCK_DGRAM | SOCK_CLOEXEC,0);
    if (fd < 0) {
        log("socket error %d:%s\n", errno, strerror(errno));
        return -1;
    }
    fcntl(fd, F_SETFL, fcntl(fd, F_GETFL) | O_NONBLOCK);
    return fd;
}

int feed_dog(int timeout, char *name)
{
    static int fd = -1;
    static const struct sockaddr_un addr = { .sun_family = AF_UNIX, .sun_path = SWATCHDOG_PATH};
    int ret = -1;
    struct DogFood food = {0};

    if ( fd < 0 ) {
        fd = register_dog();
    }

    if ( fd > 0 ) {
        food.sig_head = FOOD_SIG_HEAD;
        food.sig_foot = FOOD_SIG_FOOT;
        food.pid = getpid();
        food.timeout = timeout;
        food.tid = pthread_self();
        strncpy(food.name, name, sizeof(food.name));
        ret = sendto(fd, &food, sizeof(struct DogFood), 0,(struct sockaddr*)&addr, sizeof(addr));
        if ( ret == -1 ) {
            log("sendto %s error %d:%s\n", addr.sun_path, errno, strerror(errno));
            if ( errno == EAGAIN || errno == EINTR ) {
                ret = 0;
            } else {
                close(fd);
                fd = -1;
            }
        }
    }
    return fd;
}
