#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <signal.h>
#include <errno.h>
#include <string.h>
#include <stdint.h>
#include <sys/time.h>
#include <sys/epoll.h>

#include "log.h"
#include "list.h"

#include "swatchdog.h"

#define TAG "swatchdogd"

#define log(format, ...)        logw(LOG_LOCAL5, TAG, format, ##__VA_ARGS__)
//#define log(format, ...)        printf(format, ##__VA_ARGS__)

#define MIN(x,y)            ((x)<(y)?(x):(y))
#define CMDLINE_LENGTH      256

struct client_context {
    pid_t                   pid;
    pthread_t               tid;
    char                    name[NAME_LENGTH];
    char                    cmdline[CMDLINE_LENGTH];
    int64_t                 expires;
    struct list_head        list;
};

struct client_context client_list = {
    .list   =   LIST_HEAD_INIT(client_list.list),
};

static inline int64_t get_current_time_us(void)
{
    struct timeval tv;
    gettimeofday(&tv, NULL);
    return (int64_t)tv.tv_sec * 1000000 + tv.tv_usec;
}

static inline int64_t get_current_time(void)
{
    return get_current_time_us() / 1000;
}

static int open_unix_socket(char *name)
{
    int fd;
    struct sockaddr_un addr = {.sun_family = AF_UNIX, .sun_path = SWATCHDOG_PATH};

    fd = socket(AF_UNIX,SOCK_DGRAM | SOCK_CLOEXEC,0);
    if (fd < 0) {
        log("socket error %d:%s\n", errno, strerror(errno));
        return -1;
    }

    unlink(name);
    if (bind (fd, (struct sockaddr *)&addr, sizeof(addr)) < 0) {
        log("bind error %d:%s\n", errno, strerror(errno));
        close(fd);
        return -1;
    }

    fcntl(fd, F_SETFL, fcntl(fd, F_GETFL) | O_NONBLOCK);
    log("bind ok %s\n", addr.sun_path);

    return fd;
}

static inline void die_client(struct client_context *ctx)
{
    list_del(&ctx->list);
    free(ctx);
}

static int get_cmdline_from_pid(int pid, char *cmdline, int size)
{
    char filename[32];
    int fd = -1;
    int ret = -1;
    int i = 0;

    snprintf(filename, sizeof(filename), "/proc/%d/cmdline", pid);

    fd = open(filename, O_RDONLY);
    if ( fd < 0 ) {
        log("open %s error! %d:%s\n", filename, errno, strerror(errno));
        return ret;
    }

    ret = read(fd, cmdline, size);
    for ( i = 0; i < ret-1; i++ ) {
        if ( cmdline[i] == 0 ) {
            cmdline[i] = ' ';
        }
    }
    
    close(fd);
    return ret;
}

static inline void print_client(struct client_context *ctx)
{
    log("pid:%d thread id:%ld name:%s cmd:%s expires:%lld(current:%lld)\n", ctx->pid, ctx->tid, ctx->name, ctx->cmdline, ctx->expires, get_current_time());
}

static int new_client(struct DogFood *food)
{
    struct client_context *cli_ctx = malloc(sizeof(struct client_context));
    if ( !cli_ctx ) {
        log("malloc failed for client %s\n", __func__);
        return -ENOMEM;
    }

    memset(cli_ctx, 0, sizeof(struct client_context));

    cli_ctx->pid = food->pid;
    cli_ctx->tid = food->tid;
    cli_ctx->expires = MIN(food->timeout, MAX_TIMEOUT) + get_current_time();
    strncpy(cli_ctx->name, food->name, strlen(food->name));
    if ( get_cmdline_from_pid(cli_ctx->pid, cli_ctx->cmdline, sizeof(cli_ctx->cmdline)) <= 0 ) {
        free(cli_ctx);
        return -1;
    }

    list_add(&cli_ctx->list, &client_list.list);
    log("new client register\n");
    print_client(cli_ctx);

    return 0;
}

void feed_clients(struct DogFood *food)
{
    struct client_context *pos, *next;
    int is_new_client = 1;

    list_for_each_entry_safe(pos, next, &client_list.list, list) {
        if ( food->pid == pos->pid && food->tid == pos->tid ) {
            is_new_client = 0;
            pos->expires = MIN(food->timeout, MAX_TIMEOUT) + get_current_time();
        }
    }

    if ( is_new_client ) {
        new_client(food);
    }
}

void run_cmd(char *cmdline)
{
    pid_t pid = vfork();

    if ( pid == 0 ) {
        int i = 0;
        char *argv[16];
        argv[0] = strtok(cmdline, " ");
        for ( i = 1; i < 16 && (argv[i] = strtok(NULL, " ")); i++ ) {
        }

        if (execv(argv[0], argv) < 0) {
            log("exec cmd:%s failed, errno:%d\n", argv[0], errno);
        }

        exit(127);
    } else if ( pid < 0 ) {
        log("vfork failed:%d:%s, fatal error!!!\n", errno, strerror(errno));
    }
}

static void check_clients()
{
    struct client_context *pos, *next;
    pid_t pid = 0;
    char cmdline[CMDLINE_LENGTH];

    list_for_each_entry_safe(pos, next, &client_list.list, list) {
        if ( pos->expires < get_current_time() ) {
            //expires happened, need kill the client
            pid = pos->pid;
            strncpy(cmdline, pos->cmdline, CMDLINE_LENGTH);
            log("thread expires happened, pid=%d, name=%s \n", pos->pid, pos->name);
            break;
        }
    }

    if ( pid ) {
        list_for_each_entry_safe(pos, next, &client_list.list, list) {
            if ( pid == pos->pid ) {
                log("remove client\n");
                print_client(pos);
                die_client(pos);
            }
        }
        
        // kill the process
        kill(pid, SIGKILL);

        // restart the process
        run_cmd(cmdline);
    }
}

int main( int argc, char **argv )
{
    int fd = -1;
    int epfd = -1;
    char buf[256];
    struct epoll_event ev;
    struct epoll_event events[4];
    struct DogFood *food = (struct DogFood *)buf;

    signal(SIGCHLD,SIG_IGN);

    epfd = epoll_create1(EPOLL_CLOEXEC);
    if (0 > epfd) {
        log("epoll create failed. err: %s\n", strerror(errno));
        return -1;
    }

    if((fd = open_unix_socket(SWATCHDOG_PATH)) < 0) {
        log("open unix socket %s error!", SWATCHDOG_PATH);
        return -1;
    }

    ev.events   = EPOLLIN;
    ev.data.fd  = fd;
    if(epoll_ctl(epfd, EPOLL_CTL_ADD, fd, &ev) < 0) {
        loge(LOG_RCDAEMON, TAG, "%s,epoll control add fd error.\n", __func__);
        return 0;
    }

    while ( 1 ) {
        int ret = epoll_wait(epfd, events, sizeof(events)/sizeof(events[0]), 500);
        if (ret > 0) {
            memset(buf, 0, sizeof(buf));
            ret = recvfrom(fd, buf, sizeof(buf), 0, NULL, NULL);

            if ( ret >= sizeof(struct DogFood) 
                    && food->sig_head == FOOD_SIG_HEAD && food->sig_foot == FOOD_SIG_FOOT ) {
                feed_clients(food);
            }
        }

        check_clients();
    }

    epoll_ctl(epfd, EPOLL_CTL_DEL, fd, &ev);
    close(epfd);
    close(fd);

    return 0;
}
