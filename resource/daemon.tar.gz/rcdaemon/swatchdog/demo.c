#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <stdlib.h>

#include "libswatchdog.h"

#define log(format, ...)        printf(format, ##__VA_ARGS__)

int main( int argc, char **argv ) {
    printf("usage: %s delay name timeout\n", argv[0]);
    int fd = -1;
    char name[32] = {0};
    int delay = 200;
    int timeout = 500;
    if ( argc >= 2 ) {
        delay = atoi(argv[1]);
    } 
    if ( argc >= 3 ) {
        sscanf(argv[2], "%s", name);
    }
    if ( argc >= 4 ) {
        timeout = atoi(argv[3]);
    }
    
    log("pid=%d delay=%d timeout=%d name=%s\n", getpid(), delay, timeout, name);

    while ( 1 ) {
        fd = feed_dog(timeout, name);
        if ( delay > 1000 ) {
            sleep(delay/1000);
        }
        usleep((delay%1000) * 1000);
    }

    if ( fd > 0 ) {
        unregister_dog(fd);
    }
    return 0;
}
