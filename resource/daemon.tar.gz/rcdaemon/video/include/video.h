#ifndef __VIDEO_H__
#define __VIDEO_H__

#ifdef __cplusplus
extern "C" {
#endif



///**********************************************/
///   type define                               */
///**********************************************/
/*
 * hot plug dev status
 */
typedef enum HotPlugStatus
{
    EHOT_PLUG_DISCONNECT    = 1,    /// out
    EHOT_PLUG_CONNECTING,           /// in but not ready
    EHOT_PLUG_CONNECTED,            /// in and ready
}EHotPlugStatus;

/*
 * usb dev type
 */
typedef enum UsbDevType
{
    EUSB_DEV_UNKWON     = 0,    /// unkwon usb type
    EUSB_DEV_ANDROID    = 1,    /// android dev
    EUSB_DEV_ISO        = 2,    /// ios dev
}EUsbDevType;

/*
 * usb connection event
 */
typedef struct UsbConnEvent
{
    EUsbDevType     type;       /// phone type
    EHotPlugStatus  status;     /// in or out
}TUsbConnEvent;

///**********************************************/
///   function declare                          */
///**********************************************/
/*
 * mplayer process init function
 * init all submodule
 */
int video_init(char *filename);

/*
 * mplayer process deinit function
 * deinit all submodule
 */
int video_deinit();

/*
 * set wifi connect status
 */
int video_set_wifi_status(EHotPlugStatus status);

/*
 * set hdmi connect status
 */
void video_set_hdmi_status(EHotPlugStatus status);

/*
 * set phone connect status
 */
void video_set_phone_status(int hasios, int hasadb, int handle);

/*
 * set adb connect status
 */
int video_set_usb_conn_status(TUsbConnEvent *ev);



#ifdef __cplusplus
}
#endif

#endif  /// __VIDEO_H__
