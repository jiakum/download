#ifndef __RTSP_SWITCH_H__
#define __RTSP_SWITCH_H__

#ifdef __cplusplus
extern "C" {
#endif




///**********************************************/
///   function declare                          */
///**********************************************/
/*
 * rtsp_switch server listen port
 */
int rtsp_switch_init(uint16_t port);

/*
 * rtsp_switch server listen port
 */
int rtsp_switch_set_usb_connect_status();

/*
 * set phone connect status
 */
void rs_set_phone_status(int hasios, int hasadb, int handle);

#ifdef __cplusplus
}
#endif

#endif  /// __RTSP_SWITCH_H__
