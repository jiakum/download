#ifndef __COMMON_H__
#define __COMMON_H__

#ifdef __cplusplus
extern "C" {
#endif

#include "video.h"

/*
 * define common mem free opration
 */
#define SAFE_FREE(p)    do {if (NULL != (p))   {free(p); (p) = NULL;}} while(0)

/*
 * module log api
 */
#define video_loge(fmt, ...)     av_log(NULL, AV_LOG_ERROR, "[video]"fmt, ##__VA_ARGS__)


#ifdef __cplusplus
}
#endif

#endif  /// __COMMON_H__
