#ifndef __HDMI_H__
#define __HDMI_H__

#ifdef __cplusplus
extern "C" {
#endif


#include "video.h"

/// HDMI module
///// 提供初始化反初始化接口，提供上报hdmi接入拔出事件，提供主动查询接口

/*
 * hdmi event callback data structrue
 */
typedef struct HdmiEvent
{
    EHotPlugStatus status;  /// see @EHotPlugStatus
}THdmiEvent;

/// hdmi event callbalck
typedef int (*FHdmiCallBack)(THdmiEvent *event, void *context);

/*
 * hdmi init
 */
int hdmi_init();

/*
 * hdmi deinit
 */
int hdmi_deinit();

/*
 * set hdmi callback function
 */
int hdmi_set_callback(FHdmiCallBack pf, void *context);

/*
 * set hdmi callback function
 */
int hdmi_get_status(THdmiEvent *event);



#ifdef __cplusplus
}
#endif

#endif  /// __HDMI_H__
