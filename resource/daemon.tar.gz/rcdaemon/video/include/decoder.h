#ifndef __DECODER_H__
#define __DECODER_H__

/*
 * init decoder
 */
int dec_init(AVCodecContext *avctx);

/*
 * dec commit frame
 */
int dec_commit_frame(AVPacket *avpkt);

/*
 * dec commit frame
 */
int dec_run();

/*
 * dec get one picture
 */
int dec_get_picture(AVCodecContext *avctx, void *data, int *data_size);

/*
 * send signal to exit dec task
 */
void dec_exit_task();

#endif // __DECODER_H__
