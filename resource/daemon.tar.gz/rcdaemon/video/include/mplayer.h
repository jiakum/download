
#ifndef __MPLAYER_H__
#define __MPLAYER_H__

#ifdef __cplusplus
extern "C" {
#endif


///**********************************************/
///   type define                               */
///**********************************************/
/// localplay pkt callback for switch
typedef int (*FLocalPlayerPktCb)(AVPacket *pkt, void *context);

/// event from localplay
#define EPLAYER_EV_RTSP_EXIT    1           /// need high-level restart stream

/// mplayer event
typedef struct MplayerEvent
{
    uint32_t ev;
}TMplayerEvent;

/// localplay event callback function synopsis
typedef int (*FLocalPlayerEvCb)(TMplayerEvent *ev, void *context);


///**********************************************/
///   function declare                          */
///**********************************************/
/*
 * init mplayer
 */
int localplay_init();

/*
 * uninit mplayer
 */
void localplay_uninit();

/*
 * open rtsp stream
 */
int localplay_open_stream(int *handle, char *pszUrl);

/*
 * set AVPacket data callback,unset with  pfavpacket_cb set to NULL
 */
int localplay_set_pkt_callback(int handle, FLocalPlayerPktCb pfavpacket_cb, void *context);

/*
 * set event callback,unset with  pfavpacket_cb set to NULL
 */
int localplay_set_ev_callback(int handle, FLocalPlayerEvCb pfev_cb, void *context);

/*
 * close stream
 */
void localplay_close_stream();

/*
 * get AVFormatContext*
 */
AVFormatContext *localplay_get_avformatcontext(int handle);



#ifdef __cplusplus
}
#endif

#endif  /// __MPLAYER_H__
