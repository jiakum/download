/*
 * Copyright (c) 2015 Jens Kuske <jenskuske@gmail.com>
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 *
 */

#ifndef SUNXI_DISP_H_
#define SUNXI_DISP_H_

#include <stdint.h>

/**
* \hideinitializer
* \brief The "NV12" YCbCr surface format.
*
* This format has a two planes, a Y plane and a UV plane.
*
* The Y plane is an array of byte-sized Y components.
* Applications should access this data via a uint8_t pointer.
*
* The UV plane is an array of interleaved byte-sized U and V
* components, in the order U, V, U, V. Applications should
* access this data via a uint8_t pointer.
*/
#define VDP_YCBCR_FORMAT_NV12     ((VdpYCbCrFormat)0)
/**
* \hideinitializer
* \brief The "YV12" YCbCr surface format.
*
* This format has a three planes, a Y plane, a V plane, and a U
* plane.
*
* Each of the planes is an array of byte-sized components.
*
* Applications should access this data via a uint8_t pointer.
*/
#define VDP_YCBCR_FORMAT_YV12     ((VdpYCbCrFormat)1)
/**
* \hideinitializer
* \brief The "UYVY" YCbCr surface format.
*
* This format may also be known as Y422, UYNV, HDYC.
*
* This format has a single plane.
*
* This plane is an array of interleaved byte-sized Y, U, and V
* components, in the order U, Y, V, Y, U, Y, V, Y.
*
* Applications should access this data via a uint8_t pointer.
*/
#define VDP_YCBCR_FORMAT_UYVY     ((VdpYCbCrFormat)2)
/**
* \hideinitializer
* \brief The "YUYV" YCbCr surface format.
*
* This format may also be known as YUY2, YUNV, V422.
*
* This format has a single plane.
*
* This plane is an array of interleaved byte-sized Y, U, and V
* components, in the order Y, U, Y, V, Y, U, Y, V.
*
* Applications should access this data via a uint8_t pointer.
*/
#define VDP_YCBCR_FORMAT_YUYV     ((VdpYCbCrFormat)3)
#define INTERNAL_YCBCR_FORMAT (VdpYCbCrFormat)0xffff

typedef struct {
	/** Left X co-ordinate. Inclusive. */
	uint32_t x0;
	/** Top Y co-ordinate. Inclusive. */
	uint32_t y0;
	/** Right X co-ordinate. Exclusive. */
	uint32_t x1;
	/** Bottom Y co-ordinate. Exclusive. */
	uint32_t y1;
} VdpRect;

struct cedrus_mem
{
	void *virt;
	uint32_t phys;
	size_t size;
};
typedef struct cedrus_mem cedrus_mem_t;
typedef uint32_t VdpYCbCrFormat;

static inline uint32_t cedrus_mem_get_phys_addr(const struct cedrus_mem *mem)
{
	if (!mem)
		return 0x0;

	return mem->phys;
}

typedef struct
{
	int ref_count;
	cedrus_mem_t *data;
} yuv_data_t;

typedef struct video_surface_ctx_struct
{
	uint32_t width, height;
	VdpYCbCrFormat source_format;
	yuv_data_t *yuv;
	int luma_size, chroma_size;
} video_surface_ctx_t;

typedef struct output_surface_ctx_struct
{
	video_surface_ctx_t *vs;
	yuv_data_t *yuv;
	VdpRect video_src_rect, video_dst_rect;
} output_surface_ctx_t;

typedef struct output_surface_ctx_struct output_surface_ctx_t;

struct sunxi_disp
{
	void (*close)(struct sunxi_disp *sunxi_disp);
	int (*set_video_layer)(struct sunxi_disp *sunxi_disp, int x, int y, int width, int height, output_surface_ctx_t *surface);
	void (*close_video_layer)(struct sunxi_disp *sunxi_disp);
	int (*set_osd_layer)(struct sunxi_disp *sunxi_disp, int x, int y, int width, int height, output_surface_ctx_t *surface);
	void (*close_osd_layer)(struct sunxi_disp *sunxi_disp);
};

struct sunxi_disp *sunxi_disp_open(int osd_enabled);
struct sunxi_disp *sunxi_disp2_open(int osd_enabled);
struct sunxi_disp *sunxi_disp1_5_open(int osd_enabled);

#endif
