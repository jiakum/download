
#include "libavcodec/internal.h"
#include "libavutil/internal.h"
#include "libavcodec/avcodec.h"
#include "libavutil/timestamp.h"
#include <vdecoder.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/ioctl.h>
#include <pthread.h>

#include <memoryAdapter.h>

enum FORMAT_CONVERT_COLORFORMAT
{
	CONVERT_COLOR_FORMAT_NONE = 0,
	CONVERT_COLOR_FORMAT_YUV420PLANNER,
	CONVERT_COLOR_FORMAT_YUV422PLANNER,
	CONVERT_COLOR_FORMAT_YUV420MB,
	CONVERT_COLOR_FORMAT_YUV422MB,
};

typedef struct _CedarContext_ {
	int b_have_pts;
	pthread_t thread;
	pthread_mutex_t mutex;
	pthread_cond_t cond;
	AVCodecContext   *s;
	VideoDecoder     *decoder;
	int              width,height;
	int              running;
	FILE             *fp;
} CedarContext;

typedef struct ScalerParameter
{
	int mode; //0: YV12 1:thumb yuv420p
	int format_in;
	int format_out;

	int width_in;
	int height_in;

	int width_out;
	int height_out;

	void *addr_y_in;
	void *addr_c_in;
	unsigned int addr_y_out;
	unsigned int addr_u_out;
	unsigned int addr_v_out;
}ScalerParameter;

/*******************************************************************************
Function name: map32x32_to_yuv_Y
Description:
    1. we should know : vdecbuf is 32*32 align
    2. must match gpuBuf size.
    3. we guarantee: vdecbufSize>=gpuBufSize
    4. if coded_width is stride, we can support gpu_buf_width 32byte align and 16byte align!
    5. A20_GPU:
        YV12: y_width_align=16, u_width_align=16, v_width_align=16,
              y/u/v_height can be any number(not even).

Parameters:

Return:

Time: 2013/4/15
*******************************************************************************/
static void map32x32_to_yuv_Y(unsigned char* srcY, unsigned char* tarY,unsigned int coded_width,unsigned int coded_height)
{
	unsigned int i,j,l,m,n;
	unsigned int mb_width,mb_height,twomb_line, twomb_width;
	unsigned long offset;
	unsigned char *ptr;
	unsigned char *dst_asm,*src_asm;
    unsigned vdecbuf_width;
    int nWidthMatchFlag;
    int nLeftValidLine;  //in the bottom macroblock(32*32), the valid line is < 32.
	ptr = srcY;

    mb_width = ((coded_width+31)&~31) >>4;
	mb_height = ((coded_height+31)&~31) >>4;
	twomb_line = (mb_height+1)>>1;
    twomb_width = (mb_width+1)>>1;
    if(twomb_line < 1 || twomb_width < 1)
        av_log(NULL, AV_LOG_INFO, "fatal error! twomb_line=%d, twomb_width=%d", twomb_line, twomb_width);
    vdecbuf_width = twomb_width*32;

    if(vdecbuf_width > coded_width) {
        nWidthMatchFlag = 0;
        if((vdecbuf_width - coded_width) != 16)
            av_log(NULL, AV_LOG_ERROR, "fatal error! vdecbuf_width=%d, gpubuf_width=%d,  the program will crash!", vdecbuf_width, coded_width);
    } else if(vdecbuf_width == coded_width)
        nWidthMatchFlag = 1;
    else {
        av_log(NULL, AV_LOG_ERROR,"fatal error! vdecbuf_width=%d <= gpubuf_width=%d, the program will crash!", vdecbuf_width, coded_width);
        nWidthMatchFlag = 0;
    }

	for(i=0;i<twomb_line-1;i++) {  //twomb line number
		for(j=0;j<twomb_width-1;j++) {  //macroblock(32*32) number in one line
			for(l=0;l<32;l++) {
				//first mb
				m=i*32 + l;     //line num
				n= j*32;        //byte num in one line
				offset = m*coded_width + n;
				//memcpy(tarY+offset,ptr,32);
				dst_asm = tarY+offset;
				src_asm = ptr;
				asm volatile (
				        "vld1.8         {d0 - d3}, [%[src_asm]]              \n\t"
				        "vst1.8         {d0 - d3}, [%[dst_asm]]              \n\t"
				        : [dst_asm] "+r" (dst_asm), [src_asm] "+r" (src_asm)
				        :  //[srcY] "r" (srcY)
				        : "cc", "memory", "d0", "d1", "d2", "d3", "d4", "d5", "d6", "d16", "d17", "d18", "d19", "d20", "d21", "d22", "d23", "d24", "d28", "d29", "d30", "d31"
				        );

				ptr += 32;  //32 byte in one process.
			}
		}
        //process last macroblock of one line, gpu buf must be 16byte align or 32 byte align
        { //last mb of one line
            for(l=0;l<32;l++) {
				//first mb
				m=i*32 + l;     //line num
				n= j*32;        //byte num in one line
				offset = m*coded_width + n;
				//memcpy(tarY+offset,ptr,32);
				dst_asm = tarY+offset;
				src_asm = ptr;
                if(nWidthMatchFlag) {
    				asm volatile (
    				        "vld1.8         {d0 - d3}, [%[src_asm]]              \n\t"
    				        "vst1.8         {d0 - d3}, [%[dst_asm]]              \n\t"
    				        : [dst_asm] "+r" (dst_asm), [src_asm] "+r" (src_asm)
    				        :  //[srcY] "r" (srcY)
    				        : "cc", "memory", "d0", "d1", "d2", "d3", "d4", "d5", "d6", "d16", "d17", "d18", "d19", "d20", "d21", "d22", "d23", "d24", "d28", "d29", "d30", "d31"
    				        );
                } else{
                    asm volatile (
    				        "vld1.8         {d0,d1}, [%[src_asm]]              \n\t"
    				        "vst1.8         {d0,d1}, [%[dst_asm]]              \n\t"
    				        : [dst_asm] "+r" (dst_asm), [src_asm] "+r" (src_asm)
    				        :  //[srcY] "r" (srcY)
    				        : "cc", "memory", "d0", "d1", "d2", "d3", "d4", "d5", "d6", "d16", "d17", "d18", "d19", "d20", "d21", "d22", "d23", "d24", "d28", "d29", "d30", "d31"
    				        );
                }

				ptr += 32;  //32 byte in one process.
			}
        }
	}

    //last twomb line, we process it alone
    nLeftValidLine = coded_height - (twomb_line-1)*32;
	nLeftValidLine = nLeftValidLine < 0 ? 0 : nLeftValidLine;
    for(j=0;j<twomb_width-1;j++) {  //macroblock(32*32) number in one line
		for(l=0;l<(unsigned int)nLeftValidLine;l++) {
			//first mb
			m=i*32 + l;     //line num
			n= j*32;        //byte num in one line
			offset = m*coded_width + n;
			//memcpy(tarY+offset,ptr,32);
			dst_asm = tarY+offset;
			src_asm = ptr;
			asm volatile (
			        "vld1.8         {d0 - d3}, [%[src_asm]]              \n\t"
			        "vst1.8         {d0 - d3}, [%[dst_asm]]              \n\t"
			        : [dst_asm] "+r" (dst_asm), [src_asm] "+r" (src_asm)
			        :  //[srcY] "r" (srcY)
			        : "cc", "memory", "d0", "d1", "d2", "d3", "d4", "d5", "d6", "d16", "d17", "d18", "d19", "d20", "d21", "d22", "d23", "d24", "d28", "d29", "d30", "d31"
			        );

			ptr += 32;  //32 byte in one process.
		}
        ptr += (32-nLeftValidLine)*32;
	}

    //process last macroblock of last line, gpu buf must be 16byte align or 32 byte align
    { //last mb of last line
        for(l=0;l<(unsigned int)nLeftValidLine;l++) {
			//first mb
			m=i*32 + l;     //line num
			n= j*32;        //byte num in one line
			offset = m*coded_width + n;
			//memcpy(tarY+offset,ptr,32);
			dst_asm = tarY+offset;
			src_asm = ptr;
            if(nWidthMatchFlag) {
				asm volatile (
				        "vld1.8         {d0 - d3}, [%[src_asm]]              \n\t"
				        "vst1.8         {d0 - d3}, [%[dst_asm]]              \n\t"
				        : [dst_asm] "+r" (dst_asm), [src_asm] "+r" (src_asm)
				        :  //[srcY] "r" (srcY)
				        : "cc", "memory", "d0", "d1", "d2", "d3", "d4", "d5", "d6", "d16", "d17", "d18", "d19", "d20", "d21", "d22", "d23", "d24", "d28", "d29", "d30", "d31"
				        );
            } else{
                asm volatile (
				        "vld1.8         {d0,d1}, [%[src_asm]]              \n\t"
				        "vst1.8         {d0,d1}, [%[dst_asm]]              \n\t"
				        : [dst_asm] "+r" (dst_asm), [src_asm] "+r" (src_asm)
				        :  //[srcY] "r" (srcY)
				        : "cc", "memory", "d0", "d1", "d2", "d3", "d4", "d5", "d6", "d16", "d17", "d18", "d19", "d20", "d21", "d22", "d23", "d24", "d28", "d29", "d30", "d31"
				        );
            }

			ptr += 32;  //32 byte in one process.
		}
        ptr += (32-nLeftValidLine)*32;
    }
}

/*******************************************************************************
Function name: map32x32_to_yuv_Y
Description:
    1. we should know : vdecbuf_uv is 32*32 align too
    2. must match gpuBuf_uv size.
    3. gpuBuf_uv size is half of gpuBuf_y size
    4. we guarantee: vdecbufSize>=gpuBufSize
    5. uv's macroblock is also 16*16. Vdec_macroblock is also twomb(32*32).
    6. if coded_width is stride/2, we can support gpu_buf_width 16byte align and 8byte align!
       But need outer set right value of coded_width, must meet gpu_uv_buf_width align's request!
Parameters:
    1. mode = 0:yv12, 1:thumb yuv420p
    2. coded_width and coded_height is uv size, already half of y_size
Return:

Time: 2013/4/15
*******************************************************************************/
//#define USE_VLD2_8  1
static void map32x32_to_yuv_C(int mode, unsigned char* srcC,unsigned char* tarCb,unsigned char* tarCr,unsigned int coded_width,unsigned int coded_height)
{
	unsigned int   i,j,l,m,n;
	unsigned int   mb_width,mb_height,twomb_line,twomb_width;
	unsigned long  offset;
	unsigned char  *ptr;
	unsigned char  *dst0_asm,*dst1_asm,*src_asm;
    unsigned       vdecbuf_width; //unit: pixel
    int            nWidthMatchFlag;
    int            nLeftValidLine;  //in the bottom macroblock(32*32), the valid line is < 32.
    int            dst_stride = mode==0 ? (coded_width + 15) & (~15) : coded_width;

	ptr = srcC;

    mb_width = ((coded_width+15)&~15)>>4;   //vdec's uvBuf is 32byte align, so uBuf and vBuf is 16byte align!
	mb_height = ((coded_height+31)&~31)>>4;
	twomb_line = (mb_height+1)>>1;
	//recon_width = (mb_width+1)&0xfffffffe;
    twomb_width = mb_width; //vdec mb32 is uv interleave, so uv_32 byte == u_16byte
    if(twomb_line < 1 || twomb_width < 1)
        av_log(NULL, AV_LOG_ERROR, "map32x32_to_yuv_C() fatal error! twomb_line=%d, twomb_width=%d", twomb_line, twomb_width);
    //vdec mb32 uvBuf, one vdec_macro_block, extract u component, u's width and height.
    vdecbuf_width = twomb_width*16;
    if(vdecbuf_width > coded_width) {
        nWidthMatchFlag = 0;
        if((vdecbuf_width - coded_width) != 8)
            av_log(NULL, AV_LOG_ERROR, "fatal error! vdec_UVbuf_width=%d, gpu_UVbuf_width=%d,  the program will crash!", vdecbuf_width, coded_width);
    }
    else if(vdecbuf_width == coded_width)
        nWidthMatchFlag = 1;
    else {
        av_log(NULL, AV_LOG_WARNING, "fatal error! vdec_UVbuf_width=%d <= gpu_UVbuf_width=%d, the program will crash!", vdecbuf_width, coded_width);
        nWidthMatchFlag = 0;
    }

	for(i=0;i<twomb_line-1;i++) {
		for(j=0;j<twomb_width-1;j++) {
			for(l=0;l<32;l++) {
				//first mb
				m=i*32 + l; //line num
				n= j*16;    //byte num in dst_one_line
				offset = m*dst_stride + n;

				dst0_asm = tarCb + offset;
				dst1_asm = tarCr+offset;
				src_asm = ptr;
				asm volatile (
						"vld2.8         {d0 - d3}, [%[src_asm]]              \n\t"
						"vst1.8         {d0,d1}, [%[dst0_asm]]              \n\t"
						"vst1.8         {d2,d3}, [%[dst1_asm]]              \n\t"
						 : [dst0_asm] "+r" (dst0_asm), [dst1_asm] "+r" (dst1_asm), [src_asm] "+r" (src_asm)
						 :  //[srcY] "r" (srcY)
						 : "cc", "memory", "d0", "d1", "d2", "d3", "d4", "d5", "d6", "d16", "d17", "d18", "d19", "d20", "d21", "d22", "d23", "d24", "d28", "d29", "d30", "d31"
						 );

				ptr += 32;
			}
		}
        //process last twomb_macroblock of one line, gpu buf must be 16 byte align or 8 byte align.
        for(l=0;l<32;l++) {
			//first mb
			m=i*32 + l; //line num
			n= j*16;    //byte num in dst_one_line
			offset = m*dst_stride + n;

			dst0_asm = tarCb + offset;
			dst1_asm = tarCr+offset;
			src_asm = ptr;

            if(nWidthMatchFlag) {
                asm volatile (
                        "vld2.8         {d0 - d3}, [%[src_asm]]              \n\t"
                        "vst1.8         {d0,d1}, [%[dst0_asm]]              \n\t"
                        "vst1.8         {d2,d3}, [%[dst1_asm]]              \n\t"
                         : [dst0_asm] "+r" (dst0_asm), [dst1_asm] "+r" (dst1_asm), [src_asm] "+r" (src_asm)
                         :  //[srcY] "r" (srcY)
                         : "cc", "memory", "d0", "d1", "d2", "d3", "d4", "d5", "d6", "d16", "d17", "d18", "d19", "d20", "d21", "d22", "d23", "d24", "d28", "d29", "d30", "d31"
                         );
            } else{
                asm volatile (
                        "vld2.8         {d0,d1}, [%[src_asm]]              \n\t"
                        "vst1.8         {d0}, [%[dst0_asm]]              \n\t"
                        "vst1.8         {d1}, [%[dst1_asm]]              \n\t"
                         : [dst0_asm] "+r" (dst0_asm), [dst1_asm] "+r" (dst1_asm), [src_asm] "+r" (src_asm)
                         :  //[srcY] "r" (srcY)
                         : "cc", "memory", "d0", "d1", "d2", "d3", "d4", "d5", "d6", "d16", "d17", "d18", "d19", "d20", "d21", "d22", "d23", "d24", "d28", "d29", "d30", "d31"
                         );
            }
			ptr += 32;
		}
	}

    //last twomb line, we process it alone
    nLeftValidLine = coded_height - (twomb_line-1)*32;  //uv height can be odd number,must be very careful!
	nLeftValidLine = nLeftValidLine < 0 ? 0 : nLeftValidLine;
    for(j=0;j<twomb_width-1;j++) {  //macroblock(32*32) number in one line
		for(l=0;l< (unsigned int)nLeftValidLine;l++) {
			//first mb
			m=i*32 + l;     //line num
			n= j*16;        //byte num in dst_one_line
			offset = m*dst_stride + n;

			dst0_asm = tarCb + offset;
			dst1_asm = tarCr+offset;
			src_asm = ptr;
            asm volatile (
                    "vld2.8         {d0 - d3}, [%[src_asm]]              \n\t"
                    "vst1.8         {d0,d1}, [%[dst0_asm]]              \n\t"
                    "vst1.8         {d2,d3}, [%[dst1_asm]]              \n\t"
                     : [dst0_asm] "+r" (dst0_asm), [dst1_asm] "+r" (dst1_asm), [src_asm] "+r" (src_asm)
                     :  //[srcY] "r" (srcY)
                     : "cc", "memory", "d0", "d1", "d2", "d3", "d4", "d5", "d6", "d16", "d17", "d18", "d19", "d20", "d21", "d22", "d23", "d24", "d28", "d29", "d30", "d31"
                     );
			ptr += 32;  //32 byte in one process.
		}
        ptr += (32-nLeftValidLine)*32;
	}

    //process last macroblock of last line, gpu UVbuf must be 16byte align or 8 byte align
    { //last mb of last line
        for(l=0;l<(unsigned int)nLeftValidLine;l++) {
			//first mb
			m=i*32 + l;     //line num
			n= j*16;        //byte num in one line
			offset = m*dst_stride + n;

			dst0_asm = tarCb + offset;
			dst1_asm = tarCr+offset;
			src_asm = ptr;
            if(nWidthMatchFlag) {
                asm volatile (
                        "vld2.8         {d0 - d3}, [%[src_asm]]              \n\t"
                        "vst1.8         {d0,d1}, [%[dst0_asm]]              \n\t"
                        "vst1.8         {d2,d3}, [%[dst1_asm]]              \n\t"
                         : [dst0_asm] "+r" (dst0_asm), [dst1_asm] "+r" (dst1_asm), [src_asm] "+r" (src_asm)
                         :  //[srcY] "r" (srcY)
                         : "cc", "memory", "d0", "d1", "d2", "d3", "d4", "d5", "d6", "d16", "d17", "d18", "d19", "d20", "d21", "d22", "d23", "d24", "d28", "d29", "d30", "d31"
                         );
            } else{
                asm volatile (
                        "vld2.8         {d0,d1}, [%[src_asm]]              \n\t"
                        "vst1.8         {d0}, [%[dst0_asm]]              \n\t"
                        "vst1.8         {d1}, [%[dst1_asm]]              \n\t"
                         : [dst0_asm] "+r" (dst0_asm), [dst1_asm] "+r" (dst1_asm), [src_asm] "+r" (src_asm)
                         :  //[srcY] "r" (srcY)
                         : "cc", "memory", "d0", "d1", "d2", "d3", "d4", "d5", "d6", "d16", "d17", "d18", "d19", "d20", "d21", "d22", "d23", "d24", "d28", "d29", "d30", "d31"
                         );
            }

			ptr += 32;  //32 byte in one process.
		}
        ptr += (32-nLeftValidLine)*32;
    }
}

static void SoftwarePictureScaler(ScalerParameter *cdx_scaler_para)
{
	map32x32_to_yuv_Y((unsigned char*)cdx_scaler_para->addr_y_in,
						(unsigned char*)cdx_scaler_para->addr_y_out,
						cdx_scaler_para->width_out,
						cdx_scaler_para->height_out);

	map32x32_to_yuv_C(cdx_scaler_para->mode,
						(unsigned char*)cdx_scaler_para->addr_c_in,
						(unsigned char*)cdx_scaler_para->addr_u_out,
						(unsigned char*)cdx_scaler_para->addr_v_out,
						cdx_scaler_para->width_out / 2,
						cdx_scaler_para->height_out / 2);
}

static void TransformToYUVPlaner(VideoPicture *pict, uint8_t* ybuf, uint8_t *ubuf, uint8_t *vbuf)
{
	ScalerParameter cdx_scaler_para;
	int display_height;
	int display_width;
	int display_height_align;
	int display_width_align;

	if(pict == NULL)
		return;

	display_height = pict->nBottomOffset - pict->nTopOffset;
	display_width = pict->nRightOffset - pict->nLeftOffset;

	if (pict->nHeight &  0x01)
		av_log(NULL, AV_LOG_WARNING, "display_height[%d] is odd number!!!", pict->nHeight);

	display_height_align = (display_height + 1) & (~1);
	display_width_align  = (display_width + 15) & (~15);

	cdx_scaler_para.mode = 1;

	cdx_scaler_para.format_in  = CONVERT_COLOR_FORMAT_YUV420MB;
	cdx_scaler_para.format_out = CONVERT_COLOR_FORMAT_YUV420PLANNER;
	cdx_scaler_para.width_in   = pict->nWidth;
	cdx_scaler_para.height_in  = pict->nHeight;
	cdx_scaler_para.addr_y_in  = (void*)pict->pData0; /*y*/
	cdx_scaler_para.addr_c_in  = (void*)pict->pData1; /*uv*/
	cdx_scaler_para.width_out  = display_width_align;
	cdx_scaler_para.height_out = display_height_align;

	cdx_scaler_para.addr_y_out = (unsigned long)ybuf;

	cdx_scaler_para.addr_u_out = (unsigned long)ubuf;
	cdx_scaler_para.addr_v_out = (unsigned long)vbuf;

	//* use neon accelarator instruction to transform the pixel format, slow if buffer is not cached(DMA mode).
	SoftwarePictureScaler(&cdx_scaler_para);

	return;
}

static inline int m_get_buffer(AVCodecContext *avctx, AVFrame *frame, VideoPicture *pict)
{

	frame->linesize[0] = pict->nWidth;
	frame->linesize[1] = pict->nWidth / 2;
	frame->linesize[2] = pict->nWidth / 2;

	frame->data[0] =  MemAdapterPalloc(pict->nHeight * pict->nWidth * 3 / 2);
	frame->data[1] = frame->data[0] + pict->nHeight * pict->nWidth;
	frame->data[2] = frame->data[1] + pict->nHeight * pict->nWidth / 4;

	frame->hwaccel_picture_private = av_malloc(sizeof(*pict));
	memcpy(frame->hwaccel_picture_private, pict, sizeof(*pict));

	frame->width = avctx->width  = pict->nWidth;
	frame->height = avctx->height = pict->nHeight;

	return 0;
}

static int DecodeBlock(AVCodecContext *avctx, void *data, int *data_size, AVPacket *avpkt)
{
	CedarContext           *h = avctx->priv_data;
	AVFrame                *frame = data;
	VideoPicture           *pic;
	VideoStreamDataInfo    info;
	char                   *buf,*ringbuf;
	int                    size,ringsize;

	*data_size = 0;
retry:
	if(avpkt->data) {
		pthread_mutex_lock(&h->mutex);
		if(RequestVideoStreamBuffer(h->decoder, avpkt->size, &buf, &size, &ringbuf, &ringsize, 0) < 0) {
			av_log(avctx, AV_LOG_ERROR, "request video stream buffer failed!\n");
			pthread_cond_signal(&h->cond);
			pthread_mutex_unlock(&h->mutex);
			usleep(1000);
			goto retry;
		}
		info.nLength = avpkt->size;
		info.bIsFirstPart = 1;
		info.bIsLastPart  = 1;
		info.pData        = buf;

		if(avpkt->pts >= 0) {
			info.nPts = avpkt->pts;
			info.bValid = 1;
		} else {
			info.nPts = (int64_t)-1;
			info.bValid = 0;
		}

		if(avpkt->size <= size)
			memcpy(buf, avpkt->data, avpkt->size);
		else {
			memcpy(buf, avpkt->data, size);
			memcpy(ringbuf, avpkt->data + size, avpkt->size - size);
		}
		SubmitVideoStreamData(h->decoder, &info, 0);
        pthread_cond_signal(&h->cond);
        pthread_mutex_unlock(&h->mutex);
	}


	if(ValidPictureNum(h->decoder, 0)) {
		pic = RequestPicture(h->decoder, 0);

		m_get_buffer(avctx, frame, pic);

		TransformToYUVPlaner(pic, frame->data[0], frame->data[1], frame->data[2]);
		MemAdapterFlushCache(frame->data[0], pic->nWidth * pic->nHeight * 3 /2);
		frame->pts = pic->nPts;
		frame->pkt_pts = pic->nPts;
		frame->pkt_dts = pic->nPts;
		*data_size = sizeof(AVFrame);
		ReturnPicture(h->decoder, pic);
		av_log(NULL, AV_LOG_DEBUG, "return picture,pts:%s,pkt pts:%s\n",av_ts2str(pic->nPts),av_ts2str(avpkt->pts));
	}

	return 0;
}

static void *cedar_decode(void *arg)
{
	int ret;
	CedarContext *h = arg;

    h->running = 1;
	while (1 == h->running) {
		pthread_mutex_lock(&h->mutex);
		ret = DecodeVideoStream(h->decoder, 0, 0, 0, 0);

		if(ret == VDECODE_RESULT_NO_BITSTREAM) {
			pthread_cond_wait(&h->cond, &h->mutex);
		}
		pthread_mutex_unlock(&h->mutex);
	}

    h->running = 3;
	return NULL;
}

static av_cold int ff_cedar_decode_init(AVCodecContext *avctx)
{
	static VideoDecoder     *decoder;
    static int inited = 0;
	VideoStreamInfo info;
	VConfig         config;

    if (0 == inited)
    {
        h->decoder = CreateVideoDecoder();
        if(!h->decoder) {
            av_log(avctx, AV_LOG_ERROR, "Create video decoder failed\n");
            return AVERROR(ENOMEM);
        }

        memset(&info, 0, sizeof(info));
        memset(&config, 0, sizeof(config));
        info.nWidth = avctx->width;
        info.nHeight = avctx->height;
        info.nCodecSpecificDataLen = avctx->extradata_size;
        info.pCodecSpecificData    = (char*)avctx->extradata;
        config.eOutputPixelFormat = PIXEL_FORMAT_YUV_MB32_420;
        info.eCodecFormat = VIDEO_CODEC_FORMAT_H264;
        if(InitializeVideoDecoder(h->decoder, &info, &config) < 0) {
            av_log(avctx, AV_LOG_ERROR, "Initailize video decoder failed\n");
            return AVERROR(ENODEV);
        }

        decoder     = h->decoder;
    }
    else
    {
        h->decoder  = decoder;
    }


	avctx->pix_fmt = PIX_FMT_YUV420P;
	h->running = 1;

	pthread_mutex_init(&h->mutex, NULL);
	pthread_cond_init(&h->cond, NULL);

	if(pthread_create(&h->thread, NULL, cedar_decode, h)) {
		av_log(avctx, AV_LOG_ERROR, "create thread cedar failed\n");
		return AVERROR(ENOMEM);
	}

	inited = 1;
	av_log(avctx, AV_LOG_INFO, "libcedar decoder init success,%p,%p\n", avctx, avctx->priv_data);
	return 0;
}

static av_cold int ff_cedar_decode_end(AVCodecContext *avctx)
{
	CedarContext *h = avctx->priv_data;

    // exit decoder task
    h->running = 2;
    while (3 != h->running)
    {
        pthread_mutex_lock(&h->mutex);
        pthread_cond_signal(&h->cond);
        pthread_mutex_unlock(&h->mutex);
        usleep(10000);
    }

	pthread_mutex_destroy(&h->mutex);
	pthread_cond_destroy(&h->cond);
	ResetVideoDecoder(h->decoder);
	av_log(avctx, AV_LOG_INFO, "libcedar decoder exit success\n");
    return 0;
#if 0       /// here has a bug...
	DestroyVideoDecoder(h->decoder);
	av_log(avctx, AV_LOG_INFO, "close cedar\n");

	return 0;
#endif
}

AVCodec ff_cedar_decoder = {
	.name                  = "cedar",
	.type                  = AVMEDIA_TYPE_VIDEO,
	.id                    = CODEC_ID_H264,
	.capabilities          = CODEC_CAP_DR1 | CODEC_CAP_AUTO_THREADS | CODEC_CAP_DELAY,
	.priv_data_size        = sizeof(CedarContext),
	.init                  = ff_cedar_decode_init,
	.close                 = ff_cedar_decode_end,
	.decode                = DecodeBlock,
	.long_name             = NULL_IF_CONFIG_SMALL("H.264 / AVC / MPEG-4 AVC / MPEG-4 part 10 hardware decoder for Allwinner20"),
};
