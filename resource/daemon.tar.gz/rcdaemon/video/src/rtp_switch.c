// std & sys
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/epoll.h>
#include <sys/types.h>
#include <ctype.h>
#include <string.h>
#include <math.h>
#include <errno.h>
#include <signal.h>
#include <limits.h>
#include <unistd.h>
#include <sys/socket.h>
#include <sys/wait.h>
#include <sys/ioctl.h>
#include <sys/stat.h>
#include <sys/poll.h>
#include <sys/prctl.h>
#include <fcntl.h>
#include <sys/un.h>
#include <arpa/inet.h>
#include <pthread.h>
#include <netinet/in.h>
#include <dirent.h>
#include <sys/time.h>
#include <linux/fb.h>
#include <linux/netlink.h>
#include <sys/syscall.h>

#include "ffmpeg_config.h"
#include "libavformat/avformat.h"
#include "libavformat/rtsp.h"
#include "libavdevice/avdevice.h"
#include "libswscale/swscale.h"
#include "libswresample/swresample.h"
#include "libavutil/opt.h"
#include "libavutil/audioconvert.h"
#include "libavutil/parseutils.h"
#include "libavutil/lfg.h"
#include "libavutil/samplefmt.h"
#include "libavutil/colorspace.h"
#include "libavformat/avio_internal.h"
#include "libavutil/fifo.h"
#include "libavutil/intreadwrite.h"
#include "libavutil/dict.h"
#include "libavutil/mathematics.h"
#include "libavutil/pixdesc.h"
#include "libavutil/avstring.h"
#include "libavutil/libm.h"
#include "libavutil/imgutils.h"
#include "libavutil/timestamp.h"
#include "libavutil/bprint.h"
#include "libavutil/random_seed.h"
#include "libavformat/os_support.h"
#include "libavformat/rdt.h"
#include "libavformat/url.h"
#include "libavformat/avio.h"
#include "libavutil/avassert.h"
#include "libavformat/ffm.h" // not public API
#include "libavfilter/avcodec.h"
#include "libavfilter/avfilter.h"
#include "libavfilter/avfiltergraph.h"
#include "libavfilter/buffersrc.h"
#include "libavfilter/buffersink.h"

#include <usbmuxd.h>

#include "utils.h"
#include "common.h"

// #define RTP_SWITCH_DEBUG_DATA


static int rtp_switch_listen_fd = -1;;
static int rtp_switch_server_fd = -1;;

#ifdef RTP_SWITCH_DEBUG_DATA
static int rtp_switch_file_fd = -1;;
#endif

#ifdef RTP_SWITCH_DEBUG_DATA
/*
 * safe write
 */
int cbb_write(int fd, void *buf, int len)
{
    int ret;
    int size     = len;
    size_t offset   = 0;

repeat:
    ret = write(fd, buf + offset, size);
    if (ret < 0)
    {
        if (EINTR == errno)
        {
            goto repeat;
        }

        av_log(NULL, AV_LOG_ERROR, "write falied, fd:%d,errno:%d\n", fd, errno);
        return -1;
    }
    else if (ret < size)
    {
        size    = size - ret;
        offset  = len - size;
        goto repeat;
    }

    return 0;
}
#endif

/*
 * safe send
 */
int cbb_send(int fd, void *buf, int len)
{
    int ret;
    int size     = len;
    size_t offset   = 0;

repeat:
    ret = send(fd, buf + offset, size, MSG_NOSIGNAL);
    if (ret < 0)
    {
        if (EINTR == errno)
        {
            goto repeat;
        }

        av_log(NULL, AV_LOG_ERROR, "fd:%d send falied,errno:%d\n", fd, errno);
        return -1;
    }
    else if (ret < size)
    {
        size    = size - ret;
        offset  = len - size;
        goto repeat;
    }

    return 0;
}


void rtp_switch_write(uint8_t *buf, int len)
{
#include "libavformat/rtp.h"
#include <arpa/inet.h>
    static uint16_t last_seq;

    unsigned int ssrc;
    int payload_type, flags = 0;
    int ext, csrc;
    uint32_t timestamp;
    int mark, ret;
    uint8_t head[4];
    uint16_t pt_len = htons(len), seq;

#ifdef RTP_SWITCH_DEBUG_DATA
    ret = cbb_write(rtp_switch_file_fd, buf, len);
    if (ret < 0)
    {
        av_log(NULL, AV_LOG_ERROR, "write data failed\n");
    }
#endif

    if (-1 == rtp_switch_server_fd)
    {
        return;
    }
#if MPLAYER_CB_RTP
    if (len < 12)
        return -1;

    if ((buf[0] & 0xc0) != (RTP_VERSION << 6))
        return -1;

    if (RTP_PT_IS_RTCP(buf[1])) {
        return;
    }

    csrc            = buf[0] & 0x0f;
    ext             = buf[0] & 0x10;
    payload_type    = buf[1] & 0x7f;
    mark            = !!(buf[1] & 0x80);
    memcpy(&seq, buf + 2, 2);
    seq       = ntohs(seq);
    memcpy(&timestamp, buf + 4, 4);
    timestamp = ntohl(timestamp);
    memcpy(&ssrc, buf + 8, 4);
    ssrc      = ntohl(ssrc);

    if ((seq & 0xFF) == 0xFF)
    {
        av_log(NULL, AV_LOG_ERROR, "pt:%d,seq:%d,ts:%u,ssrc:%u,mark:%d,len:%d\n",
                    payload_type, seq, timestamp, ssrc, mark,len);
    }

    if (++last_seq != seq)
    {
        av_log(NULL, AV_LOG_ERROR, "seq not matched,last seq:%d,cur seq:%d\n", last_seq, seq);
    }

    last_seq = seq;
    head[0] = '$';
    head[1] = 0x1;
    memcpy(head + 2, &pt_len, 2);

    ret = cbb_send(rtp_switch_server_fd, head, 4);
    if (ret < 0)
    {
        av_log(NULL, AV_LOG_ERROR, "send data failed\n");
    }
#endif

    av_log(NULL, AV_LOG_ERROR, "send one frame,size:%d\n", len);
    ret = cbb_send(rtp_switch_server_fd, buf, len);
    if (ret < 0)
    {
        av_log(NULL, AV_LOG_ERROR, "send data failed\n");
    }

}


static int rtp_switch_new_connection(int server_fd)
{
    struct sockaddr_un unaddr;
    int fd, len;

    len = sizeof(unaddr);
    fd = accept(server_fd, (struct sockaddr *)&unaddr,
                (socklen_t *)&len);
    if (fd < 0) {
        av_log(NULL, AV_LOG_ERROR, "error during accept %s\n", strerror(errno));
        return -1;
    }
    ff_socket_nonblock(fd, 1);

    if (-1 != rtp_switch_server_fd)
    {
        close(rtp_switch_server_fd);
    }
    rtp_switch_server_fd  = fd;

    av_log(NULL, AV_LOG_ERROR, "rtp switch fd:%d\n");
    return 0;
}

/*
 * rtp switch server
 */
void *rtp_switch_task(void *arg)
{
    struct pollfd      *poll_table, *poll_entry;
    struct sockaddr_in my_rtsp_addr;
    int                delay, delay1, ret;
    struct sched_param tsched;
    uint16_t port       = 54540;

    av_log(NULL, AV_LOG_ERROR, "rtp_switch_task ready, arg:%p, tid:%ld\n", arg, syscall(SYS_gettid));
    ret = prctl(PR_SET_NAME, "RtpSwitchTask");
    if (0 != ret)
    {
        av_log(NULL, AV_LOG_ERROR, "set thread name failed,errno:%d\n", errno);
    }

    // poll
    if(!(poll_table = av_mallocz(2 * sizeof(*poll_table)))) {
        av_log(NULL, AV_LOG_ERROR, "Impossible to allocate a poll table handling connections.\n");
        return NULL;
    }

    for(;;) {
        poll_entry = poll_table;
        if (-1 != rtp_switch_listen_fd) {
            poll_entry->fd = rtp_switch_listen_fd;
            poll_entry->events = POLLIN;
            poll_entry++;
        }

        /* wait for an event on one connection. We poll at least every
           second to handle timeouts */
        do {
            ret = poll(poll_table, poll_entry - poll_table, 10);
            if (ret < 0 && EINTR != errno)
            {
                av_log(NULL, AV_LOG_ERROR, "rtsp_switch_task exit, fatal error, errno:%d\n", errno);
                return NULL;
            }
        } while (ret < 0);

        poll_entry = poll_table;
        if (-1 != rtp_switch_listen_fd) {
            /* new RTP switch connection request ? */
            if (poll_entry->revents & POLLIN)
                rtp_switch_new_connection(rtp_switch_listen_fd);
        }
    }

    av_log(NULL, AV_LOG_ERROR, "rtsp switch task exit\n");
    return NULL;
}

int rtp_switch_init()
{
    int ret;
    pthread_t rtp_switch_task_id;
    rtp_switch_listen_fd = unix_socket_open_listen("/var/run/usb_proxy_svr_554");
    if (rtp_switch_listen_fd < 0) {
        av_log(NULL, AV_LOG_ERROR, "listen local fd error\n");
        return -1;
    }

#ifdef RTP_SWITCH_DEBUG_DATA
#define RTP_SWITCH_TEST_FILE    "/mnt/data/local.h264"
    rtp_switch_file_fd = open(RTP_SWITCH_TEST_FILE,
                O_CREAT | O_TRUNC | O_WRONLY, S_IRUSR | S_IWUSR | S_IRGRP | S_IWGRP | S_IROTH);

    if (-1 == rtp_switch_file_fd)
    {
        av_log(NULL, AV_LOG_ERROR, "open file %d failed,errno:%d\n", RTP_SWITCH_TEST_FILE, errno);
    }
#endif

    ret = pthread_create(&rtp_switch_task_id, NULL, rtp_switch_task, NULL);
    if (0 != ret)
    {
        av_log(NULL, AV_LOG_ERROR, "rtsp switch create task failed, errno:%d\n", errno);
        return -1;
    }

    return 0;
}

