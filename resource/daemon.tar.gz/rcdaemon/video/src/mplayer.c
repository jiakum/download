// std & sys
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/epoll.h>
#include <sys/types.h>
#include <ctype.h>
#include <string.h>
#include <math.h>
#include <errno.h>
#include <signal.h>
#include <limits.h>
#include <unistd.h>
#include <sys/socket.h>
#include <sys/wait.h>
#include <sys/ioctl.h>
#include <sys/stat.h>
#include <sys/poll.h>
#include <sys/prctl.h>
#include <fcntl.h>
#include <sys/un.h>
#include <arpa/inet.h>
#include <pthread.h>
#include <netinet/in.h>
#include <dirent.h>
#include <sys/time.h>
#include <linux/fb.h>
#include <linux/netlink.h>
#include <sys/syscall.h>

#include "libavformat/avformat.h"
#include "libavcodec/avcodec.h"
#include "libavutil/timestamp.h"
#include "libavutil/opt.h"
#include "libavutil/mem.h"
#include "libavutil/avassert.h"

#include <memoryAdapter.h>
#include <sunxi_disp.h>
#include <vdecoder.h>


// prj include
#include "list.h"
#include "mplayer.h"
#include "debug.h"
#include "decoder.h"

#define MPLAYER_PACKETS_MAX (64)
#define MPLAYER_PICTURES_MAX (16)
#define MPLAYER_FRAME_MAX   (64)
//#define MPLAYER_DIRECT_DISPLAY
//

/// hdmi module lock/unlock define
#define LOCALPLAY_LOCK_DEVICE()   pthread_mutex_lock(&localplay_module_mutex)
#define LOCALPLAY_UNLOCK_DEVICE() pthread_mutex_unlock(&localplay_module_mutex)

typedef struct PacketQueue {
    AVPacketList *first_pkt, *last_pkt;
    int nb_packets;
    int size;
    int abort_request;
    pthread_mutex_t mutex;
    pthread_cond_t cond;
} PacketQueue;

typedef struct {
    AVFrame *avpic;
    int64_t   pts;
    int       count;
    int       eof;
    struct list_head list;
} MPicture;

#define MPLAYER_THREAD_EXITED   0x00000001U
#define MPLAYER_THREAD_EXITING  0x00000002U
#define MPLAYER_THREAD_RUNNING  0x00000004U

typedef struct __MPlayer__ {
    AVFormatContext *ic;
    pthread_t       rth,dth,pth;
    uint32_t        rth_run;
    uint32_t        dth_run;
    uint32_t        pth_run;

    uint32_t        rth_exit;
    uint32_t        dth_exit;
    uint32_t        pth_exit;
    int             handle;
    PacketQueue     vq;
    AVStream        *vst;
    AVFrame         frame;
    AVFrame         frame2;
    int             video_index;
    int             dimemsion_changed;

    int             fb;
    struct fb_var_screeninfo vinfo;
    int             framerate;
    int             st_index[AVMEDIA_TYPE_NB];

    struct sunxi_disp *disp;

    FLocalPlayerPktCb   avpacket_cb;            /// AVPacket callback func
    void *              avpacket_cb_context;    /// AVPacket callback user context
    FLocalPlayerEvCb    ev_cb;                  /// event callback func
    void *              ev_cb_context;          /// event callback user context
} MPlayer;

// localplayer init flag
static int g_localplay_init = 0;

// localplayer define
static MPlayer mplayer;

static pthread_mutex_t localplay_module_mutex = PTHREAD_MUTEX_INITIALIZER;
static pthread_mutex_t pic_mutex = PTHREAD_MUTEX_INITIALIZER;
static pthread_cond_t pic_cond = PTHREAD_COND_INITIALIZER;
static MPicture pictures = {
    .list = LIST_HEAD_INIT(pictures.list)
};

/*
 * dec
 */
void localplay_close_stream();

/*
 * dec
 */
void * mp_localplay_task(void *arg);

// static const char *audio_codec_name;
// static const char *video_codec_name = "cedar";

static void picture_queue_awake_all()
{
    pthread_mutex_lock(&pic_mutex);
    pthread_cond_signal(&pic_cond);
    pthread_mutex_unlock(&pic_mutex);
}

static int queue_picture(AVFrame *frame, int64_t pts)
{
    MPicture *mpic = av_mallocz(sizeof(*mpic));
    AVFrame *avpic = av_malloc(sizeof(*avpic));

    if(!mpic || !avpic) {
        av_log(NULL, AV_LOG_ERROR, "malloc MPicture failed\n");
        return AVERROR(ENOMEM);
    }
    *avpic = *frame;
    mpic->avpic = avpic;
    mpic->pts = pts;

    pthread_mutex_lock(&pic_mutex);
    if(!list_empty(&pictures.list)) {
        list_add_tail(&mpic->list, &pictures.list);
    } else
        list_add(&mpic->list, &pictures.list);
    pictures.count++;
    pthread_cond_signal(&pic_cond);
    pthread_mutex_unlock(&pic_mutex);

    return 0;
}

static AVFrame * get_picture(int64_t *pts, int block)
{
    struct list_head *list;
    MPicture *mpic;
    AVFrame *avpic;

    pthread_mutex_lock(&pic_mutex);

    if(pictures.eof) {
        pthread_mutex_unlock(&pic_mutex);
        return NULL;
    }
    else if(list_empty(&pictures.list))
    {
        if (!block)
        {
            pthread_mutex_unlock(&pic_mutex);
            return NULL;
        }

        pthread_cond_wait(&pic_cond, &pic_mutex);
        if(list_empty(&pictures.list)) {
            pthread_mutex_unlock(&pic_mutex);
            av_log(NULL, AV_LOG_INFO, "pictures empty after wait. eof got ?\n");
            return NULL;
        }
    }

    list = pictures.list.next;
    list_del(list);
    pictures.count--;
    pthread_mutex_unlock(&pic_mutex);

    mpic = list_entry(list, MPicture, list);
    avpic = mpic->avpic;
    *pts = mpic->pts;
    av_free(mpic);

    return avpic;
}

/*
 * localplay event callback function
 *@note in callback function, nother any localplay submodule API should be called
 */
static void localplay_ev_callback(TMplayerEvent *play_event)
{
    LOCALPLAY_LOCK_DEVICE();

    if (NULL != mplayer.ev_cb)
    {
        mplayer.ev_cb(play_event, mplayer.ev_cb_context);
    }

    LOCALPLAY_UNLOCK_DEVICE();
}


static int packet_queue_put_private(PacketQueue *q, AVPacket *pkt)
{
    AVPacketList *pkt1;

    if (q->abort_request)
        return -1;

    pkt1 = av_malloc(sizeof(AVPacketList));
    if (!pkt1)
        return -1;
    pkt1->pkt = *pkt;
    pkt1->next = NULL;

    if (!q->last_pkt)
        q->first_pkt = pkt1;
    else
        q->last_pkt->next = pkt1;
    q->last_pkt = pkt1;
    q->nb_packets++;
    q->size += pkt1->pkt.size + sizeof(*pkt1);
    /* XXX: should duplicate packet data in DV case */
    pthread_cond_signal(&q->cond);
    return 0;
}

static int packet_queue_put(PacketQueue *q, AVPacket *pkt)
{
    int ret;
    int t;
    struct timeval tv;

    /* duplicate the packet */
    if (av_dup_packet(pkt) < 0)
        return -1;

    gettimeofday(&tv, NULL);
    t = tv.tv_sec * 1000 + tv.tv_usec / 1000;
    av_log(NULL, AV_LOG_ERROR, ":%d,frm:%d\n", t, pkt->size);
    pthread_mutex_lock(&q->mutex);
    ret = packet_queue_put_private(q, pkt);
    pthread_mutex_unlock(&q->mutex);

    if (ret < 0)
        av_free_packet(pkt);

    return ret;
}

static void packet_queue_init(PacketQueue *q)
{
    memset(q, 0, sizeof(PacketQueue));
    pthread_mutex_init(&q->mutex, NULL);
    pthread_cond_init(&q->cond, NULL);
    q->abort_request = 1;
}

static void packet_queue_flush(PacketQueue *q)
{
    AVPacketList *pkt, *pkt1;

    pthread_mutex_lock(&q->mutex);
    for (pkt = q->first_pkt; pkt != NULL; pkt = pkt1) {
        pkt1 = pkt->next;
        av_free_packet(&pkt->pkt);
        av_freep(&pkt);
    }
    q->last_pkt = NULL;
    q->first_pkt = NULL;
    q->nb_packets = 0;
    q->size = 0;
    pthread_mutex_unlock(&q->mutex);
}

static void packet_queue_destroy(PacketQueue *q)
{
    packet_queue_flush(q);
    pthread_mutex_destroy(&q->mutex);
    pthread_cond_destroy(&q->cond);
}

static void packet_queue_start(PacketQueue *q)
{
    pthread_mutex_lock(&q->mutex);
    q->abort_request = 0;
    pthread_mutex_unlock(&q->mutex);
}

/* return < 0 if aborted, 0 if no packet and > 0 if packet.  */
static int packet_queue_get(PacketQueue *q, AVPacket *pkt, int block)
{
    AVPacketList *pkt1;
    int ret;

    pthread_mutex_lock(&q->mutex);

    for (;;) {
        if (q->abort_request) {
            ret = -1;
            break;
        }

        pkt1 = q->first_pkt;
        if (pkt1) {
            q->first_pkt = pkt1->next;
            if (!q->first_pkt)
                q->last_pkt = NULL;
            q->nb_packets--;
            q->size -= pkt1->pkt.size + sizeof(*pkt1);
            *pkt = pkt1->pkt;
            av_free(pkt1);
            ret = 1;
            break;
        } else if (!block) {
            ret = 0;
            break;
        } else {
            pthread_cond_wait(&q->cond, &q->mutex);
        }
    }
    pthread_mutex_unlock(&q->mutex);
    return ret;
}
#if 0
static void *mp_read_thread(void *arg)
{
    MPlayer *mplayer = arg;
    AVFormatContext *ic = mplayer->ic;
    AVPacket pkt;
    int ret,eof = 0;
    TMplayerEvent play_event;
    mplayer->rth_exit   = 0;

    // set name
    ret = prctl(PR_SET_NAME, "LocalReadTask");
    if (0 != ret)
    {
        av_log(NULL, AV_LOG_ERROR, "set thread name failed,errno:%d\n", errno);
    }

    while(!eof) {
        // to exit
        if (MPLAYER_THREAD_RUNNING != mplayer->rth_run)
        {
            av_log(NULL, AV_LOG_ERROR, "mplayer read task exited:%d\n", mplayer->rth_run);
            break;
        }

        if(mplayer->vq.nb_packets >= MPLAYER_PACKETS_MAX) {
            usleep(10000);
            // av_log(NULL, AV_LOG_ERROR, "mplayer read task wait for pkt comsume\n");
            continue;
        }

        ret = av_read_frame(ic, &pkt);
        if(ret < 0) {
            if(ret == AVERROR_EOF)
            {
                eof = 1;
            }
            av_log(NULL, AV_LOG_ERROR, "av_read_frame failed, ret:%d, EOF:%d\n", ret, AVERROR_EOF);
            break;
        }

        if (pkt.stream_index == mplayer->video_index) {
            packet_queue_put(&mplayer->vq, &pkt);
            av_log(NULL, AV_LOG_DEBUG, "curtime:%s, packet pts:%s, size:%d\n", av_ts2str(av_gettime()), av_ts2str(pkt.pts), pkt.size);
        } else
        {
            av_free_packet(&pkt);
        }
    }

    mplayer->rth_exit   = 1;

    // callback exit event
    play_event.ev = EPLAYER_EV_RTSP_EXIT;
    localplay_ev_callback(&play_event);

    return NULL;
}
#endif

/*
 * read frame thread
 */
void *mp_read_thread(void *arg)
{
    MPlayer *mplayer = arg;
    AVFormatContext *ic = mplayer->ic;
    AVPacket pkt;
    int ret,eof = 0;
    TMplayerEvent play_event;
    mplayer->rth_exit   = 0;

    // set name
    ret = prctl(PR_SET_NAME, "LocalReadTask");
    if (0 != ret)
    {
        av_log(NULL, AV_LOG_ERROR, "set thread name failed,errno:%d\n", errno);
    }

    while(!eof) {
        // to exit
        if (MPLAYER_THREAD_RUNNING != mplayer->rth_run)
        {
            av_log(NULL, AV_LOG_ERROR, "mplayer read task exited:%d\n", mplayer->rth_run);
            break;
        }

        if(mplayer->vq.nb_packets >= MPLAYER_PACKETS_MAX) {
            usleep(10000);
            av_log(NULL, AV_LOG_ERROR, "mplayer read task wait for pkt comsume\n");
            continue;
        }

        ret = av_read_frame(ic, &pkt);
        if(ret < 0) {
            if(ret == AVERROR_EOF)
            {
                eof = 1;
            }
            av_log(NULL, AV_LOG_ERROR, "av_read_frame failed, ret:%d, EOF:%d\n", ret, AVERROR_EOF);
            break;
        }

        if (pkt.stream_index == mplayer->video_index)
        {
            // put to dec
            rtp_switch_write(pkt.data, pkt.size);
            dec_commit_frame(&pkt);
            // av_log(NULL, AV_LOG_DEBUG, "curtime:%s, packet pts:%s, size:%d\n",
            //             av_ts2str(av_gettime()), av_ts2str(pkt.pts), pkt.size);
        }//  else
        {
            av_free_packet(&pkt);
        }
    }

    mplayer->rth_exit   = 1;

    // callback exit event
    play_event.ev = EPLAYER_EV_RTSP_EXIT;
    localplay_ev_callback(&play_event);

    return NULL;
}


#if 0
static int get_video_frame(MPlayer *is, AVFrame *frame, int64_t *pts, AVPacket *pkt)
{
    int got_picture, ret;

    if ((ret = packet_queue_get(&is->vq, pkt, 0)) < 0)
        return -1;
    else if(ret == 0)
        usleep(2000);

    avcodec_decode_video2(is->vst->codec, frame, &got_picture, pkt);

    if (got_picture) {
        *pts = av_frame_get_best_effort_timestamp(frame);
        if (*pts == (int64_t)AV_NOPTS_VALUE) {
            *pts = 0;
        }

        return 1;
    }
    else
    {
        // av_log(NULL, AV_LOG_ERROR, "push a frame, but no frame get, maybe memory leak....\n");
    }
    return 0;
}
static int get_video_frame(MPlayer *is, AVFrame *frame, int64_t *pts, AVPacket *pkt)
{
    int got_picture, ret;
    static int seq = 0;
    struct timeval tv;
    int t;

    if ((ret = packet_queue_get(&is->vq, pkt, 0)) < 0)
        return -1;
    else if(ret == 0)
    {
        usleep(2000);
        pkt->data = NULL;
    }

    // avcodec_decode_video2(is->vst->codec, frame, );
    ret = dec_decode_frame(is->vst->codec, frame, &got_picture, pkt);
#if 0
    if (!(NULL == pkt->data && 0 == got_picture))
    {
        av_log(NULL, AV_LOG_ERROR, "dec size:%d,pts:%d,got picture:%d\n", pkt->size, frame->pkt_pts, got_picture);
    }
#endif

    if (got_picture) {
        *pts = av_frame_get_best_effort_timestamp(frame);
        if (*pts == (int64_t)AV_NOPTS_VALUE) {
            *pts = 0;
        }
        frame->display_picture_number = seq++;
        gettimeofday(&tv, NULL);
        t = tv.tv_sec * 1000 + tv.tv_usec / 1000;
        av_log(NULL, AV_LOG_ERROR, "%d,size:%d,d_seq:%d\n", t, pkt->size, frame->display_picture_number);
        return 1;
    }
    return 0;
}

#endif



void *mp_decode_thread(void *arg)
{
    MPlayer *mplayer = arg;
    // AVFrame *frame = &mplayer->frame;
    TMplayerEvent play_event;
    // AVPacket pkt;
    int ret,eof = 0; // , width, height;
    struct sched_param tsched;
    // struct timeval tv;

    tsched.sched_priority = 97;
    ret = pthread_setschedparam(pthread_self(), SCHED_RR, &tsched);
    if (0 != ret)
    {
        av_log(NULL, AV_LOG_ERROR, "set thread policy failed ,errno:%d\n", ret);
    }

    // set name
    ret = prctl(PR_SET_NAME, "LocalDecTask");
    if (0 != ret)
    {
        av_log(NULL, AV_LOG_ERROR, "set thread name failed,errno:%d\n", errno);
    }

    mplayer->dth_exit   = 0;
    while(!eof) {
        // to exit
        if (MPLAYER_THREAD_RUNNING != mplayer->dth_run)
        {
            av_log(NULL, AV_LOG_ERROR, "mplayer decode task exited:%d\n", mplayer->dth_run);
            break;
        }

        dec_run();
#if 0
        tv.tv_sec = 0;
        tv.tv_usec = 10000;
        select(1, NULL, NULL, NULL, &tv);
#endif
    }

#if 0
    pictures.eof = 1;
    pthread_mutex_lock(&pic_mutex);
    pthread_cond_signal(&pic_cond);
    pthread_mutex_unlock(&pic_mutex);

#endif
    // avcodec_flush_buffers(mplayer->vst->codec);

    // set exit flat
    mplayer->dth_exit   = 1;

    // callback exit event
    play_event.ev = EPLAYER_EV_RTSP_EXIT;
    localplay_ev_callback(&play_event);

    return NULL;
}

#if 0
static void *mp_decode_thread(void *arg)
{
    MPlayer *mplayer = arg;
    AVFrame *frame = &mplayer->frame;
    TMplayerEvent play_event;
    AVPacket pkt;
    int64_t pts_int = AV_NOPTS_VALUE;
    double pts;
    int ret,eof = 0, width, height;
    struct sched_param tsched;

    tsched.sched_priority = 99;
    ret = pthread_setschedparam(pthread_self(), SCHED_FIFO, &tsched);
    if (0 != ret)
    {
        av_log(NULL, AV_LOG_ERROR, "set thread policy failed ,errno:%d\n", ret);
    }

    // set name
    ret = prctl(PR_SET_NAME, "LocalDecTask");
    if (0 != ret)
    {
        av_log(NULL, AV_LOG_ERROR, "set thread name failed,errno:%d\n", errno);
    }

    mplayer->dth_exit   = 0;
    while(!eof) {
        // to exit
        if (MPLAYER_THREAD_RUNNING != mplayer->dth_run)
        {
            av_log(NULL, AV_LOG_ERROR, "mplayer decode task exited:%d\n", mplayer->dth_run);
            break;
        }

        if(*(volatile int*)(&pictures.count) >= MPLAYER_PICTURES_MAX) {
            usleep(1000 * 10);
            continue;
        }

        width = frame->width, height = frame->height;
        ret = get_video_frame(mplayer, frame, &pts_int, &pkt);
        if(ret < 0)
        {
            av_log(NULL, AV_LOG_ERROR, "localplay decode thread get frame, return null, sleep 10ms\n");
            // usleep(10000);
            continue;
        }

        av_free_packet(&pkt);
        if(ret == 0)
            continue;

        pts = pts_int * av_q2d(mplayer->vst->time_base);
        pts_int = (int64_t)(pts * (double)1000 * (double)1000);
        // av_log(NULL, AV_LOG_DEBUG, "curtime:%s, get the correct pts_int:%s\n", av_ts2str(av_gettime()), av_ts2str(pts_int));
        if(width != frame->width || height != frame->height)
            mplayer->dimemsion_changed = 1;
        queue_picture(frame, pts_int);
    }

#if 0
    pictures.eof = 1;
    pthread_mutex_lock(&pic_mutex);
    pthread_cond_signal(&pic_cond);
    pthread_mutex_unlock(&pic_mutex);

#endif
    // avcodec_flush_buffers(mplayer->vst->codec);

    // set exit flat
    mplayer->dth_exit   = 1;

    // callback exit event
    play_event.ev = EPLAYER_EV_RTSP_EXIT;
    localplay_ev_callback(&play_event);

    return NULL;
}
#endif

int check_stream_specifier(AVFormatContext *s, AVStream *st, const char *spec)
{
    if (*spec <= '9' && *spec >= '0') /* opt:index */
        return strtol(spec, NULL, 0) == st->index;
    else if (*spec == 'v' || *spec == 'a' || *spec == 's' || *spec == 'd' ||
             *spec == 't') { /* opt:[vasdt] */
        enum AVMediaType type;

        switch (*spec++) {
        case 'v': type = AVMEDIA_TYPE_VIDEO;      break;
        case 'a': type = AVMEDIA_TYPE_AUDIO;      break;
        case 's': type = AVMEDIA_TYPE_SUBTITLE;   break;
        case 'd': type = AVMEDIA_TYPE_DATA;       break;
        case 't': type = AVMEDIA_TYPE_ATTACHMENT; break;
        default:  av_assert0(0);
        }
        if (type != st->codec->codec_type)
            return 0;
        if (*spec++ == ':') { /* possibly followed by :index */
            int index = strtol(spec, NULL, 0);
            unsigned int i;
            for (i = 0; i < s->nb_streams; i++)
                if (s->streams[i]->codec->codec_type == type && index-- == 0)
                   return (int)i == st->index;
            return 0;
        }
        return 1;
    } else if (*spec == 'p' && *(spec + 1) == ':') {
        int prog_id;
        unsigned int i, j;
        char *endptr;
        spec += 2;
        prog_id = strtol(spec, &endptr, 0);
        for (i = 0; i < s->nb_programs; i++) {
            if (s->programs[i]->id != prog_id)
                continue;

            if (*endptr++ == ':') {
                int stream_idx = strtol(endptr, NULL, 0);
                return stream_idx >= 0 &&
                    (unsigned int)stream_idx < s->programs[i]->nb_stream_indexes &&
                    (unsigned int)st->index == s->programs[i]->stream_index[stream_idx];
            }

            for (j = 0; j < s->programs[i]->nb_stream_indexes; j++)
                if ((unsigned int)st->index == s->programs[i]->stream_index[j])
                    return 1;
        }
        return 0;
    } else if (*spec == '#') {
        int sid;
        char *endptr;
        sid = strtol(spec + 1, &endptr, 0);
        if (!*endptr)
            return st->id == sid;
    } else if (!*spec) /* empty specifier, matches everything */
        return 1;

    av_log(s, AV_LOG_ERROR, "Invalid stream specifier: %s.\n", spec);
    return AVERROR(EINVAL);
}

AVDictionary *filter_codec_opts(AVDictionary *opts, AVCodec *codec,
                                AVFormatContext *s, AVStream *st)
{
    AVDictionary    *ret = NULL;
    AVDictionaryEntry *t = NULL;
    int            flags = s->oformat ? AV_OPT_FLAG_ENCODING_PARAM
                                      : AV_OPT_FLAG_DECODING_PARAM;
    char          prefix = 0;
    const AVClass    *cc = avcodec_get_class();

    if (!codec)
        return NULL;

    switch (codec->type) {
    case AVMEDIA_TYPE_VIDEO:
        prefix  = 'v';
        flags  |= AV_OPT_FLAG_VIDEO_PARAM;
        break;
    case AVMEDIA_TYPE_AUDIO:
        prefix  = 'a';
        flags  |= AV_OPT_FLAG_AUDIO_PARAM;
        break;
    case AVMEDIA_TYPE_SUBTITLE:
        prefix  = 's';
        flags  |= AV_OPT_FLAG_SUBTITLE_PARAM;
        break;
    default:
        return NULL;
    }

    while ((t = av_dict_get(opts, "", t, AV_DICT_IGNORE_SUFFIX))) {
        char *p = strchr(t->key, ':');

        /* check stream specification in opt name */
        if (p)
            switch (check_stream_specifier(s, st, p + 1)) {
            case  1: *p = 0; break;
            case  0:         continue;
            default:         return NULL;
            }

        if (av_opt_find(&cc, t->key, NULL, flags, AV_OPT_SEARCH_FAKE_OBJ) ||
            (codec && codec->priv_class &&
             av_opt_find(&codec->priv_class, t->key, NULL, flags,
                         AV_OPT_SEARCH_FAKE_OBJ)))
            av_dict_set(&ret, t->key, t->value, 0);
        else if (t->key[0] == prefix &&
                 av_opt_find(&cc, t->key + 1, NULL, flags,
                             AV_OPT_SEARCH_FAKE_OBJ))
            av_dict_set(&ret, t->key + 1, t->value, 0);

        if (p)
            *p = ':';
    }
    return ret;
}

AVDictionary *format_opts, *codec_opts;
AVCodecContext *avctx;
/* open a given stream. Return 0 if OK */
static int stream_component_open(MPlayer *mplayer)
{
    AVFormatContext *ic = mplayer->ic;
    // AVCodecContext *avctx;
    AVFrame *frame = &mplayer->frame;
    AVFrame *frame2 = &mplayer->frame2;
    // AVCodec *codec;
    AVDictionary *opts;
    AVDictionaryEntry *t = NULL;
    int stream_index;
    int ret;

    stream_index = mplayer->st_index[AVMEDIA_TYPE_VIDEO];
    if (stream_index < 0 || stream_index >= (int)ic->nb_streams)
    {
        return -1;
    }

    avctx = ic->streams[stream_index]->codec;

    if ((t = av_dict_get(opts, "", NULL, AV_DICT_IGNORE_SUFFIX))) {
        av_log(NULL, AV_LOG_ERROR, "Option %s not found.\n", t->key);
        return AVERROR_OPTION_NOT_FOUND;
    }

    packet_queue_start(&mplayer->vq);
    mplayer->vst = ic->streams[stream_index];
    mplayer->video_index = stream_index;
    if ((0 == avctx->width) && (avctx->width == avctx->height))
    {
        avctx->width    = 1280;
        avctx->height   = 720;
    }

    av_log(NULL, AV_LOG_DEBUG, "timebase den:%d, num:%d\n", mplayer->vst->time_base.den, mplayer->vst->time_base.num);
    if(avctx->width && avctx->height) {
        frame->linesize[0] = avctx->width;
        frame->linesize[1] = avctx->width / 2;
        frame->linesize[2] = avctx->width / 2;

        frame->data[0] =  MemAdapterPalloc(avctx->height * avctx->width * 3 / 2);
        frame->data[1] = frame->data[0] + avctx->height * avctx->width;
        frame->data[2] = frame->data[1] + avctx->height * avctx->width / 4;
        frame->hwaccel_picture_private  = av_malloc(sizeof(struct VIDEOPICTURE));

        frame2->linesize[0] = avctx->width;
        frame2->linesize[1] = avctx->width / 2;
        frame2->linesize[2] = avctx->width / 2;

        frame2->data[0] =  MemAdapterPalloc(avctx->height * avctx->width * 3 / 2);
        frame2->data[1] = frame2->data[0] + avctx->height * avctx->width;
        frame2->data[2] = frame2->data[1] + avctx->height * avctx->width / 4;
        frame2->hwaccel_picture_private  = av_malloc(sizeof(struct VIDEOPICTURE));
    }

    // init decoder
    ret = dec_init(avctx);
    if (ret < 0)
    {
        av_log(NULL, AV_LOG_ERROR, "init decoder failed\n");
        return  -1;
    }

    // create read/decode/display thread
    mplayer->rth_run    = MPLAYER_THREAD_RUNNING;
    mplayer->dth_run    = MPLAYER_THREAD_RUNNING;
    mplayer->pth_run    = MPLAYER_THREAD_RUNNING;
    ret = pthread_create(&mplayer->rth, NULL, mp_read_thread, mplayer);
    if (0 != ret)
    {
        av_log(NULL, AV_LOG_ERROR, "localplayer read thread failed,fatal error:%d\n", ret);
        return -1;
    }

    ret = pthread_create(&mplayer->dth, NULL, mp_decode_thread, mplayer);
    if (0 != ret)
    {
        av_log(NULL, AV_LOG_ERROR, "localplayer decode thread failed,fatal error:%d\n", ret);
        return -1;
    }

    ret = pthread_create(&mplayer->pth, NULL, mp_localplay_task, &mplayer);
    if (0 != ret)
    {
        av_log(NULL, AV_LOG_ERROR, "localplayer display thread failed,fatal error:%d\n", ret);
        return -1;
    }

    return 0;
}
#if 0
typedef struct output_surface_ctx_struct
{
	video_surface_ctx_t *vs;
	yuv_data_t *yuv;
	VdpRect video_src_rect, video_dst_rect;
} output_surface_ctx_t;
#endif

static AVFrame *lastpic = NULL;
int Display(MPlayer *mplayer, AVFrame *avpic)
{
    VideoPicture   *vp = avpic->hwaccel_picture_private;
    output_surface_ctx_t out;
    video_surface_ctx_t vs;
    yuv_data_t yuv;
    cedrus_mem_t data;
    // struct timeval tv;
    // int t;

    if(vp) {
        // memset(&out, 0, sizeof(out));
        out.video_src_rect.x0 = vp->nLeftOffset;
        out.video_src_rect.x1 = vp->nRightOffset;
        out.video_src_rect.y0 = vp->nTopOffset;
        out.video_src_rect.y1 = vp->nBottomOffset;

        out.video_dst_rect.x1 = vp->nRightOffset - vp->nLeftOffset;
        out.video_dst_rect.y1 = vp->nBottomOffset - vp->nTopOffset;
        out.video_dst_rect.x0 = 0; // vp->nRightOffset - vp->nLeftOffset;
        out.video_dst_rect.y0 = 0; // vp->nBottomOffset - vp->nTopOffset;

        vs.width = vp->nRightOffset - vp->nLeftOffset;
        vs.height = vp->nBottomOffset - vp->nTopOffset;
        vs.source_format = INTERNAL_YCBCR_FORMAT;
        vs.luma_size = avpic->linesize[0] * vp->nHeight;
        vs.chroma_size = avpic->linesize[1] * vp->nHeight;

        data.virt = avpic->data[0];
        data.phys = (unsigned long)MemAdapterGetPhysicAddress(data.virt);
        data.size = vs.luma_size + vs.chroma_size;
        yuv.data  = &data;
        yuv.ref_count = 1;
        out.vs = &vs; out.yuv = &yuv;

        mplayer->disp->set_video_layer(mplayer->disp, 0, 0, vp->nRightOffset - vp->nLeftOffset,
                    vp->nBottomOffset - vp->nTopOffset, &out);
        // mplayer->framerate = vp->nFrameRate;
        // av_log(NULL, AV_LOG_DEBUG, "curtime:%s, pic pts:%s\n", av_ts2str(av_gettime()), av_ts2str(vp->nPts));
    }

    ioctl(mplayer->fb, FBIOPAN_DISPLAY, &mplayer->vinfo);
#if 0
    // gettimeofday(&tv, NULL);
    // t = tv.tv_sec * 1000 + tv.tv_usec / 1000;
    // av_log(NULL, AV_LOG_ERROR, "%d d_seq:%d\n", t, avpic->display_picture_number);
    if (lastpic)
    {
       //  MemAdapterPfree(lastpic->data[0]);
        // av_free(lastpic->hwaccel_picture_private);
        // av_free(lastpic);
    }
    lastpic = avpic;
#endif

    return 0;
}

static struct sunxi_disp *sdisp;
static void close_libcedarx(int sig)
{
    sdisp->close_video_layer(sdisp);
    sdisp->close(sdisp);
    av_log(NULL, AV_LOG_INFO, "catch signal :%d\n", sig);
    exit(0);
}

static int vs_index;
void localplay_rtp_data_cb(void *context, int stream_index,  uint8_t *buf, int len)
{
    if (vs_index == stream_index)
    {
        rtp_switch_write(buf, len);
    }
}


AVFormatContext *localplay_get_avformatcontext(int handle)
{
    av_log(NULL, AV_LOG_ERROR, "localplay get avformatcontext:%d\n", handle);
    return mplayer.ic;
}

// open rtsp stream,if success,return handle
int localplay_open_stream(int *handle, char *pszUrl)
{
    int *st_index, ret;
    AVFormatContext *ic = NULL;

    LOCALPLAY_LOCK_DEVICE();
    st_index = (int*)&(mplayer.st_index);
    memset(st_index, -1, sizeof(mplayer.st_index));
    ret = avformat_open_input(&ic, pszUrl, NULL, NULL);
    if(ret < 0) {
        av_log(NULL, AV_LOG_ERROR, "failed to open %s, ret:%d\n", pszUrl, ret);
        LOCALPLAY_UNLOCK_DEVICE();
        return -1;
    }
    mplayer.ic = ic;
    // ic->rtp_data_cb         = localplay_rtp_data_cb;
    // ic->rtp_data_cb_context = &mplayer;
    st_index[AVMEDIA_TYPE_VIDEO] = av_find_best_stream(ic, AVMEDIA_TYPE_VIDEO, -1, -1, NULL, 0);
    st_index[AVMEDIA_TYPE_AUDIO] = av_find_best_stream(ic, AVMEDIA_TYPE_AUDIO, -1, -1, NULL, 0);
    vs_index = st_index[AVMEDIA_TYPE_VIDEO];

    ret = stream_component_open(&mplayer);
    if (ret < 0)
    {
        av_log(NULL, AV_LOG_ERROR, "stream_component_open failed, ret:%d\n", ret);
        LOCALPLAY_UNLOCK_DEVICE();
        return -1;
    }

    if (NULL != handle)
    {
        *handle = 1;
    }
    mplayer.handle = 1;
    LOCALPLAY_UNLOCK_DEVICE();

    return 0;
}

// set AVPacket callback
int localplay_set_pkt_callback(int handle, FLocalPlayerPktCb pfavpacket_cb, void *context)
{
    av_log(NULL, AV_LOG_ERROR, "localplay set pkt callback,handle:%d\n", handle);
    mplayer.avpacket_cb         = pfavpacket_cb;
    mplayer.avpacket_cb_context = context;

    return 0;
}

/*
 * set event callback,unset with  pfavpacket_cb set to NULL
 */
int localplay_set_ev_callback(int handle, FLocalPlayerEvCb pfev_cb, void *context)
{
    av_log(NULL, AV_LOG_ERROR, "localplay set ev callback:%p,handle:%d\n", pfev_cb, handle);
    mplayer.ev_cb         = pfev_cb;
    mplayer.ev_cb_context = context;

    return 0;
}

/*
 * close cur play stream
 */
void localplay_close_stream()
{
    LOCALPLAY_LOCK_DEVICE();

    if (0 == mplayer.handle)
    {
        LOCALPLAY_UNLOCK_DEVICE();
        return;
    }

    mplayer.rth_run   |= MPLAYER_THREAD_EXITING;
    mplayer.dth_run   |= MPLAYER_THREAD_EXITING;

    av_log(NULL, AV_LOG_ERROR, "func:%s line:%d\n", __FUNCTION__, __LINE__);
    while ( (1 != mplayer.rth_exit) || (1 != mplayer.dth_exit) )
    {
        usleep(10000);
        dec_exit_task();
    }

    av_log(NULL, AV_LOG_ERROR, "func:%s line:%d\n", __FUNCTION__, __LINE__);
    mplayer.pth_run   |= MPLAYER_THREAD_EXITING;
    while (1 != mplayer.pth_exit)
    {
        av_log(NULL, AV_LOG_ERROR, "awake present thread\n");
        usleep(10000);
        dec_exit_task();
    }

    if (mplayer.frame.data[0])
    {
        MemAdapterPfree(mplayer.frame.data[0]);
        mplayer.frame.data[0] = NULL;
    }

    if (mplayer.frame2.data[0])
    {
        MemAdapterPfree(mplayer.frame2.data[0]);
        mplayer.frame2.data[0] = NULL;
    }

    if (mplayer.frame.hwaccel_picture_private)
    {
        av_free(mplayer.frame.hwaccel_picture_private);
        mplayer.frame.hwaccel_picture_private = NULL;
    }

    if (mplayer.frame2.hwaccel_picture_private)
    {
        av_free(mplayer.frame2.hwaccel_picture_private);
        mplayer.frame2.hwaccel_picture_private = NULL;
    }

    av_log(NULL, AV_LOG_ERROR, "func:%s line:%d\n", __FUNCTION__, __LINE__);
    mplayer.rth = -1;
    mplayer.dth = -1;
    mplayer.pth = -1;
    avcodec_close(avctx);
    avformat_close_input(&mplayer.ic);
    MemAdapterPfree(mplayer.frame.data[0]);
    packet_queue_flush(&mplayer.vq);
    mplayer.handle = 0;

    LOCALPLAY_UNLOCK_DEVICE();
}


// init mplay
extern AVCodec ff_cedar_decoder;
int localplay_init()
{
    LOCALPLAY_LOCK_DEVICE();
    if (g_localplay_init > 0)
    {
        LOCALPLAY_UNLOCK_DEVICE();
        return 0;
    }

    // avcodec_register(&ff_cedar_decoder);
    debug_init();

    // init player
    memset(&mplayer, 0, sizeof(mplayer));

    if (!(sdisp = mplayer.disp = sunxi_disp2_open(0))) {
        av_log(NULL, AV_LOG_ERROR, "libcedarx_display_open failed\n");
        LOCALPLAY_UNLOCK_DEVICE();
        return -1;;
    }

    mplayer.framerate = 50;
    mplayer.fb = open("/dev/fb0", O_RDWR);
    ioctl(mplayer.fb, FBIOGET_VSCREENINFO, &mplayer.vinfo);

    g_localplay_init = 1;
    LOCALPLAY_UNLOCK_DEVICE();
    return 0;
}

// uninit mplay
void localplay_uninit()
{
    LOCALPLAY_LOCK_DEVICE();
    if (g_localplay_init > 0)
    {
        g_localplay_init = 0;
        packet_queue_destroy(&mplayer.vq);
    }
    LOCALPLAY_UNLOCK_DEVICE();
}


/*
 * local play task
 */
void *mp_localplay_task(void *arg)
{
    // AVFrame *avpic;
    // int64_t pts, startpts = AV_NOPTS_VALUE,curtime, lasttime, starttime;
    // int sleeptime = 0;
    TMplayerEvent play_event;
    int ret;
    struct sched_param tsched;
    pthread_attr_t attr;
    AVFrame *frame = &mplayer.frame;
    // struct timeval tv;

    int got_size;

    pthread_attr_init(&attr);
    pthread_attr_setscope(&attr, PTHREAD_SCOPE_SYSTEM);

    tsched.sched_priority = 98;
    ret = pthread_setschedparam(pthread_self(), SCHED_RR, &tsched);
    if (0 != ret)
    {
        av_log(NULL, AV_LOG_ERROR, "set thread policy failed ,errno:%d\n", ret);
    }

    // set name
    ret = prctl(PR_SET_NAME, "LocalDisplay");
    if (0 != ret)
    {
        av_log(NULL, AV_LOG_ERROR, "set thread name failed,errno:%d\n", errno);
    }

    av_log(NULL, AV_LOG_ERROR, "LocalDisplay task,arg:%p, tid:%ld\n", arg, syscall(SYS_gettid));
    // curtime = av_gettime();
    // starttime = curtime;
    // sleeptime = 0;

    // Display(&mplayer, &mplayer.frame);
    mplayer.pth_exit   = 0;
    while(1)
    {
        // to exit
        if (MPLAYER_THREAD_RUNNING != mplayer.pth_run)
        {
            av_log(NULL, AV_LOG_ERROR, "mplayer display task exited:%d\n", mplayer.pth_run);
            break;
        }
#if 0
        avpic = get_picture(&pts, 1);
        if (NULL == avpic)
        {
            av_log(NULL, AV_LOG_ERROR, "localplay display thread get picture, return null, sleep 10ms\n");
            usleep(10000);
            continue;
        }
#endif
        if (frame->data[0])
        {
            MemAdapterPfree(frame->data[0]);
            frame->data[0] = NULL;
        }
#if 0
        if (frame->hwaccel_picture_private)
        {
            av_free(frame->hwaccel_picture_private);
            frame->hwaccel_picture_private = NULL;
        }
#endif

        ret = dec_get_picture(avctx, frame, &got_size);

        if (0 != got_size)
        {
            Display(&mplayer, frame);
            // usleep(10000);

            if (frame == &mplayer.frame)
            {
                frame = &mplayer.frame2;
            }
            else
            {
                frame = &mplayer.frame;
            }
        }
        else
        {
#if 0
            tv.tv_sec = 0;
            tv.tv_usec = 10000;
            select(1, NULL, NULL, NULL, &tv);
#endif
        }
#if 0
        if(startpts == (int64_t)AV_NOPTS_VALUE) {
            curtime = av_gettime();
            startpts = pts;
            starttime = curtime;
        }
#endif
    }
#if 0
    /// release last resource
    while(NULL != (avpic = get_picture(&pts, 0)))
    {
        Display(&mplayer, avpic);
    }

    if (lastpic)
    {
        MemAdapterPfree(lastpic->data[0]);
        av_free(lastpic->hwaccel_picture_private);
        av_free(lastpic);
    }
    lastpic = NULL;
#endif

    // set exit flat
    mplayer.pth_exit   = 1;

    // callback exit event
    play_event.ev = EPLAYER_EV_RTSP_EXIT;
    localplay_ev_callback(&play_event);

    return 0;
}

#if 0
// local play task
static void * mp_localplay_task(void *arg)
{
    AVFrame *avpic;
    int64_t pts, startpts = AV_NOPTS_VALUE,curtime, lasttime, starttime;
    int sleeptime = 0;
    TMplayerEvent play_event;
    int ret;
    struct sched_param tsched;
    pthread_attr_t attr;

    pthread_attr_init(&attr);
    pthread_attr_setscope(&attr, PTHREAD_SCOPE_SYSTEM);

    tsched.sched_priority = 98;
    ret = pthread_setschedparam(pthread_self(), SCHED_RR, &tsched);
    if (0 != ret)
    {
        av_log(NULL, AV_LOG_ERROR, "set thread policy failed ,errno:%d\n", ret);
    }

    // set name
    ret = prctl(PR_SET_NAME, "LocalDisplay");
    if (0 != ret)
    {
        av_log(NULL, AV_LOG_ERROR, "set thread name failed,errno:%d\n", errno);
    }

    av_log(NULL, AV_LOG_ERROR, "localplay play task,arg:%p, tid:%d\n", arg, syscall(SYS_gettid));
    curtime = av_gettime();
    starttime = curtime;
    sleeptime = 0;

    // Display(&mplayer, &mplayer.frame);
    mplayer.pth_exit   = 0;
    while(1)
    {
        // to exit
        if (MPLAYER_THREAD_RUNNING != mplayer.pth_run)
        {
            av_log(NULL, AV_LOG_ERROR, "mplayer display task exited:%d\n", mplayer.pth_run);
            break;
        }

        avpic = get_picture(&pts, 1);
        if (NULL == avpic)
        {
            av_log(NULL, AV_LOG_ERROR, "localplay display thread get picture, return null, sleep 10ms\n");
            usleep(10000);
            continue;
        }

#if 0
        if(startpts != (int64_t)AV_NOPTS_VALUE) {
            curtime = av_gettime();
            sleeptime = pts - startpts - (curtime - starttime);
        }
        if(sleeptime > 10000) {
            if (sleeptime > 100000)
            {
                sleeptime = 40000;  // 25fps
            }

            // av_log(NULL, AV_LOG_ERROR, "starttime:%s,sleeptime:%d\n", av_ts2str(starttime), sleeptime);
            usleep(sleeptime);
        }
#endif

        Display(&mplayer, avpic);

        if(startpts == (int64_t)AV_NOPTS_VALUE) {
            curtime = av_gettime();
            startpts = pts;
            starttime = curtime;
        }
    }

    /// release last resource
    while(NULL != (avpic = get_picture(&pts, 0)))
    {
        Display(&mplayer, avpic);
    }

    if (lastpic)
    {
        MemAdapterPfree(lastpic->data[0]);
        av_free(lastpic->hwaccel_picture_private);
        av_free(lastpic);
    }
    lastpic = NULL;

    // set exit flat
    mplayer.pth_exit   = 1;

    // callback exit event
    play_event.ev = EPLAYER_EV_RTSP_EXIT;
    localplay_ev_callback(&play_event);

    return 0;
}
#endif
