// std & sys
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/epoll.h>
#include <sys/types.h>
#include <ctype.h>
#include <string.h>
#include <math.h>
#include <errno.h>
#include <signal.h>
#include <limits.h>
#include <unistd.h>
#include <sys/socket.h>
#include <sys/wait.h>
#include <sys/ioctl.h>
#include <sys/stat.h>
#include <sys/poll.h>
#include <sys/prctl.h>
#include <fcntl.h>
#include <sys/un.h>
#include <arpa/inet.h>
#include <pthread.h>
#include <netinet/in.h>
#include <dirent.h>
#include <sys/time.h>
#include <linux/fb.h>
#include <linux/netlink.h>
#include <sys/syslog.h>

// ffmpeg head
#include "libavformat/avformat.h"

// prj include
#include "video_common.h"
#include "hdmi.h"

#define UEVENT_MSG_LEN      4096
#define HDMI_EPOLL_SIZE     2

/// task running state
#define HDMI_TASK_EXITING    0
#define HDMI_TASK_RUNNING    1

/// hdmi module lock/unlock define
#define HDMI_LOCK_DEVICE()   pthread_mutex_lock(&hdmi_mutex)
#define HDMI_UNLOCK_DEVICE() pthread_mutex_unlock(&hdmi_mutex)

/// hdmi msg type collection
#define HDMI_MSG_ACTION_CHANGE  0x00000001U
#define HDMI_MSG_SYSTEM_SWITCH  0x00000002U
#define HDMI_MSG_SWITCH_HDMI    0x00000004U
#define HDMI_MSG_SWITCH_STATE   0x00000010U
#define HDMI_MSG_HDMI_DECTED  (HDMI_MSG_ACTION_CHANGE | HDMI_MSG_SYSTEM_SWITCH | HDMI_MSG_SWITCH_HDMI | HDMI_MSG_SWITCH_STATE)

/*
 * hdmi msg from kernel
 */
struct HdmiUeventMsg{
    const char *action;
    const char *path;
    const char *subsystem;
    const char *switch_state;
};

static struct HdmiDev
{
    int             id;         /// reserved,for ext
    int             fd;         /// socket fd,recv msg from kernel
    EHotPlugStatus  dev_status; /// disconnected or connected, @EHOT_PLUG_DISCONNECT @EHOT_PLUG_CONNECTED
    char            msg[UEVENT_MSG_LEN+2];
}hdmi_dev = {0, -1, EHOT_PLUG_DISCONNECT, {0}};

static struct HdmiModuleInfo
{
    int             module_inited;
    pthread_t       task_id;
    int             task_state;         /// task state,@WPA_TASK_EXITING @WPA_TASK_RUNNING
    FHdmiCallBack   callback;
    void            *context;
}hdmi_module_info = {0, 0, 0, NULL, NULL};

/*
 * global lock for module api
 */
static pthread_mutex_t hdmi_mutex    = PTHREAD_MUTEX_INITIALIZER;

/*
 * dec
 */
static void hdmi_parse_msg(char *msg);

/*
 * dec
 */
static void hdmi_recv_msg(struct epoll_event *ev, int size);

static int hdmi_open_nlsocket(void)
{
    struct sockaddr_nl addr;
    int sz = 64 * 1024;
    int fd, ret;

    memset(&addr, 0, sizeof(addr));
    addr.nl_family = AF_NETLINK;
    addr.nl_pid = getpid();
    addr.nl_groups = 0xffffffff;

    fd = socket(PF_NETLINK, SOCK_DGRAM, NETLINK_KOBJECT_UEVENT);
    if (fd < 0)
    {
        av_log(NULL, AV_LOG_ERROR, "create netlink socket failed:%d\n", errno);
        return -1;
    }

    ret = setsockopt(fd, SOL_SOCKET, SO_RCVBUFFORCE, &sz, sizeof(sz));
    if (ret < 0)
    {
        av_log(NULL, AV_LOG_ERROR, "set socket recv buf size failed:%d\n", errno);
    }

    ret = bind(fd, (struct sockaddr *) &addr, sizeof(addr));
    if (ret < 0)
    {
        av_log(NULL, AV_LOG_ERROR, "bind socket fialed:%d\n", errno);
        close(fd);
        return -1;
    }

    return fd;
}

/*
 * hdmi task
 */
static void *hdmi_task(void *arg)
{
    int ret;
    struct epoll_event ev;
    int timeout = 100;
    int ep_fd;

    av_log(NULL, AV_LOG_ERROR, "hdmi_task in param:%p\n", arg);
    struct epoll_event* ep_ev = (struct epoll_event*)malloc(sizeof(struct epoll_event) * HDMI_EPOLL_SIZE);
    if (ep_ev == NULL)
    {
        av_log(NULL, AV_LOG_ERROR, "malloc failed\n");
        return (void *)1;
    }
    memset(ep_ev, 0, sizeof(struct epoll_event) * HDMI_EPOLL_SIZE);

    // create epoll
    ep_fd = epoll_create1(EPOLL_CLOEXEC);
    if (ep_fd < 0)
    {
        av_log(NULL, AV_LOG_ERROR, "epoll_create1 failed, errno:%d\n", errno);
        return (void *)1;
    }

    // add dev fd
    ev.events   = EPOLLIN;
    ev.data.fd  = hdmi_dev.fd;
    ret = epoll_ctl(ep_fd, EPOLL_CTL_ADD, hdmi_dev.fd, &ev);
    if (ret < 0)
    {
        av_log(NULL, AV_LOG_ERROR, "epoll_ctl failed, errno:%d\n", errno);
        return (void *)1;
    }

    // infinite
    for(;;)
    {
        // if need to exit
        if (HDMI_TASK_RUNNING != hdmi_module_info.task_state)
        {
            break;
        }

        // wait for coming cmd
        ret = epoll_wait(ep_fd, ep_ev, HDMI_EPOLL_SIZE, timeout);
        if (ret < 0)
        {
            if (errno == EINTR)
            {
                /// ...
                /// cal time
                av_log(NULL, AV_LOG_ERROR, "epoll_wait exit by INTR\n");
                continue;
            }

            av_log(NULL, AV_LOG_ERROR, "hdmi epoll exit,sys error:%d\n", errno);
            break;
        }
        else if (ret > 0)
        {
            hdmi_recv_msg(ep_ev, ret);
        }

        timeout = 100;
    }

    // free mem
    SAFE_FREE(ep_ev);

    av_log(NULL, AV_LOG_ERROR, "hdmi task exit\n");

    return NULL;
}


static void hdmi_recv_msg(struct epoll_event *ev, int size)
{
    int index, n;

    // deal each event
    for (index = 0; index < size; index++)
    {
        if ( (ev[index].data.fd == hdmi_dev.fd) && (ev[index].events & EPOLLIN) )
        {
            while ((n = recv(hdmi_dev.fd, hdmi_dev.msg, UEVENT_MSG_LEN, 0)) > 0)
            {
                if (n == UEVENT_MSG_LEN)
                {
                  continue;
                }

                // parse msg
                hdmi_dev.msg[n] = '\0';
                hdmi_dev.msg[n+1] = '\0';
                hdmi_parse_msg(hdmi_dev.msg);
            }
        }
        else
        {
            av_log(NULL, AV_LOG_ERROR, "undealed epoll event,events:%d,data:%p\n", ev[index].events, ev[index].data.ptr);
        }
    }
}

static void hdmi_parse_msg(char *msg)
{
    uint32_t is_hdmi = 0;
    THdmiEvent event;
    while (*msg)
    {
        if (!strncmp(msg, "ACTION=change", 13))
        {
            is_hdmi |= HDMI_MSG_ACTION_CHANGE;
        }
        else if (!strncmp(msg, "SUBSYSTEM=switch", 16))
        {
            is_hdmi |= HDMI_MSG_SYSTEM_SWITCH;
        }
        else if (!strncmp(msg, "SWITCH_NAME=hdmi", 16))
        {
            is_hdmi |= HDMI_MSG_SWITCH_HDMI;
        }
        else if (!strncmp(msg, "SWITCH_STATE=0", 14))
        {
            is_hdmi |= HDMI_MSG_SWITCH_STATE;
            event.status = EHOT_PLUG_DISCONNECT;
        }
        else if (!strncmp(msg, "SWITCH_STATE=1", 14))
        {
            is_hdmi |= HDMI_MSG_SWITCH_STATE;
            event.status = EHOT_PLUG_CONNECTED;
        }

        /* advance to after the next \0 */
        while(*msg++);
    }

    // callback this event to highlevel
    av_log(NULL, AV_LOG_ERROR, "uevent detected:%u, hdmi:%u\n", is_hdmi, HDMI_MSG_HDMI_DECTED);
    if ((HDMI_MSG_HDMI_DECTED == is_hdmi) && (NULL != hdmi_module_info.callback))
    {
        av_log(NULL, AV_LOG_ERROR, "hdmi detected %s\n", (event.status == EHOT_PLUG_CONNECTED) ? "in" : "out");
        hdmi_module_info.callback(&event, hdmi_module_info.context);
    }
}

static int hdmi_inter_init()
{
    int ret, fd;
    pthread_t task_id;

    if (1 == hdmi_module_info.module_inited)
    {
        return 0;
    }

    fd = hdmi_open_nlsocket();
    if (fd < 0)
    {
        av_log(NULL, AV_LOG_ERROR, "hdmi open socket failed\n");
        return -1;
    }

    // set fd,dev_status
    hdmi_dev.fd         = fd;
    hdmi_dev.dev_status = EHOT_PLUG_DISCONNECT;

    hdmi_module_info.task_state     = HDMI_TASK_RUNNING;
    ret = pthread_create(&task_id, NULL, hdmi_task, NULL);
    if (0 != ret)
    {
        av_log(NULL, AV_LOG_ERROR, "hdmi open socket failed, errno:%d\n", ret);

        return -1;
    }

    hdmi_module_info.task_id        = task_id;
    hdmi_module_info.module_inited  = 1;

    return ret;
}

/*
 * hdmi submodule init
 */
int hdmi_init()
{
    int ret;

    // set socket
    HDMI_LOCK_DEVICE();

    ret = hdmi_inter_init();

    // set socket
    HDMI_UNLOCK_DEVICE();

    return ret;
}

static int hdmi_inter_deinit()
{
    int ret;

    // if deinited already
    if (0 == hdmi_module_info.module_inited)
    {
        return 0;
    }

    // make task exit
    hdmi_module_info.task_state     = HDMI_TASK_EXITING;

    // wait thread exit
    ret = pthread_join(hdmi_module_info.task_id, NULL);
    if (0 != ret)
    {
        av_log(NULL, AV_LOG_ERROR, "pthread join failed,errno:%d", ret);
    }

    close(hdmi_dev.fd);

    // set module init flat
    hdmi_module_info.module_inited  = 0;

    return 0;
}

/*
 * hdmi submodule deinit
 */
int hdmi_deinit()
{
    int ret;

    // lock
    HDMI_LOCK_DEVICE();

    ret = hdmi_inter_deinit();

    // unlock
    HDMI_UNLOCK_DEVICE();

    return ret;
}

/*
 * set hdmi callback function
 */
int hdmi_set_callback(FHdmiCallBack pf, void *context)
{
    // set socket
    HDMI_LOCK_DEVICE();

    hdmi_module_info.callback   = pf;
    hdmi_module_info.context    = context;

    // set socket
    HDMI_UNLOCK_DEVICE();

    return 0;
}

/*
 * set hdmi callback function
 */
int hdmi_get_status(THdmiEvent *event)
{
    int fd, len;
    char buf;

    if (NULL == event)
    {
        av_log(NULL, AV_LOG_ERROR, "param null\n");
        return -1;
    }
    event->status = hdmi_dev.dev_status;

    fd = open("/sys/class/switch/hdmi/state", O_RDONLY);
    if (fd < 0)
    {
        av_log(NULL, AV_LOG_ERROR, "open sys class switch hdmi failed, errno:%d\n", errno);
        return 0;
    }

    len = read(fd, &buf, 1);
    if (1 != len)
    {
        av_log(NULL, AV_LOG_ERROR, "read buf failed\n");
    }

    // close state file
    close(fd);

    if ('1' == buf)
    {
        event->status = hdmi_dev.dev_status = EHOT_PLUG_CONNECTED;
    }
    else
    {
        event->status = hdmi_dev.dev_status = EHOT_PLUG_DISCONNECT;
    }

    return 0;
}
