// std & sys
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/epoll.h>
#include <sys/types.h>
#include <ctype.h>
#include <string.h>
#include <math.h>
#include <errno.h>
#include <signal.h>
#include <limits.h>
#include <unistd.h>
#include <sys/socket.h>
#include <sys/wait.h>
#include <sys/ioctl.h>
#include <sys/stat.h>
#include <sys/poll.h>
#include <sys/prctl.h>
#include <fcntl.h>
#include <sys/un.h>
#include <arpa/inet.h>
#include <pthread.h>
#include <netinet/in.h>
#include <dirent.h>
#include <sys/time.h>
#include <linux/fb.h>
#include <linux/netlink.h>
#include <sys/syslog.h>
#include "stdarg.h"

// ffmpeg head
#include "libavformat/avformat.h"

// prj include
#include "video_common.h"
#include "mplayer.h"
#include "hdmi.h"
#include "rtsp_switch.h"


#define MODULE_NAME             "mplayer"

#define video_loge(fmt, ...)     av_log(NULL, AV_LOG_ERROR, "[video]"fmt, ##__VA_ARGS__)

//#define DEBUG_RTSP_SWITCH
#define LOG_MODULE_TAG          MODULE_NAME

#define LOG_MPLAYER             LOG_LOCAL3
#define LOG_CUR_MOEULE          LOG_MPLAYER

/// video mgr global info
static struct tagVideoMgrInfo
{
    THdmiEvent hdmi_event;          /// hdmi status
    EHotPlugStatus wifi_status;     /// wifi status
    EHotPlugStatus adb_status;      /// adb status
    int             hasadb;
    int             hasios;
    int             ios_handle;
}video_mgr_info = {0};

/*
 * decl
 */
static void *mgr_video_task(void *arg);

/*
 * video log
 */
static void video_log(void* avcl, int level, const char* fmt,va_list vl)
{
    static pthread_mutex_t lock = PTHREAD_MUTEX_INITIALIZER;

    if (level <= AV_LOG_INFO)
    {
        vprintf(fmt, vl);
    }
    // return;

    // pthread_mutex_lock(&lock);
    openlog(LOG_MODULE_TAG, LOG_ODELAY, LOG_CUR_MOEULE);
    vsyslog(LOG_ERR, fmt, vl);
    // pthread_mutex_unlock(&lock);
}


void exit_program(int ret)
{
    exit(ret);
}

/*
 * set wifi connect status
 */
int video_set_wifi_status(EHotPlugStatus status)
{
    video_mgr_info.wifi_status = status;
    video_loge("set wifi status:%u\n", status);
    return 0;
}

/*
 * set adb connect status
 */
int video_set_adb_status(EHotPlugStatus status)
{
    // video_mgr_info.adb_status = status;
    video_loge("set adb status:%u\n", status);
    return 0;
}

/// hdmi status
static THdmiEvent hdmi_event;

void video_set_hdmi_status(EHotPlugStatus status)
{
    hdmi_event.status = status;
    video_loge("set hdmi status:%u\n", status);
}

void video_set_phone_status(int hasios, int hasadb, int handle)
{
    video_mgr_info.hasios       = hasios;
    video_mgr_info.hasadb       = hasadb;
    video_mgr_info.ios_handle   = handle;

    video_loge("set phone status,have iphone:%d,have adb:%d\n", hasios, hasadb);
}


static int localplay_exit = 0;
/*
 * localplayer callback
 *@note this function must not call any localplay API interface
 */
int m_localplay_ev_callback(TMplayerEvent *ev, void *context)
{
    int ret = 0;
    av_log(NULL, AV_LOG_ERROR, "localplay callback, task exited\n");

    if ((NULL != ev) && (EPLAYER_EV_RTSP_EXIT == ev->ev))
    {
        localplay_exit = 1;
    }

    return ret;
}


/*
 * mplayer process init function
 * init all submodule
 */
int video_init(char *filename)
{
    int ret;
    pthread_t video_mgr_pid;

    // init ffmpeg lib
    av_register_all();
    avcodec_register_all();
    avformat_network_init();
    av_log_set_callback(video_log);

    // version
    av_log(NULL, AV_LOG_ERROR, "program :%s, compile time:%s %s\n", MODULE_NAME, __DATE__, __TIME__);

    // step 1: init localplay
    ret = localplay_init();
    if (ret < 0)
    {
        av_log(NULL, AV_LOG_ERROR, "localplay init failed, program to exit\n");
        return -1;
    }

    ret = rtp_switch_init();
    if (ret < 0)
    {
        av_log(NULL, AV_LOG_ERROR, "init rtp_switch failed\n");
        return -1;
    }

#if 0
    ret = rtsp_switch_init(54540);
    if (ret < 0)
    {
        av_log(NULL, AV_LOG_ERROR, "init rtsp_switch failed\n");
        return -1;
    }
#endif

    // start localplay service
    ret = pthread_create(&video_mgr_pid, NULL, mgr_video_task, filename);
    if (0 != ret)
    {
        av_log(NULL, AV_LOG_ERROR, "create video mgr task fialed,errno:%d\n", ret);
        return -1;
    }

    return 0;
}

/*
 * mplayer process deinit function
 * deinit all submodule
 */
int video_deinit()
{
    return 0;
}

static void mgr_deal_localplay(char *pszurl, THdmiEvent *ev)
{
    static int localplay_start = 0;
    static int  restart = 0;
    int ret;
    static int phone_connected = 0;

    if ( (video_mgr_info.hasadb) || (video_mgr_info.hasios) )
    {
        phone_connected = 1;
    }
    else
    {
        phone_connected = 0;
    }

    phone_connected = 0;
    if (1 == localplay_start)
    {
        if ( (1 == localplay_exit) || (EHOT_PLUG_DISCONNECT == ev->status) || (1 == phone_connected) )
        {
            ret = localplay_set_ev_callback(1, NULL, NULL);
            if (ret < 0)
            {
                av_log(NULL, AV_LOG_ERROR, "localplay set ev callback failed\n");
                return;
            }

            // close stream
            localplay_close_stream();

            localplay_exit = 0;
            localplay_start = 0;
        }
    }
    else if ((EHOT_PLUG_CONNECTED == ev->status) && (0 == phone_connected))
    {
        ret = localplay_set_ev_callback(1, m_localplay_ev_callback, NULL);
        if (ret < 0)
        {
            av_log(NULL, AV_LOG_ERROR, "localplay set ev callback failed, program to exit\n");
            return;
        }

        // rtsp://192.168.42.1/live
        restart++;
        av_log(NULL, AV_LOG_ERROR, "localplay restrat num:%d,phone connect:%d,open stream:%s\n",
                        restart, phone_connected, pszurl);
        ret = localplay_open_stream(NULL, pszurl);
        if (ret < 0)
        {
            av_log(NULL, AV_LOG_ERROR, "localplay open stream failed, program to exit\n");
            return;
        }

        av_log(NULL, AV_LOG_ERROR, "[main] localplay open stream successfull\n");
        localplay_start = 1;
    }
}

void *mgr_video_task(void *arg)
{
    int ret;
    THdmiEvent event;
    int hasadb, hasios;

    // set name
    ret = prctl(PR_SET_NAME, "VideoMgrTask");
    if (0 != ret)
    {
        av_log(NULL, AV_LOG_ERROR, "set thread name failed,errno:%d\n", errno);
    }

    // get hdmi status
    ret = hdmi_get_status(&event);
    if (ret < 0)
    {
        av_log(NULL, AV_LOG_ERROR, "get hdmi status failed\n");
    }
    hdmi_event = event;

    hasadb = video_mgr_info.hasadb;
    hasios = video_mgr_info.hasios;

    for (;;)
    {
        // deal localplay
        mgr_deal_localplay(arg, (volatile THdmiEvent *)&event);

        usleep(100000);
        event = hdmi_event;

        if ( (hasadb != video_mgr_info.hasadb) || (hasios != video_mgr_info.hasios) )
        {
            hasadb = video_mgr_info.hasadb;
            hasios = video_mgr_info.hasios;
            rs_set_phone_status(hasios, hasadb, video_mgr_info.ios_handle);
        }
    }

    return NULL;
}

#ifdef DEBUG_MPLAYER
/*
 * app entry
 */
int main(int argc, char **argv)
{
    int ret;
    struct sigaction ignore, saveintr;

    // igore SIGINT & SIGQUIT
    ignore.sa_handler = SIG_IGN;
    sigemptyset(&ignore.sa_mask);
    ignore.sa_flags = 0;
    if (sigaction(SIGPIPE, &ignore, &saveintr) < 0) {
        av_log(NULL, AV_LOG_ERROR, "sigaction ignore SIGINT failed:%d, fatal error!!!\n", errno);
        return -1;
    }

    // init all modules
    ret = video_init(argv[1]);
    if (ret < 0)
    {
        av_log(NULL, AV_LOG_ERROR, "[main] init failed\n");
        return -1;
    }

    for(;;)
    {
        sleep(100);
    }

    return 0;
}
#endif
