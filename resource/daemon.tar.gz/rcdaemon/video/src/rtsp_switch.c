
// std & sys
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/epoll.h>
#include <sys/types.h>
#include <ctype.h>
#include <string.h>
#include <math.h>
#include <errno.h>
#include <signal.h>
#include <limits.h>
#include <unistd.h>
#include <sys/socket.h>
#include <sys/wait.h>
#include <sys/ioctl.h>
#include <sys/stat.h>
#include <sys/poll.h>
#include <sys/prctl.h>
#include <fcntl.h>
#include <sys/un.h>
#include <arpa/inet.h>
#include <pthread.h>
#include <netinet/in.h>
#include <dirent.h>
#include <sys/time.h>
#include <linux/fb.h>
#include <linux/netlink.h>
#include <ctype.h>
#include <string.h>
#include <math.h>
#include <stdlib.h>
#include <errno.h>
#include <signal.h>
#include <limits.h>
#include <unistd.h>
#include <errno.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <arpa/inet.h>
#include <pthread.h>
#include <netinet/in.h>
#include <poll.h>
#include <sys/syscall.h>

#include "ffmpeg_config.h"
#include "libavformat/avformat.h"
#include "libavformat/rtsp.h"
#include "libavdevice/avdevice.h"
#include "libswscale/swscale.h"
#include "libswresample/swresample.h"
#include "libavutil/opt.h"
#include "libavutil/audioconvert.h"
#include "libavutil/parseutils.h"
#include "libavutil/lfg.h"
#include "libavutil/samplefmt.h"
#include "libavutil/colorspace.h"
#include "libavformat/avio_internal.h"
#include "libavutil/fifo.h"
#include "libavutil/intreadwrite.h"
#include "libavutil/dict.h"
#include "libavutil/mathematics.h"
#include "libavutil/pixdesc.h"
#include "libavutil/avstring.h"
#include "libavutil/libm.h"
#include "libavutil/imgutils.h"
#include "libavutil/timestamp.h"
#include "libavutil/bprint.h"
#include "libavutil/random_seed.h"
#include "libavformat/os_support.h"
#include "libavformat/rdt.h"
#include "libavformat/url.h"
#include "libavformat/avio.h"
#include "libavutil/avassert.h"
#include "libavformat/ffm.h" // not public API
#include "libavfilter/avcodec.h"
#include "libavfilter/avfilter.h"
#include "libavfilter/avfiltergraph.h"
#include "libavfilter/buffersrc.h"
#include "libavfilter/buffersink.h"

#include <usbmuxd.h>

#include "utils.h"
#include "common.h"
#include "rtsp_switch.h"

/*
 * module log api
 */
#define video_loge(fmt, ...)     av_log(NULL, AV_LOG_ERROR, "[video]"fmt, ##__VA_ARGS__)

enum RTSP_INDEX_FLAG{
    RTSP_INDEX_READ_MASK =       0x0ffff,
    RTSP_INDEX_READ_MAX = RTSP_INDEX_READ_MASK,
    RTSP_INDEX_FLAG_BASE =       0x10000,
    RTSP_INDEX_FLAG_INIT =       0x20000,
};
enum TRANS_PROTOCOL{
    TRANS_NETWORK,
    TRANS_UNIX_SOCKET,
    TRANS_USBMUXD,
    TRANS_ADB,
};


#define rtsp_log(fmt, ...)     av_log(NULL, AV_LOG_DEBUG, fmt, ##__VA_ARGS__)
#define RECVBUF_SIZE 10 * RTP_MAX_PACKET_LENGTH
#define POLL_TIMEOUT_MS 100
#define READ_PACKET_TIMEOUT_S 10
#define MAX_TIMEOUTS READ_PACKET_TIMEOUT_S * 1000 / POLL_TIMEOUT_MS
#define MAX_STREAMS 20
#define RTSP_REQUEST_TIMEOUT (6000 * 1000)
#define IOBUFFER_INIT_SIZE 8192
#define MAX_CONNECTIONS (10)

enum HTTPState {
    HTTPSTATE_WAIT_REQUEST,
    HTTPSTATE_SEND_HEADER,
    HTTPSTATE_SEND_DATA_HEADER,
    HTTPSTATE_SEND_DATA,          /* sending TCP or UDP data */
    HTTPSTATE_SEND_DATA_TRAILER,
    HTTPSTATE_RECEIVE_DATA,
    HTTPSTATE_WAIT_DATA,          /* wait for data from the feed */
    HTTPSTATE_READY,

    RTSPSTATE_WAIT_REQUEST,
    RTSPSTATE_SEND_REPLY,
    RTSPSTATE_SEND_PACKET,
};

/* each generated stream is described here */
enum StreamType {
    STREAM_TYPE_LIVE,
    STREAM_TYPE_STATUS,
    STREAM_TYPE_REDIRECT,
};

typedef struct {
    int64_t count1, count2;
    int64_t time1, time2;
} DataRateData;

typedef struct RTSPActionServerSetup {
    uint32_t ipaddr;
    char transport_option[512];
} RTSPActionServerSetup;

/* description of each stream of the ffserver.conf file */
typedef struct FFStream {
    enum StreamType stream_type;
    char filename[1024];     /* stream filename */
    struct FFStream *feed;   /* feed we are using (can be null if
                                coming from file) */
    AVOutputFormat *fmt;
    int users;
    int nb_streams;
    int prebuffer;      /* Number of millseconds early to start */
    int64_t max_time;      /* Number of milliseconds to run */
    int send_on_key;
    AVStream **streams;
    int feed_streams[MAX_STREAMS]; /* index of streams in the feed */
    char feed_filename[1024]; /* file name of the feed storage, or
                                 input file name for a stream */
    char author[512];
    char title[512];
    char copyright[512];
    char comment[512];
    unsigned bandwidth; /* bandwidth, in kbits/s */
    /* multicast specific */
    int is_multicast;
    struct in_addr multicast_ip;
    int multicast_port; /* first port used for multicast */
    int multicast_ttl;
    int loop; /* if 1, send the stream in loops (only meaningful if file) */

    int64_t bytes_served;
} FFStream;

/// max 128 frames, maybe with a delay for 5s
#define RTSP_SWTITCH_MAX_FRAME_NUM   128

/*
 * rtsp client session owner
 */
typedef struct rtsp_source {
    AVFormatContext         *fmt;                               /// input stream id
    int                     video_index;
    AVPacket                caches[RTSP_SWTITCH_MAX_FRAME_NUM];  /// pkt cache
    unsigned int            pkt_num;                            /// pkt num
    unsigned int            write, read;                        /// pkt position
    volatile unsigned int   start,end;                          /// pkt position
    int last_read[MAX_CONNECTIONS + 1];

    pthread_t thread;
    pthread_mutex_t lock;
    int users;
    int running;
    int exit;
    char filename[1024];
}TRtspSouce;

/* context associated with one connection */
typedef struct RTSPContext {
    enum HTTPState state;
    int fd; /* socket file descriptor */
    struct sockaddr_in from_addr; /* origin */
    struct pollfd *poll_entry; /* used when polling */
    int64_t timeout;
    uint8_t *buffer_ptr, *buffer_end;
    int http_error;
    int post;
    int chunked_encoding;
    int chunk_size;               /* 0 if it needs to be read */
    struct RTSPContext *next;
    int got_key_frame; /* stream 0 => 1, stream 1 => 2, stream 2=> 4 */
    int64_t data_count;
    /* input format handling */
    AVFormatContext *fmt_in;
    int64_t start_time;            /* In milliseconds - this wraps fairly often */
    int64_t first_pts;            /* initial pts value */
    int64_t cur_pts;             /* current pts value from the stream in us */
    int64_t cur_frame_duration;  /* duration of the current frame in us */
    int cur_frame_bytes;       /* output frame size, needed to compute
                                  the time at which we send each
                                  packet */
    int pts_stream_index;        /* stream we choose as clock reference */
    int64_t cur_clock;           /* current clock reference value in us */
    /* output format handling */
    struct FFStream *stream;
    /* -1 is invalid stream */
    int feed_streams[MAX_STREAMS]; /* index of streams in the feed */
    int switch_feed_streams[MAX_STREAMS]; /* index of streams in the feed */
    int switch_pending;
    AVFormatContext fmt_ctx; /* instance of FFStream for one user */
    int last_packet_sent; /* 1 if last data packet was sent */
    int suppress_log;
    DataRateData datarate;
    char protocol[16];
    char method[16];
    char url[128];
    int buffer_size;
    uint8_t *buffer;
    int is_packetized; /* if 1, the stream is packetized */
    int packet_stream_index; /* current stream for output in state machine */

    /* RTSP state specific */
    uint8_t *pb_buffer; /* XXX: use that in all the code */
    AVIOContext *pb;
    int seq; /* RTSP sequence number */

    /* RTP state specific */
    enum RTSPLowerTransport rtp_protocol;
    char session_id[32]; /* session id */
    AVFormatContext *rtp_ctx[MAX_STREAMS];

    /* RTP/UDP specific */
    URLContext *rtp_handles[MAX_STREAMS];
    struct rtsp_source *rtsp_source;
    int rtsp_read_index;
    struct RTSPContext *rtp_client;
    enum TRANS_PROTOCOL medium;

    /* RTP/TCP specific */
    struct RTSPContext *rtsp_c;
    uint8_t *packet_buffer, *packet_buffer_ptr, *packet_buffer_end;

    uint8_t rtcp_buf[128];
} RTSPContext;

struct client_data {
    int rtsp_server_fd;
    int local_server_fd;

    /* rtsp device fd */
    int afd;
    int ifd;
    int hasa;

    int handle;
    int hasi;

    int64_t last_connect_time;
    int rtsp_port;
    int rc_port;
    int stop_ctos;
};

static RTSPContext *first_http_ctx;
static unsigned int nb_max_connections = MAX_CONNECTIONS;
static unsigned int nb_connections;
static int64_t cur_time;           // Making this global saves on passing it around everywhere
static uint64_t current_bandwidth;
static AVLFG random_state;

void print_error(const char *filename, int err)
{
    char errbuf[128];
    const char *errbuf_ptr = errbuf;

    if (av_strerror(err, errbuf, sizeof(errbuf)) < 0)
        errbuf_ptr = strerror(AVUNERROR(err));
    av_log(NULL, AV_LOG_ERROR, "%s: %s\n", filename, errbuf_ptr);
}

static void log_connection(RTSPContext *c)
{
    if (c->suppress_log)
        return;

    av_log(NULL, AV_LOG_DEBUG,"%s - - [%s] \"%s %s\" %d %"PRId64"\n",
            inet_ntoa(c->from_addr.sin_addr), c->method, c->url,
              c->protocol, (c->http_error ? c->http_error : 200), c->data_count);
    av_log(NULL, AV_LOG_DEBUG,"closed\n");
}

/* start waiting for a new HTTP/RTSP request */
static void start_wait_request(RTSPContext *c)
{
    c->buffer_ptr = c->buffer;
    c->buffer_end = c->buffer + c->buffer_size - 1; /* leave room for '\0' */

    c->timeout = cur_time + RTSP_REQUEST_TIMEOUT;
    c->state = RTSPSTATE_WAIT_REQUEST;
    av_log(NULL, AV_LOG_ERROR, "session state now to wait request\n");
}

static RTSPContext * new_connection(int server_fd, enum TRANS_PROTOCOL medium)
{
    struct sockaddr_in from_addr;
    struct sockaddr_un unaddr;
    int fd, len;
    RTSPContext *c = NULL;

    if(medium != TRANS_NETWORK) {
        /* already connect before */
        fd = server_fd;
    } else if(medium != TRANS_UNIX_SOCKET) {
        len = sizeof(from_addr);
        fd = accept(server_fd, (struct sockaddr *)&from_addr,
                    (socklen_t *)&len);
    } else {
        len = sizeof(unaddr);
        fd = accept(server_fd, (struct sockaddr *)&unaddr,
                    (socklen_t *)&len);
    }
    if (fd < 0) {
        rtsp_log("error during accept %s\n", strerror(errno));
        return NULL;
    }
    ff_socket_nonblock(fd, 1);

    if (nb_connections >= nb_max_connections) {
        goto fail;
    }

    /* add a new connection */
    c = av_mallocz(sizeof(RTSPContext));
    if (!c)
        goto fail;

    c->fd = fd;
    c->medium = medium;
    c->poll_entry = NULL;
    c->from_addr = from_addr;
    c->buffer_size = IOBUFFER_INIT_SIZE;
    c->buffer = av_malloc(c->buffer_size);
    if (!c->buffer)
        goto fail;

    c->next = first_http_ctx;
    first_http_ctx = c;
    nb_connections++;

    video_loge("new connection[%p]. from:%d\n", c, medium);

    start_wait_request(c);

    return c;

fail:
    if (c) {
        av_free(c->buffer);
        av_free(c);
    }
    close(fd);
    return NULL;
}

/* XXX: take care with different space meaning */
static inline void skip_spaces(const char **pp)
{
    const char *p;
    p = *pp;
    while (*p == ' ' || *p == '\t')
        p++;
    *pp = p;
}

static void get_word(char *buf, int buf_size, const char **pp)
{
    const char *p;
    char *q;

    p = *pp;
    skip_spaces(&p);
    q = buf;
    while (!isspace(*p) && *p != '\0') {
        if ((q - buf) < buf_size - 1)
            *q++ = *p;
        p++;
    }
    if (buf_size > 0)
        *q = '\0';
    *pp = p;
}

/*
 * close one connection
 */
static void rtsp_close_source(RTSPContext *c)
{
    struct rtsp_source *rs = c->rtsp_source;
    unsigned int index;

    rs->users--;
    c->fmt_in = NULL;
    c->rtsp_source = NULL;
    index = c->rtsp_read_index;
    index &= RTSP_INDEX_READ_MASK;
    if(index < FF_ARRAY_ELEMS(rs->caches))
        rs->last_read[index] = -1;
    else
        av_log(NULL, AV_LOG_ERROR, "illegal read index value:%d ! This should not happen!!!", index);

    if(rs->users)
        return;

    rs->running = 0;

    pthread_join(rs->thread, NULL);
    pthread_mutex_destroy(&rs->lock);

    avformat_close_input(&rs->fmt);

    av_free(rs);

    return;
}

static void close_connection(RTSPContext *c)
{
    RTSPContext **cp, *c1;
    unsigned int i, nb_streams;
    AVFormatContext *ctx;
    URLContext *h;

    /* remove connection from list */
    cp = &first_http_ctx;
    while ((*cp) != NULL) {
        c1 = *cp;
        if (c1 == c)
            *cp = c->next;
        else
            cp = &c1->next;
    }

    /* remove references, if any (XXX: do it faster) */
    for(c1 = first_http_ctx; c1 != NULL; c1 = c1->next) {
        if (c1->rtsp_c == c)
            c1->rtsp_c = NULL;
        if (c1->rtp_client == c)
            c1->rtp_client = NULL;
    }

    /* remove connection associated resources */
    if (c->fd >= 0)
        close(c->fd);
    if(c->rtp_client)
        close_connection(c->rtp_client);
    if (c->rtsp_source)
        rtsp_close_source(c);

    /* free RTP output streams if any */
    nb_streams = 0;
    if (c->stream)
        nb_streams = c->stream->nb_streams;

    for(i=0;i<nb_streams;i++) {
        ctx = c->rtp_ctx[i];
        if (ctx) {
            if(ctx->oformat->write_trailer)
                ctx->oformat->write_trailer(ctx);
            av_freep(&ctx->streams[0]->priv_data);
            av_freep(&ctx->streams[0]->index_entries);
            if (ctx->oformat->priv_class)
                av_opt_free(ctx->priv_data);
            av_freep(&ctx->priv_data);
            av_dict_free(&ctx->metadata);
            av_free(ctx->streams[0]);
            av_free(ctx);
        }
        h = c->rtp_handles[i];
        if (h)
            ffurl_close(h);
    }

    if(c->stream && (--c->stream->users <= 0))
        av_free(c->stream);
    ctx = &c->fmt_ctx;

    if (!c->last_packet_sent && c->state == HTTPSTATE_SEND_DATA_TRAILER) {
        if (ctx->oformat) {
            /* prepare header */
            if (avio_open_dyn_buf(&ctx->pb) >= 0) {
                av_write_trailer(ctx);
                av_freep(&c->pb_buffer);
                avio_close_dyn_buf(ctx->pb, &c->pb_buffer);
            }
        }
    }

    for(i=0; i<ctx->nb_streams; i++)
        av_free(ctx->streams[i]);

    if (c->stream && !c->post && c->stream->stream_type == STREAM_TYPE_LIVE)
        current_bandwidth -= c->stream->bandwidth;

    av_freep(&c->pb_buffer);
    av_freep(&c->packet_buffer);
    av_free(c->buffer);
    av_free(c);
    nb_connections--;
}

/********************************************************************/
/* RTSP handling */

static void rtsp_reply_header(RTSPContext *c, enum RTSPStatusCode error_number)
{
    const char *str;
    time_t ti;
    struct tm *tm;
    char buf2[32];

    switch(error_number) {
    case RTSP_STATUS_OK:
        str = "OK";
        break;
    case RTSP_STATUS_METHOD:
        str = "Method Not Allowed";
        break;
    case RTSP_STATUS_BANDWIDTH:
        str = "Not Enough Bandwidth";
        break;
    case RTSP_STATUS_SESSION:
        str = "Session Not Found";
        break;
    case RTSP_STATUS_STATE:
        str = "Method Not Valid in This State";
        break;
    case RTSP_STATUS_AGGREGATE:
        str = "Aggregate operation not allowed";
        break;
    case RTSP_STATUS_ONLY_AGGREGATE:
        str = "Only aggregate operation allowed";
        break;
    case RTSP_STATUS_TRANSPORT:
        str = "Unsupported transport";
        break;
    case RTSP_STATUS_INTERNAL:
        str = "Internal Server Error";
        break;
    case RTSP_STATUS_SERVICE:
        str = "Service Unavailable";
        break;
    case RTSP_STATUS_VERSION:
        str = "RTSP Version not supported";
        break;
    default:
        str = "Unknown Error";
        break;
    }

    avio_printf(c->pb, "RTSP/1.0 %d %s\r\n", error_number, str);
    avio_printf(c->pb, "CSeq: %d\r\n", c->seq);

    /* output GMT time */
    ti = time(NULL);
    tm = gmtime(&ti);
    strftime(buf2, sizeof(buf2), "%a, %d %b %Y %H:%M:%S", tm);
    avio_printf(c->pb, "Date: %s GMT\r\n", buf2);
    if(error_number != RTSP_STATUS_OK)
        av_log(NULL, AV_LOG_ERROR, "in func %s. error: %s\n",__func__,str);
}

static void rtsp_reply_error(RTSPContext *c, enum RTSPStatusCode error_number)
{
    rtsp_reply_header(c, error_number);
    avio_printf(c->pb, "\r\n");
}

static int prepare_sdp_description(FFStream *stream, uint8_t **pbuffer)
{
    AVFormatContext *avc;
    AVStream *avs = NULL;
    int i;

    avc =  avformat_alloc_context();
    if (avc == NULL) {
        return -1;
    }
    av_dict_set(&avc->metadata, "title",
               stream->title[0] ? stream->title : "No Title", 0);
    avc->nb_streams = stream->nb_streams;
    if (stream->is_multicast) {
        snprintf(avc->filename, 1024, "rtp://%s:%d?multicast=1?ttl=%d",
                 inet_ntoa(stream->multicast_ip),
                 stream->multicast_port, stream->multicast_ttl);
    } else {
        snprintf(avc->filename, 1024, "rtp://0.0.0.0");
    }

    if (avc->nb_streams >= INT_MAX/sizeof(*avc->streams) ||
        !(avc->streams = av_malloc(avc->nb_streams * sizeof(*avc->streams))))
        goto sdp_done;
    if (avc->nb_streams >= INT_MAX/sizeof(*avs) ||
        !(avs = av_malloc(avc->nb_streams * sizeof(*avs))))
        goto sdp_done;

    for(i = 0; i < stream->nb_streams; i++) {
        avc->streams[i] = &avs[i];
        avc->streams[i]->codec = stream->streams[i]->codec;
    }
    *pbuffer = av_mallocz(2048);
    av_sdp_create(&avc, 1, (char*)*pbuffer, 2048);

 sdp_done:
    av_free(avc->streams);
    av_dict_free(&avc->metadata);
    av_free(avc);
    av_free(avs);

    return strlen((char*)*pbuffer);
}

/*
 * get current frames num
 */
static inline unsigned int rtsp_caches_size(unsigned int end,unsigned int read_index)
{
    return (end >= read_index) ? (end - read_index) : (RTSP_SWTITCH_MAX_FRAME_NUM + end - read_index);
}

static int awaker[2];
static inline int rtsp_init_awaken()
{
    if(pipe(awaker) < 0) {
        av_log(NULL, AV_LOG_ERROR, "pipe failed, error:%s\n", strerror(errno));
        return -1;
    }
    fcntl(awaker[0], F_SETFL, fcntl(awaker[0], F_GETFL) | O_NONBLOCK);
    fcntl(awaker[1], F_SETFL, fcntl(awaker[1], F_GETFL) | O_NONBLOCK);
    return 0;
}

static inline int read_all(int fd)
{
    char buf[64];
    int ret;

    do {
        ret = read(fd, buf, sizeof(buf));
        if(ret < 0 && errno != EAGAIN && errno != EINTR)
            return -1;
        else if(ret == 0)
            return -1;
    } while(ret > 0);

    return 0;
}

#define poll_add_awaken(entry) do { \
                                    entry->fd = awaker[0];  \
                                    entry->events = POLLIN; \
                               } while(0)

#define refresh_awaken(entry)   do { \
                                    if(entry->revents & POLLIN) \
                                        read_all(awaker[0]);    \
                               } while(0)

static inline int awaken_poll()
{
    return write(awaker[1], "WAKE UP", strlen("WAKE UP"));
}

#define RTSP_SWITCH_MOVE_BACK(pos, max) if (++pos >= max) {pos = 0;}

/*
 * rtsp switch buf write, thread safe
 */
static void rtsp_write_pkt(TRtspSouce *rtsp_source, AVPacket *pkt)
{
    pthread_mutex_lock(&rtsp_source->lock);

    // if full, flush early pkt out
    if (RTSP_SWTITCH_MAX_FRAME_NUM <= rtsp_source->pkt_num)
    {
        rtsp_source->pkt_num--;
        RTSP_SWITCH_MOVE_BACK(rtsp_source->read, RTSP_SWTITCH_MAX_FRAME_NUM);
        av_free_packet(&rtsp_source->caches[rtsp_source->write]);
        av_log(NULL, AV_LOG_ERROR, "rtsp switch server pkt buf full, now flush the early\n");
    }

    memcpy(&rtsp_source->caches[rtsp_source->write], pkt, sizeof(*pkt));

    RTSP_SWITCH_MOVE_BACK(rtsp_source->write, RTSP_SWTITCH_MAX_FRAME_NUM );
    rtsp_source->pkt_num++;

    pthread_mutex_unlock(&rtsp_source->lock);
    awaken_poll();
}

/*
 * rtsp switch buf read, thread safe
 */
static int rtsp_read_pkt(TRtspSouce *rtsp_source, AVPacket *pkt)
{
    int ret = 0;
    pthread_mutex_lock(&rtsp_source->lock);

    if (0 == rtsp_source->pkt_num)
    {
        // need to wait for more frames
        ret = AVERROR(EAGAIN);

        // if read thread exit
        if (1 == rtsp_source->exit)
        {
            video_loge("current rtsp session exit anomaly\n");
            ret = -1;
        }
        pthread_mutex_unlock(&rtsp_source->lock);
        return ret;
    }

    memcpy(pkt, &rtsp_source->caches[rtsp_source->read], sizeof(*pkt));

    RTSP_SWITCH_MOVE_BACK(rtsp_source->read, RTSP_SWTITCH_MAX_FRAME_NUM);
    rtsp_source->pkt_num--;

    pthread_mutex_unlock(&rtsp_source->lock);

    return ret;
}

#define RTSP_MAX_TIMEOUT   (2000)
static void *rtsp_read_thread(void *arg)
{
    AVPacket pkt;
    TRtspSouce *rtsp_source = arg;
    int ret;
    int try = 0;

    av_log(NULL, AV_LOG_ERROR, "rtsp read thread start\n");

    // set name
    ret = prctl(PR_SET_NAME, "RsServer");
    if (0 != ret)
    {
        av_log(NULL, AV_LOG_ERROR, "set thread name failed,errno:%d\n", errno);
    }

    while (1)
    {
        // av_init_packet(pkt);
        if (1 != rtsp_source->running)
        {
            av_log(NULL, AV_LOG_ERROR, "rtsp read thread commanded to exit\n");
            break;
        }

        // read frame
        ret = av_read_frame(rtsp_source->fmt, &pkt);
        if (ret == AVERROR(EAGAIN))
        {
            try++;
            if (try > RTSP_MAX_TIMEOUT)
            {
                av_log(NULL, AV_LOG_ERROR, "av read frame time out for 20s\n");
                break;
            }

            av_log(NULL,AV_LOG_INFO, "av read frame require retry:%d\n",try);
            usleep(10000);
            continue;
        }
        else if (ret < 0)
        {
            av_log(NULL, AV_LOG_ERROR, "av read frame failed:%d\n", ret);
            break;
        }

        try = 0;
        if (rtsp_source->video_index != pkt.stream_index)
        {
            av_free_packet(&pkt);
            continue;
        }

        /* duplicate the packet */
        if (av_dup_packet(&pkt) < 0)
        {
            av_log(NULL, AV_LOG_ERROR, "rtsp dup pkt failed\n");
            continue;
        }

        rtsp_write_pkt(rtsp_source, &pkt);
#ifdef DEBUG
        {
            struct timeval tv;
            gettimeofday(&tv, NULL);
            av_log(NULL, AV_LOG_ERROR, "rtsp switch read frame, size:%d, cur time:%ld, pts:%lld,dts:%lld\n",
                        pkt.size, tv.tv_sec * 1000 + tv.tv_usec / 1000, pkt.pts, pkt.dts);
        }
#endif
    }

    rtsp_source->exit       = 1;
    av_log(NULL, AV_LOG_ERROR, "rtsp read thread exit now\n");

    return NULL;
}

static int rtsp_open_source(RTSPContext *c, char *filename)
{
    char buf[1024];
    int ret;
    unsigned int i;
    RTSPContext *ctx;
    struct rtsp_source *rs_parent;

    snprintf(buf, sizeof(buf), "rtsp://%s",filename);
    for(ctx = first_http_ctx; ctx != NULL; ctx = ctx->next) {
        rs_parent = ctx->rtsp_source;
        if(rs_parent && rs_parent->running && rs_parent->users) {
            if(strncmp(buf, rs_parent->filename ,sizeof(rs_parent->filename)))
                continue;

            if(rs_parent->users >= MAX_CONNECTIONS) {
                rtsp_log("too many users. max support %d users\n", MAX_CONNECTIONS);
                continue;
            }
            rs_parent->users++;
            c->rtsp_read_index = RTSP_INDEX_READ_MAX;

            c->fmt_in = rs_parent->fmt;
            c->rtsp_source = rs_parent;

            return 0;
        }
    }

    if((rs_parent = av_mallocz(sizeof(*rs_parent))) == NULL) {
        av_log(NULL, AV_LOG_ERROR, "[rtsp switch]rtsp open source malloc failed, no memory\n");
        return -1;
    }

    if((ret = avformat_open_input(&rs_parent->fmt, buf, NULL, NULL)) < 0) {
        av_log(NULL, AV_LOG_ERROR, "open input:%s failed, ret:%d", buf, ret);
        return -1;
    }

    // only need video
    rs_parent->video_index = av_find_best_stream(rs_parent->fmt, AVMEDIA_TYPE_VIDEO, -1, -1, NULL, 0);
    if (rs_parent->video_index < 0)
    {
        av_log(NULL, AV_LOG_ERROR, "find video index failed,errno:%d\n", rs_parent->video_index);
        return -1;
    }

    if((ret = av_read_play(rs_parent->fmt)) < 0) {
        av_log(NULL, AV_LOG_ERROR, "av_read_play:%s failed, ret:%d", buf, ret);
        return -1;
    }

    for (i=0; i<FF_ARRAY_ELEMS(rs_parent->last_read); i++)
    {
        rs_parent->last_read[i] = -1;
    }
    strncpy(rs_parent->filename, buf, sizeof(rs_parent->filename));
    rs_parent->users++;
    c->fmt_in = rs_parent->fmt;
    c->rtsp_source = rs_parent;
    c->rtsp_read_index = RTSP_INDEX_READ_MAX;

    pthread_mutex_init(&rs_parent->lock, NULL);
    rs_parent->running    = 1;
    rs_parent->exit       = 0;
    if(pthread_create(&rs_parent->thread, NULL, rtsp_read_thread, rs_parent)) {
        rtsp_log("fatal error create thread error!\n");
        return -1;
    }

    return 0;
}


static void rtsp_cmd_describe(RTSPContext *c, const char *url)
{
    FFStream *stream;
    AVFormatContext *s = NULL;
    char path1[1024];
    const char *path;
    uint8_t *content = NULL;
    int content_length, len, ret;
    struct sockaddr_in my_addr;

    /* find which url is asked */
    av_url_split(NULL, 0, NULL, 0, NULL, 0, NULL, path1, sizeof(path1), url);
    path = path1;
    if (*path == '/')
        path++;

    if((stream = av_mallocz(sizeof(*stream)))) {
        av_log(NULL, AV_LOG_ERROR, "rtsp reveive path:%s\n", path);
        snprintf(stream->filename, sizeof(stream->filename), "%s",path);
        snprintf(stream->feed_filename, sizeof(stream->feed_filename), "rtsp://%s",path);

        if ((ret = rtsp_open_source(c, stream->filename)) < 0) {
            av_log(NULL, AV_LOG_ERROR, "could not open %s: %d\n", path, ret);
        } else {
            s = c->fmt_in;
            c->stream = stream;
            stream->users++;
            stream->streams = s->streams;
            stream->nb_streams = s->nb_streams;
            /* choose stream as clock source (we favorize video stream if
               present) for packet sending */
            c->pts_stream_index = 0;
            c->start_time = cur_time;
            c->first_pts = AV_NOPTS_VALUE;
            goto found;
        }
    }
    /* no stream found */
    rtsp_reply_error(c, RTSP_STATUS_SERVICE); /* XXX: right error ? */
    return;

 found:
    /* prepare the media description in sdp format */

    /* get the host IP */
    len = sizeof(my_addr);
    getsockname(c->fd, (struct sockaddr *)&my_addr, (socklen_t *)&len);
    content_length = prepare_sdp_description(stream, &content);
    if (content_length < 0) {
        rtsp_reply_error(c, RTSP_STATUS_INTERNAL);
        return;
    }
    rtsp_reply_header(c, RTSP_STATUS_OK);
    avio_printf(c->pb, "Content-Base: %s/\r\n", url);
    avio_printf(c->pb, "Content-Type: application/sdp\r\n");
    avio_printf(c->pb, "Content-Length: %d\r\n", content_length);
    avio_printf(c->pb, "\r\n");
    avio_write(c->pb, content, content_length);
    av_free(content);
}

static void rtsp_cmd_options(RTSPContext *c, const char *url)
{
    url = url;
    /* rtsp_reply_header(c, RTSP_STATUS_OK); */
    avio_printf(c->pb, "RTSP/1.0 %d %s\r\n", RTSP_STATUS_OK, "OK");
    avio_printf(c->pb, "CSeq: %d\r\n", c->seq);
    avio_printf(c->pb, "Public: %s\r\n", "OPTIONS, DESCRIBE, SETUP, TEARDOWN, PLAY, PAUSE");
    avio_printf(c->pb, "\r\n");
}

static RTSPTransportField *find_transport(RTSPMessageHeader *h, enum RTSPLowerTransport lower_transport)
{
    RTSPTransportField *th;
    int i;

    for(i = 0;i < h->nb_transports;i++) {
        th = &h->transports[i];
        if (th->lower_transport == lower_transport)
            return th;
    }
    return NULL;
}

static RTSPContext *find_rtp_session(const char *session_id)
{
    RTSPContext *c;

    if (session_id[0] == '\0')
        return NULL;

    for(c = first_http_ctx; c != NULL; c = c->next) {
        if (!strcmp(c->session_id, session_id))
            return c;
    }
    return NULL;
}

static RTSPContext *find_rtp_session_with_url(const char *url,
                                              const char *session_id)
{
    RTSPContext *rtp_c;
    char path1[1024];
    const char *path;
    char buf[1024];
    int s, len;

    rtp_c = find_rtp_session(session_id);
    if (!rtp_c)
        return NULL;

    /* find which url is asked */
    av_url_split(NULL, 0, NULL, 0, NULL, 0, NULL, path1, sizeof(path1), url);
    path = path1;
    if (*path == '/')
        path++;
    if(!strcmp(path, rtp_c->stream->filename)) return rtp_c;
    for(s=0; s<rtp_c->stream->nb_streams; ++s) {
      snprintf(buf, sizeof(buf), "%s/streamid=%d",
        rtp_c->stream->filename, s);
      if(!strncmp(path, buf, sizeof(buf))) {
    // XXX: Should we reply with RTSP_STATUS_ONLY_AGGREGATE if nb_streams>1?
        return rtp_c;
      }
    }
    len = strlen(path);
    if (len > 0 && path[len - 1] == '/' &&
        !strncmp(path, rtp_c->stream->filename, len - 1))
        return rtp_c;
    return NULL;
}

static RTSPContext *rtp_new_connection(struct sockaddr_in *from_addr,
                                       FFStream *stream, const char *session_id,
                                       enum RTSPLowerTransport rtp_protocol)
{
    RTSPContext *c = NULL;
    const char *proto_str;

    /* XXX: should output a warning page when coming
       close to the connection limit */
    if (nb_connections >= nb_max_connections)
        goto fail;

    /* add a new connection */
    c = av_mallocz(sizeof(RTSPContext));
    if (!c)
        goto fail;

    c->fd = -1;
    c->poll_entry = NULL;
    c->from_addr = *from_addr;
    c->buffer_size = IOBUFFER_INIT_SIZE;
    c->buffer = av_malloc(c->buffer_size);
    c->rtp_client = NULL;
    if (!c->buffer)
        goto fail;
    nb_connections++;
    c->stream = stream;
    stream->users++;
    av_strlcpy(c->session_id, session_id, sizeof(c->session_id));
    c->state = HTTPSTATE_READY;
    av_log(NULL, AV_LOG_ERROR, "state changed to %d\n", c->state);
    c->is_packetized = 1;
    c->rtp_protocol = rtp_protocol;

    /* protocol is shown in statistics */
    switch(c->rtp_protocol) {
    case RTSP_LOWER_TRANSPORT_UDP_MULTICAST:
        proto_str = "MCAST";
        break;
    case RTSP_LOWER_TRANSPORT_UDP:
        proto_str = "UDP";
        break;
    case RTSP_LOWER_TRANSPORT_TCP:
        proto_str = "TCP";
        break;
    default:
        proto_str = "???";
        break;
    }
    av_strlcpy(c->protocol, "RTP/", sizeof(c->protocol));
    av_strlcat(c->protocol, proto_str, sizeof(c->protocol));

    current_bandwidth += stream->bandwidth;

    video_loge("SETUP:new connection[%p]\n", c);

    c->next = first_http_ctx;
    first_http_ctx = c;
    return c;

 fail:
    if (c) {
        av_free(c->buffer);
        av_free(c);
    }
    return NULL;
}

/* add a new RTP stream in an RTP connection (used in RTSP SETUP
   command). If RTP/TCP protocol is used, TCP connection 'rtsp_c' is
   used. */
static int rtp_new_av_stream(RTSPContext *c,
                             int stream_index, struct sockaddr_in *dest_addr,
                             RTSPContext *rtsp_c)
{
    AVFormatContext *ctx;
    AVStream *st;
    char *ipaddr;
    URLContext *h = NULL;
    uint8_t *dummy_buf;
    int max_packet_size, ret;

    /* now we can open the relevant output stream */
    ctx = avformat_alloc_context();
    if (!ctx)
        return -1;
    ctx->oformat = av_guess_format("rtp", NULL, NULL);

    st = av_mallocz(sizeof(AVStream));
    if (!st)
        goto fail;
    ctx->nb_streams = 1;
    ctx->streams = av_mallocz(sizeof(AVStream *) * ctx->nb_streams);
    if (!ctx->streams)
      goto fail;
    ctx->streams[0] = st;

    if (!c->stream->feed ||
        c->stream->feed == c->stream)
        memcpy(st, c->stream->streams[stream_index], sizeof(AVStream));
    else
        memcpy(st,
                c->stream->feed->streams[c->stream->feed_streams[stream_index]],
                sizeof(AVStream));
    st->priv_data = NULL;
    st->codec->time_base.num = 1;
    st->codec->time_base.den = AV_TIME_BASE;

    /* build destination RTP address */
    ipaddr = inet_ntoa(dest_addr->sin_addr);

    switch(c->rtp_protocol) {
    case RTSP_LOWER_TRANSPORT_UDP:
    case RTSP_LOWER_TRANSPORT_UDP_MULTICAST:
        if (c->stream->is_multicast) {
            int ttl;
            ttl = c->stream->multicast_ttl;
            if (!ttl)
                ttl = 16;
            snprintf(ctx->filename, sizeof(ctx->filename),
                     "rtp://%s:%d?multicast=1&ttl=%d",
                     ipaddr, ntohs(dest_addr->sin_port), ttl);
        } else {
            snprintf(ctx->filename, sizeof(ctx->filename),
                     "rtp://%s:%d", ipaddr, ntohs(dest_addr->sin_port));
        }

        if (ffurl_open(&h, ctx->filename, AVIO_FLAG_WRITE, NULL, NULL) < 0)
            goto fail;
        c->rtp_handles[stream_index] = h;
        max_packet_size = h->max_packet_size;
        break;
    case RTSP_LOWER_TRANSPORT_TCP:
        c->rtsp_c = rtsp_c;
        max_packet_size = RTSP_TCP_MAX_PACKET_SIZE;
        break;
    default:
        goto fail;
    }

    rtsp_log("%s:%d - - \"PLAY %s/streamid=%d %s\"\n",
             ipaddr, ntohs(dest_addr->sin_port),
             c->stream->filename, stream_index, c->protocol);

    /* normally, no packets should be output here, but the packet size may be checked */
    if (ffio_open_dyn_packet_buf(&ctx->pb, max_packet_size) < 0) {
        /* XXX: close stream */
        goto fail;
    }

    if ((ret = avformat_write_header(ctx, NULL)) < 0) {
        print_error(c->stream->feed_filename, ret);
    fail:
        if (h)
            ffurl_close(h);
        c->rtp_handles[stream_index] = NULL;
        av_free(ctx);
        return -1;
    }
    avio_close_dyn_buf(ctx->pb, &dummy_buf);
    av_free(dummy_buf);

    c->rtp_ctx[stream_index] = ctx;
    return 0;
}

static void rtsp_cmd_setup(RTSPContext *c, const char *url,
                           RTSPMessageHeader *h)
{
    FFStream *stream;
    int stream_index, rtp_port, rtcp_port, i;
    char buf[1024];
    char path1[1024];
    const char *path;
    RTSPContext *rtp_c;
    RTSPTransportField *th = NULL;
    struct sockaddr_in dest_addr;
    RTSPActionServerSetup setup;

    /* find which url is asked */
    av_url_split(NULL, 0, NULL, 0, NULL, 0, NULL, path1, sizeof(path1), url);
    path = path1;
    if (*path == '/')
        path++;

    av_log(NULL, AV_LOG_INFO,"setup path :%s\n",path);
    if((stream = c->stream)) {
        if (!strcmp(path, stream->filename)) {
            if (stream->nb_streams != 1) {
                rtsp_reply_error(c, RTSP_STATUS_AGGREGATE);
                return;
            }
            stream_index = 0;
            goto found;
        }

        for(stream_index = 0; stream_index < stream->nb_streams;
            stream_index++) {
            snprintf(buf, sizeof(buf), "%s/streamid=%d",
                    stream->filename, stream_index);
            if (!strcmp(path, buf))
                goto found;
        }
    }
    /* no stream found */
    rtsp_reply_error(c, RTSP_STATUS_SERVICE); /* XXX: right error ? */
    return;
 found:

    /* generate session id if needed */
    if (h->session_id[0] == '\0')
        snprintf(h->session_id, sizeof(h->session_id), "%08x%08x",
                 av_lfg_get(&random_state), av_lfg_get(&random_state));

    /* find rtp session, and create it if none found */
    rtp_c = find_rtp_session(h->session_id);
    if (!rtp_c) {
        /* always prefer UDP. USBMUXD and ADB do not support udp */
        if(c->medium == TRANS_NETWORK)
            th = find_transport(h, RTSP_LOWER_TRANSPORT_UDP);
        if (!th) {
            th = find_transport(h, RTSP_LOWER_TRANSPORT_TCP);
            if (!th) {
                rtsp_reply_error(c, RTSP_STATUS_TRANSPORT);
                return;
            }
        }

        rtp_c = rtp_new_connection(&c->from_addr, stream, h->session_id,
                                   th->lower_transport);
        if (!rtp_c) {
            rtsp_reply_error(c, RTSP_STATUS_BANDWIDTH);
            return;
        }

        /* choose stream as clock source (we favorize video stream if
        present) for packet sending */
        c->pts_stream_index = 0;
        for(i=0;i<c->stream->nb_streams;i++) {
            if (c->pts_stream_index == 0 &&
                c->stream->streams[i]->codec->codec_type == AVMEDIA_TYPE_VIDEO) {
                c->pts_stream_index = i;
            }
        }
        rtp_c->fmt_in = c->fmt_in;
        rtp_c->rtsp_source = c->rtsp_source;
        c->rtsp_source = NULL;
        c->rtp_client = rtp_c;

        rtp_c->start_time = cur_time;
        rtp_c->first_pts = AV_NOPTS_VALUE;
        rtp_c->medium = c->medium;
        rtp_c->rtsp_read_index = RTSP_INDEX_FLAG_INIT;
    }

    /* test if stream is OK (test needed because several SETUP needs
       to be done for a given file) */
    if (rtp_c->stream != stream) {
        rtsp_reply_error(c, RTSP_STATUS_SERVICE);
        return;
    }

    /* test if stream is already set up */
    if (rtp_c->rtp_ctx[stream_index]) {
        rtsp_reply_error(c, RTSP_STATUS_STATE);
        return;
    }

    /* check transport */
    th = find_transport(h, rtp_c->rtp_protocol);
    if (!th || (th->lower_transport == RTSP_LOWER_TRANSPORT_UDP &&
                th->client_port_min <= 0)) {
        rtsp_reply_error(c, RTSP_STATUS_TRANSPORT);
        return;
    }

    /* setup default options */
    setup.transport_option[0] = '\0';
    dest_addr = rtp_c->from_addr;
    dest_addr.sin_port = htons(th->client_port_min);

    /* setup stream */
    if (rtp_new_av_stream(rtp_c, stream_index, &dest_addr, c) < 0) {
        rtsp_reply_error(c, RTSP_STATUS_TRANSPORT);
        return;
    }

    /* now everything is OK, so we can send the connection parameters */
    rtsp_reply_header(c, RTSP_STATUS_OK);
    /* session ID */
    avio_printf(c->pb, "Session: %s\r\n", rtp_c->session_id);

    switch(rtp_c->rtp_protocol) {
    case RTSP_LOWER_TRANSPORT_UDP:
        rtp_port = ff_rtp_get_local_rtp_port(rtp_c->rtp_handles[stream_index]);
        rtcp_port = ff_rtp_get_local_rtcp_port(rtp_c->rtp_handles[stream_index]);
        avio_printf(c->pb, "Transport: RTP/AVP/UDP;unicast;"
                    "client_port=%d-%d;server_port=%d-%d",
                    th->client_port_min, th->client_port_max,
                    rtp_port, rtcp_port);
        break;
    case RTSP_LOWER_TRANSPORT_TCP:
        avio_printf(c->pb, "Transport: RTP/AVP/TCP;interleaved=%d-%d",
                    stream_index * 2, stream_index * 2 + 1);
        break;
    default:
        break;
    }
    if (setup.transport_option[0] != '\0')
        avio_printf(c->pb, ";%s", setup.transport_option);
    avio_printf(c->pb, "\r\n");

    avio_printf(c->pb, "\r\n");
}

static void rtsp_cmd_play(RTSPContext *c, const char *url, RTSPMessageHeader *h)
{
    RTSPContext *rtp_c;

    rtp_c = find_rtp_session_with_url(url, h->session_id);
    if (!rtp_c) {
        rtsp_reply_error(c, RTSP_STATUS_SESSION);
        return;
    }

    if (rtp_c->state != HTTPSTATE_SEND_DATA &&
        rtp_c->state != HTTPSTATE_WAIT_DATA &&
        rtp_c->state != HTTPSTATE_READY) {
        rtsp_reply_error(c, RTSP_STATUS_STATE);
        return;
    }

    rtp_c->state = HTTPSTATE_SEND_DATA;
    av_log(NULL, AV_LOG_ERROR, "state changed to %d\n", rtp_c->state);
    /* now everything is OK, so we can send the connection parameters */
    rtsp_reply_header(c, RTSP_STATUS_OK);
    /* session ID */
    avio_printf(c->pb, "Session: %s\r\n", rtp_c->session_id);
    avio_printf(c->pb, "\r\n");
}

static void rtsp_cmd_pause(RTSPContext *c, const char *url, RTSPMessageHeader *h)
{
    RTSPContext *rtp_c;

    rtp_c = find_rtp_session_with_url(url, h->session_id);
    if (!rtp_c) {
        rtsp_reply_error(c, RTSP_STATUS_SESSION);
        return;
    }

    if (rtp_c->state != HTTPSTATE_SEND_DATA &&
        rtp_c->state != HTTPSTATE_WAIT_DATA) {
        rtsp_reply_error(c, RTSP_STATUS_STATE);
        return;
    }

    rtp_c->state = HTTPSTATE_READY;
    av_log(NULL, AV_LOG_ERROR, "state changed to %d\n", rtp_c->state);
    rtp_c->first_pts = AV_NOPTS_VALUE;
    /* now everything is OK, so we can send the connection parameters */
    rtsp_reply_header(c, RTSP_STATUS_OK);
    /* session ID */
    avio_printf(c->pb, "Session: %s\r\n", rtp_c->session_id);
    avio_printf(c->pb, "\r\n");
}

/* find an rtp connection by using the session ID. Check consistency
   with filename */
static void rtsp_cmd_teardown(RTSPContext *c, const char *url, RTSPMessageHeader *h)
{
    RTSPContext *rtp_c;

    rtp_c = find_rtp_session_with_url(url, h->session_id);
    if (!rtp_c) {
        rtsp_reply_error(c, RTSP_STATUS_SESSION);
        return;
    }

    /* now everything is OK, so we can send the connection parameters */
    rtsp_reply_header(c, RTSP_STATUS_OK);
    /* session ID */
    avio_printf(c->pb, "Session: %s\r\n", rtp_c->session_id);
    avio_printf(c->pb, "\r\n");

    /* abort the session */
    close_connection(rtp_c);
    c->rtp_client = NULL;
}

static int rtsp_parse_request(RTSPContext *c)
{
    const char *p, *p1, *p2;
    char cmd[32];
    char url[1024];
    char protocol[32];
    char line[1024];
    int len;
    RTSPMessageHeader header1, *header = &header1;

    memset(header, 0, sizeof(*header));
    c->buffer_ptr[0] = '\0';
    p = (char *)c->buffer;

    get_word(cmd, sizeof(cmd), &p);
    get_word(url, sizeof(url), &p);
    get_word(protocol, sizeof(protocol), &p);

    av_strlcpy(c->method, cmd, sizeof(c->method));
    av_strlcpy(c->url, url, sizeof(c->url));
    av_strlcpy(c->protocol, protocol, sizeof(c->protocol));

    if (avio_open_dyn_buf(&c->pb) < 0) {
        /* XXX: cannot do more */
        c->pb = NULL; /* safety */
        return -1;
    }

    /* check version name */
    if (strcmp(protocol, "RTSP/1.0") != 0) {
        rtsp_reply_error(c, RTSP_STATUS_VERSION);
        goto the_end;
    }

    /* parse each header line */
    /* skip to next line */
    while (*p != '\n' && *p != '\0')
        p++;
    if (*p == '\n')
        p++;
    while (*p != '\0') {
        p1 = memchr(p, '\n', (char *)c->buffer_ptr - p);
        if (!p1)
            break;
        p2 = p1;
        if (p2 > p && p2[-1] == '\r')
            p2--;
        /* skip empty line */
        if (p2 == p)
            break;
        len = p2 - p;
        if (len > (int)sizeof(line) - 1)
            len = sizeof(line) - 1;
        memcpy(line, p, len);
        line[len] = '\0';
        ff_rtsp_parse_line(header, line, NULL, NULL);
        p = p1 + 1;
    }

    /* handle sequence number */
    c->seq = header->seq;
    av_log(NULL, AV_LOG_ERROR, "func:%s,line%d,cmd:%s,curtime:%s\n",__func__,__LINE__,cmd,av_ts2str(cur_time));

    if (!strcmp(cmd, "DESCRIBE"))
        rtsp_cmd_describe(c, url);
    else if (!strcmp(cmd, "OPTIONS"))
        rtsp_cmd_options(c, url);
    else if (!strcmp(cmd, "SETUP"))
        rtsp_cmd_setup(c, url, header);
    else if (!strcmp(cmd, "PLAY"))
        rtsp_cmd_play(c, url, header);
    else if (!strcmp(cmd, "PAUSE"))
        rtsp_cmd_pause(c, url, header);
    else if (!strcmp(cmd, "TEARDOWN"))
        rtsp_cmd_teardown(c, url, header);
    else
        rtsp_reply_error(c, RTSP_STATUS_METHOD);

    av_log(NULL, AV_LOG_ERROR, "cmd:%s\n", cmd);
 the_end:
    len = avio_close_dyn_buf(c->pb, &c->pb_buffer);
    c->pb = NULL; /* safety */
    if (len < 0) {
        /* XXX: cannot do more */
        return -1;
    }
    c->buffer_ptr = c->pb_buffer;
    c->buffer_end = c->pb_buffer + len;
    c->state = RTSPSTATE_SEND_REPLY;
    av_log(NULL, AV_LOG_ERROR, "state changed to %d\n", c->state);

    return 0;
}


/* return the server clock (in us) */
static int64_t get_server_clock(RTSPContext *c)
{
    /* compute current pts value from system time */
    return (cur_time - c->start_time) * 1000;
}

/* return the estimated time at which the current packet must be sent
   (in us) */
static int64_t get_packet_send_clock(RTSPContext *c)
{
    int bytes_left, bytes_sent, frame_bytes;

    frame_bytes = c->cur_frame_bytes;
    if (frame_bytes <= 0)
        return c->cur_pts;
    else {
        bytes_left = c->buffer_end - c->buffer_ptr;
        bytes_sent = frame_bytes - bytes_left;
        return c->cur_pts + (c->cur_frame_duration * bytes_sent) / frame_bytes;
    }
}

static int http_prepare_data(RTSPContext *c)
{
    int i, len, ret;
    AVFormatContext *ctx;

    av_freep(&c->pb_buffer);
    switch(c->state) {
    case HTTPSTATE_SEND_DATA_HEADER:
        memset(&c->fmt_ctx, 0, sizeof(c->fmt_ctx));
        av_dict_set(&c->fmt_ctx.metadata, "author"   , c->stream->author   , 0);
        av_dict_set(&c->fmt_ctx.metadata, "comment"  , c->stream->comment  , 0);
        av_dict_set(&c->fmt_ctx.metadata, "copyright", c->stream->copyright, 0);
        av_dict_set(&c->fmt_ctx.metadata, "title"    , c->stream->title    , 0);

        c->fmt_ctx.streams = av_mallocz(sizeof(AVStream *) * c->stream->nb_streams);

        for(i=0;i<c->stream->nb_streams;i++) {
            AVStream *src;
            c->fmt_ctx.streams[i] = av_mallocz(sizeof(AVStream));
            /* if file or feed, then just take streams from FFStream struct */
            if (!c->stream->feed ||
                c->stream->feed == c->stream)
                src = c->stream->streams[i];
            else
                src = c->stream->feed->streams[c->stream->feed_streams[i]];

            *(c->fmt_ctx.streams[i]) = *src;
            c->fmt_ctx.streams[i]->priv_data = 0;
            c->fmt_ctx.streams[i]->codec->frame_number = 0; /* XXX: should be done in
                                           AVStream, not in codec */
        }
        /* set output format parameters */
        c->fmt_ctx.oformat = c->stream->fmt;
        c->fmt_ctx.nb_streams = c->stream->nb_streams;

        c->got_key_frame = 0;

        /* prepare header and save header data in a stream */
        if (avio_open_dyn_buf(&c->fmt_ctx.pb) < 0) {
            /* XXX: potential leak */
            return -1;
        }
        c->fmt_ctx.pb->seekable = 0;

        /*
         * HACK to avoid mpeg ps muxer to spit many underflow errors
         * Default value from FFmpeg
         * Try to set it use configuration option
         */
        c->fmt_ctx.max_delay = (int)(0.7*AV_TIME_BASE);

        if (avformat_write_header(&c->fmt_ctx, NULL) < 0) {
            rtsp_log("Error writing output header\n");
            return -1;
        }
        av_dict_free(&c->fmt_ctx.metadata);

        len = avio_close_dyn_buf(c->fmt_ctx.pb, &c->pb_buffer);
        c->buffer_ptr = c->pb_buffer;
        c->buffer_end = c->pb_buffer + len;

        c->state = HTTPSTATE_SEND_DATA;
        av_log(NULL, AV_LOG_ERROR, "state changed to %d\n", c->state);
        c->last_packet_sent = 0;
        break;
    case HTTPSTATE_SEND_DATA:
        if (c->stream->max_time &&
            c->stream->max_time + c->start_time < cur_time )
        {
            /* We have timed out */
            c->state = HTTPSTATE_SEND_DATA_TRAILER;
            av_log(NULL, AV_LOG_ERROR, "state changed to %d\n", c->state);
        }
        else {
            AVPacket pkt;
        redo:
            ret = rtsp_read_pkt(c->rtsp_source, &pkt);
            if (ret ==  AVERROR(EAGAIN))
                return 1;
            else if(ret < 0)
            {
                av_log(NULL, AV_LOG_ERROR, "rtspswitch read pkt faile\n");
                return -2;
            }
            else
            {
                AVCodecContext *codec;
                AVStream *ist, *ost;
                int source_index = pkt.stream_index;

                /* update first pts if needed */
                if (c->first_pts == (int64_t)AV_NOPTS_VALUE) {
                    c->first_pts = av_rescale_q(pkt.dts, c->fmt_in->streams[pkt.stream_index]->time_base, AV_TIME_BASE_Q);
                    c->start_time = cur_time;
                }

                ist = c->fmt_in->streams[source_index];
                /* specific handling for RTP: we use several
                   output stream (one for each RTP
                   connection). XXX: need more abstract handling */
                if (c->is_packetized) {
#if 0
                    /* compute send time and duration */
                    c->cur_pts = av_rescale_q(pkt.dts, ist->time_base, AV_TIME_BASE_Q);
                    c->cur_pts -= c->first_pts;
                    c->cur_frame_duration = av_rescale_q(pkt.duration, ist->time_base, AV_TIME_BASE_Q);
#endif
                    /* we send as many as we received */
                    c->cur_pts = get_server_clock(c) + !ret;
                    c->cur_frame_duration = 0;

                    /* find RTP context */
                    c->packet_stream_index = pkt.stream_index;
                    ctx = c->rtp_ctx[c->packet_stream_index];
                    if(!ctx) {
                        av_log(NULL, AV_LOG_ERROR, "func:%s,line%d,unkown stream index\n",__func__,__LINE__);
                        break;
                    }
                    codec = ctx->streams[0]->codec;

                    /* only one stream per RTP connection */
                    pkt.stream_index = 0;
                } else {
                    ctx = &c->fmt_ctx;
                    /* Fudge here */
                    codec = ctx->streams[pkt.stream_index]->codec;
                }

                if (c->is_packetized) {
                    int max_packet_size;
                    if (c->rtp_protocol == RTSP_LOWER_TRANSPORT_TCP)
                        max_packet_size = RTSP_TCP_MAX_PACKET_SIZE;
                    else
                        max_packet_size = c->rtp_handles[c->packet_stream_index]->max_packet_size;
                    ret = ffio_open_dyn_packet_buf(&ctx->pb, max_packet_size);
                } else {
                    ret = avio_open_dyn_buf(&ctx->pb);
                }

                if (ret < 0) {
                    /* XXX: potential leak */
                    return -1;
                }
                ost = ctx->streams[pkt.stream_index];

                ctx->pb->seekable = 0;
                if (pkt.dts != (int64_t)AV_NOPTS_VALUE)
                    pkt.dts = av_rescale_q(pkt.dts, ist->time_base, ost->time_base);
                if (pkt.pts != (int64_t)AV_NOPTS_VALUE)
                    pkt.pts = av_rescale_q(pkt.pts, ist->time_base, ost->time_base);
                pkt.duration = av_rescale_q(pkt.duration, ist->time_base, ost->time_base);
                if (av_write_frame(ctx, &pkt) < 0) {
                    c->state = HTTPSTATE_SEND_DATA_TRAILER;
                    av_log(NULL, AV_LOG_ERROR, "state changed to %d\n", c->state);
                }
#ifdef DEBUG
                av_log(NULL, AV_LOG_ERROR, "av_write_frame to packetize, size:%d, ts:%lld\n", pkt.size, pkt.pts);
#endif

                len = avio_close_dyn_buf(ctx->pb, &c->pb_buffer);
                c->cur_frame_bytes = len;
                c->buffer_ptr = c->pb_buffer;
                c->buffer_end = c->pb_buffer + len;

                codec->frame_number++;
                if (len == 0) {
                    goto redo;
                }
            }
        }
        break;
    default:
    case HTTPSTATE_SEND_DATA_TRAILER:
        /* last packet test ? */
        if (c->last_packet_sent || c->is_packetized)
            return -1;
        ctx = &c->fmt_ctx;
        /* prepare header */
        if (avio_open_dyn_buf(&ctx->pb) < 0) {
            /* XXX: potential leak */
            return -1;
        }
        c->fmt_ctx.pb->seekable = 0;
        av_write_trailer(ctx);
        len = avio_close_dyn_buf(ctx->pb, &c->pb_buffer);
        c->buffer_ptr = c->pb_buffer;
        c->buffer_end = c->pb_buffer + len;

        c->last_packet_sent = 1;
        break;
    }
    return 0;
}

static void update_datarate(DataRateData *drd, int64_t count)
{
    if (!drd->time1 && !drd->count1) {
        drd->time1 = drd->time2 = cur_time;
        drd->count1 = drd->count2 = count;
    } else if (cur_time - drd->time2 > 5000) {
        drd->time1 = drd->time2;
        drd->count1 = drd->count2;
        drd->time2 = cur_time;
        drd->count2 = count;
    }
}

/* should convert the format at the same time */
/* send data starting at c->buffer_ptr to the output connection
   (either UDP or TCP connection) */
static int http_send_data(RTSPContext *c)
{
    int len, ret;

    for(;;) {
        if (c->buffer_ptr >= c->buffer_end) {
            ret = http_prepare_data(c);
            // av_log(NULL, AV_LOG_ERROR, "http prepare data ret:%d\n", ret);
            if (ret < 0)
            {
                av_log(NULL, AV_LOG_ERROR, "http prepare data failed, now to send goodbye packet, ret:%d\n", ret);
#ifdef DEBUG_MPLAYER
                // need to send rtcp goodbye
                if (-2 == ret)
                {
                    char buf[40] = {0};
                    int interleaved_index;
                    int position = 0;
                    RTSPContext *rtsp_c;
                    rtsp_c = c->rtsp_c;
                    /* if no RTSP connection left, error */
                    if (!rtsp_c)
                    {
                        av_log(NULL, AV_LOG_ERROR, "rtsp client left\n");
                        return -1;
                    }

                    interleaved_index = c->packet_stream_index * 2;
                    // interleaved_index++;

                    /* write RTSP TCP header */
                    buf[position++] = '$';
                    buf[position++] = interleaved_index;
                    buf[position++] = 0;
                    buf[position++] = 36;

                    buf[position++] = 0x80;
                    buf[position++] = 0xc8;
                    buf[position++] = 0x00;
                    buf[position++] = 0x6;

                    // ssrc
                    memcpy(&buf[position++], c->rtcp_buf, 4);

                    // 28 + 4
                    buf[32] = 0x81;
                    buf[33] = 0xcb;
                    buf[34] = 0x0;
                    buf[35] = 0x1;

                    // ssrc
                    memcpy(&buf[36], c->rtcp_buf, 4);

                    /* send everything we can NOW */
                    len = sizeof(buf);
                    len = send(rtsp_c->fd, buf, 40, 0);
                    if (len < 0)
                    {
                        video_loge("send failed,errno:%d\n", errno);
                    }
                    
                    sleep(1);
                    close(rtsp_c->fd);
                }
#endif
                return -1;
            }
            else if (ret != 0)
                /* state change requested */
                break;
        } else {
            if (c->is_packetized) {
                /* RTP data output */
                len = c->buffer_end - c->buffer_ptr;
                if (len < 4) {
                    /* fail safe - should never happen */
                fail1:
                    c->buffer_ptr = c->buffer_end;
                    return 0;
                }

                len = (c->buffer_ptr[0] << 24) |
                    (c->buffer_ptr[1] << 16) |
                    (c->buffer_ptr[2] << 8) |
                    (c->buffer_ptr[3]);
                if (len > (c->buffer_end - c->buffer_ptr))
                    goto fail1;
                if ((get_packet_send_clock(c) - get_server_clock(c)) > 0) {
                    /* nothing to send yet: we can wait */
                    // return 0;
                    // av_log(NULL, AV_LOG_ERROR, "time need to send next packet\n");
                }

                c->data_count += len;
                update_datarate(&c->datarate, c->data_count);
                if (c->stream)
                    c->stream->bytes_served += len;

                if (c->rtp_protocol == RTSP_LOWER_TRANSPORT_TCP) {
                    /* RTP packets are sent inside the RTSP TCP connection */
                    AVIOContext *pb;
                    int interleaved_index, size;
                    uint8_t header[4];
                    RTSPContext *rtsp_c;

                    rtsp_c = c->rtsp_c;
                    /* if no RTSP connection left, error */
                    if (!rtsp_c)
                    {
                        av_log(NULL, AV_LOG_ERROR, "rtsp client left\n");
                        return -1;
                    }

                    /* if already sending something, then wait. */
                    if (rtsp_c->state != RTSPSTATE_WAIT_REQUEST)
                        break;

                    if (avio_open_dyn_buf(&pb) < 0)
                        goto fail1;
                    // av_log(NULL, AV_LOG_ERROR, "*************%p - %p\n", pb->buf_end, pb->buf_ptr);
                    interleaved_index = c->packet_stream_index * 2;
                    /* RTCP packets are sent at odd indexes */
                    if (c->buffer_ptr[1] == 200)
                    {
                        interleaved_index++;
                        video_loge("send one rtcp pakcet\n");
                    }

                    // cpy ssrc
                    memcpy(c->rtcp_buf, c->buffer_ptr + 4 + 8, 4);

                    /* write RTSP TCP header */
                    header[0] = '$';
                    header[1] = interleaved_index;
                    header[2] = len >> 8;
                    header[3] = len;
                    avio_write(pb, header, 4);

                    /* write RTP packet data */
                    c->buffer_ptr += 4;
                    avio_write(pb, c->buffer_ptr, len);
                    size = avio_close_dyn_buf(pb, &c->packet_buffer);
                    /* prepare asynchronous TCP sending */
                    rtsp_c->packet_buffer_ptr = c->packet_buffer;
                    rtsp_c->packet_buffer_end = c->packet_buffer + size;
                    c->buffer_ptr += len;

#ifdef DEBUG
                    {
                        if (rtsp_c->packet_buffer_ptr[5] & 0x80)
                        {
                            struct timeval tv;
                            uint32_t ts = *(uint32_t *)(rtsp_c->packet_buffer_ptr + 8);
                            gettimeofday(&tv, NULL);
                            video_loge("send one frame,ts:%u, now time:%ld\n", ntohl(ts), tv.tv_sec * 1000 + tv.tv_usec / 1000);
                        }
                    }
#endif

                    /* send everything we can NOW */
                    len = send(rtsp_c->fd, rtsp_c->packet_buffer_ptr,
                                rtsp_c->packet_buffer_end - rtsp_c->packet_buffer_ptr, 0);
                    if (len > 0)
                        rtsp_c->packet_buffer_ptr += len;

                    if (rtsp_c->packet_buffer_ptr < rtsp_c->packet_buffer_end) {
                        /* if we could not send all the data, we will
                           send it later, so a new state is needed to
                           "lock" the RTSP TCP connection */
                        rtsp_c->state = RTSPSTATE_SEND_PACKET;
                        av_log(NULL, AV_LOG_ERROR, "state changed to %d\n", rtsp_c->state);
                        break;
                    } else
                        /* all data has been sent */
                        av_freep(&c->packet_buffer);
                } else {
                    /* send RTP packet directly in UDP */
                    URLContext *h = c->rtp_handles[c->packet_stream_index];
                    c->buffer_ptr += 4;
                    ret = h->prot->url_write(h, c->buffer_ptr, len);
                    if(ret == AVERROR(EAGAIN)) {
                        av_log(NULL, AV_LOG_INFO, "line:%d,url write require retry\n",__LINE__);
                        continue;
                    }
                    else if(ret < 0) {
                        av_log(NULL, AV_LOG_ERROR, "url write return error:%d\n",ret);
                        return -1;
                    }
                    c->buffer_ptr += len;
                    /* here we continue as we can send several packets per 10 ms slot */
                }
            } else {
                /* TCP data output */
                len = send(c->fd, c->buffer_ptr, c->buffer_end - c->buffer_ptr, 0);
                if (len < 0) {
                    if (ff_neterrno() != AVERROR(EAGAIN) &&
                        ff_neterrno() != AVERROR(EINTR))
                    {
                        /* error : close connection */
                        av_log(NULL, AV_LOG_ERROR, "send data failed\n");
                        return -1;
                    }
                    else
                        return 0;
                } else
                    c->buffer_ptr += len;

                c->data_count += len;
                update_datarate(&c->datarate, c->data_count);
                if (c->stream)
                    c->stream->bytes_served += len;
                break;
            }
        }
    } /* for(;;) */
    return 0;
}

static int http_receive_data(RTSPContext *c)
{
    c = c;
    return 0;
}

static int handle_connection(RTSPContext *c)
{
    int len, ret;

    switch(c->state)
    {
    case RTSPSTATE_WAIT_REQUEST:
        /* timeout ? */
        if (c->timeout < cur_time)
        {
            av_log(NULL, AV_LOG_ERROR, "time out\n");
            return -1;
        }
        if (c->poll_entry->revents & (POLLERR | POLLHUP))
        {
            av_log(NULL, AV_LOG_ERROR, "err events\n");
            return -1;
        }

        /* no need to read if no events */
        if (!(c->poll_entry->revents & POLLIN))
            return 0;

        /* read the data */
    read_loop:
        len = recv(c->fd, c->buffer_ptr, 1, 0);
        if (len < 0) {
            if (ff_neterrno() != AVERROR(EAGAIN) &&
                ff_neterrno() != AVERROR(EINTR))
            {
                video_loge("rtsp_switch fd recv fialed,errno:%d\n", errno);
                return -1;
            }
        }
        else if (len == 0) {
            return -1;
        }
        else
        {
            /* search for end of request. */
            uint8_t *ptr;
            c->buffer_ptr += len;
            ptr = c->buffer_ptr;
            if ((ptr >= c->buffer + 2 && !memcmp(ptr-2, "\n\n", 2)) ||
                (ptr >= c->buffer + 4 && !memcmp(ptr-4, "\r\n\r\n", 4))) {
                /* request found : parse it and reply */
                ret = rtsp_parse_request(c);
                if (ret < 0)
                    return -1;
            } else if (ptr >= c->buffer_end) {
                /* request too long: cannot do anything */
                av_log(NULL, AV_LOG_ERROR, "request too long: cannot do anything\n");
                return -1;
            } else goto read_loop;
        }
        break;

    case HTTPSTATE_SEND_HEADER:
        if (c->poll_entry->revents & (POLLERR | POLLHUP))
        {
            av_log(NULL, AV_LOG_ERROR, "err events\n");
            return -1;
        }

        /* no need to write if no events */
        if (!(c->poll_entry->revents & POLLOUT))
            return 0;
        len = send(c->fd, c->buffer_ptr, c->buffer_end - c->buffer_ptr, 0);
        if (len < 0) {
            if (ff_neterrno() != AVERROR(EAGAIN) &&
                ff_neterrno() != AVERROR(EINTR)) {
                /* error : close connection */
                av_freep(&c->pb_buffer);
                av_log(NULL, AV_LOG_ERROR, "send data failed\n");
                return -1;
            }
        } else {
            c->buffer_ptr += len;
            if (c->stream)
                c->stream->bytes_served += len;
            c->data_count += len;
            if (c->buffer_ptr >= c->buffer_end) {
                av_freep(&c->pb_buffer);
                /* if error, exit */
                if (c->http_error)
                {
                    av_log(NULL, AV_LOG_ERROR, "http error\n");
                    return -1;
                }
                /* all the buffer was sent : synchronize to the incoming stream */
                c->state = HTTPSTATE_SEND_DATA_HEADER;
                c->buffer_ptr = c->buffer_end = c->buffer;
                av_log(NULL, AV_LOG_ERROR, "state changed to %d\n", c->state);
            }
        }
        break;

    case HTTPSTATE_SEND_DATA:
    case HTTPSTATE_SEND_DATA_HEADER:
    case HTTPSTATE_SEND_DATA_TRAILER:
        /* for packetized output, we consider we can always write (the
           input streams sets the speed). It may be better to verify
           that we do not rely too much on the kernel queues */
        if (!c->is_packetized) {
            if (c->poll_entry->revents & (POLLERR | POLLHUP))
            {
                av_log(NULL, AV_LOG_ERROR, "session is not packetized, and have err event\n");
                return -1;
            }

            /* no need to read if no events */
            if (!(c->poll_entry->revents & POLLOUT))
                return 0;
        }

        if (http_send_data(c) < 0)
        {
            av_log(NULL, AV_LOG_ERROR, "http send data failed\n");
            return -1;
        }

        /* close connection if trailer sent */
        if (c->state == HTTPSTATE_SEND_DATA_TRAILER)
        {
            av_log(NULL, AV_LOG_ERROR, "session now is send_data_trailer, to close\n");
            return -1;
        }
        break;

    case HTTPSTATE_RECEIVE_DATA:
        /* no need to read if no events */
        if (c->poll_entry->revents & (POLLERR | POLLHUP))
        {
            av_log(NULL, AV_LOG_ERROR, "event error\n");
            return -1;
        }
        if (!(c->poll_entry->revents & POLLIN))
            return 0;
        if (http_receive_data(c) < 0)
        {
            av_log(NULL, AV_LOG_ERROR, "recevie data failed\n");
            return -1;
        }
        break;
    case HTTPSTATE_WAIT_DATA:
        /* no need to read if no events */
        if (c->poll_entry->revents & (POLLIN | POLLERR | POLLHUP))
        {
            av_log(NULL, AV_LOG_ERROR, "event error\n");
            return -1;
        }

        /* nothing to do, we'll be waken up by incoming feed packets */
        break;

    case RTSPSTATE_SEND_REPLY:
        if (c->poll_entry->revents & (POLLERR | POLLHUP)) {
            av_freep(&c->pb_buffer);
            av_log(NULL, AV_LOG_ERROR, "event error\n");
            return -1;
        }
        /* no need to write if no events */
        len = send(c->fd, c->buffer_ptr, c->buffer_end - c->buffer_ptr, 0);
        if (len < 0) {
            if (ff_neterrno() != AVERROR(EAGAIN) &&
                ff_neterrno() != AVERROR(EINTR)) {
                /* error : close connection */
                av_freep(&c->pb_buffer);
                av_log(NULL, AV_LOG_ERROR, "event error\n");
                return -1;
            }
        } else {
            c->buffer_ptr += len;
            c->data_count += len;
            if (c->buffer_ptr >= c->buffer_end) {
                /* all the buffer was sent : wait for a new request */
                av_freep(&c->pb_buffer);
                start_wait_request(c);
            }
        }
        break;

    case RTSPSTATE_SEND_PACKET:
        if (c->poll_entry->revents & (POLLERR | POLLHUP)) {
            av_freep(&c->packet_buffer);
            av_log(NULL, AV_LOG_ERROR, "event error\n");
            return -1;
        }
        /* no need to write if no events */
        if (!(c->poll_entry->revents & POLLOUT))
            return 0;
        len = send(c->fd, c->packet_buffer_ptr,
                    c->packet_buffer_end - c->packet_buffer_ptr, 0);
        if (len < 0) {
            if (ff_neterrno() != AVERROR(EAGAIN) &&
                ff_neterrno() != AVERROR(EINTR)) {
                /* error : close connection */
                av_freep(&c->packet_buffer);
                av_log(NULL, AV_LOG_ERROR, "send packet failed\n");
                return -1;
            }
        } else {
            c->packet_buffer_ptr += len;
            if (c->packet_buffer_ptr >= c->packet_buffer_end) {
                /* all the buffer was sent : wait for a new request */
                av_freep(&c->packet_buffer);
                c->state = RTSPSTATE_WAIT_REQUEST;
                av_log(NULL, AV_LOG_ERROR, "state changed to %d\n", c->state);
            }
        }
        break;

    case HTTPSTATE_READY:
        /* nothing to do */
        break;

    default:
        av_log(NULL, AV_LOG_ERROR, "unkwon state\n");
        return -1;
    }

    return 0;
}

/*
 * connect to android phone
 */
static int connect_adb(struct client_data *data, int port)
{
    int    fd;
    struct sockaddr_un addr;
    int    hasa = data->hasa;

    if(!hasa) {
        av_log(NULL, AV_LOG_WARNING, "Please check data->hasa before call connect_adb!!!\n");
        return -1;
    }
    else
    {
        adb_forward(port);
        fd = socket(AF_UNIX, SOCK_STREAM, 0);
        if (fd < 0)
        {
            video_loge("connect adb,create socket failed, errno:%d\n", errno);
            return -1;
        }

        addr.sun_family      = AF_UNIX;
        snprintf(addr.sun_path, sizeof(addr.sun_path), LOCAL_SOCKET_FMT, port);

        if(connect(fd, (struct sockaddr *) &addr, sizeof(addr)) < 0) {
            av_log(NULL, AV_LOG_ERROR, "connect to adb port:%d failed. adb disconneted?\n", port + 1);
            close(fd);
            return -1;
        }
        fcntl(fd, F_SETFL, fcntl(fd, F_GETFL) | O_NONBLOCK);

        return fd;
    }
}

/*
 * connect to iphone
 */
static int connect_iphone(struct client_data *data, int port)
{
    int fd;

    if((fd = usbmuxd_connect(data->handle, port)) < 0) {
        av_log(NULL, AV_LOG_DEBUG, "connect to iphone failed. port:%d\n", port);
        return -1;
    } else {
        av_log(NULL, AV_LOG_INFO, "connect to iphone success. port:%d\n", port);
        return fd;
    }
}

/*
 * deal phone connect
 */
static void rs_deal_phone_connect(struct client_data *cdata, int64_t current_time)
{
    // do connect every 500ms
    if (cdata->last_connect_time + 1000 > current_time)
    {
        return;
    }

    cdata->last_connect_time = current_time;
    if (cdata->ifd < 0 && cdata->hasi)
    {
        cdata->ifd = connect_iphone(cdata, cdata->rtsp_port);
        if(cdata->ifd >= 0)
          new_connection(cdata->ifd, TRANS_USBMUXD);
    }

    // if have android phone
    if (cdata->afd < 0 && cdata->hasa)
    {
        cdata->afd = connect_adb(cdata, cdata->rtsp_port);
        if(cdata->afd >= 0)
          new_connection(cdata->afd, TRANS_ADB);
    }
}

static struct client_data cdata;
/*
 * rtsp switch server
 */
void *rtsp_switch_task(void *arg)
{
    struct pollfd      *poll_table, *poll_entry;
    struct sockaddr_in my_rtsp_addr;
    int                delay, delay1, ret;
    RTSPContext        *c, *c_next;
    struct sched_param tsched;
    uint16_t port       = 54540;

    rtsp_init_awaken();
    av_log(NULL, AV_LOG_ERROR, "rtsp_switch_task ready, arg:%p, tid:%ld\n", arg, syscall(SYS_gettid));
    ret = prctl(PR_SET_NAME, "RtspSwitchTask");
    if (0 != ret)
    {
        av_log(NULL, AV_LOG_ERROR, "set thread name failed,errno:%d\n", errno);
    }

    tsched.sched_priority = 90;
    ret = pthread_setschedparam(pthread_self(), SCHED_RR, &tsched);
    if (0 != ret)
    {
        av_log(NULL, AV_LOG_ERROR, "set thread policy failed ,errno:%d\n", ret);
    }

    cur_time = av_gettime() / 1000;
    av_lfg_init(&random_state, av_get_random_seed());
    av_log(NULL, AV_LOG_ERROR, "rtsp switch port:%u\n", port);
    av_log_set_level(AV_LOG_INFO);

    // poll
    if(!(poll_table = av_mallocz((16 + 2)*sizeof(*poll_table)))) {
        av_log(NULL, AV_LOG_ERROR, "Impossible to allocate a poll table handling %d connections.\n", nb_max_connections);
        return NULL;
    }

    cdata.rtsp_port = port;
    // cdata.hasa = 1;
    cdata.ifd = -1;
    cdata.afd = -1;
    my_rtsp_addr.sin_port = htons(port);
    my_rtsp_addr.sin_addr.s_addr = htonl(INADDR_ANY);
    if((cdata.rtsp_server_fd = socket_open_listen(&my_rtsp_addr)) < 0) {
        av_log(NULL, AV_LOG_ERROR, "listen fd error\n");
        return NULL;
    }
    if((cdata.local_server_fd = unix_socket_open_listen("/var/run/usb_proxy_svr_554")) < 0) {
        av_log(NULL, AV_LOG_ERROR, "listen local fd error\n");
        return NULL;
    }

    for(;;) {
        poll_entry = poll_table;
        if (cdata.rtsp_server_fd) {
            poll_entry->fd = cdata.rtsp_server_fd;
            poll_entry->events = POLLIN;
            poll_entry++;
        }
        if (cdata.local_server_fd) {
            poll_entry->fd = cdata.local_server_fd;
            poll_entry->events = POLLIN;
            poll_entry++;
        }

        poll_add_awaken(poll_entry);
        poll_entry++;

        /* wait for events on each HTTP handle */
        c = first_http_ctx;
        delay = 10;
        while (c != NULL) {
            int fd;
            fd = c->fd;
            switch(c->state) {
            case HTTPSTATE_SEND_HEADER:
            case RTSPSTATE_SEND_REPLY:
            case RTSPSTATE_SEND_PACKET:
                c->poll_entry = poll_entry;
                poll_entry->fd = fd;
                poll_entry->events = POLLOUT;
                poll_entry++;
                break;
            case HTTPSTATE_SEND_DATA_HEADER:
            case HTTPSTATE_SEND_DATA:
            case HTTPSTATE_SEND_DATA_TRAILER:
                if (c->is_packetized) {
                    /* for TCP, we output as much as we can (may need to put a limit) */
                    c->poll_entry = poll_entry;
                    poll_entry->fd = fd;
                    poll_entry->events = POLLOUT;
                    poll_entry++;
                } else {
                    /* when ffserver is doing the timing, we work by
                       looking at which packet need to be sent every
                       10 ms */
                    delay1 = 10; /* one tick wait XXX: 10 ms assumed */
                    if (delay1 < delay)
                        delay = delay1;
                }
                break;
            case HTTPSTATE_WAIT_REQUEST:
            case HTTPSTATE_RECEIVE_DATA:
            case HTTPSTATE_WAIT_DATA:
            case RTSPSTATE_WAIT_REQUEST:
                /* need to catch errors */
                c->poll_entry = poll_entry;
                poll_entry->fd = fd;
                poll_entry->events = POLLIN;/* Maybe this will work */
                poll_entry++;
                break;
            default:
                c->poll_entry = NULL;
                break;
            }
            c = c->next;
        }

        /* wait for an event on one connection. We poll at least every
           second to handle timeouts */
        do {
            ret = poll(poll_table, poll_entry - poll_table, 10);
            if (ret < 0 && EINTR != errno)
            {
                av_log(NULL, AV_LOG_ERROR, "rtsp_switch_task exit, fatal error, errno:%d\n", errno);
                return NULL;
            }
        } while (ret < 0);

        cur_time = av_gettime() / 1000;

        /* now handle the events */
        for(c = first_http_ctx; c != NULL; c = c_next)
        {
            c_next = c->next;
            ret = handle_connection(c);
            if ( (ret < 0) || (c->medium == TRANS_USBMUXD && !cdata.hasi)
                            || ((c->medium == TRANS_ADB) && !cdata.hasa)) {
                /* close and free the connection */
                if(c->medium == TRANS_USBMUXD)
                    cdata.ifd = -1;
                else if(c->medium == TRANS_ADB)
                    cdata.afd = -1;

                video_loge("close connection[%p] now, has android:%d\n", c, cdata.hasa);
                log_connection(c);
                close_connection(c);
            }
        }
        poll_entry = poll_table;
        if (cdata.rtsp_server_fd) {
            /* new RTSP connection request ? */
            if (poll_entry->revents & POLLIN)
                new_connection(cdata.rtsp_server_fd, TRANS_NETWORK);
            poll_entry++;
        }
        if (cdata.local_server_fd) {
            /* new RTSP connection request ? */
            if (poll_entry->revents & POLLIN)
                new_connection(cdata.local_server_fd, TRANS_UNIX_SOCKET);
            poll_entry++;
        }
        refresh_awaken(poll_entry);

        rs_deal_phone_connect(&cdata, cur_time);
    }

    av_log(NULL, AV_LOG_ERROR, "rtsp switch task exit\n");
    return NULL;
}



/// rtsp_switch task
static pthread_t rtsp_switch_task_id;

/*
 * rtsp switch submodule init
 */
int rtsp_switch_init(uint16_t port)
{
    int ret;

    memset(&cdata, 0, sizeof(cdata));

    ret = pthread_create(&rtsp_switch_task_id, NULL, rtsp_switch_task, NULL);
    if (0 != ret)
    {
        av_log(NULL, AV_LOG_ERROR, "rtsp switch create task failed, errno:%d\n", errno);
        return -1;
    }

    av_log(NULL, AV_LOG_ERROR, "rtsp switch init successfully, port:%u\n", port);

    return ret;
}

/*
 * set phone connect status
 */
void rs_set_phone_status(int hasios, int hasadb, int handle)
{
    cdata.hasi = hasios;
    cdata.hasa = hasadb;
    cdata.handle = handle;
}

