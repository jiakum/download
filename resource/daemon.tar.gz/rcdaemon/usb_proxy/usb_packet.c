#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <pthread.h>
#include "list.h"
#include "usb_packet.h"

#define log(format, ...)        printf("%s:%d "format"\n", __func__, __LINE__, ##__VA_ARGS__)

static inline int usb_packet_check_header(uint8_t *buf)
{
    struct usb_packet_header *header = (struct usb_packet_header *)buf;
    return header->sig == SIG_MAGIC_NUMBER
        && header->crc == calc_crc8((uint8_t *)header, sizeof(struct usb_packet_header)-1);
}

static uint8_t pktbuf[DEV_MRU] = {0};
static uint32_t pktlen = 0;

uint8_t *usb_packet_get_next()
{
    return pktbuf + pktlen;
}

void usb_packet_reset()
{
    pktlen = 0;
}

static int (*usb_packet_on_recv)(uint8_t *buf, int len) = NULL;

void usb_packet_register_callback_on_recv(int (*callback)(uint8_t *buf, int len))
{
    usb_packet_on_recv = callback;
}

void usb_packet_dispatch(int length)
{
    static int64_t correct = 0;
    int i = 0;

        static int count = -1;
        static int64_t last = 0;
        if (get_current_time() > last + 1000) {
            if (last != 0) {
                int temp = (int)(get_current_time() - last);
                log("rx speed: %d KB/s correct %lld bytes", count/temp, correct);
            }
            last = get_current_time();
            count = 0;
        }

    //log("pkt in: %d + %d = %d", pktlen, length, pktlen+length);
    pktlen += length;

    while (i+sizeof(struct usb_packet_header) < pktlen) {
        if (usb_packet_check_header(&pktbuf[i])) {
            struct usb_packet_header *hdr = (struct usb_packet_header*)(&pktbuf[i]);
            int size = hdr->len + sizeof(struct usb_packet_header);
            //log("pkt found: pktlen=%d i=%d pkt size=%d", pktlen, i, size);
            if (pktlen - i >= size) {
                if (usb_packet_on_recv) {
                    usb_packet_on_recv((uint8_t *)hdr, size);   
                }
                i += size;
                count += size;
                correct += size;
            } else {
                break;
            }
        } else {
            i++;
        }
    }
    //log("pkt out: %d - %d = %d", pktlen, i, pktlen-i);
    pktlen -= i;
    memcpy(pktbuf, pktbuf+i, pktlen);
}
