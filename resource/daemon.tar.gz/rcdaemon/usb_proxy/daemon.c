#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <errno.h>
#include <sys/types.h>
#include <poll.h>
#include <libusb-1.0/libusb.h>
#include "android_open_accessory.h"
#include "epoll_context.h"
#include "utils.h"
#include "priv.h"
#include "rctimer.h"

static struct libusb_context *android_context = NULL;

libusb_device *find_iphone(struct libusb_device **devs, int size)
{
    return NULL;
}

void check_usb_devices()
{
    struct libusb_device **devs;
    struct libusb_device *dev;
    int cnt = 0;
    int has_aoa = 0;
    int has_iphone = 0;

    if (RUN_ONCE_IN_LAST_MS(2000)) {
        return;
    }
    
    cnt = libusb_get_device_list(android_context, &devs);
    if (cnt < 0) {
        log("get device list failed, error code=%d", cnt);
        return;
    }

    log("here %d", cnt);

    if ((dev = find_iphone(devs, cnt)) != NULL) {
        has_iphone = 1;
    } else if ((dev = find_android_accessory(devs, cnt)) != NULL) {
        has_aoa = 1;
        android_accessory_on_connect(dev);
    } else if ((dev = find_android_phone(devs, cnt)) != NULL) {
        android_switch_accessory(dev);
    }

    if (!has_aoa) {
        android_accessory_on_disconnect();
    }
    if (!has_iphone) {
        //iphone_on_disconnect();
    }

    libusb_free_device_list(devs, 1);
}


extern int uevent_init();
extern int handle_uevent(int fd);
extern void uevent_deinit();
extern int client_init();
extern void client_deinit();

int main(int argc, char *argv[])
{
    int ret = 0;
    int uevent_netlink_sock = -1;

    log("Version:%s %s", __DATE__, __TIME__);

    uevent_netlink_sock = uevent_init();
    if ( uevent_netlink_sock < 0) {
        log("init uevent link failed");
        goto error;
    }

    if (client_init() < 0) {
        log("init client proxy failed");
        goto error;
    }

    ret = libusb_init(&android_context);
    if (ret != 0) {
        log("libusb_init failed");
        goto error;
    }

    struct pollfd *fds;
    int fd_cnt = 0;
    while (1) {
        int i = 0;
        const struct libusb_pollfd **usbfds;
        const struct libusb_pollfd **p;
        usbfds = libusb_get_pollfds(android_context);
        if(!usbfds) {
            log("libusb_get_pollfds failed");
            continue;
        }
        p = usbfds;
        fd_cnt = 0;
        while(*p) {
            fd_cnt++;
            p++;
        }

        fds = malloc(sizeof(struct pollfd) * (fd_cnt+1));

        p = usbfds;
        fds[0].fd = uevent_netlink_sock;
        fds[0].events = POLLIN;
        fds[0].revents = 0;
        i = 1;
        while(*p) {
            fds[i].fd = (*p)->fd;
            fds[i].events = (*p)->events;
            fds[i].revents = 0;
            i++;
            p++;
        }
        free(usbfds);

        i = poll(fds, fd_cnt+1, 500);
        if (i<0) {
            log("poll error: ret = %d", i);
            continue;
        } else if (i>0) {
            for (i = 0; i < fd_cnt+1; ++i) {
                if (fds[i].revents) {
                    if (fds[i].fd == uevent_netlink_sock) {
                        handle_uevent(uevent_netlink_sock);
                    } else {
                        libusb_handle_events(android_context);
                    }
                }
            }
        }

        free(fds);
        check_usb_devices();
    }

error:
    if (android_context) {
        libusb_exit(android_context);
    }

    client_deinit();

    if (uevent_netlink_sock >= 0) {
        close(uevent_netlink_sock);
    }

    return 0;
}
