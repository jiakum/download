#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <pthread.h>
#include "utils.h"
#include "libusbproxy.h"

int fd = -1;

static inline int writen2(int fd, uint8_t *buf, int size)
{
    int left = size;
    int ret = 0;

    do {
        if((ret = send(fd, buf + size - left, left, 0)) < 0) {
            if(errno != EAGAIN && errno != EINTR) {
                return -1;
            }
            /* continue */
        } else {
            left -= ret;
        }
    } while(left > 0);

    return 0;
}

int delay = 0;

void *tx_thread(void *filename)
{
    int tfd = open(filename, O_RDWR | O_CLOEXEC);
    if (tfd < 0) {
        log("open file %s failed! %s", filename, strerror(errno));
        return NULL;
    }
    unsigned char buf[16376] = {0};
    while (1) {
        int ret = read(tfd, buf, sizeof(buf));
        if (ret>0) {
            if(writen2(fd, buf, ret)<0) {
                log("error happened");
            }
            usleep(delay);
        } else if (ret == 0) {
            log("Get End of file!");
            break;
        } else {
            log("error happened! %s", strerror(errno));
            break;
        }
    }
    usleep(50000);
    exit(0);
    close(tfd);
    pthread_exit(NULL);
    return NULL;
}

static inline int writen1(int fd, uint8_t *buf, int size)
{
    int left = size;
    int ret = 0;

    do {
        if((ret = write(fd, buf + size - left, left)) < 0) {
            if(errno != EAGAIN && errno != EINTR) {
                return -1;
            }
            /* continue */
        } else {
            left -= ret;
        }
    } while(left > 0);

    return 0;
}

int main(int argc, char *argv[])
{
    int id = -1;
    pthread_t tid = 0;
    log("Version:%s %s", __DATE__, __TIME__);
    if (argc < 3) {
        printf("Usage: %s [1|2|3|4] filename\n", argv[0]);
        exit(-1);
    }

    sscanf(argv[1], "%d", &id);
    fd = connect_usb_proxy(id);
    printf("fd = %d\n", fd);

    pthread_create(&tid, NULL, tx_thread, argv[2]);

    if (argc > 3) {
        sscanf(argv[3], "%d", &delay);
    }

    int rfd = open("./recv.dat", O_RDWR | O_CREAT | O_CLOEXEC | O_TRUNC | O_NONBLOCK);
    if (rfd < 0) {
        log("open recv.dat failed");
        goto error;
    }

    unsigned char buf[16376] = {0};
    while(1){
        int size = 0;
        size = recv(fd, buf, sizeof(buf), 0);
        if (size > 0) {
            writen1(rfd, buf, size);
        } else if (size < 0 && errno != EAGAIN && errno != EINTR) {
            break;
        }
    }
    close(rfd);
    log("recv end");

error:
    pthread_join(tid, NULL);
    close(fd);

    return 0;
}
