#ifndef USB_PACKET_H_6IKJCNQX
#define USB_PACKET_H_6IKJCNQX

#include "utils.h"

#define SIG_MAGIC_NUMBER        0x6666

#define USB_MRU 16384
#define DEV_MRU 65536 //16384 * 4

struct usb_packet_header {
    uint16_t    sig;
    uint16_t    len;
    uint16_t    id;
    uint8_t     flag;
    uint8_t     crc;
} __attribute__((packed));

static inline void init_usb_packet_header(uint8_t *buf, int len, uint8_t flag, uint16_t id)
{
    struct usb_packet_header *header = (struct usb_packet_header*)buf;
    header->sig = SIG_MAGIC_NUMBER;
    header->len = len & 0xffff;
    header->id = id;
    header->flag = flag;
    header->crc = calc_crc8(buf, sizeof(struct usb_packet_header)-1);
}

void usb_packet_dispatch(int length);
uint8_t *usb_packet_get_next();
void usb_packet_reset();
void usb_packet_register_callback_on_recv(int (*callback)(uint8_t *buf, int len));

#endif /* end of include guard: USB_PACKET_H_6IKJCNQX */
