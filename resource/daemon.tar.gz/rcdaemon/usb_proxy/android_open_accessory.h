#ifndef ANDROID_OPEN_ACCESSORY_H_HEF5G0Q4
#define ANDROID_OPEN_ACCESSORY_H_HEF5G0Q4

#include <libusb-1.0/libusb.h>

struct libusb_device* find_android_accessory(struct libusb_device **devs, int size);
struct libusb_device* find_android_phone(struct libusb_device **devs, int size);
int android_switch_accessory(struct libusb_device *dev);
struct usb_device * android_accessory_on_connect(struct libusb_device *dev);
void android_accessory_on_disconnect();
int android_accessory_write(uint8_t *buf, int size);

#endif /* end of include guard: ANDROID_OPEN_ACCESSORY_H_HEF5G0Q4 */
