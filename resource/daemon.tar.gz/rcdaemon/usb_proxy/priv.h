#ifndef __PRIV_H__
#define __PRIV_H__

#ifdef __cplusplus
extern "C" {
#endif

#include <stdio.h>
#include <stdint.h>

#define RUN_ONCE_IN_LAST_MS(x)   ({ \
    int __ret = 1; \
    static int64_t last=0; \
    int64_t current = get_current_time(); \
    if(current >= last + (x)) { \
        last = current; \
        __ret = 0; \
    } \
    __ret; \
})

#define log(format, ...)        printf("%s:%d "format"\n", __func__, __LINE__, ##__VA_ARGS__)

#ifdef __cplusplus
}
#endif

#endif /* __PRIV_H__ */
