#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <string.h>
#include <libusb-1.0/libusb.h>
#include <pthread.h>
#include <sys/time.h>
#include <linux/usb/ch9.h>

#include "list.h"
#include "utils.h"
#include "priv.h"
#include "rctimer.h"

#include "f_accessory.h"
#include "usb_packet.h"

#define TAG "android_accessory"
//#define log(format, ...)        logw(LOG_LOCAL5, TAG, format, ##__VA_ARGS__)

#define RXSYNC 1

static struct usb_device {
    libusb_device_handle    *handle;
    uint8_t                 ep_in;
    uint8_t                 ep_out;
    uint8_t                 bus;
    uint8_t                 addr;
    int                     wMaxPacketSize;
    int                     alive;
    pthread_t               rx_tid;
} *aoa_device = NULL;

static inline int is_accessory(struct libusb_device_descriptor *desc)
{
    return (desc->idVendor == USB_ACCESSORY_VENDOR_ID)
            && (desc->idProduct >= USB_ACCESSORY_PRODUCT_ID)
            && (desc->idProduct <= USB_ACCESSORY_AUDIO_ADB_PRODUCT_ID);
}

struct libusb_device* find_android_accessory(struct libusb_device **devs, int size)
{
    int i;
    int ret = 0;
    int found = 0;
    struct libusb_device_descriptor devdesc;
    struct libusb_device *dev;

    for (i = 0; i < size; ++i) {
        dev= devs[i];

        ret = libusb_get_device_descriptor(dev, &devdesc);
        if (ret != 0) {
            log("get device descriptor @ bus addr failed, error code=%d", size);
            continue;
        }

        if (is_accessory(&devdesc)) {
            found = 1;
            break;
        }
    }

    return found ? dev : NULL;
}

static inline int get_protocol(struct libusb_device_handle *handle, uint16_t *protocol)
{
    return libusb_control_transfer(handle,
            LIBUSB_ENDPOINT_IN | LIBUSB_REQUEST_TYPE_VENDOR | LIBUSB_RECIPIENT_DEVICE,
            ACCESSORY_GET_PROTOCOL,
            0,
            0,
            (uint8_t *)protocol,
            2,
            200);
}

static inline int send_string(struct libusb_device_handle *handle, int index, const char *str)
{
    return libusb_control_transfer(handle,
            LIBUSB_ENDPOINT_OUT | LIBUSB_REQUEST_TYPE_VENDOR | LIBUSB_RECIPIENT_DEVICE,
            ACCESSORY_SEND_STRING,
            0,
            index,
            (unsigned char *)str,
            strlen(str) + 1,
            200);
}

static inline int start_accessory(struct libusb_device_handle *handle)
{
    return libusb_control_transfer(handle,
            LIBUSB_ENDPOINT_OUT | LIBUSB_REQUEST_TYPE_VENDOR | LIBUSB_RECIPIENT_DEVICE,
            ACCESSORY_START,
            0,
            0,
            NULL,
            0,
            200);
}

int android_switch_accessory(struct libusb_device *dev)
{
    uint16_t protocol = 0;
    struct libusb_device_handle *handle = NULL;
    int ret = 0;

    if (RUN_ONCE_IN_LAST_MS(3000)) {
        return 0;
    }

    ret = libusb_open(dev, &handle);
    if (ret < 0) {
        log("libusb open failed! error code = %d", ret);
        return -1;
    }

    ret = get_protocol(handle, &protocol);
    if (ret < 0) {
        log("get protocol failed! error code = %d", ret);
        goto error;
    } else {
        log("android open accessory protocol %d", protocol);
    }

    if ( (ret = send_string(handle, ACCESSORY_STRING_MANUFACTURER, "Yuneec Inc.")) < 0 ||
            (ret = send_string(handle, ACCESSORY_STRING_MODEL, "Remote Controller")) < 0 ||
            (ret = send_string(handle, ACCESSORY_STRING_DESCRIPTION, "Yuneec Remote Controller Android Open Accessory")) < 0 ||
            (ret = send_string(handle, ACCESSORY_STRING_VERSION, "0.1")) < 0 ||
            (ret = send_string(handle, ACCESSORY_STRING_URI, "http://www.yuneec.com")) < 0 ||
            (ret = send_string(handle, ACCESSORY_STRING_SERIAL, "1234567890")) < 0 ) {
        log("send string error! error code =  %d", ret );
        goto error;
    }

    ret = start_accessory(handle);

    log("start accessory ret %d", ret);

error:
    libusb_close(handle);
    return ret;
}

#define ADB_CLASS              USB_CLASS_VENDOR_SPEC
#define ADB_SUBCLASS           0x42
#define ADB_PROTOCOL           0x1

static inline int is_adb_intf(const struct libusb_interface_descriptor *intf)
{
    return (intf->bNumEndpoints == 2) && (intf->bInterfaceClass == ADB_CLASS)
                && (intf->bInterfaceSubClass == ADB_SUBCLASS) && (intf->bInterfaceProtocol == ADB_PROTOCOL);
}

#define MTP_CLASS              USB_CLASS_VENDOR_SPEC
#define MTP_SUBCLASS           USB_SUBCLASS_VENDOR_SPEC
#define MTP_PROTOCOL           0x0

static inline int is_mtp_intf(const struct libusb_interface_descriptor *intf)
{
    return (intf->bInterfaceClass == MTP_CLASS)
                && (intf->bInterfaceSubClass == MTP_SUBCLASS)
                && (intf->bInterfaceProtocol == MTP_PROTOCOL);
}

struct libusb_device* find_android_phone(struct libusb_device **devs, int size)
{
    int i;
    int ret;
    int found = 0;
    struct libusb_device *dev;

    for (i = 0; i < size && found == 0; ++i) {
        struct libusb_config_descriptor *config;

        dev= devs[i]; 

        ret = libusb_get_active_config_descriptor(dev, &config);
        if (ret != 0) {
            log("get active config failed, error code=%d", ret);
        } else {
            int j,k; 
            for (j = 0; j < config->bNumInterfaces && found == 0; j++) {
                const struct libusb_interface *intf = &config->interface[j];
                for (k = 0; k < intf->num_altsetting && found == 0; k++) {
                    const struct libusb_interface_descriptor *intf_desc =  &intf->altsetting[k];
                    if (is_adb_intf(intf_desc) || is_mtp_intf(intf_desc)) {
                        found = 1;
                    }
                }
            }
            libusb_free_config_descriptor(config);
        }
    }

    return found ? dev : NULL;
}

int android_accessory_write(uint8_t *buf, int size)
{
    int send = 0;
    int try = 1;
    int ret = -1;
    static int64_t last;
    static int64_t total;
    static int count;
    static int pkt_num;
    struct usb_device *dev = aoa_device;
    if (dev == NULL) {
        return -1;
    }
    do {
        int timeout = 3000;
        ret = libusb_bulk_transfer(dev->handle, dev->ep_out, buf, size, &send, timeout);
        if (ret == 0) {
            pkt_num++;
            total+=size;
            count+=size;
            break;
        } else if (ret == LIBUSB_ERROR_TIMEOUT) {
            try--;
            if (try > 0) {
                ret = 0;
            }
            log("send buffer timeout (%dms) happened, would try %d times", timeout, try);
        } else {
            try = 0;
            log("send buffer error %d", ret);
        }
    } while (try > 0);

    if (get_current_time() > last + 1000) {
        if (last != 0) {
            int temp = (int)(get_current_time() - last);
            log("sync tx speed: %d KB/s %d packets total: %lld bytes", count/temp, pkt_num, total); 
        }
        last = get_current_time();
        count = 0;
    }

    return ret;
}

#ifndef RXSYNC
// Callback from read operation
// Under normal operation this issues a new read transfer request immediately,
// doing a kind of read-callback loop
static void rx_callback(struct libusb_transfer *xfer)
{
    struct usb_device *dev = xfer->user_data;
    //log("RX callback dev %d-%d len %d status %d", dev->bus, dev->addr, xfer->actual_length, xfer->status);
    if(xfer->status == LIBUSB_TRANSFER_COMPLETED) {
        usb_packet_dispatch(xfer->actual_length);
        xfer->buffer = usb_packet_get_next();
        libusb_submit_transfer(xfer);
    } else {
        switch(xfer->status) {
            case LIBUSB_TRANSFER_COMPLETED: //shut up compiler
            case LIBUSB_TRANSFER_ERROR:
                // funny, this happens when we disconnect the device while waiting for a transfer, sometimes
                log("Device %d-%d RX aborted due to error or disconnect", dev->bus, dev->addr);
                break;
            case LIBUSB_TRANSFER_TIMED_OUT:
                log("RX transfer timed out for device %d-%d", dev->bus, dev->addr);
                break;
            case LIBUSB_TRANSFER_CANCELLED:
                log("Device %d-%d RX transfer cancelled", dev->bus, dev->addr);
                break;
            case LIBUSB_TRANSFER_STALL:
                log("RX transfer stalled for device %d-%d", dev->bus, dev->addr);
                break;
            case LIBUSB_TRANSFER_NO_DEVICE:
                // other times, this happens, and also even when we abort the transfer after device removal
                log("Device %d-%d RX aborted due to disconnect", dev->bus, dev->addr);
                break;
            case LIBUSB_TRANSFER_OVERFLOW:
                log("RX transfer overflow for device %d-%d", dev->bus, dev->addr);
                break;
                // and nothing happens (this never gets called) if the device is freed after a disconnect! (bad)
            default:
                // this should never be reached.
                break;
        }

        libusb_free_transfer(xfer);

        // we can't usb_disconnect here due to a deadlock, so instead mark it as dead and reap it after processing events
        // we'll do device_remove there too
        //dev->alive = 0;
    }
}

static inline int start_rx_loop(struct usb_device *dev)
{
    int ret = -1;
    struct libusb_transfer *xfer = libusb_alloc_transfer(0);
    if (xfer == NULL) {
        log("alloc failed");
        return -1;
    }

    usb_packet_reset();
    libusb_fill_bulk_transfer(xfer, dev->handle, dev->ep_in, usb_packet_get_next(), USB_MRU, rx_callback, dev, 0);
    if((ret = libusb_submit_transfer(xfer)) != 0) {
        log("submit xfer failed! error %d", ret);
        libusb_free_transfer(xfer);
    }

    return ret;
}
#else
static void* rx_thread(void* data)
{
    struct usb_device *dev = data;
    log("start rx thread, addr %d", dev->ep_in);
    int recv = 0;
    int64_t last = get_current_time();
    int count = 0;
    while (dev->alive) {
        recv = 0;
        int ret = libusb_bulk_transfer(dev->handle, dev->ep_in, usb_packet_get_next(), USB_MRU, &recv, 2000);
        if (ret != 0) {
            if (ret != LIBUSB_ERROR_TIMEOUT) {
                libusb_reset_device(dev->handle);
                break;
            }
            log("recv buffer error %d", ret);
        } else {
            //log("recv %d bytes", recv);
            usb_packet_dispatch(recv);
            count += recv;
        }
        if (get_current_time() > last + 1000) {
            last = get_current_time();
            log("rx speed: %d KB/s", count/1000); 
            count = 0;
        }
    }
    log("end rx thread");
    pthread_exit(NULL);
    return NULL;
}
#endif

struct usb_device * android_accessory_on_connect(struct libusb_device *dev)
{
    int ret = 0;
    int current_config = 0;
    struct libusb_config_descriptor *config;
    if (aoa_device) {
        return aoa_device;
    }

    struct usb_device *usbdev = malloc(sizeof(struct usb_device));
    if (usbdev == NULL) {
        log("Malloc for usb device failed!");
        return NULL;
    }

    memset(usbdev, 0, sizeof(struct usb_device));
    
    ret = libusb_open(dev, &usbdev->handle);
    if (ret < 0) {
        log("libusb open failed! error code = %d", ret);
        goto error;
    }

    ret = libusb_get_configuration(usbdev->handle, &current_config);
    if (ret != 0) {
        log("libusb get configuration failed! error code = %d", ret);
        goto error;
    }

    if (current_config != 1) {
        ret = libusb_set_configuration(usbdev->handle, 1);
        if (ret != 0) {
            log("libusb set configuration failed! error code = %d", ret);
            goto error;
        }
    }

    if (libusb_kernel_driver_active(usbdev->handle, 0) == 1) {
        log("Kernel driver actived, detaching it");
        if (libusb_detach_kernel_driver(usbdev->handle, 0) != 0) {
            log("Detach the kernel failed");
            goto error;
        }
        log("Kernel driver detached");
    }

    ret = libusb_claim_interface(usbdev->handle, 0);
    if (ret != 0) {
        log("libusb claim intf failed");
        goto error;
    }

    log("Claimed Interface");

    ret = libusb_get_active_config_descriptor(dev, &config);
    if (ret != 0) {
        libusb_release_interface(usbdev->handle, 0);
        log("get active config failed, error code=%d", ret);
        goto error;
    } else {
        int i = 0;
        for (i = 0; i < 2; ++i) {
            const struct libusb_endpoint_descriptor *ep_desc = &config->interface[0].altsetting[0].endpoint[i];
            if (ep_desc->bEndpointAddress & LIBUSB_ENDPOINT_IN) {
                usbdev->ep_in = ep_desc->bEndpointAddress;
            } else {
                usbdev->ep_out = ep_desc->bEndpointAddress;
            }
        }
        libusb_free_config_descriptor(config);
    }

    usbdev->bus = libusb_get_bus_number(dev);
    usbdev->addr = libusb_get_device_address(dev);
    usbdev->wMaxPacketSize = libusb_get_max_packet_size(dev, usbdev->ep_out);

    usbdev->alive = 1;

#ifdef RXSYNC
    pthread_create(&usbdev->rx_tid, NULL, rx_thread, usbdev);
#else
    ret = start_rx_loop(usbdev);
    if (ret < 0) {
        log("start rx loops failed! ret = %d", ret);
        goto error;
    }
#endif

    aoa_device = usbdev;
error:
    if (ret != 0) {
        if (usbdev->handle) {
            libusb_close(usbdev->handle);
        }
        free(usbdev);
        usbdev = NULL;
    }

    log("connect ret = %d", ret);
    return usbdev;
}

void android_accessory_on_disconnect()
{
    if (aoa_device == NULL) {
        return;
    }

    log("AOA disconnect");
    aoa_device->alive = 0;

    if (aoa_device->handle) {
        libusb_reset_device(aoa_device->handle);
        libusb_release_interface(aoa_device->handle, 0);
        libusb_close(aoa_device->handle);
    }

    if (aoa_device->rx_tid) {
        pthread_join(aoa_device->rx_tid, NULL);   
    }

    free(aoa_device);
    aoa_device = NULL;
    return;
}
