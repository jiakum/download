#include <stdio.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <sys/un.h>
#include <sys/epoll.h>
#include <sys/stat.h>
#include <errno.h>
#include <string.h>
#include <pthread.h>
#include "list.h"
#include "epoll_context.h"
#include "utils.h"
#include "priv.h"
#include "rctimer.h"
#include "usb_packet.h"
#include "android_open_accessory.h"

#define USB_PROXY_SERVER_PATH_FORMAT    "/var/run/usb_proxy_svr_%d"
#define USB_PROXY_CLIENT_PATH_FORMAT    "/var/run/usb_proxy_cli_%d_%lu"

struct client_t {
    int                     id;
    int                     fd;
    struct list_head        list;
    struct epoll_context    ep_ctx;
};

struct client_proxy_t {
    int                     listenfd;;
    int                     epfd;
    struct epoll_context    epoll_ctx;
    pthread_t               pid;
    int                     alive;
    pthread_mutex_t         client_list_mutex;
    struct list_head        client_list;
} context;

static inline int writen(int fd, uint8_t *buf, int size)
{
    int left = size;
    int ret = 0;
    int try = 10;

    do {
        if((ret = send(fd, buf + size - left, left, 0)) < 0) {
            if(errno != EAGAIN && errno != EINTR) {
                return -1;
            }
            /* continue */
            try--;
        } else {
            left -= ret;
        }
    } while(left > 0 && try > 0);

    if (left > 0) {
        log("send failed 10 times, this should not happened");
    }

    return 0;
}

static struct client_t * find_client_by_id(int id)
{
    struct client_t *pos, *next;
    struct client_t *ret = NULL;
    pthread_mutex_lock(&context.client_list_mutex);
    list_for_each_entry_safe(pos, next, &context.client_list, list) {
        if (pos->id == id) {
            ret = pos;
            break;
        }
    }
    pthread_mutex_unlock(&context.client_list_mutex);
    return ret;
}

static void client_remove(struct client_t *client)
{
    if (!client) {
        return;
    }

    log("client %d disconnected", client->id);
    epoll_ctl(context.epfd, EPOLL_CTL_DEL, client->fd, NULL);

    if (client->fd >= 0) {
        close(client->fd);
    }

    pthread_mutex_lock(&context.client_list_mutex);
    list_del(&client->list);
    pthread_mutex_unlock(&context.client_list_mutex);
    free(client);
}

static void client_remove_all()
{
    struct client_t *pos, *next;
    pthread_mutex_lock(&context.client_list_mutex);
    list_for_each_entry_safe(pos, next, &context.client_list, list) {
        client_remove(pos);
    }
    pthread_mutex_unlock(&context.client_list_mutex);
}

static int client_on_recv(struct client_t *client)
{
    static uint8_t client_buf[USB_MRU] = {0};
    int size;

    size = recv(client->fd, client_buf+sizeof(struct usb_packet_header), USB_MRU-sizeof(struct usb_packet_header), 0);
    if (size < 0 && errno != EINTR && errno != EAGAIN) {
        log("recv error:%d %s", errno, strerror(errno));
        client_remove(client);
    } else if (size <= 0) {
        size = 0;
    } else {
        int ret = 0;
        init_usb_packet_header(client_buf, size, 0, client->id);
        ret = android_accessory_write(client_buf, size+sizeof(struct usb_packet_header));
        if (ret != 0) {
            //client_remove_all();
        }
    }

    return size;
}

static int handle_client(struct epoll_event *ev, struct epoll_context *epctx)
{
    if (ev->events & (EPOLLHUP | EPOLLERR)) {
        client_remove((struct client_t*)epctx->data);
    } else if (ev->events & EPOLLIN) {
        client_on_recv(epctx->data);
    }
    return 0;
}

struct client_t *client_add(int fd, int id)
{
    struct epoll_event ev = {.events = EPOLLIN | EPOLLRDHUP};
    struct client_t *client = malloc(sizeof(struct client_t));
    if (!client) {
        log("malloc failed\n");
        return NULL;
    }

    memset(client, 0, sizeof(struct client_t));
    client->id = id;
    client->fd = fd;
    client->ep_ctx.callback = handle_client;
    client->ep_ctx.data = client;
    pthread_mutex_lock(&context.client_list_mutex);
    list_add(&client->list, &context.client_list);
    pthread_mutex_unlock(&context.client_list_mutex);
    ev.data.ptr = &client->ep_ctx;
    if (epoll_ctl(context.epfd, EPOLL_CTL_ADD, fd, &ev) < 0) {
        client_remove(client);
        return NULL;
    }


    log("client %d connected", id);
    return client;
}

#if 0
static int accept_client(int fd)
{
    struct sockaddr_un addr;
    int cfd;
    int id;
    pthread_t pid;
    socklen_t len = sizeof(struct sockaddr_un);
    cfd = accept(fd, (struct sockaddr *)&addr, &len);
    if (cfd < 0) {
        log("accept() failed (%s)", strerror(errno));
        return cfd;
    }

    log("client %s connected", addr.sun_path);
    sscanf(addr.sun_path, USB_PROXY_CLIENT_PATH_FORMAT, &id, &pid);

    int flags = fcntl(cfd, F_GETFL, 0);
    if (flags < 0) {
        log("ERROR: Could not get socket flags!");
    } else {
        if (fcntl(cfd, F_SETFL, flags | O_NONBLOCK) < 0) {
            log("ERROR: Could not set socket to non-blocking mode");
        }
    }

    if (client_add(cfd, id) == NULL) {
        close(cfd);
    }

    return fd;
}
#endif

void *client_poll_thread(void *data)
{
    struct client_proxy_t *ptr = data;
    struct epoll_event events[8];
    int ret = -1;

    ptr->alive = 1;
    while (ptr->alive) {
        int i = 0;
        do {
            ret = epoll_wait(ptr->epfd, events, sizeof(events)/sizeof(events[0]), 500);
            if (ret < 0 && errno != EAGAIN && errno != EINTR) {
                log("epoll return error:%d! This should never happen!!!\n",ret);
                goto error;
            }
        } while (ret < 0);

        for ( i = 0; i < ret; i++ ) {
            struct epoll_context *epctx = events[i].data.ptr;

            if(epctx && epctx->callback)
                epctx->callback(&events[i], epctx);
            else 
                log("Illegal data! %p,%p\n", epctx, epctx ? epctx->callback : NULL);
        }
    }

error:
    pthread_exit(NULL);
    return NULL;
}

int client_send_packet(uint8_t *buf, int len)
{
    struct usb_packet_header *hdr = (struct usb_packet_header*)buf;
    struct client_t *client = find_client_by_id(hdr->id);

    if (client) {
        if (writen(client->fd, buf+sizeof(struct usb_packet_header), hdr->len) != 0) {
            client_remove(client);
        }
    } else {
        char path[64] = {0};
        int fd = -1;
        sprintf(path, USB_PROXY_SERVER_PATH_FORMAT, hdr->id);
        log("try to connect %s", path);
        fd = unix_socket_connect(path);
        if (fd > 0) {
            client = client_add(fd, hdr->id);
            if (client) {
                if (writen(client->fd, buf+sizeof(struct usb_packet_header), hdr->len) != 0) {
                    client_remove(client);
                }
            }
        }
    }
    return 0;
}

void client_deinit()
{
    if (context.alive) {
        context.alive = 0;
        pthread_join(context.pid, NULL);
        context.pid = 0;
    }

    if (context.epfd >= 0) {
        close(context.epfd);
        context.epfd = -1;
    }

    pthread_mutex_destroy(&context.client_list_mutex);
}

int client_init()
{
    memset(&context, 0, sizeof(struct client_proxy_t));

    pthread_mutex_init(&context.client_list_mutex, NULL);
    INIT_LIST_HEAD(&context.client_list);

    context.epfd = epoll_create1(EPOLL_CLOEXEC);
    if (context.epfd < 0) {
        log("epoll create failed. err: %s\n", strerror(errno));
        pthread_mutex_destroy(&context.client_list_mutex);
        return -1;
    }

    pthread_create(&context.pid, 0, client_poll_thread, &context);
    usb_packet_register_callback_on_recv(client_send_packet);

    return 0;
}

