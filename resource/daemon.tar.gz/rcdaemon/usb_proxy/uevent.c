#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <linux/netlink.h>
#include <errno.h>
#include <string.h>

#define log(format, ...)        printf("%s:%d "format"\n", __func__, __LINE__, ##__VA_ARGS__)

#define UEVENT_BUFFER_SIZE 2048
static char uevent_buf[UEVENT_BUFFER_SIZE] = {0};

extern void check_usb_devices();
int handle_uevent(int fd)
{
    int i = 0;
    int size = recv(fd, uevent_buf, sizeof(uevent_buf), 0);
    if (size > 0) {
        uevent_buf[size-1] = 0;
        for (i = 0; i < size; ++i) {
            if (uevent_buf[i] == 0 && i+1 < size - strlen("SUBSYSTEM=usb")) {
                if (strcmp(&uevent_buf[i+1], "SUBSYSTEM=usb") == 0) {
                    check_usb_devices();
                    break;
                }
            }
        }
    }
    return 0;
}

int uevent_init()
{
    struct sockaddr_nl snl;
    const int buffersize = 16 * 1024 * 1024;
    int retval;
    int fd;

    memset(&snl, 0x00, sizeof(struct sockaddr_nl));
    snl.nl_family = AF_NETLINK;
    snl.nl_pid = getpid();
    snl.nl_groups = 1;

    fd = socket(PF_NETLINK, SOCK_DGRAM, NETLINK_KOBJECT_UEVENT);
    if (fd == -1) {
        log("error getting socket: %s", strerror(errno));
        return -1;
    }

    /* set receive buffersize */
    setsockopt(fd, SOL_SOCKET, SO_RCVBUFFORCE, &buffersize, sizeof(buffersize));

    retval = bind(fd, (struct sockaddr *) &snl, sizeof(struct sockaddr_nl));
    if (retval < 0) {
        log("bind failed: %s", strerror(errno));
        close(fd);
        fd = -1;
    }

    return fd;
}

void uevent_deinit()
{
}
