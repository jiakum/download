#ifndef __UTILS_H__
#define __UTILS_H__

#ifdef __cplusplus
extern "C" {
#endif

#include <sys/un.h>
#include <netinet/in.h>
#include "rctimer.h"

#define LOCAL_SOCKET_FMT "/tmp/socket_%d"
/*
 *
 */
unsigned char calc_crc8(unsigned char *buf, int len);

/*
 *
 */
void print_buf(unsigned char *buf, int len);

int set_serialport(int fd,int speed,int flow_ctrl,int databits,int stopbits,int parity);

int shell_execute(char *path, char *argv[]);

int adb_forward(int port);
int socket_open_listen(struct sockaddr_in *my_addr);

int unix_socket_open_listen(const char *path);
int unix_socket_connect(const char *filename);

#ifdef __cplusplus
}
#endif

#endif /* __UTILS_H__ */
