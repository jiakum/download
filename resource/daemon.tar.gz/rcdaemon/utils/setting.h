#ifndef SETTING_H
#define SETTING_H

#ifdef __cplusplus
extern "C"
{
#endif


int init_database(const char *filename);
void deinit_database();

void store_str(const char *group, char *name, char *value);
void store_data(const char *group, char *name, void *data, int len);
void store_int(const char *group, char *name, int value);

int get_value_str(const char *group, char *name, char *value, int maxlen);
int get_value_int(const char *group, char *name, int *value);
int get_rawdata(const char *group, char *name, void *data, int len);


#ifdef __cplusplus
}
#endif

#endif // SETTING_H
