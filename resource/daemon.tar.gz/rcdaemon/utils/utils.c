#include "common.h"

#include "stdio.h"
#include <termios.h>
#include <signal.h>
#include <errno.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <sys/un.h>

#include "utils.h"
#define TAG "utils"

static const unsigned char crc8_table[256] = {0, 7, 14, 9, 28, 27, 18, 21, 56, 63, 54, 49, 36, 35, 42, 45, 112, 119, 126, 121, 108, 107,
    98, 101, 72, 79, 70, 65, 84, 83, 90, 93, 224, 231, 238, 233, 252, 251, 242, 245, 216, 223, 214, 209, 196,
    195, 202, 205, 144, 151, 158, 153, 140, 139, 130, 133, 168, 175, 166, 161, 180, 179, 186, 189, 199, 192,
    201, 206, 219, 220, 213, 210, 255, 248, 241, 246, 227, 228, 237, 234, 183, 176, 185, 190, 171, 172, 165,
    162, 143, 136, 129, 134, 147, 148, 157, 154, 39, 32, 41, 46, 59, 60, 53, 50, 31, 24, 17, 22, 3, 4, 13, 10,
    87, 80, 89, 94, 75, 76, 69, 66, 111, 104, 97, 102, 115, 116, 125, 122, 137, 142, 135, 128, 149, 146, 155,
    156, 177, 182, 191, 184, 173, 170, 163, 164, 249, 254, 247, 240, 229, 226, 235, 236, 193, 198, 207, 200,
    221, 218, 211, 212, 105, 110, 103, 96, 117, 114, 123, 124, 81, 86, 95, 88, 77, 74, 67, 68, 25, 30, 23, 16,
    5, 2, 11, 12, 33, 38, 47, 40, 61, 58, 51, 52, 78, 73, 64, 71, 82, 85, 92, 91, 118, 113, 120, 127, 106, 109,
    100, 99, 62, 57, 48, 55, 34, 37, 44, 43, 6, 1, 8, 15, 26, 29, 20, 19, 174, 169, 160, 167, 178, 181, 188,
    187, 150, 145, 152, 159, 138, 141, 132, 131, 222, 217, 208, 215, 194, 197, 204, 203, 230, 225, 232, 239,
    250, 253, 244, 243};

unsigned char calc_crc8(unsigned char *buf, int len)
{
    unsigned char crc8 = 0;
    int i = 0;
    for (i=0; i<len; i++) {
        crc8 = crc8_table[crc8^buf[i]];
    }
    return crc8;
}

int set_serialport(int fd,int speed,int flow_ctrl,int databits,int stopbits,int parity)
{
    unsigned int   i;
    int            speed_arr[] = { B230400, B115200, B38400, B19200, B9600, B4800, B2400, B1200, B300 };
    int            name_arr[]  = { 230400, 115200, 38400, 19200, 9600, 4800, 2400, 1200, 300 };
    struct termios options;

    if (tcgetattr(fd, &options) == -1) {
        loge(LOG_RCDAEMON, TAG, "tcgetattr error:%s\n",strerror(errno));
        return -1;
    }

    //设置串口输入波特率和输出波特率
    for (i = 0; i < sizeof(speed_arr)/sizeof(speed_arr[0]); i++) {
        if (speed == name_arr[i]) {
            cfsetispeed(&options, speed_arr[i]);
            cfsetospeed(&options, speed_arr[i]);
			break;
        }
    }

    //修改控制模式，保证程序不会占用串口
    options.c_cflag |= CLOCAL;
    //修改控制模式，使得能够从串口中读取输入数据
    options.c_cflag |= CREAD;

    //设置数据流控制
    switch (flow_ctrl) {
        case 0: //不使用流控制
            options.c_cflag &= ~CRTSCTS;
            break;

        case 1: //使用硬件流控制
            options.c_cflag |= CRTSCTS;
            break;
        case 2: //使用软件流控制
            options.c_cflag |= IXON | IXOFF | IXANY;
            break;
    }
    //设置数据位
    //屏蔽其他标志位
    options.c_cflag &= ~CSIZE;
    switch (databits) {
        case 5:
            options.c_cflag |= CS5;
            break;
        case 6:
            options.c_cflag |= CS6;
            break;
        case 7:
            options.c_cflag |= CS7;
            break;
        case 8:
            options.c_cflag |= CS8;
            break;
        default:
            loge(LOG_RCDAEMON, TAG, "arg error:unsupport databits\n");
            return -1;
    }
    //设置校验位
    switch (parity) {
        case 'n':
        case 'N': //无奇偶校验位。
            options.c_cflag &= ~PARENB;
            options.c_iflag &= ~INPCK;
            break;
        case 'o':
        case 'O': //设置为奇校验
            options.c_cflag |= (PARODD | PARENB);
            options.c_iflag |= INPCK;
            break;
        case 'e':
        case 'E': //设置为偶校验
            options.c_cflag |= PARENB;
            options.c_cflag &= ~PARODD;
            options.c_iflag |= INPCK;
            break;
        case 's':
        case 'S': //设置为空格
            options.c_cflag &= ~PARENB;
            options.c_cflag &= ~CSTOPB;
            break;
        default:
            loge(LOG_RCDAEMON, TAG, "arg error:unsupport parity\n");
            return -1;
    }
    // 设置停止位
    switch (stopbits) {
        case 1:
            options.c_cflag &= ~CSTOPB;
            break;
        case 2:
            options.c_cflag |= CSTOPB;
            break;
        default:
            loge(LOG_RCDAEMON, TAG, "arg error:unsupport stopbits\n");
            return -1;
    }

    //修改输出模式，原始数据输出
    options.c_oflag &= ~OPOST;

    options.c_lflag &= ~(ICANON | ECHO | ECHOE | ISIG);
    //options.c_lflag &= ~(ISIG | ICANON);

    options.c_iflag &= ~(BRKINT | ICRNL | INPCK | ISTRIP | IXON);

    //设置等待时间和最小接收字符
    options.c_cc[VTIME] = 1; /* 读取一个字符等待1*(1/10)s */
    options.c_cc[VMIN]  = 0; /* 读取字符的最少个数为1 */

    //如果发生数据溢出，接收数据，但是不再读取 刷新收到的数据但是不读
    tcflush(fd, TCIFLUSH);

    //激活配置 (将修改后的termios数据设置到串口中）
    if (tcsetattr(fd, TCSANOW, &options) == -1) {
        loge(LOG_RCDAEMON, TAG, "tcsetattr error:%s\n",strerror(errno));
        return -1;
    }
    return 0;
}

void print_buf(unsigned char *buf, int len)
{
    int i = 0;
    for ( i = 0; i < len; i++ ) {
        if(i%16 == 0) {
            printf("\n");
        }
        printf("%.2X ",buf[i]);
    }
}

// do cmd "adb forward localfilesystem:port+1 tcp:port
int adb_forward(int port)
{
    char   cmd[64] = {0};
    char   cmd2[32] = {0};
    int ret = -1;
    char *argv[] = {"/bin/adb", "-d", "forward", cmd, cmd2, NULL};
    snprintf(cmd, sizeof(cmd), "localfilesystem:"LOCAL_SOCKET_FMT, port);
    snprintf(cmd2, sizeof cmd2, "tcp:%d", port);

    ret = shell_execute("/bin/adb", argv);
    if (-1 == ret)
    {
        loge(LOG_RCDAEMON, TAG, "exec cmd:/bin/adb forward %s failed, errno:%d\n", cmd, errno);
    }

    return ret;
}

// shell cmd execute
int shell_execute(char *path, char *argv[])
{
    int ret = 0;
    pid_t child_pid;
    struct sigaction ignore, saveintr, savequit;
    sigset_t chldmask, savemask;

    // param error
    if ((NULL == path) || (NULL == argv))
    {
        return -1;
    }

    // igore SIGINT & SIGQUIT
    ignore.sa_handler = SIG_IGN;
    sigemptyset(&ignore.sa_mask);
    ignore.sa_flags = 0;
    if (sigaction(SIGINT, &ignore, &saveintr) < 0)
    {
        loge(LOG_RCDAEMON, TAG, "sigaction ignore SIGINT failed:%d, fatal error!!!\n", errno);
        return -1;
    }
    if (sigaction(SIGQUIT, &ignore, &savequit) < 0)
    {
        loge(LOG_RCDAEMON, TAG, "sigaction ignore SIGQUIT failed:%d, fatal error!!!\n", errno);
        return -1;
    }

    // block SIGCHLD
    sigemptyset(&chldmask);
    sigaddset(&chldmask, SIGCHLD);
    if (sigprocmask(SIG_BLOCK, &chldmask, &savemask) < 0)
    {
        loge(LOG_RCDAEMON, TAG, "block SIGCHLD failed:%d, fatal error!!!\n", errno);
        return -1;
    }

    // execute  cmd
    child_pid = vfork();
    if (child_pid == 0)
    {
        // restore signal action & reset signal mask
        sigaction(SIGINT, &saveintr, NULL);
        sigaction(SIGQUIT, &savequit, NULL);
        sigprocmask(SIG_SETMASK, &savemask, NULL);
        ret = execv(path, argv);
        if (ret < 0)
        {
            loge(LOG_RCDAEMON, TAG, "exec cmd:%s failed, errno:%d\n", path, errno);
        }
        exit(127);
    }
    else if (child_pid > 0)
    {
        // wait child process exit
        ret = waitpid(child_pid, NULL, 0);
        if (ret < 0)
        {
            if (errno == ECHILD)
            {
                ret = 0;
            }
            else
            {
                loge(LOG_RCDAEMON, TAG, "shell execute,wait child process failed:%d\n", errno);
            }
        }

        // restore signal action & reset signal mask
        if (sigaction(SIGINT, &saveintr, NULL) < 0)
        {
            loge(LOG_RCDAEMON, TAG, "signal action reset SIGINT failed:%d\n", errno);
            ret = -1;
        }
        if (sigaction(SIGQUIT, &savequit, NULL) < 0)
        {
            loge(LOG_RCDAEMON, TAG, "signal action reset SIGQUIT failed:%d\n", errno);
            ret = -1;
        }
        if (sigprocmask(SIG_SETMASK, &savemask, NULL) < 0)
        {
            loge(LOG_RCDAEMON, TAG, "signal action reset sigmask failed:%d\n", errno);
            ret = -1;
        }
    }
    else
    {
        loge(LOG_RCDAEMON, TAG, "vfork failed:%d, fatal error!!!\n", errno);
        ret = -1;
    }

    return ret;
}

/* open a listening socket */
int socket_open_listen(struct sockaddr_in *my_addr)
{
    int server_fd, tmp;

    server_fd = socket(AF_INET,SOCK_STREAM | SOCK_CLOEXEC,0);
    if (server_fd < 0) {
        loge(LOG_RCDAEMON, TAG, "socket\n");
        return -1;
    }

    tmp = 1;
    setsockopt(server_fd, SOL_SOCKET, SO_REUSEADDR, &tmp, sizeof(tmp));

    my_addr->sin_family = AF_INET;
    if (bind (server_fd, (struct sockaddr *) my_addr, sizeof (*my_addr)) < 0) {
        char bindmsg[32];
        snprintf(bindmsg, sizeof(bindmsg), "bind(port %d)", ntohs(my_addr->sin_port));
        loge(LOG_RCDAEMON, TAG, "%s\n", bindmsg);
        close(server_fd);
        return -1;
    }

    if (listen (server_fd, 5) < 0) {
        loge(LOG_RCDAEMON, TAG, "listen\n");
        close(server_fd);
        return -1;
    }

    fcntl(server_fd, F_SETFL, fcntl(server_fd, F_GETFL) | O_NONBLOCK);

    return server_fd;
}

int unix_socket_open_listen(const char *path)
{
    struct sockaddr_un bind_addr;
    int fd;

    if(unlink(path) == -1 && errno != ENOENT) {
        loge(LOG_RCDAEMON, TAG, "unlink(%s) failed: %s", path, strerror(errno));
        return -1;
    }

    fd = socket(AF_UNIX, SOCK_STREAM | SOCK_CLOEXEC, 0);
    if (fd == -1) {
        loge(LOG_RCDAEMON, TAG, "socket() failed: %s", strerror(errno));
        return -1;
    }

    int flags = fcntl(fd, F_GETFL, 0);
    if (flags < 0) {
        loge(LOG_RCDAEMON, TAG, "ERROR: Could not get flags for socket");
    } else {
        if (fcntl(fd, F_SETFL, flags | O_NONBLOCK) < 0) {
            loge(LOG_RCDAEMON, TAG, "ERROR: Could not set socket to non-blocking");
        }
    }

    bzero(&bind_addr, sizeof(bind_addr));
    bind_addr.sun_family = AF_UNIX;
    strcpy(bind_addr.sun_path, path);
    if (bind(fd, (struct sockaddr*)&bind_addr, sizeof(bind_addr)) != 0) {
        loge(LOG_RCDAEMON, TAG, "bind() failed: %s", strerror(errno));
        close(fd);
        return -1;
    }

    // Start listening
    if (listen(fd, 5) != 0) {
        loge(LOG_RCDAEMON, TAG, "listen() failed: %s", strerror(errno));
        close(fd);
        return -1;
    }

    logi(LOG_RCDAEMON, TAG, "start listen");
    chmod(path, 0666);
    return fd;
}

int unix_socket_connect(const char *filename)
{
    struct sockaddr_un name;
    int sfd = -1;
    size_t size;

    // make a new socket
    if ((sfd = socket(AF_UNIX, SOCK_STREAM | SOCK_CLOEXEC, 0)) < 0) {
        loge(LOG_RCDAEMON, TAG, "socket: %s", strerror(errno));
        return -1;
    }

    name.sun_family = AF_UNIX;
    strncpy(name.sun_path, filename, sizeof(name.sun_path));
    name.sun_path[sizeof(name.sun_path) - 1] = 0;

    size = (offsetof(struct sockaddr_un, sun_path)
            + strlen(name.sun_path) + 1);

    if (connect(sfd, (struct sockaddr *) &name, size) < 0) {
        close(sfd);
        loge(LOG_RCDAEMON, TAG, "connect: %s\n",strerror(errno));
        return -1;
    }

    fcntl(sfd, F_SETFL, fcntl(sfd, F_GETFL) | O_NONBLOCK);

    return sfd;
}
