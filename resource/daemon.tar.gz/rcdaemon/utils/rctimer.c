#include "list.h"

#include "rctimer.h"
#include "log.h"
#define TAG "rctimer"

static RcTimer timerlist = {
    .list       =       LIST_HEAD_INIT(timerlist.list),
};

RcTimer *add_rctimer(void *p, int (*func)(RcTimer *), int timeout)
{
    RcTimer *timer = (RcTimer *)malloc(sizeof(RcTimer));

    if (!timer || !func) {
        loge(LOG_RCDAEMON, TAG,  "invaild timer=NULL\n");
        return NULL;
    }

    timer->func = func;
    timer->p = p;
    timer->timeout = get_current_time() + (int64_t)timeout;

    list_add(&timer->list, &timerlist.list);

    return timer;
}

int process_rctimer()
{
    RcTimer *pos, *next;
    int64_t curr_time = get_current_time();
    int64_t min = curr_time + TIMER_CYCLE;

    list_for_each_entry_safe(pos, next, &timerlist.list, list) {
        if (pos->timeout <= curr_time) {
            pos->func(pos);
        }

        if (pos->timeout > curr_time && pos->timeout < min) {
            min = pos->timeout;
        }
    }

    return (int)(min - curr_time);
}

