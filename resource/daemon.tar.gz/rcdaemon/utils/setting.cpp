
#include <QDebug>
#include <QSettings>
#include <QVariant>
#include <errno.h>
#include <QMutex>
#include <QCoreApplication>
#include "setting.h"

static QSettings *global_setting;
static QMutex *lock;

int init_database(const char *filename)
{

    if(Q_UNLIKELY(global_setting)) {
        qDebug("init twice ? deinit last one.");
        delete global_setting;
    }

    if(!filename)
        filename = "/root/st10c.ini";

    global_setting = new QSettings(filename, QSettings::NativeFormat);
    global_setting->setIniCodec("UTF-8");
    lock = new QMutex;
    if(Q_UNLIKELY(!global_setting || !lock))
        return -ENOMEM;
    return 0;
}

void deinit_database()
{
    if(Q_UNLIKELY(!global_setting))
        return;

    delete global_setting;
    global_setting = NULL;
    delete lock;
    lock = NULL;
}

void store_str(const char *group, char *name, char *value)
{
    if(Q_UNLIKELY(!global_setting))
        return;

    lock->lock();
    global_setting->beginGroup(QString::fromUtf8(group));
    global_setting->setValue(QString::fromUtf8(name), QVariant(QString::fromUtf8(value)));
    global_setting->endGroup();
    lock->unlock();
    global_setting->sync();
}

void store_int(const char *group, char *name, int value)
{
    if(Q_UNLIKELY(!global_setting))
        return;

    lock->lock();
    global_setting->beginGroup(QString::fromUtf8(group));
    global_setting->setValue(QString::fromUtf8(name), QVariant(value));
    global_setting->endGroup();
    lock->unlock();
    global_setting->sync();
}

void store_data(const char *group, char *name, void *data, int len)
{
    if(Q_UNLIKELY(!global_setting))
        return;

    lock->lock();
    global_setting->beginGroup(QString::fromUtf8(group));
    global_setting->setValue(QString::fromUtf8(name), QVariant(QByteArray((const char *)data, len)));
    global_setting->endGroup();
    lock->unlock();
    global_setting->sync();
}

int get_value_int(const char *group, char *name, int *value)
{
    QVariant variant;
    if(Q_UNLIKELY(!global_setting))
        return -1;

    lock->lock();
    global_setting->beginGroup(QString::fromUtf8(group));
    variant = global_setting->value(QString::fromUtf8(name));
    global_setting->endGroup();
    lock->unlock();

    if(variant.isNull() || (variant.type() != QVariant::Int))
        return -EINVAL;

    *value = variant.toInt();

    return 0;
}

int get_value_str(const char *group, char *name, char *value, int maxlen)
{
    QVariant variant;
    QString str;
    QByteArray bytearray;

    if(Q_UNLIKELY(!global_setting))
        return -1;

    lock->lock();
    global_setting->beginGroup(QString::fromUtf8(group));
    variant = global_setting->value(QString::fromUtf8(name));
    global_setting->endGroup();
    lock->unlock();

    if(variant.isNull() || (variant.type() != QVariant::String))
        return -EINVAL;

    str= variant.toString();

    bytearray = str.toUtf8();
    if(value && maxlen)
        strncpy(value, bytearray.constData(), maxlen);

    return 0;
}

int get_rawdata(const char *group, char *name, void *data, int len)
{
    QVariant variant;
    QByteArray bytearray;

    if(Q_UNLIKELY(!global_setting))
        return -1;

    lock->lock();
    global_setting->beginGroup(QString::fromUtf8(group));
    variant = global_setting->value(QString::fromUtf8(name));
    global_setting->endGroup();
    lock->unlock();

    if(variant.isNull() || (variant.type() != QVariant::ByteArray))
        return -EINVAL;

    bytearray = variant.toByteArray();

    len = bytearray.size() > len ? len : bytearray.size();
    memcpy(data, bytearray.constData(), len);

    return 0;
}
