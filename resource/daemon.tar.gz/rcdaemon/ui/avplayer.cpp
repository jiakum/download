#include "avplayer.h"
#include "video.h"
#include "rtsp_switch.h"
#include <QDebug>

AVPlayer::AVPlayer(QObject *parent) :
    QObject(parent)
{
    video_init((char*)"rtsp://192.168.42.1/live");
}

void AVPlayer::set_phone_status(bool iphone, bool android, int handle)
{
    ::video_set_phone_status((int)iphone, (int)android, handle);
    qDebug("phone status change, iphone:%d, android:%d, handle:%d", (int)iphone, (int)android, handle);
}

void AVPlayer::hdmi_hotplug(int hdmi)
{
    qDebug("hdmi status change: %d", hdmi);
    ::video_set_hdmi_status( hdmi ? EHOT_PLUG_CONNECTED : EHOT_PLUG_DISCONNECT);
}

void AVPlayer::wifi_hotplug(bool wifi)
{
    video_set_wifi_status(wifi ? EHOT_PLUG_CONNECTED : EHOT_PLUG_DISCONNECT);
}

AVPlayer *AVPlayer::instance()
{
    static AVPlayer *player;

    if(Q_UNLIKELY(!player))
        player = new AVPlayer;

    return player;
}
