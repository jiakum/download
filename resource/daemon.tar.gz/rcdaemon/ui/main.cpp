#include <QApplication>
#include "factory.h"
#include "client.h"
#include <QWSServer>
#include <QLinuxFbScreen>
#include <qfeatures.h>
#include <mainwindow.h>
#include <QFont>
#include <QFontDatabase>
#include <signal.h>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);

    QWSServer *server = QWSServer::instance();
    QBrush brush;
    brush.setColor(Qt::transparent);
    server->setBackground(brush);

    QFont font(QString::fromUtf8("unifont"), 18);
    a.setFont(font);

    char name[64];
    bool found = false;
    found = Client::find_usb_storage(name, sizeof(name));
    if(found) {
        qDebug("mount udisk:%s", name);
        found = (Client::mount_udisk(name) == 0);
        if(found)
            found = QFile::exists(Factory::factory_setting_file);
        Client::umount_disk();
    }

    for(int i = 1;i < argc;i++) {
        if(!strncmp("-factory", argv[i], 8)) {
            found = true;
            break;
        }
    }

    QWidget *w;
    if(found) {
        w = new Factory;
        w->grabKeyboard();
        w->setMouseTracking(true);
    } else {
        server->closeMouse();
        server->setCursorVisible(false);
        w = new MainWindow;
    }

    w->show();
    w->setFocus();

    return a.exec();
}
