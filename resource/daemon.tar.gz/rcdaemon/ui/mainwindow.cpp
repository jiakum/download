#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "client.h"
#include "rcprotocol.h"
#include "autopilot.h"
#include "utils.h"
#include "input.h"
#include "local.h"
#include "avplayer.h"
#include <QTimer>
#include <QSettings>

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent, Qt::FramelessWindowHint),
    ui(new Ui::MainWindow) , iphone(false), android(false), task(NoneTask)
{
    ui->setupUi(this);

    player = AVPlayer::instance();
    timer = new QTimer;
    gps = new GPSData;
    set = new QSettings("/home/internal.ini", QSettings::NativeFormat);
    set->setIniCodec("UTF-8");

    local = Client::instance();
    this->connect(local, SIGNAL(pilot_data(QByteArray)), this, SLOT(pilot_data(QByteArray)));
    this->connect(local, SIGNAL(clicked(int,int)), this, SLOT(local_key_event(int,int)));
    this->connect(local, SIGNAL(response(int,QByteArray)), this, SLOT(response(int,QByteArray)));
    this->connect(timer, SIGNAL(timeout()), this, SLOT(scan()));
    this->connect(local, SIGNAL(hdmi(int)), player, SLOT(hdmi_hotplug(int)));
    this->connect(this, SIGNAL(wifi_status_changed(bool)), player, SLOT(wifi_hotplug(bool)));

    timer->start(500);
}

MainWindow::~MainWindow()
{
    delete ui;
    ::sync();
    delete set;
    delete gps;
}

void MainWindow::response(int cmd, QByteArray result)
{
    switch(cmd)
    {
    case COMMAND_PAD_GET_WIFI_STATUS:
        {
            QList<QByteArray> list = result.split('\n');

            foreach(QByteArray pos, list) {
                if(pos.startsWith("wap_state=")) {
                    QByteArray array = pos.right(pos.size() - strlen("wap_state="));
                    if(array != wstatus) {
                        bool cur = (array != "COMPLETED");
                        bool last = (wstatus != "COMPLETED");
                        wstatus = array;

                        if(cur != last)
                            emit wifi_status_changed(cur);
                    }
                } else if(pos.startsWith("ssid=")) {
                    ssid = pos.right(pos.size() - strlen("ssid="));
                }
            }
        }
        break;

    case COMMAND_PAD_GET_GPS_DATA:
        if(result.size() < (int)sizeof(*gps)) {
            qDebug("illegal gps data! wrong length :%d", result.size());
        } else {
            memcpy(gps, result.constData(), result.size());
        }
        break;

    case COMMAND_PAD_GET_BIND_STATE:
        {
            unsigned short addr = *(unsigned short *)result.constData() ;
            if((task == BindTask) && (addr == bindaddr)) {
                local->send_cmd(COMMAND_PAD_ODDER_M4_EXIT_BIND);
                local->send_cmd(COMMAND_PAD_ODDER_M4_ENTER_RUN);
                task = NoneTask;
            } else if((task == SearchPilotTask) && addr) {
                bindaddr = addr;
                task = BindTask;
                bind_pilot(false);
            }
        }
        break;

    case COMMAND_PHONE_STATUS:
        {
            QList<QByteArray> list = result.split('\n');
            bool last = (iphone || android);
            int handle;

            foreach(QByteArray pos, list) {
                if(pos.startsWith("iphone ")) {
                    if(pos.right(pos.size() - strlen("iphone ")) == "connected")
                        iphone = true;
                    else
                        iphone = false;
                } else if(pos.startsWith("android ")) {
                    if(pos.right(pos.size() - strlen("android ")) == "connected")
                        android = true;
                    else
                        android = false;
                }else if(pos.startsWith("handle ")) {
                    handle = pos.right(pos.size() - strlen("handle ")).toInt();
                }
            }

            if(last != (iphone || android)) {
                player->set_phone_status(iphone, android, handle);
                if(iphone || android)
                    task = NoneTask;
            }
        }
        break;
    }
}

void MainWindow::bind_pilot(bool reset_state)
{
    PADTOM4bindInfo info;

    if(reset_state) {
        local->send_cmd(COMMAND_PAD_ODDER_M4_EXIT_TO_AWAIT);
        local->send_cmd(COMMAND_PAD_ODDER_M4_ENTER_BIND);
        local->send_cmd(COMMAND_PAD_CLEAR_BINDED);
    }

    memset(&info, 0, sizeof(info));
    info.start_str  = DATA_PACKET_START_STR;
    info.size       = sizeof(info) - 3;
    info.Command    = bindaddr ? RECEIVER_BIND_SUCESS : ONLY_BACK;
    info.FCF        = 0x0;
    info.ComPara    = bindaddr;
    info.FInterval1 = 0x5;
    info.FInterval2 = 0xf;
    info.Type       = DATA_PACKET_TYPE_BIND_FLAG;
    info.CRC8       = calc_crc8((unsigned char*)&info + 3, sizeof(info) - 4);

    local->send_buf((unsigned char *)&info, (int)sizeof(info));
}

void MainWindow::local_key_event(int key, int value)
{
    Q_UNUSED(value);
    switch(key)
    {
    case BTN_GOHOME:
        break;

    }
}

void MainWindow::scan()
{
    local->send_cmd(COMMAND_PAD_GET_BIND_STATE);
    local->send_cmd(COMMAND_PAD_GET_WIFI_STATUS);
    local->send_cmd(COMMAND_PAD_GET_GPS_DATA);
    local->send_cmd(COMMAND_PHONE_STATUS);
}

static inline QString dotNumber(int value, int dot)
{
    int base = 1;
    while(--dot >= 0)
        base *= 10;
    return QString::number(value / base) + '.' + QString::number(value % base);
}

#include <math.h>
#define PI                      3.1415926
static double radian(int d)
{
    return (double)((double)d / 10000000.0) * PI / 180.0;
}
#define EARTH_RADIUS            6378.137
static double get_distance(TelemetryData2 *pilot, GPSData *local)
{
    double radLat1 = radian(local->lat);
    double radLat2 = radian(pilot->lat);
    double a = radLat1 - radLat2;
    double b = radian(local->lon) - radian(pilot->lon);
    double dst;

    if(!pilot->lon || !local->lon)
        return 0.0;

    dst = 2 * asin(sqrt(pow(sin(a / 2), 2) + cos(radLat1) * cos(radLat2) * pow(sin(b / 2), 2) ));
    dst = dst * EARTH_RADIUS;
    dst= round(dst * 10000) / 10000;

    return dst * 1000;
}

void MainWindow::pilot_data(QByteArray data)
{
    static const char *vehicle_types[] = {"", "H920", "Q500","350QX", "380QX", "H480", "Q380"};
    TelemetryData2 *td = (TelemetryData2 *)data.constData();
    float speed, distance, height;
    float vol = ((float)td->voltage + 50.0) / 10.0;
    int vol_percent = (int)((vol - 14.2) / (16.8 - 14.2) * 100.0);
    unsigned int vehicle;

    if(!td->motorStatus)
        return;

    if(td->pressCompassGpsStatus) {
        speed = (int)td->vx * td->vx + td->vy * td->vy + td->vz * td->vz;
        distance = get_distance(td, gps);
        height = (float)td->alt / 100.0;
        distance = sqrt(distance * distance + height * height);
        speed = sqrt(speed / 10000);

        ui->velocity->setText(QString::number(speed, 'f', 2) + " m/s");

        if(height > 999.0 || height < -999.0)
            ui->height->setText(QString::number(height / 1000, 'f', 2) + " km");
        else
            ui->height->setText(QString::number(height, 'f', 2) + " m");

        if(distance > 999.0)
            ui->distance->setText(QString::number(distance / 1000, 'f', 2) + " km");
        else
            ui->distance->setText(QString::number(distance, 'f', 2) + " m");
    }

    vol_percent = vol_percent > 100 ? 100 : (vol_percent < 0 ? 0 : vol_percent);
    ui->battery_label->setText(QString::number(vol_percent) + '%');
    if(vol_percent > 80)
        ui->battery->setStyleSheet(QString::fromUtf8("image: url(:/yuneec/quantity_of_electricity_full.png);"));
    else if(vol_percent > 50)
        ui->battery->setStyleSheet(QString::fromUtf8("image: url(:/yuneec/quantity_of_electricity1.png);"));
    else if(vol_percent > 20)
        ui->battery->setStyleSheet(QString::fromUtf8("image: url(:/yuneec/quantity_of_electricity2.png);"));
    else
        ui->battery->setStyleSheet(QString::fromUtf8("image: url(:/yuneec/quantity_of_electricity3.png);"));

    ui->gps_pic->setStyleSheet(QString::fromUtf8("image: url(:/yuneec/GPSON.png);"));
    /* aircraft gps ready flags */
    {
        static int ready;
        if(td->pressCompassGpsStatus)
            ready = 100;
        if(--ready)
            ui->gps->setText(QString::fromUtf8("GPS: READY"));
        else
            ui->gps->setText(QString::fromUtf8("GPS: ACQUIRING"));
    }

    switch(td->fMode & 0x07f)
    {
    default:
    case FMODE_Angle_SOLID:
    case FMODE_Angle_FLASHING:
    case FMODE_Angle_WOULD_BE_SOLID_NO_GPS:
        ui->fly_pic->setStyleSheet(QString::fromUtf8("image: url(:/yuneec/flymode_angle.png);"));
        ui->flymode->setText(QString::fromUtf8("Angle"));
        break;
    case FMODE_SMART:
    case FMODE_SMART_BUT_NO_GPS:
        ui->fly_pic->setStyleSheet(QString::fromUtf8("image: url(:/yuneec/flymode_smart.png);"));
        ui->flymode->setText(QString::fromUtf8("Smart"));
        break;
    case FMODE_GO_HOME:
        ui->fly_pic->setStyleSheet(QString::fromUtf8("image: url(:/yuneec/flymode_home.png);"));
        ui->flymode->setText(QString::fromUtf8("HOME"));
        break;
    }

    vehicle = td->vehicleType & 0x0f;
    vehicle = vehicle >= sizeof(vehicle_types)/sizeof(vehicle_types[0]) ? sizeof(vehicle_types)/sizeof(vehicle_types[0]) -1 : vehicle;
    ui->pilot_type->setText(QString::fromUtf8(vehicle_types[vehicle]));
}
