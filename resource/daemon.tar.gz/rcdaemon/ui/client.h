#ifndef CLIENT_H
#define CLIENT_H

#include <QObject>
#include <QTcpSocket>
#include <QHostAddress>
#include <QThread>
#include <QList>
#include <QByteArray>
#include "epoll_context.h"

struct ymavlink_buffer;
class Client: public QThread
{
    Q_OBJECT
public:
    static Client *instance();

    int send_cmd(unsigned int cmd, unsigned char *buf = NULL, int len = 0);
    int send_buf(unsigned char *buf, int len);
    void scan_wifi(void);
    void scan_gps(void);
    int get_led_status(int led = /*get all leds*/ -1);
    int set_led_status(int led, int value);
    int get_switch_states(void);
    static int mount_udisk(char *name);
    static int umount_disk();
    static int find_usb_storage(char *name, int len);

public slots:
    void connect_local();

signals:
    void hdmi(int);
    void clicked(int key, int value);
    void response(int,QByteArray);
    void pilot_data(QByteArray);
    void adc_data(QByteArray);

private:
    explicit Client(QObject *parent = 0);
    ~Client();
    void run(void);
    void close_local();
    int handle_packet(unsigned char *buf, int len);
    static int parse_local_packet(struct epoll_event *event, struct epoll_context *epctx);

    int ledfd, epfd;
    QByteArray wresult;
    struct ymavlink_buffer *data;
};


#endif // CLIENT_H
