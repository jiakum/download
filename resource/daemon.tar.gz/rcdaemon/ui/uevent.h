#ifndef UEVENT_H
#define UEVENT_H

#include <sys/epoll.h>
#include <QByteArray>
#include <QObject>
#include <QList>

class Uevent : public QObject
{
    Q_OBJECT

public:
    static Uevent *instance(void);
    static int uevent_init(epoll_event *event);

    struct SwitchState{
        QByteArray name;
        int state;
    };
    struct UsbInterface {
        QByteArray devtype,product,interface;
    };

    struct UeventPara {
        QByteArray path,action, subsystem;
        struct SwitchState switch_state;
        struct UsbInterface usb;
    };

signals:
    void hdmi(int state);
    void adb(int);
    void iphone(int);
private:
    explicit Uevent(QObject *parent = 0);
    ~Uevent();

    static int do_uevent(struct epoll_event *event, struct epoll_context *epctx);
    int parse_uevent(char *buf, int len);

    int  fd;
};


#endif // UEVENT_H
