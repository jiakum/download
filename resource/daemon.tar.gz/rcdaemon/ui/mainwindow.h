#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>

class Client;
class QSettings;
class QTimer;
class AVPlayer;
struct   __GPSDATA__ ;

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT
    
public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();

signals:
    void wifi_status_changed(bool connected);
    
private slots:
    void response(int cmd, QByteArray result);
    void pilot_data(QByteArray);
    void scan(void);
    void local_key_event(int,int);

private:
    Ui::MainWindow *ui;
    void bind_pilot(bool reset_state);

    enum {
        NoneTask = 0,
        InitialTask = 1 ,
        BindTask = InitialTask,
        SearchPilotTask
    };

    Client *local;
    QByteArray wstatus;
    QByteArray ssid;
    QSettings *set;
    QTimer *timer;
    AVPlayer *player;
    struct   __GPSDATA__  *gps;
    int bindaddr;
    bool iphone,android;
    int task;
};

#endif // MAINWINDOW_H
