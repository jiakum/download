#include "client.h"
#include <QDebug>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <net/if.h>
#include <net/if_arp.h>
#include <sys/un.h>
#include <arpa/inet.h>
#include <ctype.h>
#include <dirent.h>
#include <stdio.h>
#include <sys/mount.h>
#include <sys/stat.h>

#include <sys/prctl.h>
#include <sys/epoll.h>
#include <errno.h>
#include <sys/fcntl.h>
#include <linux/input.h>

#include "ymavlink/ymavlink.h"
#include "autopilot.h"
#include "rcprotocol.h"
#include "local.h"
#include "common.h"
#include "uevent.h"
#include "utils.h"

#include <QTimer>

#define LOCALHOST_PORT (10008)
#define SYS_LED_PATH "/sys/class/gpio_ctrl/ctrl"

int Client::find_usb_storage(char *name, int len)
{
    DIR *dir;
    struct dirent *dirent;
    bool found = false;

    if(!(dir = opendir("/dev"))) {
        printf("can not open directory : /dev!!! This should never happen!!!\n");
        return found;
    }

    while((dirent = readdir(dir))) {
        if(!strncmp(dirent->d_name, "sd", strlen("sd"))
                && (strnlen(dirent->d_name, sizeof(dirent->d_name)) > 3)
                && isdigit(dirent->d_name[3])) {
            if(!access("/mnt/usb", F_OK))
                mkdir("/mnt/usb", S_IRWXU | S_IRWXG);

            if(name && len) {
                len = len > (int)sizeof(dirent->d_name) ? sizeof(dirent->d_name) : len;
                snprintf(name, len, "/dev/%s", dirent->d_name);
            }
            found = true;
            break;
        }
    }


    closedir(dir);
    return found;
}

#include <QProcess>
int Client::mount_udisk(char *name)
{
    char argv[64];

    if(access("/mnt/usb", F_OK) < 0 && mkdir("/mnt/usb",S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH) < 0) {
        printf("mkdir /mnt/usb failed!\n");
        return -1;
    }
    ::snprintf(argv, sizeof(argv), "mount %s /mnt/usb", name);
    if(QProcess::execute(argv)) {
        printf("mount :%s on /mnt/usb failed, err:%s\n", name, strerror(errno));
        return -1;
    }

    return 0;
}

int Client::umount_disk()
{
    return umount("/mnt/usb");
}

void Client::scan_wifi(void)
{
    this->send_cmd(COMMAND_PAD_SCAN_WIFI);
}

void Client::scan_gps(void)
{
    this->send_cmd(COMMAND_PAD_GET_GPS_DATA);
}

int Client::set_led_status(int led, int value)
{
    char str[16];
    int ret, len;

    if(ledfd < 0)
        return -1;

    value = (get_led_status() & ~(0x01 << led)) | (!!value << led);
    snprintf(str, sizeof(str), "%d", value);
    len = strlen(str);
    while((ret = write(ledfd, str, len)) < 0) {
        if(errno == EINTR)
            continue;
        else
            return ret;
    }

    return ret;
}

int Client::get_led_status(int led)
{
    char str[16];
    int ret, value;

    if(ledfd < 0)
        return -1;

    while((ret = read(ledfd, str, sizeof(str))) < 0) {
        if(errno == EINTR)
            continue;
        else
            return ret;
    }
    str[15] = '\0';
    value = strtol(str, NULL, 0);

    if(led == -1)
        return value;
    else
        return (value >> led) & 0x01;
}

int Client::get_switch_states(void)
{
    char *filename = (char*)"/sys/class/input/event2/device/switch_state";
    int fd;
    char buf[16];

    if((fd = open(filename, O_RDONLY)) < 0){
        qDebug("open file:%s failed!!!", filename);
        return 0;
    }

    if(read(fd, buf, sizeof(buf)) < 0){
        qDebug("read file:%s failed", filename);
        return 0;
    }
    close(fd);

    return strtol(buf, NULL, 0);
}

void Client::connect_local()
{
    static struct epoll_context epctx;
    struct sockaddr_in addr;
    struct epoll_event event;
    int fd;

    addr.sin_family      = AF_INET;
    addr.sin_port        = htons(1108);
    addr.sin_addr.s_addr = htonl(INADDR_LOOPBACK);

    fd = socket(AF_INET, SOCK_STREAM, 0);
    if(::connect(fd, (struct sockaddr *) &addr, sizeof(addr)) < 0) {
        close(fd);
        QTimer::singleShot(500, this, SLOT(connect_local()));
        return;
    }
    ::fcntl(fd, F_SETFL, ::fcntl(fd, F_GETFL) | O_NONBLOCK);

    data->fd = fd;
    data->fdtype = FD_TYPE_SOCK;
    ymavlink_reset_buf(data);

    epctx.callback = this->parse_local_packet;
    epctx.data = this;
    event.events = EPOLLIN;
    event.data.ptr = &epctx;

    if(::epoll_ctl(epfd, EPOLL_CTL_ADD, fd, &event) < 0) {
        qDebug("%s, epoll ctl failed!!!", __func__);
        return;
    }

    qDebug("connect local host success");
}

void Client::close_local()
{
    qDebug("local socket closed ? error:%s!!", strerror(errno));
    epoll_ctl(epfd, EPOLL_CTL_DEL, data->fd, NULL);
    close(data->fd);
    data->fd = -1;
    QTimer::singleShot(500, this, SLOT(connect_local()));
}

Client::Client(QObject *parent) :
    QThread(parent)
{
    struct epoll_event event;
    int fd;

    data = new ymavlink_buffer;
    if(!data) {
        qDebug("malloc 1024 buffer failed");
        return;
    }
    memset(data, 0 ,sizeof(*data));
    if(!data->buf) {
        qDebug("malloc 1024 buffer failed");
        return;
    }
    data->fd = -1;

    if((ledfd = ::open(SYS_LED_PATH, O_RDONLY)) < 0) {
        qDebug("%s,can not open led:%s", __FILE__, SYS_LED_PATH);
    }

    if((epfd = ::epoll_create1(0)) < 0) {
        qDebug("epoll create error!");
        return;
    }
    if((fd = Uevent::uevent_init(&event)) >= 0) {
        ::epoll_ctl(epfd, EPOLL_CTL_ADD, fd, &event);
        this->connect(Uevent::instance(), SIGNAL(hdmi(int)), this, SIGNAL(hdmi(int)));
    }

    QTimer::singleShot(500, this, SLOT(connect_local()));
    this->start();
}

Client::~Client()
{
    close(epfd);
    close(data->fd);
    close(ledfd);
    delete data;
}

Client *Client::instance()
{
    static Client *client;

    if(Q_LIKELY(client))
        return client;

    client = new Client;
    return client;
}

int Client::send_cmd(unsigned int cmd,unsigned char *buf, int len)
{
    int ret;

    if(Q_LIKELY(data->fd > 0)) {
        ret = write_command_and_params(data, cmd, buf, len);
        if(ret < 0)
            close_local();
    }

    return 0;
}

int Client::send_buf(unsigned char *buf, int len)
{
    int left = len, ret = 0;

    if(Q_UNLIKELY(data->fd < 0))
        return -1;

    while(left > 0) {
        ret = send(data->fd, buf, len, 0);
        if(ret < 0) {
            if((errno == EAGAIN) || (errno == EINTR))
                continue;
            break;
        } else
            left -= ret;
    }

    if(ret < 0)
        close_local();

    return 0;
}

int Client::parse_local_packet(struct epoll_event *event, struct epoll_context *epctx)
{
    Client *client = Client::instance();
    struct ymavlink_buffer *cache = client->data;
    int ret;

    Q_UNUSED(epctx);

    if(event->events & (EPOLLERR | EPOLLHUP)) {
        client->close_local();
        return -1;
    }

    while(1) {
        ret = ymavlink_read_buf(cache);
        if(ret < 0){
            client->close_local();
            return -1;
        } else if(ret == 0)
            break;

        while((ret = ymavlink_get_packet(cache)) > 0) {
            client->handle_packet(&cache->buf[cache->offset], ret);
            ymavlink_update_buf(cache, ret);
        }
        ymavlink_cyclic_buf(cache);
    }

    return 0;
}

int Client::handle_packet(unsigned char *buf, int len)
{
    int type = buf[HEAD_DOMIAN_START_TYPE] & TYPE_BIT_2_4;
    const int hlen = sizeof(COMMAND_HEADER);
    int cmd;

    cmd = buf[COMAND_HEAD_DOMIAN_COMMAND];
    if(type == DATA_PACKET_TYPE_CHANEL_FLAG) {
        if(len < hlen + (int)sizeof(TelemetryData2))
            return -1;
        else if(cmd == COMMAND_M4_SEND_M3_BACK_CHANNEL_DATA)
            emit pilot_data(QByteArray((const char *)buf + hlen, (int)sizeof(TelemetryData2)));
        else if(cmd == COMMAND_M4_SEND_MIXED_CHANNEL_TO_PAD)
            emit adc_data(QByteArray((const char *)buf + hlen, len - hlen));
        return 0;
    } else if(type == DATA_PACKET_TYPE_RESPONSE_FLAG) {
        emit response(buf[COMAND_HEAD_DOMIAN_COMMAND], QByteArray((const char *)&buf[hlen], len - hlen));
        return 0;
    } else if((type != DATA_PACKET_TYPE_COMMAND_FLAG) || (len < hlen))
        return 0;

    //qDebug("receive packets, cmd:0x%x, len:%d", cmd, len);
    switch(cmd)
    {
    case COMMAND_PAD_REPORT_INPUTEVENT: {
        unsigned char *status = &buf[hlen];
        emit clicked((status[1] << 8) | status[2], status[3]);
        break; }
    case COMMAND_M4_SEND_M3_BACK_CHANNEL_DATA:
        emit pilot_data(QByteArray((const char *)buf + hlen, (int)sizeof(TelemetryData2)));
        break;
    default:
        break;
    }

    return 0;
}

void Client::run()
{
    struct epoll_event events[10];
    struct epoll_context *epctx;
    int    ret, i;

    prctl(PR_SET_NAME, "ClientEpollThread");
    qDebug("client run enter");

    while(1) {
        do {
            ret = ::epoll_wait(epfd, events, sizeof(events)/sizeof(events[0]), 100);
            if (ret < 0 && errno != EAGAIN && errno != EINTR) {
                printf("poll return error:%d\n",ret);
                goto end;
            }
        } while (ret < 0);

        for(i = 0;i < ret; i++) {
            epctx = (struct epoll_context *)events[i].data.ptr;
            if(Q_LIKELY(epctx && epctx->callback)) {
                ret = epctx->callback(&events[i], epctx);
                if(ret < 0) {
                    qDebug("callback return error:%d", ret);
                    continue;
                }
            } else
                qDebug("unrecognised epctx and callback");
        }

    }

end:
    qDebug("client %s end!", __func__);
    return;
}
