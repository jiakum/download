#ifndef FACTORY_H
#define FACTORY_H

#include <QWidget>
#include <QCheckBox>
#include <QKeyEvent>
#include <QTime>
#include <QTimer>
#include <QLabel>
#include <QSettings>

class Client;

namespace Ui {
class Factory;
}

class Factory : public QWidget
{
    Q_OBJECT
    
public:
    explicit Factory(QWidget *parent = 0);
    ~Factory();

    static const char *factory_setting_file;

public slots:
    void localKeyEvent(int key, int value);
    void testUsb(void);
    void testLed(void);
    void retest_last(void);
    void next_test(void);
    void find_usb_storage(void);
    void response(int cmd, QByteArray result);
    void handle_adc_data(QByteArray);

private:
    enum TestStep {
        GetSignNum = 1,
        TestWifi,
        TestUsb,
        TestKeys,
        TestBattery,
        TestLED,
        TestGps,
        TestSuccess,

        LedTestAllon = 0x10000,
        LedTestAllOff,
        LedTestOK,
        LedTestFail
    };

    struct KeyContext {
        int key;
        int type;
        bool ok;
        int value;
        QTime lasttime;
        QLabel *box;
    };

    void testHandler(bool success,bool next);
    virtual void mouseMoveEvent(QMouseEvent *);
    virtual void mousePressEvent(QMouseEvent *);
    void keyPressEvent(QKeyEvent *);

    void setUiTestOk(QWidget *w, QLabel *box);
    void setUiTestFail(QWidget *w, QLabel *box);
    void store_test_results();
    void get_sn(void);

    Ui::Factory *ui;

    Client *local;
    int test_step,led_test_step;
    int usb_ok, test_result;
    QTime lasttime;
    QTimer timer;
    QList<KeyContext> keyctx;

    QString sign_num, sn_temp;
    QByteArray wresult;
};

#endif // FACTORY_H
