#include "factory.h"
#include "ui_factory.h"
#include "client.h"
#include "mcu.h"
#include "common.h"
#include "input.h"
#include <QTimer>
#include <linux/input.h>
#include <QVariant>
#include <QTextCodec>
#include <QMessageBox>
#include <QList>
#include <gpioctrl.h>

#include "rcprotocol.h"
#include "get_bits.h"
#include "channel.h"

static const char test_ok_background[]   = "background-color: rgb(10, 200,10);";
static const char test_fail_background[] = "background-color: rgb(200, 0, 0);";
const char *Factory::factory_setting_file = "/mnt/usb/st10c_factory_23a0288ee8310d19ca339686a948db7502dd9237.ini";

enum {
    LEFT_SENSE = 0x8000 + 1,
    RIGHT_SENSE,
    LEFT_WHEEL
};

Factory::Factory(QWidget *parent) :
    QWidget(parent, Qt::FramelessWindowHint),
    ui(new Ui::Factory),test_step(0),led_test_step(0),usb_ok(0),test_result(0)
{
    ui->setupUi(this);

    keyctx.append(KeyContext{BTN_GOHOME,EV_KEY,false,0,QTime(),ui->key_home});
    keyctx.append(KeyContext{BTN_TAKEOFF,EV_KEY,false,0,QTime(),ui->key_takeoff});
    keyctx.append(KeyContext{BTN_VIDEO,EV_KEY,false,0,QTime(),ui->key_video});
    keyctx.append(KeyContext{BTN_FUNC,EV_KEY,false,0,QTime(),ui->key_func});
    keyctx.append(KeyContext{BTN_CAPTURE,EV_KEY,false,0,QTime(),ui->key_capture});
    keyctx.append(KeyContext{SW_SWITCH,EV_SW,false,0x07 << 16,QTime(),ui->switch_sw});
    keyctx.append(KeyContext{REL_WHEEL,EV_REL,false,0,QTime(),ui->right_wheel});
    keyctx.append(KeyContext{LEFT_SENSE,EV_MAX,false,0,QTime(),ui->left_sense});
    keyctx.append(KeyContext{RIGHT_SENSE,EV_MAX,false,0,QTime(),ui->right_sense});
    keyctx.append(KeyContext{LEFT_WHEEL,EV_MAX,false,0,QTime(),ui->left_wheel});

    local = Client::instance();
    this->connect(local, SIGNAL(clicked(int,int)), this, SLOT(localKeyEvent(int,int)));
    this->connect(ui->retest_last, SIGNAL(clicked()), this, SLOT(retest_last()));
    this->connect(ui->next_test, SIGNAL(clicked()), this, SLOT(next_test()));
    this->connect(local, SIGNAL(response(int,QByteArray)), this, SLOT(response(int,QByteArray)));
    this->connect(local, SIGNAL(adc_data(QByteArray)), this, SLOT(handle_adc_data(QByteArray)));

    testHandler(true, true);
}

Factory::~Factory()
{
    delete ui;
}

void Factory::handle_adc_data(QByteArray result)
{
    struct GetBitContext ctx;
    const unsigned char *buf = (const uint8_t *)result.constData();
    uint16_t channel[12];
    QString str;

    init_get_bits(&ctx, buf, (OWNER_ANUM + OWNER_SWNUM) * 3 / 2);

    for(unsigned int i = 0;i < sizeof(channel)/sizeof(channel[0]);i++)
        channel[i] = get_bits(&ctx, 12);

    /* channel 0 and 3 is left sense*/
    localKeyEvent(LEFT_SENSE, (channel[0] << 16) | channel[3]);
    str.sprintf("(%d,%d)", channel[0], channel[3]);
    ui->left_sense->setText(QString::fromUtf8("左摇杆") + str);

    localKeyEvent(RIGHT_SENSE, (channel[1] << 16) | channel[2]);
    str.sprintf("(%d,%d)", channel[1], channel[2]);
    ui->right_sense->setText(QString::fromUtf8("右摇杆") + str);

    localKeyEvent(LEFT_WHEEL, (channel[7] << 16) | channel[7]);
    str.sprintf("(%d)", channel[7]);
    ui->left_wheel->setText(QString::fromUtf8("左旋钮") + str);
}

void Factory::response(int cmd, QByteArray result)
{
    switch(cmd)
    {
    case COMMAND_PAD_SCAN_WIFI:
        {
            if(test_step != TestWifi)
                break;

            if(result.size() <= (int)strlen("FAILED")) {
                if(!strncmp(result.constData(), "START", strlen("START"))) {
                    wresult.clear();
                } else if(!strncmp(result.constData(), "END", strlen("END"))) {
                    if(wresult.size() > 0) {
                        setUiTestOk(ui->lwifi, ui->cwifi);
                        testHandler(true, true);
                    } else {
                        testHandler(false, false);
                    }
                } else {
                    qDebug("what is this ? length:%d", result.size());
                }
            } else {
                wresult.append(result);
            }
            break;
        }

    case COMMAND_PAD_GET_GPS_DATA:
        {
            GPSData *gps = (GPSData *)result.constData();

            if((test_step != TestGps) || !gps)
                break;

            if(gps->no_satelites >= 10) {
                setUiTestOk(ui->lgps, ui->cgps);
                testHandler(true, true);
            }
            ui->lgps->setText(QString::fromUtf8("正在测试gps （") + QString::number(gps->no_satelites) + QString::fromUtf8("颗卫星）"));
        }
        break;

    case MCU_CMD_GET_BAT:
        {
            BatteryInfo * battery = (BatteryInfo *)result.constData();
            if((test_step == TestBattery) && battery->charge_state) {
                setUiTestOk(ui->lcharge, ui->ccharge);
                testHandler(true, true);
            }
            //qDebug("recieve batteray cap:%d, vol:%d, info:%d", battery->volt_percent, battery->volt_value, battery->charge_state);
        }
        break;

    }

}

void Factory::retest_last()
{
    if(!--test_step)
        test_step = GetSignNum;
    test_result &= ~(0x01 << test_step );
    if(test_step == TestUsb)
        retest_last();
    else {
        timer.stop();
        timer.disconnect();
        testHandler(false, false);
    }
}

void Factory::next_test()
{
    switch(test_step) {
    case GetSignNum:
        if(sign_num.isEmpty()) {
            QMessageBox::information(NULL, QString::fromUtf8("sn码"),
                                        QString::fromUtf8("请扫描sn码"), QMessageBox::Ok);
            /* FIXME!!! */
            if(0) {
                int num = QTime::currentTime().msec();
                num = num > 0 ? num : -num;
                sn_temp= QString::number(num);
                get_sn();
            }
         } else
            get_sn();
        break;
    case TestWifi:
        setUiTestFail(ui->lwifi, ui->cwifi);
        testHandler(false, true);
        break;
    case TestUsb:
        setUiTestOk(ui->lusb, ui->cusb);
        testHandler(true, true);
        break;
    case TestGps:
        setUiTestFail(ui->lgps, ui->cgps);
        testHandler(false, true);
        break;
    case TestKeys:
        local->send_cmd(COMMAND_PAD_EXIT_FACTORY_CALIBRATION);
        setUiTestFail(NULL, ui->ckeys);
        testHandler(false, true);
        break;
    case TestLED:
        setUiTestFail(ui->lled, ui->cled);
        testHandler(false, true);
        break;
    case TestBattery:
        setUiTestFail(ui->lcharge, ui->ccharge);
        testHandler(false, true);
        break;
    case TestSuccess:
        testHandler(false, false);
        break;
    }
}

void Factory::find_usb_storage()
{
    char name[64];

    if(local->find_usb_storage(name, sizeof(name)) && (local->mount_udisk(name) == 0)) {
        timer.stop();
        timer.disconnect();
        ui->label->setText(QString::fromUtf8("正在读取数据库文件"));
        store_test_results();
        ::sync();
        local->umount_disk();
        ui->label->setText(QString::fromUtf8("测试完成"));
    }
}

void Factory::get_sn(void)
{
    QMessageBox::StandardButton button;

    sign_num = sn_temp;
    sn_temp.clear();

    button = QMessageBox::information(NULL, QString::fromUtf8("扫描sn码"),
                                QString::fromUtf8("sn码:") + sign_num, QMessageBox::Ok, QMessageBox::No);
    if(button == QMessageBox::Ok) {
        testHandler(true, true);
    } else {
        qDebug("%s,%d", __func__, __LINE__);
    }
    qDebug("get sign number:%s" ,sign_num.toUtf8().constData());
}

void Factory::testUsb()
{
    if(usb_ok) {
        setUiTestOk(ui->lusb, ui->cusb);
        timer.stop();
        timer.disconnect();
        testHandler(usb_ok, true);
    } else {
        setUiTestFail(ui->lusb, ui->cusb);
    }
}

void Factory::testLed()
{
    int i;
    QMessageBox::StandardButton button;

    qDebug("%s,%d", __func__, __LINE__);
    for(i = 0; i < 4; i++)
        gpio_set_state(i, 1);
    button = QMessageBox::information(NULL, QString::fromUtf8("led灯测试"),
                                      QString::fromUtf8("LED灯全亮 ?"), QMessageBox::Ok, QMessageBox::No);
    if(button == QMessageBox::No) {
        qDebug("%s,%d", __func__, __LINE__);
        setUiTestFail(ui->lled, ui->cled);
        testHandler(true, true);
        return;
    }

    qDebug("%s,%d", __func__, __LINE__);

    for(i = 0; i < 4; i++)
        gpio_set_state(i, 0);
    button = QMessageBox::information(NULL, QString::fromUtf8("led灯测试"),
                                      QString::fromUtf8("LED灯全灭 ?"), QMessageBox::Ok, QMessageBox::No);
    if(button == QMessageBox::No) {
        setUiTestFail(ui->lled, ui->cled);
        testHandler(true, true);
        return;
    }

    qDebug("%s,%d", __func__, __LINE__);
    gpio_set_state(4, 1);
    button = QMessageBox::information(NULL, QString::fromUtf8("马达测试"),
                                      QString::fromUtf8("马达正在震动 ?"), QMessageBox::Ok, QMessageBox::No);
    if(button == QMessageBox::No) {
        setUiTestFail(ui->lled, ui->cled);
        testHandler(true, true);
        return;
    }
    gpio_set_state(4, 0);
    button = QMessageBox::information(NULL, QString::fromUtf8("马达测试"),
                                      QString::fromUtf8("马达停止震动 ?"), QMessageBox::Ok, QMessageBox::No);
    if(button == QMessageBox::No) {
        setUiTestFail(ui->lled, ui->cled);
        testHandler(true, true);
        return;
    }

    setUiTestOk(ui->lled, ui->cled);
    testHandler(true, true);
}

void Factory::testHandler(bool success, bool next)
{
    if(next) {
        if(success) {
            test_result |= 0x01 << test_step;
        }
        ++test_step;
        lasttime = QTime::currentTime();
    }

    switch(test_step) {
    case GetSignNum:
        ui->label->setText(QString::fromUtf8("请扫描SN码"));
        break;
    case TestWifi:
        ui->label->setText(QString::fromUtf8("正在测试wifi"));
        ui->cwifi->setText(QString::fromUtf8("in test"));
        local->send_cmd(COMMAND_PAD_SCAN_WIFI);
        break;
    case TestUsb:
        ui->label->setText(QString::fromUtf8("正在测试usb"));
        ui->cusb->setText(QString::fromUtf8("in test"));
        if(usb_ok)
            testUsb();
        else {
            timer.disconnect();
            this->connect(&timer, SIGNAL(timeout()), this, SLOT(testUsb()));
            timer.start(5000);
        }
        break;
    case TestGps:
        ui->label->setText(QString::fromUtf8("正在测试gps"));
        ui->cgps->setText(QString::fromUtf8("in test"));
        local->send_cmd(COMMAND_PAD_GET_GPS_DATA);
        break;
    case TestKeys:
        local->send_cmd(COMMAND_PAD_ENTER_FACTORY_CALIBRATION);
        ui->label->setText(QString::fromUtf8("正在测试按键"));
        ui->ckeys->setText(QString::fromUtf8("in test"));
        break;
    case TestLED:
        ui->label->setText(QString::fromUtf8("正在测试led"));
        ui->cled->setText(QString::fromUtf8("in test"));
        this->testLed();
        break;
    case TestBattery:
        ui->label->setText(QString::fromUtf8("正在测试充电功能"));
        ui->ccharge->setText(QString::fromUtf8("in test"));
        break;
    case TestSuccess:
        if((test_result & ((1 << TestSuccess) - 1)) == (1 << TestSuccess) - 1) {
            ui->label->setStyleSheet(QString::fromUtf8(test_ok_background));
        } else {
            ui->label->setStyleSheet(QString::fromUtf8(test_fail_background));
        }
        ui->label->setText(QString::fromUtf8("请插入U盘!"));
        timer.disconnect();
        this->connect(&timer, SIGNAL(timeout()), this, SLOT(find_usb_storage()));
        timer.start(200);
        break;
    }
}

void Factory::localKeyEvent(int key, int value)
{
    bool allok = true;
    QList<KeyContext>::iterator  keyc;

    //qDebug("%s, key: %d, value: 0x%x", __func__, key, value);
    if(test_step == TestKeys) {
        for(keyc = keyctx.begin();keyc != keyctx.end(); keyc++) {
            if(key == keyc->key) {
                switch(keyc->type)
                {
                case EV_KEY:
                    if(value) {
                        if(keyc->lasttime.isNull())
                            keyc->lasttime == QTime::currentTime();
                    } else {
                        if(!keyc->ok) {
                            if(keyc->lasttime.addMSecs(2000) <= QTime::currentTime())
                                keyc->ok = true;
                            else {
                                keyc->box->setStyleSheet(QString::fromUtf8(test_fail_background));
                                keyc->lasttime = QTime();
                            }
                        }
                    }
                    break;
                case EV_SW:
                    keyc->value |= (1 << value);
                    if(keyc->lasttime.addMSecs(200) <= QTime::currentTime()) {
                        if((keyc->value & 0x0ff) == ((keyc->value >> 16) & 0x0ff))
                            keyc->ok = true;
                    }
                    keyc->lasttime == QTime::currentTime();
                    break;
                case EV_REL:
                    if(keyc->value && keyc->value != value)
                        keyc->ok = true;
                    keyc->value = value;
                    break;
                case EV_MAX:
                    {
                        unsigned int l, m;
                        bool low = false;

                        if(keyc->value) {
                            m = keyc->value >> 16;
                            l = value >> 16;
                            if(m > l)
                                keyc->value = (l << 16) | (keyc->value & 0x0ffff);
                            else if(m + 0x400 < l)
                                low = true;

                            m = keyc->value & 0x0ffff;
                            l = value & 0x0ffff;
                            if(m > l)
                                keyc->value = l | (keyc->value & 0xffff0000);
                            else if((m + 0x400 < l) && low)
                                keyc->ok = true;
                        } else
                            keyc->value = value;
                    }
                    break;
                }

                if(keyc->ok) {
                    keyc->box->setStyleSheet(QString::fromUtf8(test_ok_background));
                }
                break;
            }
        }

        for(keyc = keyctx.begin();keyc != keyctx.end(); keyc++) {
            if(!keyc->ok) {
                allok = false;
                break;
            }
        }

        if(allok) {
            ui->ckeys->setStyleSheet(QString::fromUtf8(test_ok_background));
            ui->ckeys->setText(QString::fromUtf8("OK"));
            local->send_cmd(COMMAND_PAD_EXIT_FACTORY_CALIBRATION);
            testHandler(true, true);
        }

    } else if(test_step == TestLED) {
        switch(led_test_step) {
        case LedTestAllon:
           if(key == BTN_GOHOME)
               led_test_step++;
           else
               led_test_step = LedTestFail;
           break;
        case LedTestAllOff:
           if(key == BTN_GOHOME)
               led_test_step++;
           else
               led_test_step = LedTestFail;
           break;
        }
    } else {
           if(key == BTN_TAKEOFF)
               next_test();
           else if(key == BTN_GOHOME)
               retest_last();
    }
}

void Factory::setUiTestOk(QWidget *w, QLabel *box)
{
    Q_UNUSED(w);
    if(box) {
        box->setStyleSheet(QString::fromUtf8(test_ok_background));
        box->setText(QString::fromUtf8("ok"));
    }
}

void Factory::setUiTestFail(QWidget *w, QLabel *box)
{
    Q_UNUSED(w);
    if(box) {
        box->setStyleSheet(QString::fromUtf8(test_fail_background));
        box->setText(QString::fromUtf8("fail"));
    }
}

void Factory::store_test_results()
{
    static const char *items[] = {"","sn", "wifi", "usb", "按键", "充电", "led", "gps"};
    QStringList strlist;
    QSettings *setting = new QSettings(QString::fromUtf8(factory_setting_file), QSettings::NativeFormat);

    setting->setIniCodec("UTF-8");
    setting->beginGroup(sign_num);
    if((test_result & ((1 << TestSuccess) - 1)) == (1 << TestSuccess) - 1) {
        setting->setValue(QString::fromUtf8("测试结果"), QVariant(QString::fromUtf8("OK")));
    } else {
        for(int i=TestWifi;i < TestSuccess;i++) {
            if((test_result & (1 << i)) == 0)
                strlist.append(QString::fromUtf8(items[i]));
        }
        setting->setValue(QString::fromUtf8("测试结果"), QVariant(QString::fromUtf8("FAILED")));
        setting->setValue(QString::fromUtf8("失败的项目"), QVariant(strlist));
    }
    setting->endGroup();
    delete setting;

    FILE *fp = ::fopen("/home/sn.ini", "w+");
    if(!fp) {
        qDebug("open /home/sn.ini file failed!");
        return;
    }

    ::fwrite(sign_num.toUtf8().constData(), sign_num.toUtf8().size(), 1, fp);
    ::fclose(fp);
}

void Factory::keyPressEvent(QKeyEvent * event)
{
    if(test_step == GetSignNum) {
        switch(event->key())
        {
        case Qt::Key_0:
        case Qt::Key_1:
        case Qt::Key_2:
        case Qt::Key_3:
        case Qt::Key_4:
        case Qt::Key_5:
        case Qt::Key_6:
        case Qt::Key_7:
        case Qt::Key_8:
        case Qt::Key_9:
            sn_temp.append(QChar((event->key() - Qt::Key_0) + '0'));
            break;
        case Qt::Key_Return:
            get_sn();
            break;
        }
    }

    QWidget::keyPressEvent(event);
}

void Factory::mouseMoveEvent(QMouseEvent *event)
{
    usb_ok = true;
    if(Q_UNLIKELY(test_step == TestUsb)) {
        testUsb();
    }

    QWidget::mouseMoveEvent(event);
}

void Factory::mousePressEvent(QMouseEvent *event)
{
    usb_ok = true;
    if(Q_UNLIKELY(test_step == TestUsb)) {
        testUsb();
    }

    QWidget::mousePressEvent(event);
}
