
#include <unistd.h>
#include <sys/socket.h>
#include <net/if.h>
#include <net/if_arp.h>
#include <sys/un.h>
#include <sys/types.h>
#include <arpa/inet.h>
#include <linux/netlink.h>
#include <stdlib.h>
#include <sys/fcntl.h>
#include <errno.h>
#include <QDebug>
#include "uevent.h"
#include "epoll_context.h"

int Uevent::parse_uevent(char *buf, int len)
{
    QList<QByteArray> list = QByteArray::fromRawData(buf, len).split('\0');
    struct UeventPara para;

    foreach(QByteArray pos, list) {
        if(pos.startsWith("ACTION="))
            para.action = pos.right(pos.size() - strlen("ACTION="));
        else if(pos.startsWith("DEVPATH="))
            para.path = pos.right(pos.size() - strlen("DEVPATH="));
        else if(pos.startsWith("SUBSYSTEM="))
            para.subsystem = pos.right(pos.size() - strlen("SUBSYSTEM="));
        else {
            if(para.subsystem == "switch") {
                if(pos.startsWith("SWITCH_NAME="))
                    para.switch_state.name = pos.right(pos.size() - strlen("SWITCH_NAME="));
                else if(pos.startsWith("SWITCH_STATE="))
                    para.switch_state.state = pos.right(pos.size() - strlen("SWITCH_STATE=")).toInt();
            } else if(para.subsystem == "usb") {
                if(pos.startsWith("DEVTYPE="))
                    para.usb.devtype = pos.right(pos.size() - strlen("DEVTYPE="));
                else if(pos.startsWith("PRODUCT="))
                    para.usb.product = pos.right(pos.size() - strlen("PRODUCT="));
                else if(pos.startsWith("INTERFACE="))
                    para.usb.interface = pos.right(pos.size() - strlen("INTERFACE="));
            }
        }
    }

    if((para.subsystem == "switch") && (para.switch_state.name == "hdmi"))
        emit hdmi(para.switch_state.state);
    else if((para.subsystem == "usb") && (para.usb.devtype == "usb_interface")) {
        if(para.usb.interface == "255/66/1") {
            if(para.action == "add")
                emit adb(1);
            else if(para.action == "remove")
                emit adb(0);
            qDebug("android %s detected ", para.action.constData());
        } else {
            if(para.usb.product.startsWith("5ac/")) {
                if(para.action == "add")
                    emit iphone(1);
                else if(para.action == "remove")
                    emit iphone(0);
                qDebug("iphone %s detected ", para.action.constData());
            }
        }
    }

    return 0;
}

int Uevent::do_uevent(struct epoll_event *event, struct epoll_context *epctx)
{
    Uevent *ue = Uevent::instance();
    static char buf[4096];
    int ret;

    Q_UNUSED(epctx);
    if(event->events & (EPOLLERR | EPOLLHUP))
        return -1;
    else if(!(event->events & EPOLLIN))
        return 0;

    while(1) {
        ret = recv(ue->fd, buf, sizeof(buf), 0);
        if(ret < 0) {
            if((errno != EAGAIN) && (errno != EINTR))
                return -1;
            break;
        } else if(ret == 0)
            return -1;

        if(ue)
            ue->parse_uevent(buf, ret);
    }

    return 0;
}

int Uevent::uevent_init(struct epoll_event *event)
{
    struct epoll_context *epctx = new epoll_context;
    Uevent *ue = instance();

    if(!ue || !epctx)
        return -ENOMEM;

    epctx->callback = ue->do_uevent;
    epctx->data = ue;

    event->events = EPOLLIN;
    event->data.ptr = epctx;

    return ue->fd;
}

Uevent::Uevent(QObject *parent)
    : QObject(parent)
{
    struct sockaddr_nl addr;
    int sz = 64 * 1024;
    addr.nl_family = AF_NETLINK;
    addr.nl_pid = getpid();
    addr.nl_groups = 0xffffffff;

    if((fd = socket(PF_NETLINK, SOCK_DGRAM, NETLINK_KOBJECT_UEVENT)) < 0) {
        qDebug("fatal error!!! create socket for netlink failed!!!");
        return;
    }
    setsockopt(fd, SOL_SOCKET, SO_RCVBUFFORCE, &sz, sizeof(sz));
    if(bind(fd, (struct sockaddr *) &addr, sizeof(addr)) < 0) {
        qDebug("fatal error!!! bind socket for netlink failed!!!");
        return;
    }
    ::fcntl(fd, F_SETFL, ::fcntl(fd, F_GETFL) | O_NONBLOCK);
}

Uevent::~Uevent()
{
    close(fd);
}

Uevent * Uevent::instance()
{
    static Uevent *uevent;

    if(Q_LIKELY(uevent && (uevent->fd >= 0)))
        return uevent;
    else if(!uevent) {
        uevent = new Uevent;
        if(uevent && (uevent->fd >= 0))
            return uevent;
    }

    return NULL;
}

