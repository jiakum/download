#ifndef AVPLAYER_H
#define AVPLAYER_H

#include <QObject>

class AVPlayer : public QObject
{
    Q_OBJECT
public:
    static AVPlayer *instance(void);
    void set_phone_status(bool iphone, bool android, int handle);
signals:
    
public slots:
    void hdmi_hotplug(int);
    void wifi_hotplug(bool);

private:
    explicit AVPlayer(QObject *parent = 0);
    
};

#endif // AVPLAYER_H
