#ifndef __YMAVLINK_H__
#define __YMAVLINK_H__

#ifdef __cplusplus
extern "C" {
#endif

#include <stdio.h>
#include <string.h>
#include "rcprotocol.h"
#include "rctimer.h"

#define DATA_PACKET_START_STR_L                     0x55
#define DATA_PACKET_START_STR_H                     0x55
#define DATA_PACKET_START_STR                       0x5555

#define CRC_START_POSITION                          3
#define CRC_INVALID_BYTES                           3

#define TYPE_BIT_0_1                                0x03
#define TYPE_BIT_2_4                                0x1C
#define TYPE_BIT_5                                  0x20
#define TYPE_BIT_6                                  0x40
#define TYPE_BIT_7                                  0x80

#define DATA_PACKET_TYPE_BIND_FLAG                  (0x00<<2)   /*绑定包*/
#define DATA_PACKET_TYPE_CHANEL_FLAG                (0x01<<2)   /*通道包*/
#define DATA_PACKET_TYPE_SENSOR_FLAG                (0x02<<2)   /*传感包*/
#define DATA_PACKET_TYPE_COMMAND_FLAG               (0x03<<2)   /*命令包*/
#define DATA_PACKET_TYPE_RESPONSE_FLAG              (0x04<<2)   /*应答包*/
#define DATA_PACKET_TYPE_EX_FLAG                    (0x05<<2)   /*扩展包*/
#define DATA_PACKET_TYPE_BEACON_FLAG                (0x07<<2)   /*信标*/

typedef enum HEADER {
    HEAD_DOMIAN_START_STR_L,
    HEAD_DOMIAN_START_STR_H,
    HEAD_DOMIAN_START_SIZE,
    HEAD_DOMIAN_START_FCF_L,
    HEAD_DOMIAN_START_FCF_H,
    HEAD_DOMIAN_START_TYPE,
    COMAND_HEAD_DOMIAN_PANID_L,
    COMAND_HEAD_DOMIAN_PANID_H,
    COMAND_HEAD_DOMIAN_NODEIDDEST_L,
    COMAND_HEAD_DOMIAN_NODEIDDEST_H,
    COMAND_HEAD_DOMIAN_NODEIDSOURCE_L,
    COMAND_HEAD_DOMIAN_NODEIDSOURCE_H,
    COMAND_HEAD_DOMIAN_COMMAND,
    COMAND_HEAD_DOMIAN_PARA,
} COMAND_HEAD_DOMIAN;

typedef struct COMMANDH {
    uint16_t     start_str;
    uint8_t      size;           //len 字节，数据长度，含len的     M3生成
    uint16_t     FCF;            //帧控制域  	见表2
    uint8_t      Type;           //帧类型，绑定时设为绑定帧 见表4
    uint16_t     PANID;          //网络地址，
    uint16_t     NodeIDdest;     //节点地址
    uint16_t     NodeIDsource;   //节点地址
    uint8_t      command;
} __attribute__((packed)) COMMAND_HEADER;

#define COMMAND_HEADER_SIZE                         sizeof(COMMAND_HEADER)
#define packet_len(x)       (((unsigned char *)(x))[HEAD_DOMIAN_START_SIZE] + CRC_INVALID_BYTES)
#define payload_len(x)      (((unsigned char *)(x))[HEAD_DOMIAN_START_SIZE] - 1)
#define MIN_PACKET_SIZE     5   // 2bytes 0x55 0x55, 1byte size, 1byte payload, 1byte crc
#define YMAVLINK_BUFFERSIZE (1024)

struct ymavlink_buffer {
    int                 fd;
    int                 fdtype;
    unsigned char       buf[YMAVLINK_BUFFERSIZE];           // the pointer to the buffer
    int                 len;            // the length of the vaild buffer
    int                 offset;           // the length of the buf has been offset
    int                 errors;         // the errors happened times
    void                *pilot;
    unsigned char       tx_buf[260];    // the max size of the ymavlink packet is 256 + 3
};

int ymavlink_write_buf(struct ymavlink_buffer *ybuf, unsigned char *buf, int size);
int ymavlink_read_buf(struct ymavlink_buffer *ybuf);

static inline int ymavlink_cyclic_buf(struct ymavlink_buffer *ybuf)
{
    if ( ybuf->offset > ybuf->len || ybuf->len > YMAVLINK_BUFFERSIZE ) {
        printf("This should not be happened: s=%d l=%d u=%d\n", YMAVLINK_BUFFERSIZE,
                ybuf->len, ybuf->offset);
        ybuf->offset = ybuf->len = 0;
        return -1;
    }

    memcpy(ybuf->buf, ybuf->buf+ybuf->offset, ybuf->len-ybuf->offset);
    ybuf->len -= ybuf->offset;
    ybuf->offset = 0;
    return ybuf->len;
}

static inline int ymavlink_update_buf(struct ymavlink_buffer *ybuf, int len)
{
    ybuf->offset += len;
    return 0;
}

static inline int ymavlink_reset_buf(struct ymavlink_buffer *ybuf)
{
    ybuf->offset = ybuf->len = ybuf->errors = 0;
    return 0;
}

static inline struct ymavlink_buffer *alloc_ymavlink_buf(int fdtype)
{
    struct ymavlink_buffer *ybuf = (struct ymavlink_buffer *)malloc(sizeof(*ybuf));

    if(ybuf) {
        ybuf->offset = ybuf->len = ybuf->errors = 0;
        ybuf->fd = -1;
        ybuf->fdtype = fdtype;
        ybuf->pilot = NULL;
    }

    return ybuf;
}

int ymavlink_get_packet(struct ymavlink_buffer *ybuf);
int ymavlink_send_packet(struct ymavlink_buffer *ybuf, unsigned char type, unsigned int command, unsigned char* param, unsigned int param_size);

static inline int response_command(struct ymavlink_buffer *ybuf, unsigned int command, unsigned char* param, unsigned int param_size)
{
    return ymavlink_send_packet(ybuf, DATA_PACKET_TYPE_RESPONSE_FLAG, command, param, param_size);
}

static inline int write_command_and_params(struct ymavlink_buffer *ybuf, unsigned int command, unsigned char* param, unsigned int param_size)
{
    return ymavlink_send_packet(ybuf, DATA_PACKET_TYPE_COMMAND_FLAG, command, param, param_size);
}

static inline int write_command(struct ymavlink_buffer *ybuf, unsigned int command)
{
    return ymavlink_send_packet(ybuf, DATA_PACKET_TYPE_COMMAND_FLAG, command, NULL, 0);
}

typedef struct {
    int              size;
    int              freq;     // in millinsecends
    RcTimer          *timer;
    unsigned char    *buf;
    struct ymavlink_buffer *ybuf;
} SendTask;

static inline void del_sendtask(SendTask *task)
{
    if ( task ) {
        del_rctimer(task->timer);
        if (task->buf) {
            free(task->buf);
        }
        free(task);
    }
}

SendTask * add_sendtask(struct ymavlink_buffer *cache, unsigned char *buf, int size, int freq);

#ifdef __cplusplus
}
#endif

#endif /* __YMAVLINK_H__ */
