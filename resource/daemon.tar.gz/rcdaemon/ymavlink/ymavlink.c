
#include <stdlib.h>
#include <stdint.h>
#include <sys/types.h>
#include <unistd.h>

#include <errno.h>
#include "common.h"
#include "ymavlink.h"
#include "rcprotocol.h"
#include "utils.h"
#include "autopilot.h"

#define TAG "ymavlink"

static inline int _write_(int fd, unsigned char *buf, int size, int type)
{
    if ( type == FD_TYPE_SOCK ) {
        return send(fd, buf, size, 0);
    } else {
        return write(fd, buf, size);
    }
}

/* use these carefully. Check the return value.*/
int ymavlink_write_buf(struct ymavlink_buffer *ybuf, unsigned char *buf, int size)
{
    int left = size;
    int fd;
    int ret = 0;
    int try = 10;

    fd = ybuf->fd;

    do {
        if((ret = _write_(fd, buf + size - left, left, ybuf->fdtype)) < 0) {
            if(errno != EAGAIN && errno != EINTR) {
                return -1;
            }
            /* continue */
            try--;
            loge(LOG_RCDAEMON, TAG, "try=%d errno=%d\n", try, errno);
        } else {
            left -= ret;
        }
    } while(left > 0 && try > 0);

    return 0;
}

int ymavlink_read_buf(struct ymavlink_buffer *ybuf)
{
    int  ret;

    if ( ybuf->fdtype == FD_TYPE_SOCK ) {
        ret = recv(ybuf->fd, ybuf->buf+ybuf->len, YMAVLINK_BUFFERSIZE-ybuf->len, 0);
    } else {
        ret = read(ybuf->fd, ybuf->buf+ybuf->len, YMAVLINK_BUFFERSIZE-ybuf->len);
    }

    if ( ret < 0 ) {
        if ( errno != EAGAIN && errno != EINTR ) {
            loge(LOG_RCDAEMON, TAG, "%s error\n", __func__);
            return -1;
        }
        return 0;
    } else if(ret == 0) {
        /* fd is NON_BLOCK type. closed !*/
        return -1;
    }

    ybuf->len += ret;

    return ret;
}

int ymavlink_get_packet(struct ymavlink_buffer *ybuf)
{
    while ( (HEAD_DOMIAN_START_SIZE + 1) < (ybuf->len - ybuf->offset) ) {
        uint8_t *buf = ybuf->buf + ybuf->offset;

        if ( ((uint16_t*)buf)[0] != 0x5555 ) {
            do {
                if ( buf[ybuf->offset + 1] != 0x55 ) {
                    ybuf->offset += 2;
                } else if ( buf[ybuf->offset + 0] != 0x55 ) {
                    ybuf->offset += 1;
                } else {
                    break;
                }
            } while (ybuf->offset + 2 < ybuf->len);

        } else {
            // Find the 0x5555 at the buf head
            int len = packet_len(buf);
            if ( len > ybuf->len - ybuf->offset ) {
                // This packet is not complete, need to continue to read
                break;      // break the top while
            } else if ( len < MIN_PACKET_SIZE ) {
                ybuf->errors++;
                ybuf->offset += HEAD_DOMIAN_START_SIZE + 1;
                logw(LOG_RCDAEMON, TAG, "id=%d s=%d l=%d u=%d\n", ybuf->fdtype, YMAVLINK_BUFFERSIZE, ybuf->len, ybuf->offset);
            } else {
                if ( calc_crc8( buf+HEAD_DOMIAN_START_FCF_L, payload_len(buf) ) != buf[len-1] ) {
                    // This packet crc8 check error, so we need move the ybuf->offset
                    ybuf->errors++;
                    ybuf->offset += CRC_INVALID_BYTES;
                    logw(LOG_RCDAEMON, TAG, "id=%d s=%d l=%d u=%d\n", ybuf->fdtype, YMAVLINK_BUFFERSIZE, ybuf->len, ybuf->offset);
                } else {
                    // Check CRC8 correctlly, so we get one packet
                    // The packet start from ybuf->buf[ybuf->offset]
                    // and the length of the packet = ret
                    // the packet consumer function should update the ybuf->offset later
                    return len;
                }
            }
        }
    }

    return 0;
}

int ymavlink_send_packet(struct ymavlink_buffer *ybuf, unsigned char type, unsigned int command, unsigned char* param, unsigned int param_size)
{
    unsigned char *buf;
    COMMAND_HEADER *headr;
    AutoPilot *p = ybuf->pilot;
    int ret = 0;

    //logi(LOG_RCDAEMON, TAG, "%s ,type=%d command=%d size=%d\n", __func__, type, command, param_size);
    buf = ybuf->tx_buf;
    headr = (COMMAND_HEADER *)buf;

    memset(headr, 0, COMMAND_HEADER_SIZE);

    headr->start_str = DATA_PACKET_START_STR;
    headr->Type      |= type;
    headr->command   = command & 0xFF;
    headr->NodeIDsource = 0;

    if (p) {
        headr->FCF          = p->rc_bindinfo.FCF;
        headr->PANID        = p->rc_bindinfo.TxPANID;
        headr->NodeIDdest   = p->autopilot_bindinfo.RxAddr;
        headr->NodeIDsource = p->bind_tx_addr;
        headr->PANID        = p->autopilot_bindinfo.RxPANID;
    }

    headr->size      = COMMAND_HEADER_SIZE + param_size + 1 - 3;

    memcpy(buf + COMMAND_HEADER_SIZE, param, param_size);

    buf[packet_len(buf) - 1] = calc_crc8(buf+HEAD_DOMIAN_START_FCF_L, payload_len(buf));

    ret = ymavlink_write_buf(ybuf, buf, packet_len(buf));

    return ret;
}

static int sendtask_func(RcTimer *timer)
{
    SendTask      *task     = timer->p;
    unsigned char *buf      = task->buf;
    struct ymavlink_buffer *ybuf    = task->ybuf;
    int           ret       = 0;

    ret = ymavlink_write_buf(ybuf, buf, task->size);

    timer->timeout += (int64_t)task->freq;

    return ret;
}

SendTask * add_sendtask(struct ymavlink_buffer *ybuf, unsigned char *buf, int size, int freq)
{
    SendTask *task  = malloc(sizeof(SendTask));
    int      len    = ALIGN32(size);

    if(!task) {
        loge(LOG_RCDAEMON, TAG, "malloc failed. No memory to alloc SendTask!!!\n");
        return NULL;
    }
    if(!(task->buf = malloc(len))) {
        free(task);
        loge(LOG_RCDAEMON, TAG, "malloc failed. No memory to alloc %d buffer!!!\n", len);
        return NULL;
    }

    memcpy(task->buf, buf, size);
    task->size = size;
    task->freq = freq;
    task->ybuf = ybuf;

    task->timer = add_rctimer(task, sendtask_func, freq);

    return task;
}
