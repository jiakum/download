#ifndef __PHONE_H__
#define __PHONE_H__

#include "rcprotocol.h"
#include "ymavlink.h"

int phone_write_cmd(uint8_t type, uint8_t cmd, uint8_t *buf, int size);

static inline int phone_response(uint8_t cmd, uint8_t *buf, int size)
{
    return phone_write_cmd(DATA_PACKET_TYPE_RESPONSE_FLAG, cmd, buf, size);
}

static inline int phone_command(uint8_t cmd, uint8_t *buf, int size)
{
    return phone_write_cmd(DATA_PACKET_TYPE_COMMAND_FLAG, cmd, buf, size);
}

int phone_write_buf(uint8_t *buf, int size);
int phone_init();
void phone_deinit();

#endif /* __PHONE_H__ */
