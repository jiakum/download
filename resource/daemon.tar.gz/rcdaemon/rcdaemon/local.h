#ifndef _LOCAL_H_
#define _LOCAL_H_

#include "epoll_context.h"
#include "rcprotocol.h"
#include "ymavlink.h"

#define COMMAND_PHONE_STATUS (0x10)
#define RCDAEMON_LOCAL_SOCKET "/tmp/socket_for_ui"

int local_write_cmd(uint8_t type, uint8_t cmd, uint8_t *buf, int size);

static inline int local_response(uint8_t cmd, uint8_t *buf, int size)
{
    return local_write_cmd(DATA_PACKET_TYPE_RESPONSE_FLAG, cmd, buf, size);
}

static inline int local_command(uint8_t cmd, uint8_t *buf, int size)
{
    return local_write_cmd(DATA_PACKET_TYPE_COMMAND_FLAG, cmd, buf, size);
}

int local_write_buf(uint8_t *buf, int size);

int init_local(int epfd, struct epoll_context *epctx);

#endif // _LOCAL_H_
