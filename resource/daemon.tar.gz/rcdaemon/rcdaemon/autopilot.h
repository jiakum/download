#ifndef __AUTOPILOT_H__
#define __AUTOPILOT_H__

#include "channel.h"

enum STATE_ENUM {
    STATE_NONE,
    STATE_AWAIT,
    STATE_BIND,
    STATE_CALIBRATE,
    STATE_SETUP,
    STATE_RUN,
    STATE_SIMULATOR,
    STATE_DEFAULT_CALIBRATE,
    STATE_SETUP_RUN,
    STATE_END
};

typedef enum BIND_STATES_ENUM {
    UNBINDED,
    BINDED
} BIND_STATES;

typedef enum BIND_COMMAND_ENUM {
    REVC_BIND_INFO_NO_BACK,
    REVC_BIND_INFO_BACK,
    ONLY_BACK,
    RESVE1,
    RECEIVER_BIND_SUCESS
} BIND_COMMAND;

typedef enum PARSE_MODE_ENUM {
    TRANSMITTER_TYPE,
    RECEIVER_TYPE
} PARSE_MODE;

//#define AIRPLANE_MODE_FUN

#ifdef AIRPLANE_MODE_FUN
typedef enum AIRPLANE_TYPE_ENUM {
    SMART_MODE,
    ANGLE_MODE,
    HOME_MODE
} FLIGHT_MODE_TYPE;
#endif

enum {
    FMODE_Throttle_SOLID, //0
    FMODE_Throttle_FLASHING, //1
    FMODE_Throttle_WOULD_BE_SOLID_NO_GPS, //2
    FMODE_Angle_SOLID, //3
    FMODE_Angle_FLASHING, //4
    FMODE_Angle_WOULD_BE_SOLID_NO_GPS, //5
    FMODE_SMART, //6
    FMODE_SMART_BUT_NO_GPS, //7
    FMODE_MOTORS_STARTING, //8
    FMODE_TEMP_CALIB, //9
    FMODE_PRESS_CALIB, //10
    FMODE_ACCELBIAS_CALIB, //11
    FMODE_EMERGENCY_KILLED, //12
    FMODE_GO_HOME,//13
    FMODE_LANDING, //14
    FMODE_BINDING, //15
    FMODE_READY_TO_START, //16
    FMODE_WAITING_FOR_RC, //17
    FMODE_MAG_CALIB, //18
    FMODE_UNKNOWN ,
    FMODE_Agility, //20
    FMODE_FOLLOW, //21
    FMODE_FOLLOW_NO_ST10_GPS, //22
    FMODE_Watch_Me, //23
    FMODE_Watch_Me_NO_ST10_GPS, //24
    FMODE_GUIDE_MODE, //25
    FMODE_CCC, //26
    FMODE_Jour, //27
    FMODE_Orbit, //28
    FMODE_POI, //29
    FMODE_3D_FOLLOW_WIZARD, //30
    FMODE_3D_Watch_Me_WIZARD //31

  };

typedef struct BPADTOM4 {
    uint16_t     start_str;
    uint8_t      size;           //len 字节，数据长度，含len的
    uint16_t     FCF;            //帧控制域  绑定时设为目的地址模式	见表2
    uint8_t      Type;           //帧类型，绑定时设为绑定帧 见表4
    uint8_t      Command;        //命令字节，绑定时的相关命令
    uint16_t     ComPara;        //命令的参数
    uint8_t      FInterval1;     //跳频间隔时间1
    uint8_t      FInterval2;     //跳频间隔时间2
    uint8_t      CRC8;           //CRC校验
}__attribute__((packed)) PADTOM4bindInfo;

typedef struct BM4TOM3 {
    uint16_t     start_str;
    uint8_t      size;           //len 字节，数据长度，不包含len自己的长度
    uint16_t     FCF;            //帧控制域  绑定时设为目的地址	见表2
    uint8_t      Type;           //帧类型，绑定时设为绑定帧 见表4
    uint8_t      Command;        //命令字节，绑定时的相关命令
    uint16_t     ComPara;        //命令的参数
    uint16_t     Protocol;       //发射机协议版本号          		M3定义
    uint16_t     Mode;           //发射机型号对应编号			M3定义
    uint16_t     TxPANID;        //本机发射机网络地址         	M3定义
    uint16_t     TxAddr;         //本机发射机地址				M3定义
    uint8_t      FInterval1;     //跳频间隔时间1              	PAD定义
    uint8_t      FInterval2;     //跳频间隔时间 2             	PAD定义
    uint8_t      ANum;           //本发射机拥有的模拟通道个数     M4定义
    uint8_t      ABits;          //每个模拟通道的数据位数，如0，位数定义参见表3  M4定义
    uint8_t      TrNum;          //本发射机拥有的微调通道个数  M4定义
    uint8_t      TrBits;         //每个微调通道拥有的数据位数，如0，位数定义参见表3  M4
    uint8_t      SwNum;          //本发射机拥有的开关通道个数  M4定义
    uint8_t      SwBits;         //每个开关通道拥有的数据位数，如为0，位数定义参见表3  M4
    uint8_t      ExtraNum;       //保留
    uint8_t      ExtraBits;      //保留
#if OWNER_ANUM
    uint8_t      AchName[OWNER_ANUM];        //各模拟通道对应的通道名编号，ANum个，内容参见表3. M4
#endif
#if OWNER_TRNUM
    uint8_t      TrName[OWNER_TRNUM];        //各微调通道对应的通道名编号，参见表3   	M4
#endif
#if OWNER_SWNUM
    uint8_t      SwName[OWNER_SWNUM];        //各开关通道对应的通道名编号，参见表3   	M4
#endif
#if OWNER_EXTRANUM
    uint8_t      ExtName[OWNER_EXTRANUM];
#endif
    uint8_t      CRC8;           //CRC校验
}__attribute__((packed))  M4ToM3bindInfo;

typedef struct BM3TOM4TOPAD {
    uint16_t     start_str;
    uint8_t      size;           //len 字节，数据长度，含len的
    uint16_t     FCF;            //帧控制域  绑定时设为源地址模式	见表2
    uint8_t      Type;           //帧类型，绑定时设为绑定帧 见表4
    uint8_t      RxState;        //接收机的当前状态
    uint16_t     Protocol;       //接收机协议版本号
    uint16_t     Mode;           //接收机型号对应编号
    uint16_t     RxPANID;        //本机最近使用的网络地址
    uint16_t     RxAddr;         //本机最近使用的接收机地址
    uint8_t      ExtraID[8];     //接收机唯一的设备ID地址
    uint8_t      ANum;           //本接收机拥有的模拟通道个数
    uint8_t      ABits;          //每个模拟通道的数据位数，如为0，位数定义参见表3
    uint8_t      TrNum;          //本接收机拥有的微调通道个数
    uint8_t      TrBits;         //每个微调通道拥有的数据位数，如为0，位数定义参见表3
    uint8_t      SwNum;          //本接收机拥有的开关通道个数
    uint8_t      SwBits;         //每个开关通道拥有的数据位数，如为0，位数定义参见表3
    uint8_t      MonitNum;       //本接收机拥有的可回传通道个数
    uint8_t      MonitBits;      //每个可回传通道拥有的数据位数，如为0，位数定义参见表3
    uint8_t      ExtraNum;
    uint8_t      ExtraBits;
    //uint8_t    AchName[];      //各模拟通道对应的通道名编号，ANum个，内容参见表3.
    //uint8_t	TrName[];       //各微调通道对应的通道名编号，参见表3
    //uint8_t	SwName[];       //各开关通道对应的通道名编号，参见表3
    //uint8_t	MonitName[];    //各可回传通道对应的通道名编号，参见表3
    //uint8_t	CRC8;           //CRC校验
}__attribute__((packed))  M3TOM4TOPADBindInfo;

typedef struct
{
    uint16_t t;             //packet counter or clock

    int32_t lat;            //lattitude (degrees)  +/- 90 deg
    int32_t lon;            //longitude (degrees)  +/- 180 deg
    int32_t alt;            //0.01m resolution, altitude (meters)

    int16_t vx;
    int16_t vy;
    int16_t vz;             //velocity 0.01m res, +/-320.00  North - East - Down
    uint8_t nsat;           //number of satellites (up to 32), fix type (2 bits), gps used 1 bit

    uint8_t voltage;        //25.4V    voltage = 5 + 255*0.1 = 30.5V, min=5V
    uint8_t current;        //0.5A resolution

    int16_t roll;
    int16_t pitch;
    int16_t yaw;            //0.01 degree resolution

    uint8_t motorStatus;    //1 bit per motor for status 1=good, 0= fail
    uint8_t imuStatus;      //mpu6050 (FC0), mpu6050 (IMU), accelerometer (IMU)
    uint8_t pressCompassGpsStatus;      //pressure (FC0), pressure (IMU), compass1, compass2, GPS1, GPS2
    uint8_t fMode;          //vehicle flight mode
    uint8_t vehicleType;

    uint8_t errorFlags1;         //warning flags
    uint8_t gpsAccH;             //gps accuracy in 0.05m resolution
    int8_t fsk_rssi;            //[-100,0]
} __attribute__((packed)) TelemetryData2;            //34 bytes

typedef struct SET_PLATFORM_DATA {
    uint8_t cmd_type;            //  0xab
    uint16_t plane_rf2_add;
    uint16_t plane_rf2_pan_id;
    uint16_t plat_add;
    int32_t lat;            //lattitude (degrees)	+/- 90 deg
    int32_t lon;            //longitude (degrees)	+/- 180 deg
    int32_t alt;            //0.01m resolution, altitude (meters)
} __attribute__((packed)) SET_PLATFORM_DATA;


typedef struct {
    enum STATE_ENUM         state;
    M3TOM4TOPADBindInfo     autopilot_bindinfo;         // the bindinfo got from autopilot
    M4ToM3bindInfo          rc_bindinfo;                // the bindinfo sent to autopilot
    uint8_t                 is_binded;
    uint8_t                 bind_sucess_count;
    uint16_t                bind_tx_addr;
    uint16_t                to_bind_addr;
    struct ymavlink_buffer  *ybuf;
    struct epoll_context    *epctx;
    int                     epfd;
    int32_t                 drone_lat;
    int32_t                 drone_lon;
    uint8_t                 gps_fixed;
    uint8_t                 channel_buf[64];
} AutoPilot;

int autopilot_write_command_and_params(unsigned int cmd, uint8_t *param, int size);
int autopilot_get_bindinfo(uint8_t *addr, int size);
int autopilot_write_buf(unsigned char *buf, int size);
int autopilot_set_state(enum STATE_ENUM val);
enum STATE_ENUM autopilot_get_state();
void autopilot_clear_bind();
int autopilot_send_bindinfo(int on, unsigned char* buf, unsigned int size);
int autopilot_set_rf_enter_run(int on);
int init_pilot(int epfd, struct epoll_context *epctx);

#endif /* __AUTOPILOT_H__ */
