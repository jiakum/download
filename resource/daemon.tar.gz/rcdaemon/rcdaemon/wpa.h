#ifndef __WPA_H__
#define __WPA_H__

#include "epoll_context.h"

enum WSTATE {
    WSTATE_NONE, /* wpa_supplicant is not connected */
    WSTATE_IDLE, /* wpa_supplicant is connected , but no task */
    WSTATE_SCAN,
    WSTATE_GET_RESULTS,
    WSTATE_ADDNET,
    WSTATE_SETSSID,
    WSTATE_SETPSK,
    WSTATE_SELECTNET,
    WSTATE_ENABLENET,
    WSTATE_DISCONNECT,
    WSTATE_GET_STATUS,
};

static inline int get_line(unsigned char *buf, int len)
{
    unsigned char *end = buf + len;
    unsigned char *start = buf;

    while(*buf != '\n' && *buf != '\0') {
        if(*buf == '	')
            *buf = ' ';
        if(++buf >= end)
            break;
    }

    return (buf - start + 1);
}

int wpa_init(int epfd, struct epoll_context *epctx);
void wpa_deinit(void);

int wpa_scan(void);
int wpa_get_status(void);
int wpa_connect(char *essid, char *psk);

#endif /* __WPA_H__ */
