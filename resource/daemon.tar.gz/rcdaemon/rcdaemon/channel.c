#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>

#include "log.h"
#include "set_bits.h"
#include "list.h"
#include "setting.h"
#include "analog_input.h"

#include "channel.h"

#define CH_MAP_STR              "channel_map"

#define TAG "channel"

typedef struct {
    int                 val;
    int                 times;
    struct list_head    list;
} ChannelValue;

typedef struct {
    int16_t extra_value;
    uint8_t extra_type;    // 0:Disable 1:override 2:add
} ExtraConfig;

typedef uint16_t (*func)(int index);

typedef struct {
    int             channel_map_index;
    uint16_t        curve_points[ADC_NUMS][MAX_POINTS_COUNT];
    ChannelValue    ch10_queue;
    ExtraConfig     extra_config[OWNER_ANUM + OWNER_SWNUM];
    int             is_smart_mode;
    int             is_go_home;
    func            get_values[OWNER_ANUM + OWNER_SWNUM];
} Channel;

Channel g_channel;

static uint8_t channel_map[4][4] = {{HW_ID_J3, HW_ID_J4, HW_ID_J1, HW_ID_J2},
                                    {HW_ID_J1, HW_ID_J4, HW_ID_J3, HW_ID_J2},
                                    {HW_ID_J3, HW_ID_J2, HW_ID_J1, HW_ID_J4},
                                    {HW_ID_J1, HW_ID_J2, HW_ID_J3, HW_ID_J4}};

static inline void channel_init_map(Channel *ch)
{
    int val = 0;

    ch->channel_map_index = 1;

    if (get_value_int(NULL, CH_MAP_STR, &val) >= 0) {
        if ( val > 0 && val < 4 ) {
            ch->channel_map_index = val;
        }
    }
    return;
}

int channel_set_map(int index)
{
    Channel *ch = &g_channel;

    if ( index < 0 || index >= 4 ) {
        loge(LOG_RCDAEMON, TAG, "invaild arg index=%d\n", index);
        return -1;
    }

    store_int(NULL, CH_MAP_STR, index);
    ch->channel_map_index = index;

    return 0;
}

int channel_get_map()
{
    Channel *ch = &g_channel;

    return ch->channel_map_index;
}

static float calc_cross_curve(int index, uint16_t val)
{
    Channel *ch = &g_channel;
    uint8_t range;
    float slp;
    int16_t ipt;
    uint8_t size = MAX_POINTS_COUNT;


    if (val > CH_MAX)
        val = CH_MAX;

    range =(uint8_t)(val / DELTAX);
    if ((range >= size - 1) && (size > 1))
    {
        range = size - 2;
    }

    slp = (ch->curve_points[index][range+1] - ch->curve_points[index][range]) / DELTAX;
    ipt = ch->curve_points[index][range] - range*(ch->curve_points[index][range+1] - ch->curve_points[index][range]);

    return (val*slp + ipt);
}

// for CH_THR, CH_ALE, CH_ELE, CH_RUD
static uint16_t get_value_for_joystick(int index)
{
    uint16_t ret = CH_DEFAULT_VAL;
    Channel *ch = &g_channel;
    int hw_id = channel_map[ch->channel_map_index][index];

    if ( index > CH_RUD ) {
        return ret;
    }

    if ( hw_id < HW_ID_J1 || hw_id > HW_ID_J4  ) {
        return ret;
    }

    ret = analog_input_get_value(hw_id);
    ret = calc_cross_curve(index, ret);

    return ret;
}

void channel_set_smart_mode(int val)
{
    Channel *ch = &g_channel;

    if ( ch->is_smart_mode == val ) {
        return;
    }

    ch->is_smart_mode = val;
    return;
}

int channel_get_smart_mode()
{
    Channel *ch = &g_channel;
    return ch->is_smart_mode;
}

#define CH_SMART_MODE_VAL   3414
#define CH_HOME_MODE_VAL    683

static inline uint16_t get_value_for_ch5(int index)
{
    return channel_get_gohome() ? CH_HOME_MODE_VAL : (channel_get_smart_mode() ? CH_SMART_MODE_VAL : CH_DEFAULT_VAL);
}

void channel_set_gohome(int val)
{
    Channel *ch = &g_channel;

    if ( ch->is_go_home == val ) {
        return;
    }

    ch->is_go_home = val;
    return;
}

int channel_get_gohome()
{
    Channel *ch = &g_channel;
    return ch->is_go_home;
}

#define CH_GO_HOME_VAL  4095
static uint16_t get_value_for_ch6(int index)
{
    return channel_get_gohome() ? CH_GO_HOME_VAL: CH_DEFAULT_VAL;
}

static uint16_t get_value_for_ch7(int index)
{
    return analog_input_get_value(HW_ID_K1);
}

static uint16_t get_value_for_ch8(int index)
{
    return analog_input_get_value(HW_ID_K2);
}

static uint16_t get_value_for_ch9(int index)
{
    return CH_DEFAULT_VAL;
}

int ch10_send_value(int val)
{
    Channel *ch = &g_channel;
    ChannelValue *temp = (ChannelValue *)malloc(sizeof(ChannelValue));

    if (temp == NULL) {
        loge(LOG_RCDAEMON, TAG, "malloc failed val=%u\n", val);
        return -1;
    }

    temp->times = 10;
    temp->val = val;

    list_add(&temp->list, &ch->ch10_queue.list);
    return 0;
}

static inline void del_channelvalue(ChannelValue *chv)
{
    if ( chv ) {
        list_del(&chv->list);
        free(chv);
    }
}

static uint16_t get_value_for_ch10(int index)
{
    ChannelValue *ch_val;
    Channel *ch = &g_channel;

    if ( list_empty(&ch->ch10_queue.list) ) {
        return CH_DEFAULT_VAL;
    }

    ch_val = list_first_entry(&ch->ch10_queue.list, ChannelValue, list);
    if ( ch_val->times-- > 5 ) {
        return ch_val->val;
    }

    if ( ch_val->times == 0 ) {
        del_channelvalue(ch_val);
    }
    return CH_DEFAULT_VAL;
}

static uint16_t get_value_for_ch11(int index)
{
    return CH_DEFAULT_VAL;
}

static uint16_t get_value_for_ch12(int index)
{
    return CH_DEFAULT_VAL;
}

static uint16_t ch_thr_ale_ele_curve_def[MAX_POINTS_COUNT] = {683, 854, 1025, 1196, 1367, 1538, 1709, 1880, 2048, 2217, 2388, 2559, 2730, 2901, 3072, 3243, 3414};
static uint16_t ch_rud_curve_def[MAX_POINTS_COUNT] = {956, 1093, 1230, 1367, 1504, 1641, 1778, 1915, 2048, 2181, 2316, 2451, 2586, 2721, 2856, 2991, 3126};
static char CH_CURVE_STR[ADC_NUMS][16]   = {"thr_curve", "ale_curve", "ele_curve", "rud_curve", "k1_curve", "k2_curve"};

static inline void channel_set_default_curve(int index)
{
    Channel *ch = &g_channel;

    if ( index == CH_RUD ) {
        memcpy(&ch->curve_points[index][0], ch_rud_curve_def, sizeof(ch_rud_curve_def));
    } else {
        memcpy(&ch->curve_points[index][0], ch_thr_ale_ele_curve_def, sizeof(ch_thr_ale_ele_curve_def));
    }
}

int channel_set_curve(int index, uint8_t *buf, int size)
{
    Channel *ch = &g_channel;

    if ( index >= ADC_NUMS || size < sizeof(ch->curve_points[index]) ) {
        loge(LOG_RCDAEMON, TAG, "invaild arg index=%u, size=%d\n", index, size);
        return -1;
    }

    store_data(NULL, CH_CURVE_STR[index], buf, sizeof(ch->curve_points[index]));

    memcpy(&ch->curve_points[index][0], buf, sizeof(ch->curve_points[index]));

    return 0;
}

int channel_get_curve(int index, uint8_t *buf, int size)
{
    Channel *ch = &g_channel;
    if ( index >= ADC_NUMS || size < sizeof(ch->curve_points[index]) ) {
        loge(LOG_RCDAEMON, TAG, "invaild arg index=%u, size=%d\n", index, size);
        return -1;
    }

    if (get_rawdata(NULL, CH_CURVE_STR[index], buf, sizeof(ch->curve_points[index])) < 0) {
        channel_set_default_curve(index);
    } else {
        memcpy(&ch->curve_points[index][0], buf, sizeof(ch->curve_points[index]));
    }

    return 0;
}

static inline void channel_init_curve(Channel *ch)
{
    uint8_t tmp[sizeof(ch->curve_points[0])];
    channel_get_curve(CH_THR, tmp, sizeof(tmp));
    channel_get_curve(CH_ALE, tmp, sizeof(tmp));
    channel_get_curve(CH_ELE, tmp, sizeof(tmp));
    channel_get_curve(CH_RUD, tmp, sizeof(tmp));
}

static inline void channel_init_get_values(Channel *ch)
{
    int i = 0;

    for ( i = 0; i <= CH_RUD; i++ ) {
        ch->get_values[i] = get_value_for_joystick;
    }

    ch->get_values[CH_5] = get_value_for_ch5;
    ch->get_values[CH_6] = get_value_for_ch6;
    ch->get_values[CH_7] = get_value_for_ch7;
    ch->get_values[CH_8] = get_value_for_ch8;
    ch->get_values[CH_9] = get_value_for_ch9;
    ch->get_values[CH_10] = get_value_for_ch10;
    ch->get_values[CH_11] = get_value_for_ch11;
    ch->get_values[CH_12] = get_value_for_ch12;
}

static int __channel_init(int aNum, int aBits, int swNum, int swBits)
{
    Channel *ch = &g_channel;
    memset(ch, 0, sizeof(Channel));

    INIT_LIST_HEAD(&ch->ch10_queue.list);

    channel_init_map(ch);
    channel_init_curve(ch);
    channel_init_get_values(ch);

    return 0;
}

int channel_init()
{
    return __channel_init(OWNER_ANUM, OWNER_ABITS, OWNER_SWNUM, OWNER_SWBITS);
}

void channel_deinit()
{
    Channel *ch = &g_channel;
    ChannelValue *entry;

    while ( !list_empty(&ch->ch10_queue.list) ) {
        entry = list_first_entry(&ch->ch10_queue.list, ChannelValue, list);
        del_channelvalue(entry);
    }

    return;
}

uint16_t channel_get_value(unsigned int index)
{
    uint16_t ret = CH_DEFAULT_VAL;
    Channel *ch = &g_channel;
    ExtraConfig *config = NULL;
    int bits = index < OWNER_ANUM ? OWNER_ABITS : OWNER_SWBITS;

    if ( index > CH_12 ) {
        loge(LOG_RCDAEMON, TAG, "invaild arg index=%u\n", index);
        return ret;
    }

    config = &ch->extra_config[index];

    if (config->extra_type == EXTRA_OVERRIDE) {
        ret = config->extra_value;
    } else {
        if ( ch->get_values[index] ) {
            ret = ch->get_values[index](index);
        } else {
            ret = CH_DEFAULT_VAL;
        }
        if (config->extra_type == EXTRA_ADD) {
            int16_t t = ret;
            t += config->extra_value;
            ret = t;
        }
    }

    ret &= ((1 << bits) - 1);
    return ret;
}

int channel_set_extra_value(unsigned int index,
                             int extra_type, int16_t val)
{
    Channel *ch = &g_channel;
    ExtraConfig *config = NULL;

    if ( index >= OWNER_ANUM + OWNER_SWNUM ) {
        loge(LOG_RCDAEMON, TAG, "invaild arg index=%u\n", index);
        return -1;
    }

    config = &ch->extra_config[index];
    config->extra_type = extra_type;
    config->extra_value = val;

    return 0;
}

int fill_channel_data(unsigned char *buf, int size)
{
    SetBitContext s;
    int i;
    int bits;

    if ( buf == NULL || size < 20 ) {
        loge(LOG_RCDAEMON, TAG, "invaild arg:buf=%p size=%d(size should >= 20)\n", buf, size);
        return -1;
    }

    init_set_bits(&s, buf, size);

    for ( i = 0; i < OWNER_ANUM + OWNER_SWNUM; i++ ) {
        bits = i < OWNER_ANUM ? OWNER_ABITS : OWNER_SWBITS;
        set_bits(&s, bits, channel_get_value(i));
    }

    return 0;
}
