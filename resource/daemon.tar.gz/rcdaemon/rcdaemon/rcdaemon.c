
#include <errno.h>
#include <signal.h>

#include "common.h"
#include "rcprotocol.h"
#include "list.h"
#include "set_bits.h"
#include "utils.h"
#include "ymavlink.h"
#include "mcu.h"
#include "input.h"
#include "wpa.h"
#include "phone.h"
#include "autopilot.h"
#include "channel.h"
#include "devices.h"
#include "gps/ublox.h"
#include "local.h"
#include "utils.h"
#include "setting.h"
#include "libswatchdog.h"
#include "gpioctrl.h"

#define TAG "rcdaemon"

#define RCDAEMON_VERSION        "1.00.01 @ " __DATE__ " " __TIME__

#define START_TIMES             "times"

struct init_proc {
    int (*func) (int epfd, struct epoll_context *epctx);
    char *name;
};

#define INIT_PROC(fun) {.func = fun, .name = #fun}
static const struct init_proc programs[] = {
    INIT_PROC(init_local),
    INIT_PROC(phone_init),
    INIT_PROC(gps_init),
    INIT_PROC(init_pilot),
    INIT_PROC(wpa_init),
    INIT_PROC(init_mcu),
    INIT_PROC(open_input),
};

static int feed_dog_func(RcTimer *timer)
{
    int ret = feed_dog(500, "rcdaemon_main_thread");
    refresh_rctimer(timer, 100);
    return ret;
}

#define DATABASE_FILENAME   "/mnt/data/rcdaemon.conf"

int main( int argc, char **argv )
{
    int                delay = TIMER_CYCLE;
    int                ret, i, epfd;
    RcTimer            *watchdog_timer;

    signal(SIGPIPE, SIG_IGN);
    signal(SIGCHLD, SIG_IGN);

    gpio_set_state(PWR_LED, 1);
    logi(LOG_RCDAEMON, TAG, "Version: %s\n", RCDAEMON_VERSION);

    epfd = epoll_create1(EPOLL_CLOEXEC);
    if (0 > epfd) {
        loge(LOG_RCDAEMON, TAG, "epoll create failed. err: %s\n", strerror(errno));
        return -1;
    }

    if ( init_database(DATABASE_FILENAME) < 0 ) {
        loge(LOG_RCDAEMON, TAG, "init_database failed! %s\n", DATABASE_FILENAME);
        return -1;
    }

    if(device_init() < 0 || channel_init() < 0) {
        loge(LOG_RCDAEMON, TAG, "device init failed. error:%s\n",strerror(errno));
        return -1;
    }

    for(i = 0; i < sizeof(programs)/sizeof(programs[0]); i++) {
        if((ret = programs[i].func(epfd, malloc(sizeof(struct epoll_context)))) < 0) {
            loge(LOG_RCDAEMON, TAG, "%s failed! ret:%d, error: %s", programs[i].name, ret, strerror(errno));
            return -1;
        }
    }

    logi(LOG_RCDAEMON, TAG, "Initial Done, start working\n");

    watchdog_timer = add_rctimer(NULL, feed_dog_func, 100);

    while(1) {
        struct epoll_event events[16];
        do {
            ret = epoll_wait(epfd, events, sizeof(events)/sizeof(events[0]), delay);
            if (ret < 0 && errno != EAGAIN && errno != EINTR) {
                loge(LOG_RCDAEMON, TAG, "epoll return error:%d! This should never happen!!!\n",ret);
                return -1;
            }
        } while (ret < 0);

        for ( i = 0; i < ret; i++ ) {
            struct epoll_context *epctx = events[i].data.ptr;

            if(epctx && epctx->callback)
                epctx->callback(&events[i], epctx);
            else 
                loge(LOG_RCDAEMON, TAG, "Illegal data! %p,%p\n", epctx, epctx ? epctx->callback : NULL);
        }

        delay = process_rctimer();
    }

    del_rctimer(watchdog_timer);

    loge(LOG_RCDAEMON, TAG, "main loop end!\n");

    return 0;
}
