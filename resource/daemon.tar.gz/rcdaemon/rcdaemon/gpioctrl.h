#ifndef __GPIOCTRL_H__
#define __GPIOCTRL_H__

#ifdef __cplusplus
extern "C" {
#endif

#define TAKEOFF_LED     0
#define PWR_LED         1
#define GOHOME_LED      2
#define WIFI_LED        3
#define VIB_CONTROL     4

int gpio_set_state(uint8_t index, uint8_t state);

#ifdef __cplusplus
}
#endif
#endif /* __GPIOCTRL_H__ */
