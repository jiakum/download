#ifndef __INPUT_H__
#define __INPUT_H__

#include "rctimer.h"
#include "epoll_context.h"

#define SW_SWITCH           0x0e
#define BTN_CAPTURE         0x2f0
#define BTN_FUNC            0x2f1
#define BTN_VIDEO           0x2f2
#define BTN_TAKEOFF         0x2f3
#define BTN_GOHOME          0x2f4

#define INPUT_DIR           "/dev/input"

typedef struct InputItem {
    uint8_t         type;       // EV_SW, EV_KEY
    uint16_t        code;
    int8_t          value;
    struct timeval  tv;
    RcTimer         *timer;     // used to judge button long press
    void            *p;
} InputItem;

int open_input(int epfd, struct epoll_context *epctx);
int close_input(int fd);

uint8_t get_switch_states();

#endif /* __INPUT_H__ */
