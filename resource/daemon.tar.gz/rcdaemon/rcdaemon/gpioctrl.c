#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <string.h>
#include <stdint.h>
#include <log.h>
#include "gpioctrl.h"
#define GPIO_PATH    "/sys/class/gpio_ctrl/ctrl"
#define GPIO_NUMS    5

/*
 *  index = 0, Bind_LED
 *  index = 1, PWR_LED
 *  index = 2, GOHOME_LED
 *  index = 3, WIFI_LED
 *  index = 4, VIB_CONTROL
 */
int gpio_set_state(uint8_t index, uint8_t state)
{
    int  ret = 0;
    char buf[8];
    int  states = 0;

    if (index >= GPIO_NUMS) {
        return -1;
    }

    int fd = open(GPIO_PATH, O_RDWR);
    if (fd < 0) {
        return -1;
    }

    ret = read(fd, buf, sizeof(buf));
    if (ret <= 0) {
        close(fd);
        return -1;
    }

    states = atoi(buf);
    if (states < 0 || states > 0x1f) {
        close(fd);
        return -1;
    }

    states &= ~(0x01 << index);
    states |= !!state << index;
    memset(buf, 0, sizeof(buf));
    sprintf(buf, "%u\n", states);

    ret = write(fd, buf, strlen(buf));
    if (ret <= 0) {
        close(fd);
        return -1;
    }
    close(fd);

    return 0;
}

