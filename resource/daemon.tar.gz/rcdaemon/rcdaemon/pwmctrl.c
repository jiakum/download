#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <string.h>
#include <stdint.h>

#define FAN_ON_TIME     "/sys/class/st10c_pwm/fan_on_time"
#define FAN_FREQ        "/sys/class/st10c_pwm/fan_freq"
#define BUZZER_ON_TIME  "/sys/class/st10c_pwm/buzzer_on_time"
#define BUZZER_FREQ     "/sys/class/st10c_pwm/buzzer_freq"

int pwm_set_state(uint8_t index, int32_t on_time, uint32_t freq)
{
    int ret = 0;
    char buf[8];

    if (index != 0 && index != 1) {
        return -1;
    }

    int fd = open(index == 0 ? FAN_FREQ : BUZZER_FREQ, O_WRONLY);
    if (fd < 0) {
        return -1;
    }

    memset(buf, 0x00, sizeof(buf));
    sprintf(buf, "%u\n", freq);
    ret = write(fd, buf, strlen(buf));
    if (ret <= 0) {
        close(fd);
        return -1;
    }
    close(fd);


    fd = open(index == 0 ? FAN_ON_TIME : BUZZER_ON_TIME, O_WRONLY);
    if (fd < 0) {
        return -1;
    }

    memset(buf, 0x00, sizeof(buf));
    sprintf(buf, "%d\n", on_time);
    ret = write(fd, buf, strlen(buf));
    if (ret <= 0) {
        close(fd);
        return -1;
    }
    close(fd);

    return 0;
}

