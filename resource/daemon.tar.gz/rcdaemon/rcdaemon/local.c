#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/epoll.h>
#include <sys/types.h>
#include <ctype.h>
#include <string.h>
#include <math.h>
#include <errno.h>
#include <signal.h>
#include <limits.h>
#include <unistd.h>
#include <sys/socket.h>
#include <sys/wait.h>
#include <sys/ioctl.h>
#include <sys/stat.h>
#include <sys/poll.h>
#include <fcntl.h>
#include <sys/un.h>
#include <arpa/inet.h>

#include "local.h"
#include "common.h"
#include "utils.h"
#include "autopilot.h"
#include "input.h"
#include "devices.h"
#include "wpa.h"
#include "gps/ublox.h"
#include "rcprotocol.h"
#include "mcu.h"

#define TAG "local"

struct local_context {
    int epfd, serverfd, localfd;
    struct ymavlink_buffer *ybuf;
};

static struct local_context *lctx;

int local_write_cmd(uint8_t type, uint8_t cmd, uint8_t *buf, int size)
{
    if(lctx->localfd > 0)
        return ymavlink_send_packet(lctx->ybuf, type, cmd, buf, size);
    else
        return 0;
}

int local_write_buf(uint8_t *buf, int size)
{
    if(lctx->localfd > 0)
        return ymavlink_write_buf(lctx->ybuf, buf, size);
    else
        return 0;
}

static int parse_ssid_and_psk(unsigned char *buf, int len, char *ssid, int ssid_size, char *psk, int psk_size)
{
    int i = 0, ptr;

    buf += sizeof(COMMAND_HEADER);
    len -= sizeof(COMMAND_HEADER);
    buf[len - 1] = '\0';

    while(buf[i] == ' ' || buf[i] == '\0' || buf[i] == '\"') {
        if(++i >= len)
            return 0;
    }

    ptr = 0;
    while(buf[i] != ' ' && buf[i] != '\0' && buf[i] != '\"') {
        ssid[ptr] = buf[i];
        if(++i >= len || ++ptr >= ssid_size - 1)
            return 0;
    }
    if(ptr == 0)
        return 0;
    ssid[ptr] = '\0';

    while(buf[i] == ' ' || buf[i] == '\0' || buf[i] == '\"') {
        if(++i >= len)
            return 0;
    }

    ptr = 0;
    while(buf[i] != ' ' && buf[i] != '\0') {
        psk[ptr] = buf[i];
        if(++i >= len || ++ptr >= psk_size - 1)
            return 0;
    }
    if(ptr == 0)
        return 0;
    psk[ptr] = '\0';
    logi(LOG_RCDAEMON, TAG, "recieve local connect request. ssid:%s, psk:%s\n", ssid, psk);

    return 1;
}

static int handle_packet(uint8_t *buf, int size)
{
    int ret = 0;

    if((buf[HEAD_DOMIAN_START_TYPE] & TYPE_BIT_2_4) == DATA_PACKET_TYPE_COMMAND_FLAG) {
        logi(LOG_COMMAND, TAG, "local type:0x%.2X cmd:0x%.2X size:%d\n", buf[HEAD_DOMIAN_START_TYPE], buf[COMAND_HEAD_DOMIAN_COMMAND], size);
        switch ( buf[COMAND_HEAD_DOMIAN_COMMAND] ) {
            case COMMAND_PAD_SCAN_WIFI:
                wpa_scan();
                break;

            case COMMAND_PAD_CONNECT_WIFI:
                {
                    char ssid[64];
                    char psk[128];
                    if(parse_ssid_and_psk(buf, size, ssid, sizeof(ssid), psk, sizeof(psk))) {
                        wpa_connect(ssid, psk);
                    } else {
                        local_response(COMMAND_PAD_CONNECT_WIFI, (unsigned char*)"FAILED", strlen("FAILED"));
                    };
                }
                break;

            case COMMAND_PAD_GET_WIFI_STATUS:
                wpa_get_status();
                break;

            case COMMAND_PAD_GET_BIND_STATE:
                {
                    uint8_t addr[sizeof(M3TOM4TOPADBindInfo)] = {0};
                    autopilot_get_bindinfo(addr, sizeof(addr));
                    addr[0] = 0;
                    addr[1] = 0;
                    ret = local_response(COMMAND_PAD_GET_BIND_STATE, addr, sizeof(addr));
                }
                break;

            case COMMAND_PAD_CLEAR_BINDED:
                autopilot_clear_bind();
                ret = local_response(COMMAND_PAD_CLEAR_BINDED, NULL, 0);
                break;

            case COMMAND_PAD_GET_TRANSMITTER_MCU_SW_VERSION:
                local_response(COMMAND_PAD_GET_TRANSMITTER_MCU_SW_VERSION, (uint8_t*)APP_SW_VERSION, sizeof(APP_SW_VERSION));
                break;

            case COMMAND_PAD_GET_TRANSMITTER_RF_SW_VERSION:
                break;

            case COMMAND_PAD_ODDER_M4_ENTER_BIND:
                autopilot_set_state(STATE_BIND);
                ret = local_response(COMMAND_PAD_ODDER_M4_ENTER_BIND, NULL, 0);
                break;

            case COMMAND_PAD_SET_PLAT_DATA:
                ret = autopilot_write_command_and_params(COMMAND_M4_SET_PLAT_DATA, buf+COMAND_HEAD_DOMIAN_PARA, sizeof(SET_PLATFORM_DATA));
                if(ret >= 0)
                    ret = local_response(COMMAND_PAD_SET_PLAT_DATA, NULL, 0);
                break;

            case COMMAND_PAD_GET_GPS_DATA:
                {
                    GPSData gps;

                    get_gps(&gps);
                    local_response(COMMAND_PAD_GET_GPS_DATA, (unsigned char*)&gps, sizeof(gps));
                }
                break;

            case COMMAND_PHONE_STATUS: 
                {
                    static char format[] = "iphone %s\nandroid %s\nhandle %d\n";
                    char buf[64];
                    int handle, hasi = device_has_iphone(&handle);
                    snprintf(buf, sizeof(buf), format, hasi ? "connected" : "disconnected"
                                                     , device_has_adb() ? "connected" : "disconnected"
                                                     , handle);
                    local_response(COMMAND_PHONE_STATUS, (unsigned char *)buf, strlen(buf));
                }
                break;
            case COMMAND_PAD_ODDER_M4_ENTER_RUN:
                {
                    local_response(COMMAND_PAD_ODDER_M4_ENTER_RUN, NULL, 0);
                    autopilot_set_state(STATE_SETUP_RUN);
                }
                break;

            case COMMAND_PAD_ODDER_M4_EXIT_BIND:
                autopilot_set_state(STATE_AWAIT);
                local_response(COMMAND_PAD_ODDER_M4_EXIT_BIND, NULL, 0);
                break;

            case COMMAND_PAD_ODDER_M4_EXIT_RUN:
                local_response(COMMAND_PAD_ODDER_M4_EXIT_RUN, NULL, 0);
                autopilot_set_state(STATE_AWAIT);
                break;

            case COMMAND_PAD_ODDER_M4_EXIT_TO_AWAIT:
                local_response(COMMAND_PAD_ODDER_M4_EXIT_TO_AWAIT, NULL, 0);
                autopilot_set_state(STATE_AWAIT);
                break;

            case COMMAND_PAD_GET_SWITCH_STATES:
                {
                    uint8_t switch_states = get_switch_states();
                    local_response(COMMAND_PAD_GET_SWITCH_STATES, &switch_states, sizeof(switch_states));
                }
                break;

            case COMMAND_PAD_ENTER_FACTORY_CALIBRATION:
                mcu_start_calibrate();
                break;

            case COMMAND_PAD_EXIT_FACTORY_CALIBRATION:
                mcu_stop_calibrate();
                break;

            default:
                break;
        }
    } else if ((buf[HEAD_DOMIAN_START_TYPE] & TYPE_BIT_2_4) == DATA_PACKET_TYPE_BIND_FLAG) {
        ret = autopilot_send_bindinfo(1, buf, size);
    } else if ((buf[HEAD_DOMIAN_START_TYPE] & TYPE_BIT_2_4) == DATA_PACKET_TYPE_CHANEL_FLAG) {
        ret = autopilot_write_buf(buf, size);
    } else if ((buf[HEAD_DOMIAN_START_TYPE] & TYPE_BIT_2_4) == DATA_PACKET_TYPE_EX_FLAG) {
        ret = autopilot_write_buf(buf, size);
    }

    return ret;
}

static int handle_local(struct epoll_event *ev, struct epoll_context *epctx)
{
    int len;

    if(ev->events & (EPOLLHUP | EPOLLERR)) {
        loge(LOG_RCDAEMON, TAG, "local socket closed?\n");
        epoll_ctl(lctx->epfd, EPOLL_CTL_DEL, lctx->localfd, NULL);
        close(lctx->localfd);
        free(epctx);
        lctx->localfd = -1;
    } else if(ev->events & EPOLLIN) {
        struct ymavlink_buffer *ybuf = lctx->ybuf;
        while(1) {
            len = ymavlink_read_buf(ybuf);
            if(len <= 0)
                break;

            while((len = ymavlink_get_packet(ybuf)) > 0) {
                handle_packet(ybuf->buf + ybuf->offset, len);
                ymavlink_update_buf(ybuf, len);
            }
            ymavlink_cyclic_buf(ybuf);
        }

        if(len < 0) {
            printf("local socket closed ?");
            epoll_ctl(lctx->epfd, EPOLL_CTL_DEL, lctx->localfd, NULL);
            close(lctx->localfd);
            free(epctx);
            lctx->localfd = -1;
        }
    }

    return 0;
}

static int handle_server(struct epoll_event *ev, struct epoll_context *epctx)
{
    struct epoll_context *newep;
    struct ymavlink_buffer *ybuf = lctx->ybuf;
    struct epoll_event newev;
    struct sockaddr_in addr;
    int len, fd;

    if(lctx->localfd > 0) {
        loge(LOG_RCDAEMON, TAG, "local connect twice ?\n");
        return 0;
    }

    if(ev->events & EPOLLIN) {
        len = sizeof(addr);
        if((fd = accept(lctx->serverfd, (struct sockaddr *)&addr, (socklen_t *)&len)) < 0) {
            loge(LOG_RCDAEMON, TAG, "accept error for %s!!! error: %s\n", __func__, strerror(errno));
            return -1;
        }
        fcntl(fd, F_SETFL, fcntl(fd, F_GETFL) | O_NONBLOCK);

        newep = malloc(sizeof(*newep));
        if(!newep) {
            loge(LOG_RCDAEMON, TAG, "malloc failed %s\n", __func__);
            return -ENOMEM;
        }
        newep->callback = handle_local;
        newep->data = lctx;
        newev.events = EPOLLIN;
        newev.data.ptr = newep;

        if(epoll_ctl(lctx->epfd, EPOLL_CTL_ADD, fd, &newev) < 0) {
            loge(LOG_RCDAEMON, TAG, "epoll ctl error for %s\n", __func__);
            return -1;
        }

        ybuf->fd = fd; ybuf->fdtype = FD_TYPE_SOCK;
        ymavlink_reset_buf(ybuf);
        lctx->localfd = fd;
    }

    return 0;
}

int init_local(int epfd, struct epoll_context *epctx)
{
    struct epoll_event ev;
    struct sockaddr_in addr;
    struct ymavlink_buffer *ybuf = malloc(sizeof(*ybuf));
    int rcport = 1108, fd;

    lctx = malloc(sizeof(*lctx));

    if(!epctx || !lctx || !ybuf)
        return -ENOMEM;

    addr.sin_port        = htons(rcport);
    addr.sin_addr.s_addr = htonl(INADDR_ANY);
    if((fd = socket_open_listen(&addr)) < 0) {
        loge(LOG_RCDAEMON, TAG, "%s listen socket error!", __func__);
        return -1;
    }

    memset(lctx, 0, sizeof(*lctx));
    memset(ybuf, 0, sizeof(*ybuf));
    lctx->ybuf = ybuf;
    lctx->epfd = epfd;
    lctx->serverfd = fd;
    epctx->callback = handle_server;
    epctx->data = lctx;

    ev.events = EPOLLIN;
    ev.data.ptr = epctx;

    if(epoll_ctl(epfd, EPOLL_CTL_ADD, fd, &ev) < 0) {
        loge(LOG_RCDAEMON, TAG, "epoll ctl failed for %s\n", __func__);
        return -1;
    }

    return 0;
}
