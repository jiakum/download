
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <fcntl.h>
#include <errno.h>
#include <termios.h>
#include <sys/select.h>
#include <sys/poll.h>

#include <string.h>
#include <sys/time.h>
#include <pthread.h>
#include <math.h>
#include "utils.h"
#include "ublox.h"
#include "rcprotocol.h"
#include "common.h"

#define POS_AVERAGE_COUNT_MAX	10
#define GPS_ERROR_VALUE			50000

//#define GPS_DISTANCE_FILTER
#define GPS_DISTANCE_VALUE		0.005 //km
#define PI                      3.1415926
#define EARTH_RADIUS            6378.137 

#define msleep(n) usleep((n) * 1000)

#define TAG "gps"

typedef struct 
{
    int    fd, epfd;
    UBXPacket *txpkt, *rxpkt;

    pthread_t thread;
    struct epoll_context *epctx;
    GPS_DATA_TIME gps_time;
    GPS_DATA_RAW  raw;
    GPSData       average;
    GPS_DATA_SAT  sat;

} UBXContext;

static UBXContext *ubxctx;

static void get_average_position(GPS_DATA_RAW * raw, GPSData *average)
{
#define AVERAGE_SIZE (10)
    static int position[AVERAGE_SIZE][2];
    static int ptr, all;
    int i, index;
    int64_t lat, lon;

    if(raw->pdop > 9999)
        return;

    position[ptr][0] = raw->lat;
    position[ptr][1] = raw->lon;

    if(++ptr >= AVERAGE_SIZE) {
        all = 1;
        ptr = 0;
    }

    if(all) {
        lat = position[ptr][0];
        lon = position[ptr][1];
        for(i = 1;i < AVERAGE_SIZE;i++) {
            index = ptr + i;
            index = index >= AVERAGE_SIZE ? index - AVERAGE_SIZE : index;
            lat = ((int64_t)position[index][0] + lat) / 2;
            lon = ((int64_t)position[index][1] + lon) / 2;
        }
    } else {
        lat = raw->lat;
        lon = raw->lon;
    }

    average->lat = lat;
    average->lon = lon;
    average->alt = ((float) raw->hMSL) / 1000.0;
    average->accuracy = raw->pdop / 10;
    average->speed = raw->gSpeed / 100;
    average->angle = (raw->headMot / 100000) > 180 ? (raw->headMot / 100000 - 360) : raw->headMot / 100000;
    average->no_satelites = raw->numSV;

    //printf("%s, fixtype:%d, alt:%f, height:%d\n", __func__, raw->fixType, average->alt, raw->height);
}

static inline void send_data_to_ubx(UBXContext *ubx, UBXPacket *pkt)
{
    unsigned char *buf = (unsigned char *)pkt;
    int len = pkt->len;

    write(ubx->fd, buf, len + 8);
}

static void ubx_checksum(UBXPacket *pkt)
{
    int i, len;
    unsigned char CK_A, CK_B;
    unsigned char *buf = (unsigned char *)pkt;

    CK_A = 0;
    CK_B = 0;

    len = pkt->len + UBLOX_COMMON_HEADER_SIZE;
    for(i = 2; i < len; i++) {
        CK_A += buf[i];
        CK_B += CK_A;
    }

    buf[len + 0] = CK_A;
    buf[len + 1] = CK_B;
}

static int ubx_get_packet(UBXContext *ubx, UBXPacket *pkt)
{
    unsigned char *buf = (unsigned char *)pkt;
    int ret, len = pkt->total;

    ret = read(ubx->fd, buf + len, UBX_MAX_BUFFER_SIZE - len);

    if(ret < 0) {
        if(errno != EAGAIN && errno != EINTR) {
            loge(LOG_RCDAEMON, TAG, "recv returns error:%s\n",strerror(errno));
            return -1;
        } /* else  go through to next_packet */
    } else if(ret == 0) {
        return -1;
    } else {
        //dump_buf(buf,ret);
        pkt->total += ret;
    }

next_packet:
    len = pkt->total;

    if(len < UBLOX_COMMON_HEADER_SIZE)
        return 0;
    else if(((uint16_t*)buf)[0] != UBLOX_SYNC_CODE) {
        int retry = 0;

        len = 0;
        do {
            if((buf[len + 1] != UBLOX_SYSC_CHAR2) || (buf[len + 0] != UBLOX_SYSC_CHAR1))
                len++; 
            else {
                retry = 1;
                break;
            }
        } while(len + 2 <= pkt->total);

        pkt->total -= len;
        memcpy(buf, buf + len, pkt->total);
        if(retry)
            goto next_packet;
        else
            return 0;
    } else if(len < UBLOX_COMMON_HEADER_SIZE + pkt->len + 2) {
        return 0;
    } else {
        int i;
        unsigned char CK_A = 0, CK_B = 0;

        len = pkt->len;
        for(i = 2; i < len + UBLOX_COMMON_HEADER_SIZE; i++) {
            CK_A += buf[i];
            CK_B += CK_A;
        }

        len += UBLOX_COMMON_HEADER_SIZE;
        if(CK_A != buf[len + 0] || CK_B != buf[len + 1]) {
            len += 2;
            pkt->total -= len;
            memcpy(buf, buf + len, pkt->total);

            logw(LOG_RCDAEMON, TAG, "ubx recieve packet crc check failed\n");
            if(pkt->total < UBLOX_COMMON_HEADER_SIZE)
                return 0;
            else
                goto next_packet;
        } else
            return 1;
    }

    return 0;
}

static inline void ubx_finish_packet(UBXPacket *pkt)
{
    unsigned char *buf = (unsigned char *)pkt;
    int len = pkt->len + 8;

    pkt->total -= len;
    memcpy(buf, buf + len, pkt->total);
}

static inline int64_t ubx_gettime(void)
{
    struct timeval tv;
    gettimeofday(&tv,NULL);
    return (int64_t)(tv.tv_sec * 1000000 + tv.tv_usec) / 1000;
}

static int ubx_check_ack(UBXContext *ubx, int class, int id, int wait_time)
{
    UBXPacket *pkt = ubx->rxpkt;
    int ret, left;
    struct pollfd table;
    int64_t start;

    left = wait_time;
    start = ubx_gettime();
    while(left > 0) {

        table.fd = ubx->fd;
        table.events = POLLIN;
        do {
            ret = poll(&table, 1, left);
            if (ret < 0 && errno != EAGAIN && errno != EINTR) {
                loge(LOG_RCDAEMON, TAG, "poll return error:%d! This should never happen!!!\n",ret);
                return -1;
            }
        } while (ret < 0);

        while(1) {
            if((ret = ubx_get_packet(ubx, pkt)) < 0)
                return -1;
            else if(ret > 0) {
                if(pkt->class == 0x05 && pkt->id == 0x01) {
                    unsigned char *buf = pkt->payload;

                    if(buf[0] == class && buf[1] == id)
                        return 1;
                    else
                        logw(LOG_RCDAEMON, TAG, "missed ack, classid:%d, msgid:%d\n", buf[0], buf[1]);
                }
                ubx_finish_packet(pkt);
            } else
                break;
        }
        left = ubx_gettime() - start;
        left = wait_time - left;
    }

    return 0;
}

static int ubx_set_navigation_engine(UBXContext *ubx, unsigned char dynModel)
{
    static unsigned char buf[] = {0xb5, 0x62, 0x06, 0x24, 0x24, 0x00,
        0xff, 0xff, 0x00, 0x03,  0x00, 0x00, 0x00, 0x00,  0x10, 0x27, 0x00, 0x00,
        0x05, 0x00, 0xfa, 0x00,  0xfa, 0x00, 0x64, 0x00,  0x2c, 0x01, 0x00, 0x3c,  
        0x00, 0x00, 0x00, 0x00,  0xc8, 0x00, 0x00, 0x00,  0x00, 0x00, 0x00, 0x00};
    UBXPacket *pkt = ubx->txpkt;
    unsigned char test_count = 0;

    buf[UBLOX_COMMON_HEADER_SIZE + 2] = dynModel;

    memcpy(pkt, buf, sizeof(buf));
    ubx_checksum(pkt);

    while(1) {
        send_data_to_ubx(ubx, pkt);
        if(ubx_check_ack(ubx, 0x06, 0x24, 20) == 1)
            return 1;
        else {
            if(++test_count >= 20) {
                logw(LOG_RCDAEMON, TAG, "%s:%d. check if gps is right connected!!!\n", __func__, __LINE__);
                continue;
            }
        }
    }

    return 0;
}

static void set_ubx_uartclk_to_115200(UBXContext *ubx)
{
    static unsigned char buf[] = {0x01, 0x00, 0x00, 0x00,  0xD0, 0x08, 0x00, 0x00,  0x00, 0xc2, 0x01, 0x00,
        0x01, 0x00, 0x01, 0x00,  0x00, 0x00, 0x00, 0x00};
    UBXPacket *pkt = ubx->txpkt;

    pkt->syncchar1 = 0xb5;
    pkt->syncchar2 = 0x62;
    pkt->class     = 0x06;
    pkt->id        = 0x00;
    pkt->len       = sizeof(buf);

    memcpy(pkt->payload, buf, sizeof(buf));
    ubx_checksum(pkt);
    send_data_to_ubx(ubx, pkt);
    pkt->len = 0;
    ubx_checksum(pkt);
    send_data_to_ubx(ubx, pkt);
}

static int ubx_cfg_message_rate(UBXContext *ubx, int msgid, int rate)
{
    static unsigned char buf[] = {0xb5, 0x62, 0x06, 0x01, 0x03, 0x00,  0x01, 0x07, 0x01};
    UBXPacket *pkt = ubx->txpkt;
    unsigned char test_count = 0;

    buf[6] = (msgid >> 8) & 0x0ff;
    buf[7] = msgid & 0x0ff;
    buf[8] = rate;

    memcpy(pkt, buf, sizeof(buf));
    ubx_checksum(pkt);
    while(1) {
        send_data_to_ubx(ubx, ubx->txpkt);
        if(ubx_check_ack(ubx, 0x06, 0x01, 20) == 1)
            return 1;
        else if(test_count++ >= 20) {
            logw(LOG_RCDAEMON, TAG, "%s:%d. check if gps is right connected!!!\n", __func__, __LINE__);
            continue;
        }
    }

    return 0;
}

static int ubx_set_rate(UBXContext *ubx, unsigned char freq,unsigned char navRate,unsigned char timeRef)
{
    UBXPacket *pkt = ubx->txpkt;
    unsigned char test_count = 0;
    unsigned int time_interval = 1000/freq;

    pkt->syncchar1 = 0xb5;
    pkt->syncchar2 = 0x62;
    pkt->class     = 0x06;
    pkt->id        = 0x08;
    pkt->len       = 0x06;

    pkt->payload[0] = time_interval&0xff;
    pkt->payload[1] = (time_interval>>8)&0xff;
    pkt->payload[2] = navRate&0xff;
    pkt->payload[3] = (navRate>>8)&0xff;
    pkt->payload[4] = timeRef&0xff;
    pkt->payload[5] = (timeRef>>8)&0xff;

    ubx_checksum(pkt);
    while(1) {
        send_data_to_ubx(ubx, pkt);
        if(ubx_check_ack(ubx, 0x06, 0x08, 20)){
            return 1;
        } else {
            if(++test_count >= 20) {
                logw(LOG_RCDAEMON, TAG, "%s:%d. check if gps is right connected!!!\n", __func__, __LINE__);
                continue;
            }
        }
    }

    return 0;
}

#ifdef 	GPS_DISTANCE_FILTER
static double radian(int32_t d)
{
    return (double)(d / 10000000.0) * PI / 180.0; 
}

static double get_distance(int32_t lat1, int32_t lng1, int32_t lat2, int32_t lng2)
{
    double radLat1 = radian(lat1);
    double radLat2 = radian(lat2);
    double a = radLat1 - radLat2;
    double b = radian(lng1) - radian(lng2);

    double dst = 2 * asin((sqrt(pow(sin(a / 2), 2) + cos(radLat1) * cos(radLat2) * pow(sin(b / 2), 2) )));

    dst = dst * EARTH_RADIUS;
    dst= round(dst * 10000) / 10000;

    return dst;
}
#endif

/* ublox Navigation Position Velocity Time Solution*/
static void ubx_nav_pvt_pkt(UBXContext *ubx, UBXPacket *pkt)
{
    GPS_DATA_TIME *gps_time = &ubx->gps_time;
    unsigned char *buf = pkt->payload;
    unsigned char flags = buf[21], fixtype = buf[20];
    GPS_DATA_RAW *data = &ubx->raw;

    if(fixtype < TwoDFix || fixtype > GNSSDeadReckoningCombined)
        return;
    if(!(flags & 0x01)) {
        loge(LOG_RCDAEMON, TAG, "gnss fix not ok!!!\n");
        return;
    }
    gps_time->year    = ubx_read16(buf + 4);
    gps_time->month   = buf[6];
    gps_time->day     = buf[7];
    gps_time->hour    = buf[8];
    gps_time->min     = buf[9];
    gps_time->sec     = buf[10];
    data->fixType     = buf[20];

    data->numSV      = buf[23];
    data->lon        = ubx_read32(buf + 24);
    data->lat        = ubx_read32(buf + 28);
    data->height     = ubx_read32(buf + 32);
    data->hMSL       = ubx_read32(buf + 36);

    data->hAcc = ubx_read32(buf + 40);
    data->vAcc = ubx_read32(buf + 44);
    data->velN = ubx_read32(buf + 48);
    data->velE = ubx_read32(buf + 52);
    data->velD = ubx_read32(buf + 56);

    data->gSpeed  = ubx_read32(buf + 60);
    data->headMot = ubx_read32(buf + 64);
    data->sAcc    = ubx_read32(buf + 68);
    data->pdop    = ubx_read16(buf + 76);

    get_average_position(data, &ubx->average);
    WARN_ONCE(LOG_RCDAEMON, TAG, "gps get time, %d year, %d month, %d day,"
            "%d hour, %d minutes, %d second\n"
            , gps_time->year, gps_time->month, gps_time->day
            , gps_time->hour, gps_time->min, gps_time->sec);
    WARN_ONCE(LOG_RCDAEMON, TAG, "fixtype:%d, longitude:%d, latitude:%d\n", data->fixType, data->lon, data->lat);
}

int get_gps(GPSData *gps)
{
    UBXContext *ubx = ubxctx;
    GPS_DATA_RAW *data = &ubx->raw;

    memcpy(gps, &ubx->average, sizeof(*gps));
    if(data->fixType < TwoDFix) {
        return 1;
    }

    return 0;
}

static int ubx_satelite_packet(UBXContext *ubx, UBXPacket *pkt)
{
    unsigned char *buf = pkt->payload;
    GPS_DATA_SAT  *sat = &ubx->sat;
    int i, max;

    max = buf[5] > MAX_SATELLITE ? MAX_SATELLITE : buf[5];
    sat->numSV = max;
    for(i = 0; i < max;i++) {
        sat->SVdata[i].gnssId = buf[12 * i + 8];
        sat->SVdata[i].svId = buf[12 * i + 9];
        sat->SVdata[i].strength = buf[12 * i + 10];
    }
    //logd(LOG_RCDAEMON, TAG, "%s, %d satelite\n", __func__, max);

    return 0;
}

static int handle_gps(struct epoll_event *ev, struct epoll_context * epctx)
{
    UBXContext *ubx;
    UBXPacket *pkt;
    int ret;

    if(!(ubx = ubxctx)) {
        loge(LOG_RCDAEMON, TAG, "gps init failed!!!\n");
        return 0;
    }

    pkt = ubx->rxpkt;
    while(1) {
        if((ret = ubx_get_packet(ubx, pkt)) < 0)
            return -1;
        else if(ret > 0) {
            switch((pkt->class << 8) | pkt->id) {
                case 0x0107:
                    ubx_nav_pvt_pkt(ubx, pkt);
                    break;
                case 0x0135:
                    ubx_satelite_packet(ubx, pkt);
                    break;
                case 0x0501:
                    break;
                default:
                    logw(LOG_RCDAEMON, TAG, "Unrecognised class:0x%x,id:0x%x\n", pkt->class, pkt->id);
            }
            ubx_finish_packet(pkt);
        } else
            break;
    }

    return 0;
}

static void *gps_init_internal(void *arg)
{
    struct epoll_event ev;
    struct epoll_context *epctx = ubxctx->epctx;
    int fd = ubxctx->fd, ret, try = 0, epfd = ubxctx->epfd;

    /* set default uart clock from 9600 to 115200*/

    while(1) {

        set_serialport(fd, 9600, 0, 8, 1, 'n');

        set_ubx_uartclk_to_115200(ubxctx);
        msleep(10);
        set_ubx_uartclk_to_115200(ubxctx);
        msleep(100);

        set_serialport(fd, 115200, 0, 8, 1, 'n');

        if(ubx_check_ack(ubxctx, 0x06, 0x00, 10) == 1)
            break;
        set_ubx_uartclk_to_115200(ubxctx);
        msleep(10);

        if(ubx_check_ack(ubxctx, 0x06, 0x00, 10) == 1)
            break;

        if(try++ >= 20) {
            logw(LOG_RCDAEMON, TAG, "check if gps is right connected!!!\n");
            break;
        }
    }

    if(ubx_set_rate(ubxctx, 10, 1, 0) == 1)
        ret = ubx_set_navigation_engine(ubxctx, portable) && ubx_cfg_message_rate(ubxctx, 0x0107, 1);

    ubx_cfg_message_rate(ubxctx, 0x0135, 1);

    epctx->callback = handle_gps;
    epctx->data = ubxctx;
    ev.events = EPOLLIN;
    ev.data.ptr = epctx;

    if(epoll_ctl(epfd, EPOLL_CTL_ADD, fd, &ev) < 0) {
        loge(LOG_RCDAEMON, TAG, "epoll ctl for %s failed!!!!\n", __func__);
        return NULL;
    }

    logd(LOG_RCDAEMON, TAG, "gps init internal finished. result:%d\n", ret);

    return NULL;
}

int gps_init(int epfd, struct epoll_context *epctx)
{
    pthread_attr_t attr;
    unsigned char *txbuf, *rxbuf;
    int fd;

    txbuf = malloc(UBX_MAX_BUFFER_SIZE);
    rxbuf = malloc(UBX_MAX_BUFFER_SIZE);
    ubxctx = malloc(sizeof(*ubxctx));
    if(!ubxctx || !txbuf || !rxbuf || !epctx) {
        loge(LOG_RCDAEMON, TAG, "malloc for ubxctx failed!!!\n");
        return -ENOMEM;
    }

    memset(ubxctx, 0, sizeof(*ubxctx));
    ubxctx->txpkt = (UBXPacket*)txbuf;
    ubxctx->rxpkt = (UBXPacket*)rxbuf;

    if(((fd = open(GPS_DEFAULT_UART, O_RDWR)) < 0) || set_serialport(fd, 9600, 0, 8, 1, 'n') < 0) {
        loge(LOG_RCDAEMON, TAG, "open uart failed, reason:%s\n", strerror(errno));
        return fd;
    }
    fcntl(fd, F_SETFL, fcntl(fd, F_GETFL) | O_NONBLOCK);

    ubxctx->fd = fd;
    ubxctx->epfd = epfd;
    ubxctx->epctx = epctx;

    pthread_attr_init(&attr);
    pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_DETACHED);
    if(pthread_create(&ubxctx->thread, &attr, gps_init_internal, NULL) < 0) {
        loge(LOG_RCDAEMON, TAG, "pthread create failed!!\n");
        return -ENOMEM;
    }
    pthread_attr_destroy(&attr);
    logd(LOG_RCDAEMON, TAG, "gps init finished.\n");

    return 0;
}

