#ifndef GPS_UBLOX_H__
#define GPS_UBLOX_H__
#define MAX_SATELLITE	50

#include <stdint.h>
#include "rcprotocol.h"
#include "epoll_context.h"

#define UBX_MAX_BUFFER_SIZE (1024)
typedef struct
{
    uint8_t syncchar1, syncchar2;
    uint8_t class, id;
    uint16_t len;
    uint8_t payload[UBX_MAX_BUFFER_SIZE - 8];
    uint8_t CK_A, CK_B;
    int     total;
}__attribute__((packed)) UBXPacket;

#define UBLOX_COMMON_HEADER_SIZE  (6)
#define UBLOX_SYNC_CODE           (0x62b5)
#define UBLOX_SYSC_CHAR1          (0xb5)
#define UBLOX_SYSC_CHAR2          (0x62)
#define GPS_DEFAULT_UART ("/dev/ttyS3")

typedef struct 
{
    unsigned char  numSV;
    int lon;
    int lat;
    int height;
    int hMSL;
    unsigned char fixType;
    unsigned int hAcc;
    unsigned int vAcc;
    int velN;
    int velE;
    int velD;
    int gSpeed;
    int headMot;
    unsigned int sAcc;
    unsigned short pdop;
} GPS_DATA_RAW;

typedef struct 
{
    unsigned char gnssId;
    unsigned char svId;
    unsigned char strength;
}__attribute__((packed)) GPS_SV_INFO;

typedef struct 
{
    unsigned char  numSV;
    GPS_SV_INFO SVdata[MAX_SATELLITE];
}__attribute__((packed)) GPS_DATA_SAT;

typedef struct 
{
    unsigned short year;
    unsigned char month;
    unsigned char day;
    unsigned char hour;
    unsigned char min;
    unsigned char sec;
} GPS_DATA_TIME;

typedef enum
{
    portable =  0,
    stationary = 2,
    pedestrian = 3,
    automotive = 4,
    sea        = 5,
    lessThan1G = 6,
    lessThan2G = 7,
    lessThan4G = 8
}DYN_MODEL;

typedef enum
{
    NoFix = 0,
    DeadReckoningOnly = 1,
    TwoDFix = 2,
    ThreeDFix = 3,
    GNSSDeadReckoningCombined = 4,
    TimeOnlyFix = 5
}FIX_TYPE;

/* 
 * gps_init
 * return 0 if success else return error
 */
int gps_init(int epfd, struct epoll_context *epctx);

/* 
 * get_gps
 * return 0 if success else return 1
 */
int get_gps(GPSData *gps);

static inline uint32_t ubx_read32(unsigned char *buf)
{
    return *(uint32_t *)buf;
}

static inline uint16_t ubx_read16(unsigned char *buf)
{
    return *(uint16_t *)buf;
}

#endif // GPS_UBLOX_H__
