#include "common.h"
#include <errno.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/socket.h>
#include <sys/un.h>

#include "rcprotocol.h"
#include "ymavlink.h"
#include "phone.h"
#include "wpa.h"
#include "autopilot.h"
#include "input.h"
#include "local.h"
#include "rctimer.h"
#include "devices.h"
#include "mcu.h"
#include "gps/ublox.h"
#include "utils.h"

#define TAG "phone"

#define log(format, ...)        printf("%s:%d "format"\n", __func__, __LINE__, ##__VA_ARGS__)

struct phone_t {
    struct epoll_context        epctx;
    struct ymavlink_buffer      ybuf;
    struct list_head            list;
};

struct phone_context {
    int                         epfd;
    int                         listenfd;
    struct epoll_context        *epctx;
    struct list_head            phone_list;
    unsigned char               rf_sw_version[ALIGN32(RF_SW_VERSION_LEN)];
};

static struct phone_context *phctx;

static inline void phone_disconnect(struct phone_t *phone)
{
    struct ymavlink_buffer *ybuf = &phone->ybuf;

    if ( ybuf->fd > 0 ) {
        if(epoll_ctl(phctx->epfd, EPOLL_CTL_DEL, ybuf->fd, NULL) < 0)
            loge(LOG_RCDAEMON, TAG, "epoll ctl for phone delete error!!!");
        close(ybuf->fd);
        ybuf->fd = -1;
        logi(LOG_RCDAEMON, TAG, "phone disconnect\n");
    }

    log("phone disconnect\n");
    ybuf->fd = -1;
    list_del(&phone->list);
    free(phone);

    return;
}


int phone_write_cmd(uint8_t type, uint8_t cmd, uint8_t *buf, int size)
{
    struct phone_t *pos, *next;

    list_for_each_entry_safe(pos, next, &phctx->phone_list, list) {
        int ret = -1;
        if(pos->ybuf.fd > 0) {
            ret = ymavlink_send_packet(&pos->ybuf, type, cmd, buf, size);
            if (ret < 0) {
                phone_disconnect(pos);
            }
        }
    }
    return 0;
}

int phone_write_buf(uint8_t *buf, int size)
{
    struct phone_t *pos, *next;

    list_for_each_entry_safe(pos, next, &phctx->phone_list, list) {
        int ret = -1;
        if(pos->ybuf.fd > 0) {
            ret = ymavlink_write_buf(&pos->ybuf, buf, size);
            if (ret < 0) {
                phone_disconnect(pos);
            }
        }
    }
    return 0;
}

static int parse_ssid_and_psk(unsigned char *buf, int len, char *ssid, int ssid_size, char *psk, int psk_size)
{
    int i = 0, ptr;

    buf += sizeof(COMMAND_HEADER);
    len -= sizeof(COMMAND_HEADER);
    buf[len - 1] = '\0';

    while(buf[i] == ' ' || buf[i] == '\0' || buf[i] == '\"') {
        if(++i >= len)
            return 0;
    }

    ptr = 0;
    while(buf[i] != ' ' && buf[i] != '\0' && buf[i] != '\"') {
        ssid[ptr] = buf[i];
        if(++i >= len || ++ptr >= ssid_size - 1)
            return 0;
    }
    if(ptr == 0)
        return 0;
    ssid[ptr] = '\0';

    while(buf[i] == ' ' || buf[i] == '\0' || buf[i] == '\"') {
        if(++i >= len)
            return 0;
    }

    ptr = 0;
    while(buf[i] != ' ' && buf[i] != '\0') {
        psk[ptr] = buf[i];
        if(++i >= len || ++ptr >= psk_size - 1)
            return 0;
    }
    if(ptr == 0)
        return 0;
    psk[ptr] = '\0';
    logi(LOG_RCDAEMON, TAG, "recieve phone connect request. ssid:%s, psk:%s\n", ssid, psk);

    return 1;
}

static int handle_packet(uint8_t *buf, int size)
{
    int ret = 0;

    if((buf[HEAD_DOMIAN_START_TYPE] & TYPE_BIT_2_4) == DATA_PACKET_TYPE_COMMAND_FLAG) {
        if ( buf[COMAND_HEAD_DOMIAN_COMMAND] != COMMAND_PAD_CHECK_RC_ALIVE ) {
            printf("phone type:0x%.2X cmd:0x%.2X size:%d\n", buf[HEAD_DOMIAN_START_TYPE], buf[COMAND_HEAD_DOMIAN_COMMAND], size);
            logi(LOG_COMMAND, TAG, "phone type:0x%.2X cmd:0x%.2X size:%d\n", buf[HEAD_DOMIAN_START_TYPE], buf[COMAND_HEAD_DOMIAN_COMMAND], size);
        }
        switch ( buf[COMAND_HEAD_DOMIAN_COMMAND] ) {
            case COMMAND_PAD_SCAN_WIFI:
                wpa_scan();
                break;

            case COMMAND_PAD_CONNECT_WIFI:
                {
                    char ssid[64];
                    char psk[128];
                    if(parse_ssid_and_psk(buf, size, ssid, sizeof(ssid), psk, sizeof(psk))) {
                        wpa_connect(ssid, psk);
                    } else {
                        phone_response(COMMAND_PAD_CONNECT_WIFI, (unsigned char*)"FAILED", strlen("FAILED"));
                    };
                }
                break;

            case COMMAND_PAD_GET_WIFI_STATUS:
                wpa_get_status();
                break;

            case COMMAND_PAD_GET_BIND_STATE:
                {
                    uint8_t addr[sizeof(M3TOM4TOPADBindInfo)] = {0};
                    autopilot_get_bindinfo(addr, sizeof(addr));
                    addr[0] = 0;
                    addr[1] = 0;
                    ret = phone_response(COMMAND_PAD_GET_BIND_STATE, addr, sizeof(addr));
                }
                break;

            case COMMAND_PAD_CLEAR_BINDED:
                autopilot_clear_bind();
                ret = phone_response(COMMAND_PAD_CLEAR_BINDED, NULL, 0);
                break;

            case COMMAND_PAD_GET_TRANSMITTER_MCU_SW_VERSION:
                phone_response(COMMAND_PAD_GET_TRANSMITTER_MCU_SW_VERSION, (uint8_t*)APP_SW_VERSION, sizeof(APP_SW_VERSION));
                break;

            case COMMAND_PAD_GET_TRANSMITTER_RF_SW_VERSION:
                phone_response(COMMAND_PAD_GET_TRANSMITTER_RF_SW_VERSION, (uint8_t *)phctx->rf_sw_version, RF_SW_VERSION_LEN);
#if 0
                ret = write_command(gp_rc, &gp_rc->ybuf[ID_AUTOPILOT], COMMAND_M4_GET_RF_SW_VERSION);
                if(gp_rc->rf_version_timer)
                    delRcTimer(gp_rc->rf_version_timer);
                gp_rc->rf_version_timer = add_rctimer(gp_rc, sendRfVersionTostruct phone_context, 500);
                if(gp_rc->rf_version_st)
                    delSendTask(gp_rc->rf_version_st);
                gp_rc->rf_version_st = addSendTask(&gp_rc->ybuf[ID_AUTOPILOT], gp_rc->ybuf[ID_AUTOPILOT].tx_buf, packet_len(gp_rc->ybuf[ID_AUTOPILOT].tx_buf), 30);
#endif
                break;

            case COMMAND_PAD_ODDER_M4_ENTER_BIND:
                autopilot_set_state(STATE_BIND);
                ret = phone_response(COMMAND_PAD_ODDER_M4_ENTER_BIND, NULL, 0);
                break;

            case COMMAND_PAD_SET_PLAT_DATA:
                ret = autopilot_write_command_and_params(COMMAND_M4_SET_PLAT_DATA, buf+COMAND_HEAD_DOMIAN_PARA, sizeof(SET_PLATFORM_DATA));
                if(ret >= 0)
                    ret = phone_response(COMMAND_PAD_SET_PLAT_DATA, NULL, 0);
                break;

            case COMMAND_PAD_ODDER_M4_ENTER_RUN:
                {
                    phone_response(COMMAND_PAD_ODDER_M4_ENTER_RUN, NULL, 0);
                    autopilot_set_state(STATE_SETUP_RUN);
                }
                break;

            case COMMAND_PAD_ODDER_M4_EXIT_BIND:
                autopilot_set_state(STATE_AWAIT);
                phone_response(COMMAND_PAD_ODDER_M4_EXIT_BIND, NULL, 0);
                break;

            case COMMAND_PAD_SET_CHANNEL_DATA:
                {
#if 0
                    COMMAND_HEADER *header = (COMMAND_HEADER*)buf;

                    header->start_str    = DATA_PACKET_START_STR;
                    header->size         = size - CRC_INVALID_BYTES;
                    header->Type         = DATA_PACKET_TYPE_CHANEL_FLAG | 0x80;
                    if(size > 30)
                        header->Type    |= 0x1 << 6;
                    header->FCF          = rc->g_M4ToM3bindInfo.FCF;
                    header->NodeIDdest   = rc->g_bind_receiver_addr;
                    header->NodeIDsource = rc->g_bind_tx_addr;
                    header->PANID        = rc->g_bind_tx_panid;
                    header->command      = COMMAND_M4_SEND_MIXED_CHANNEL_TO_M3;
                    buf[size - 1]        = calc_crc8(&buf[CRC_INVALID_BYTES], size - 4);

                    autopilot_write_buf(buf, size);
#endif
                }
            case COMMAND_PAD_ODDER_M4_EXIT_RUN:
                phone_response(COMMAND_PAD_ODDER_M4_EXIT_RUN, NULL, 0);
                autopilot_set_state(STATE_AWAIT);
                break;

            case COMMAND_PAD_ODDER_M4_EXIT_TO_AWAIT:
                phone_response(COMMAND_PAD_ODDER_M4_EXIT_TO_AWAIT, NULL, 0);
                autopilot_set_state(STATE_AWAIT);
                break;

            case COMMAND_PAD_GET_SWITCH_STATES:
                {
                    uint8_t switch_states = get_switch_states();
                    phone_response(COMMAND_PAD_GET_SWITCH_STATES, &switch_states, sizeof(switch_states));
                }
                break;

            case COMMAND_PAD_CHECK_RC_ALIVE:
                break;

            case COMMAND_PAD_ENTER_FACTORY_CALIBRATION:
                mcu_start_calibrate();
                break;

            case COMMAND_PAD_EXIT_FACTORY_CALIBRATION:
                mcu_stop_calibrate();
                break;

            case COMMAND_PAD_GET_CH_MAP:
                {
                    uint8_t temp = (uint8_t)channel_get_map();
                    phone_response(COMMAND_PAD_GET_CH_MAP, &temp, sizeof(temp));
                }
                break;

            case COMMAND_PAD_SET_CH_MAP:
                {
                    uint8_t temp = buf[COMAND_HEAD_DOMIAN_PARA];
                    int ret = channel_set_map(temp);
                    if ( ret == 0 ) {
                        phone_response(COMMAND_PAD_SET_CH_MAP, NULL, 0);
                    }
                }
                break;

            case COMMAND_PAD_GET_CH_CURVE:
                {
                    uint8_t temp = buf[COMAND_HEAD_DOMIAN_PARA];
                    uint8_t param_buf[sizeof(uint16_t)*MAX_POINTS_COUNT + 1];
                    int ret = channel_get_curve(temp, param_buf+1, sizeof(param_buf) - 1);
                    param_buf[0] = temp;
                    if ( ret == 0 ) {
                        phone_response(COMMAND_PAD_GET_CH_CURVE, param_buf, sizeof(param_buf));
                    }
                }
                break;

            case COMMAND_PAD_SET_CH_CURVE:
                {
                    uint8_t temp = buf[COMAND_HEAD_DOMIAN_PARA];
                    int ret = -1;
                    if (size - COMMAND_HEADER_SIZE - 1 == sizeof(uint16_t)*MAX_POINTS_COUNT + 1) {
                        ret = channel_set_curve(temp, &buf[COMAND_HEAD_DOMIAN_PARA+1], sizeof(uint16_t)*MAX_POINTS_COUNT);
                    }
                    if ( ret == 0 ) {
                        phone_response(COMMAND_PAD_SET_CH_CURVE, NULL, 0);
                    }
                }
                break;

            case COMMAND_PAD_GET_GPS_DATA:
                {
                    GPSData gps;
                    get_gps(&gps);
                    phone_response(COMMAND_PAD_GET_GPS_DATA, (unsigned char*)&gps, sizeof(gps));
                }
                break;

            default:
                break;
        }
    } else if ((buf[HEAD_DOMIAN_START_TYPE] & TYPE_BIT_2_4) == DATA_PACKET_TYPE_BIND_FLAG) {
        ret = autopilot_send_bindinfo(1, buf, size);
    } else if ((buf[HEAD_DOMIAN_START_TYPE] & TYPE_BIT_2_4) == DATA_PACKET_TYPE_CHANEL_FLAG) {
        ret = autopilot_write_buf(buf, size);
    } else if ((buf[HEAD_DOMIAN_START_TYPE] & TYPE_BIT_2_4) == DATA_PACKET_TYPE_EX_FLAG) {
        ret = autopilot_write_buf(buf, size);
    }

    return ret;
}

static inline int proc_phone(struct ymavlink_buffer *ybuf)
{
    int len;

    while(1) {
        len = ymavlink_read_buf(ybuf);
        if(len <= 0) {
            break;
        }

        while ((len = ymavlink_get_packet(ybuf)) > 0) {
            handle_packet(ybuf->buf + ybuf->offset, len);
            ymavlink_update_buf(ybuf, len);
        }

        ymavlink_cyclic_buf(ybuf);
    }

    return len;
}

static int handle_phone(struct epoll_event *ev, struct epoll_context *epctx)
{
    struct phone_t *phone = epctx->data;
    if( ev->events & (EPOLLERR | EPOLLHUP)
        || ((ev->events & (EPOLLIN)) && (proc_phone(&phone->ybuf) < 0)) ) {
        phone_disconnect(phone);
    }

    return 0;
}

static int accept_client(int fd)
{
    struct sockaddr_un addr;
    int cfd;
    socklen_t len = sizeof(struct sockaddr_un);

    cfd = accept(fd, (struct sockaddr *)&addr, &len);
    if (cfd < 0) {
        loge(LOG_RCDAEMON, TAG, "accept() failed (%s)", strerror(errno));
        return cfd;
    }

    fcntl(cfd, F_SETFL, fcntl(cfd, F_GETFL, 0) | O_NONBLOCK);

    return cfd;
}

static inline int phone_connect(struct phone_context *ctx)
{
    struct ymavlink_buffer *ybuf;
    struct phone_t *phone;
    struct epoll_event ev;
    int fd = accept_client(ctx->listenfd);

    if (fd < 0) {
        return -1;
    }

    phone = malloc(sizeof(struct phone_t));
    if (!phone) {
        return -ENOMEM;
    }

    ybuf = &phone->ybuf;
    ybuf->fd = fd;
    ybuf->fdtype = FD_TYPE_SOCK;
    ymavlink_reset_buf(ybuf);

    phone->epctx.callback = handle_phone;
    phone->epctx.data = phone;
    ev.events = EPOLLIN;
    ev.data.ptr = &phone->epctx;
    if(epoll_ctl(ctx->epfd, EPOLL_CTL_ADD, ybuf->fd, &ev) < 0) {
        loge(LOG_RCDAEMON, TAG, "epoll ctl for phone add error!!!");
        return -1;
    }

    list_add(&phone->list, &phctx->phone_list);
    logi(LOG_RCDAEMON, TAG, "phone connect success!!\n");
    log("phone connect success!!\n");

    return 0;
}

static int handle_phone_connect(struct epoll_event *ev, struct epoll_context *epctx)
{
    struct phone_context *ctx = epctx->data;
    if(ev->events & EPOLLIN) {
        phone_connect(ctx);
    }

    return 0;
}

#define UNIX_SOCK_RCDAEMON_PATH "/var/run/usb_proxy_svr_4"

int phone_init(int epfd, struct epoll_context *epctx)
{
    struct epoll_event ev;
    phctx = malloc(sizeof(*phctx));
    if(!phctx || !epctx)
        return -ENOMEM;

    memset(phctx, 0, sizeof(*phctx));

    INIT_LIST_HEAD(&phctx->phone_list);
    phctx->epfd = epfd;
    phctx->epctx = epctx;

    epctx->callback = handle_phone_connect;
    epctx->data = phctx;
    ev.events = EPOLLIN;
    ev.data.ptr = phctx->epctx;

    phctx->listenfd = unix_socket_open_listen(UNIX_SOCK_RCDAEMON_PATH);
    if (phctx->listenfd < 0) {
        free(phctx);
        phctx = NULL;
        return -1;
    }

    if(epoll_ctl(phctx->epfd, EPOLL_CTL_ADD, phctx->listenfd, &ev) < 0) {
        loge(LOG_RCDAEMON, TAG, "epoll ctl for listenfd add error!!!");
        close(phctx->listenfd);
        free(phctx);
        phctx = NULL;
        return -1;
    }

    return 0;
}

void phone_deinit()
{
    if (phctx) {
        if (phctx->listenfd > 0) {
            close(phctx->listenfd);
        }
        free(phctx);
        phctx = NULL;
    }
}
