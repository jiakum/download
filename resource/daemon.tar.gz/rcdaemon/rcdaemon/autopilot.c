#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

#include "epoll_context.h"
#include "common.h"
#include "log.h"
#include "rcprotocol.h"
#include "phone.h"
#include "local.h"
#include "utils.h"
#include "ymavlink.h"
#include "gps/ublox.h"
#include "setting.h"
#include "gpioctrl.h"

#include "autopilot.h"

#define TAG "autopilot"

static AutoPilot ap;

int autopilot_write_buf(unsigned char *buf, int size)
{
    return ymavlink_write_buf(ap.ybuf, buf, size);
}

int autopilot_write_command_and_params(unsigned int cmd, uint8_t *param, int size)
{
    return write_command_and_params(ap.ybuf, cmd, param, size);
}

int autopilot_get_bindinfo(uint8_t *addr, int size)
{
    AutoPilot *p = &ap;

    if ( addr == NULL ) {
        return -1;
    }

    memcpy(addr, &p->autopilot_bindinfo, size);

    return 0;
}

#define BIND_INFO_STR       "bindinfo"

static inline void store_bindinfo(AutoPilot *p)
{
    uint8_t buf[sizeof(p->autopilot_bindinfo) + sizeof(p->bind_tx_addr)] = {0};
    memcpy(buf, &p->bind_tx_addr, sizeof(p->bind_tx_addr));
    memcpy(buf+sizeof(p->bind_tx_addr), &p->autopilot_bindinfo, sizeof(p->autopilot_bindinfo));
    store_data(NULL, BIND_INFO_STR, buf, sizeof(buf));
}

static inline void load_bindinfo(AutoPilot *p)
{
    uint8_t buf[sizeof(p->autopilot_bindinfo) + sizeof(p->bind_tx_addr)] = {0};
    if (get_rawdata(NULL, BIND_INFO_STR, buf, sizeof(buf)) == 0) {
        memcpy(&p->bind_tx_addr, buf, sizeof(p->bind_tx_addr));
        memcpy(&p->autopilot_bindinfo, buf+sizeof(p->bind_tx_addr), sizeof(p->autopilot_bindinfo));
    }
    logi(LOG_RCDAEMON, TAG, "Load bindinfo bind_tx_addr=0x%X RxAddr=0x%X PanID=0x%X\n", p->bind_tx_addr, p->autopilot_bindinfo.RxAddr, p->autopilot_bindinfo.RxPANID);
}

static int ask_for_panid_addr_msg(int on)
{
    AutoPilot *p = &ap;

    static SendTask *st = NULL;

    if ( st ) {
        del_sendtask(st);
        st = NULL;
    }

    if ( on ) {
        write_command(ap.ybuf, COMMAND_M3_SEND_PANID_ADDR_MSG_TO_M4);

        st = add_sendtask(ap.ybuf, p->ybuf->tx_buf,
                packet_len(p->ybuf->tx_buf), 100);
        if ( st == NULL ) {
            return -1;
        }
    }

    return 0;
}

static void init_rc_bindinfo()
{
    AutoPilot *p = &ap;
    M4ToM3bindInfo  *info = &p->rc_bindinfo;

    memset(info, 0, sizeof(M4ToM3bindInfo));

    info->start_str = DATA_PACKET_START_STR;
    info->size      = sizeof(M4ToM3bindInfo) - CRC_INVALID_BYTES;
    info->Type     |= DATA_PACKET_TYPE_BIND_FLAG;
    info->ANum      = OWNER_ANUM;
    info->ABits     = OWNER_ABITS;
    info->TrNum     = OWNER_TRNUM;
    info->TrBits    = OWNER_TRBITS;
    info->SwNum     = OWNER_SWNUM;
    info->SwBits    = OWNER_SWBITS;
    info->ExtraNum  = OWNER_EXTRANUM;
    info->ExtraBits = OWNER_EXTRABITS;

    ask_for_panid_addr_msg(1);

    return;
}

static int send_channel_data(RcTimer *timer)
{
    AutoPilot *p = timer->p;
    uint8_t type = DATA_PACKET_TYPE_CHANEL_FLAG | (RECEIVER_TYPE << 7);
    int size = BITS_TO_BYTES(OWNER_ANUM * OWNER_ABITS + OWNER_SWNUM * OWNER_SWBITS);
    uint8_t *buf = p->channel_buf;
    static int i = 1;
    int j;
    static char str_buf[3*sizeof(p->channel_buf)];

    i = i % 5;
    fill_channel_data(p->channel_buf, sizeof(p->channel_buf));

    if ( i == 0 ) {     // send gps and compass with channel
        GPSData data;
        float compass = 0.0;
        type |= TYPE_BIT_6;
        get_gps(&data);
        memcpy(buf + size, &data, sizeof(GPSData));
        memcpy(buf + size + sizeof(GPSData), &compass, sizeof(compass));
        size += sizeof(GPSData) + sizeof(compass);
    }

    for ( j = 0; j < size; j++ ) {
        sprintf(str_buf + 3 * j,"%.2X ", buf[j]);
    }
    str_buf[3 * size - 1] = '\0';
    logi(LOG_CHANNEL, "channel", "size=%d buf: %s", size, str_buf);

    ymavlink_send_packet(ap.ybuf, type, COMMAND_M4_SEND_MIXED_CHANNEL_TO_M3, buf, size);
    phone_write_cmd(type, COMMAND_M4_SEND_MIXED_CHANNEL_TO_PAD, buf, size);
    local_write_cmd(type, COMMAND_M4_SEND_MIXED_CHANNEL_TO_PAD, buf, size);
    refresh_rctimer(timer, 20);
    i++;
    return 0;
}

static int autopilot_send_channel(int on)
{
    AutoPilot *p = &ap;

    static RcTimer *timer = NULL;

    if ( timer ) {
        del_rctimer(timer);
        timer = NULL;
    }

    if ( on ) {
        timer = add_rctimer(p, send_channel_data, 20);
        if ( timer == NULL ) {
            loge(LOG_RCDAEMON, TAG, "add rctimer failed\n");
            return -1;
        }
    }

    return 0;
}

int autopilot_send_bindinfo(int on, unsigned char* buf, unsigned int size)
{
    AutoPilot *p = &ap;

    static SendTask *st = NULL;

    logi(LOG_RCDAEMON, TAG, "%s, on ? %d \n", __func__, on);
    if ( st ) {
        del_sendtask(st);
        st = NULL;
    }

    if ( on ) {
        PADTOM4bindInfo *padinfo    = (PADTOM4bindInfo *)buf;
        int len                     = p->rc_bindinfo.size + CRC_INVALID_BYTES;

        if ( buf == NULL ) {
            loge(LOG_RCDAEMON, TAG, "invaild buf\n");
            return -1;
        }

        if (((PADTOM4bindInfo*)buf)->Command == RECEIVER_BIND_SUCESS) {
            autopilot_clear_bind();
            p->to_bind_addr = padinfo->ComPara;
        }

        p->rc_bindinfo.FCF          = padinfo->FCF;
        p->rc_bindinfo.Command      = padinfo->Command;
        p->rc_bindinfo.ComPara      = padinfo->ComPara;
        p->rc_bindinfo.FInterval1   = padinfo->FInterval1;
        p->rc_bindinfo.FInterval2   = padinfo->FInterval2;
        p->rc_bindinfo.CRC8         = calc_crc8((uint8_t *)(&p->rc_bindinfo) + CRC_START_POSITION, len - CRC_INVALID_BYTES - 1);

        ymavlink_write_buf(ap.ybuf, (uint8_t *)(&p->rc_bindinfo), len);

        st = add_sendtask(ap.ybuf, (uint8_t *)(&p->rc_bindinfo), len, 30);
        if ( st == NULL ) {
            loge(LOG_RCDAEMON, TAG, "add send task failed\n");
            return -1;
        }
    }

    return 0;
}

int autopilot_set_rf_enter_run(int on)
{
    AutoPilot *p = &ap;

    static SendTask *st = NULL;

    if ( st ) {
        del_sendtask(st);
        st = NULL;
    }

    if ( on ) {
        write_command_and_params(ap.ybuf, COMMAND_M4_SET_RF_ENTER_RUN,
                (uint8_t *)&p->autopilot_bindinfo.Mode, sizeof(&p->autopilot_bindinfo.Mode));

        st = add_sendtask(ap.ybuf, p->ybuf->tx_buf,
                packet_len(p->ybuf->tx_buf), 100);
        if ( st == NULL ) {
            return -1;
        }
    }

    return 0;
}

#if 0
int sendRfVersionToPhone(RcTimer *timer)
{
    RcDaemon *rc = timer->p;

    response_command(NULL, &rc->ybuf[ID_PHONE], COMMAND_PAD_GET_TRANSMITTER_RF_SW_VERSION, rc->rf_sw_version, RF_SW_VERSION_LEN);
    if(rc->rf_version_st) {
        del_sendtask(rc->rf_version_st);
        rc->rf_version_st = NULL;
    }

    if(rc->rf_version_timer)
        del_rctimer(rc->rf_version_timer);
    rc->rf_version_timer = NULL;

    return 0;
}

static void get_rf_sw_version(RcDaemon *rc, unsigned char *buf, int size)
{
    unsigned char *version = rc->rf_sw_version;
    uint32_t      num;
    uint8_t       tmep;

    if ((size - sizeof(COMMAND_NO_PARAMS)) == (RF_SW_VERSION_LEN - 1)) {
        memcpy(version, buf+COMAND_HEAD_DOMIAN_PARA, RF_SW_VERSION_LEN);
        version[RF_SW_VERSION_LEN-1] = '\0';

        tmep = (version[RF_SW_VERSION_NUM_BIT]-'0') < 0 ? 0 : (version[RF_SW_VERSION_NUM_BIT]-'0');
        num  = tmep * 1000;
        tmep = (version[RF_SW_VERSION_NUM_BIT+1]-'0') < 0 ? 0 : (version[RF_SW_VERSION_NUM_BIT+1]-'0');
        num += tmep * 100;
        tmep = (version[RF_SW_VERSION_NUM_BIT+3]-'0') < 0 ? 0 : (version[RF_SW_VERSION_NUM_BIT+3]-'0');
        num += tmep * 10;
        tmep = (version[RF_SW_VERSION_NUM_BIT+4]-'0') < 0 ? 0 : (version[RF_SW_VERSION_NUM_BIT+4]-'0');
        num += tmep;

        rc->rf_sw_num_version = num;
    }
}
#endif

int autopilot_set_state(enum STATE_ENUM val)
{
    AutoPilot *p = &ap;
    loge(LOG_RCDAEMON, TAG, "o=%d, n=%d\n", p->state, val);
    if ( p->state == val ) {
        return 0;
    }

    switch ( p->state ) {
        case STATE_AWAIT:
            break;
        case STATE_BIND:
            autopilot_send_bindinfo(0, NULL, 0);
            break;
        case STATE_CALIBRATE:
            break;
        case STATE_SETUP:
            break;
        case STATE_RUN:
            autopilot_send_channel(0);
            break;
        case STATE_SIMULATOR:
            break;
        case STATE_DEFAULT_CALIBRATE:
            break;
        case STATE_SETUP_RUN:
            autopilot_set_rf_enter_run(0);
            break;
        default:
            break;
    }

    switch ( val ) {
        case STATE_AWAIT:
            ask_for_panid_addr_msg(0);
            autopilot_send_bindinfo(0, NULL, 0);
            autopilot_set_rf_enter_run(0);
            autopilot_send_channel(0);
            break;
        case STATE_BIND:
            autopilot_send_channel(0);
            break;
        case STATE_CALIBRATE:
            break;
        case STATE_SETUP:
            break;
        case STATE_RUN:
            autopilot_send_channel(1);
            break;
        case STATE_SIMULATOR:
            break;
        case STATE_DEFAULT_CALIBRATE:
            break;
        case STATE_SETUP_RUN:
            load_bindinfo(p);
            autopilot_set_rf_enter_run(1);
            break;
        default:
            break;
    }

    p->state = val;
    return 0;
}

enum STATE_ENUM autopilot_get_state()
{
    return ap.state;
}

void autopilot_clear_bind()
{
    AutoPilot *p = &ap;

    p->is_binded                = UNBINDED;
    p->bind_sucess_count        = 0;
    p->bind_tx_addr             = 0;
    memset(&p->autopilot_bindinfo, 0, sizeof(M3TOM4TOPADBindInfo));
    logi(LOG_RCDAEMON, TAG, "clear bind\n");
    return;
}

static inline void autopilot_update_bind_status(uint8_t *buf, int size)
{
    AutoPilot *p = &ap;

    if ( p->is_binded != BINDED ) {
        p->bind_tx_addr             = *(unsigned short *)((unsigned char*)buf + size - 3);
        memcpy(&p->autopilot_bindinfo, buf, sizeof(M3TOM4TOPADBindInfo));
        logi(LOG_RCDAEMON, TAG, "Bind successfully! bind_tx_addr=0x%X RxAddr=0x%X PanID=0x%X\n", p->bind_tx_addr, p->autopilot_bindinfo.RxAddr, p->autopilot_bindinfo.RxPANID);
        store_bindinfo(p);
        p->is_binded = BINDED;
    }

    return;
}

static inline int autopilot_handle_bind_packet(uint8_t *buf, int size)
{
    int ret = 0;
    AutoPilot *p = &ap;

    if(((M3TOM4TOPADBindInfo*)buf)->RxState == RECEIVER_BIND_SUCESS) {
        if(p->to_bind_addr == ((M3TOM4TOPADBindInfo*)buf)->RxAddr) {
            p->bind_sucess_count++;
            autopilot_write_buf(buf, size);
        } else {
            autopilot_clear_bind();
        }

        if(p->bind_sucess_count < 2) {
            return 0;
        } else {
            autopilot_update_bind_status(buf, size);
            autopilot_send_bindinfo(0, NULL, 0);
            autopilot_write_buf(buf, size);
        }
    }

    phone_write_buf(buf, size);
    local_write_buf(buf, size);
    return ret;
}

static inline int autopilot_handle_channel_packet(uint8_t *buf, int size)
{
    int ret = 0;
    AutoPilot *p = &ap;
    TelemetryData2 *param = (TelemetryData2*)(buf + COMAND_HEAD_DOMIAN_PARA);

    p->drone_lat = param->lat;
    p->drone_lon = param->lon;
    p->gps_fixed = (param->nsat & 0x80) ? 1 : 0;

    if (param->fMode == FMODE_GO_HOME) {
        gpio_set_state(GOHOME_LED, 1);
    } else {
        gpio_set_state(GOHOME_LED, 0);
    }


    buf[COMAND_HEAD_DOMIAN_COMMAND] = COMMAND_M4_SEND_M3_BACK_CHANNEL_DATA;
    buf[size-1] = calc_crc8(buf+CRC_START_POSITION, size-CRC_INVALID_BYTES-1);
    phone_write_buf(buf, size);
    local_write_buf(buf, size);

    return ret;
}

static inline int autopilot_handle_ex_packet(uint8_t *buf, int size)
{
    phone_write_buf(buf, size);
    local_write_buf(buf, size);
    return 0;
}

static int autopilot_handle_other_packet(uint8_t *buf, int size)
{
    int ret = 0;
    AutoPilot *p = &ap;

    printf("autopilot type:0x%.2X cmd:0x%.2X size:%d\n", buf[HEAD_DOMIAN_START_TYPE], buf[COMAND_HEAD_DOMIAN_COMMAND], size);
    logi(LOG_RCDAEMON, TAG, "autopilot type:0x%.2X cmd:0x%.2X size:%d\n", buf[HEAD_DOMIAN_START_TYPE], buf[COMAND_HEAD_DOMIAN_COMMAND], size);
    switch ( buf[COMAND_HEAD_DOMIAN_COMMAND] ) {
        case COMMAND_M4_SET_RF_ENTER_RUN:
            autopilot_set_rf_enter_run(0);
            autopilot_set_state(STATE_RUN);
            break;

        case COMMAND_M4_GET_RF_SW_VERSION:
#if 0
            get_rf_sw_version(rc, buf, size);
            if(rc->rf_version_st) {
                delSendTask(rc->rf_version_st);
                rc->rf_version_st = NULL;
            }
            if(rc->rf_version_timer) {
                delRcTimer(rc->rf_version_timer);
                rc->rf_version_timer = NULL;
            }
            phone_response_cmd(COMMAND_PAD_GET_TRANSMITTER_RF_SW_VERSION, rc->rf_sw_version, RF_SW_VERSION_LEN);
#endif
            break;

        case COMMAND_M3_SEND_PANID_ADDR_MSG_TO_M4:
            p->rc_bindinfo.FCF      = buf[3] | (buf[4] << 8);
            p->rc_bindinfo.Protocol = buf[13] | (buf[14] << 8);
            p->rc_bindinfo.TxPANID  = buf[17] | (buf[18] << 8);
            p->rc_bindinfo.TxAddr   = buf[19] | (buf[20] << 8);
            ask_for_panid_addr_msg(0);
            logi(LOG_RCDAEMON, TAG, "rc bindinfo F=%u P=%u PanID=%u Addr=%u\n",
                    p->rc_bindinfo.FCF, p->rc_bindinfo.Protocol, p->rc_bindinfo.TxPANID, p->rc_bindinfo.TxAddr);
            break;

        default:
            break;
    }

    return ret;
}

static int autopilot_proc_packet(uint8_t *buf, int size)
{
    int ret = 0;

    switch ( buf[HEAD_DOMIAN_START_TYPE] & TYPE_BIT_2_4 ) {

        case DATA_PACKET_TYPE_BIND_FLAG:
            ret = autopilot_handle_bind_packet(buf, size);
            break;

        case DATA_PACKET_TYPE_CHANEL_FLAG:
            ret = autopilot_handle_channel_packet(buf, size);
            break;

        case DATA_PACKET_TYPE_EX_FLAG:
            ret = autopilot_handle_ex_packet(buf, size);
            break;

        default:
            ret = autopilot_handle_other_packet(buf, size);
            break;
    }

    return ret;
}

static int proc_pilot(struct ymavlink_buffer *ybuf)
{
    int len;

    while(1) {
        len = ymavlink_read_buf(ybuf);
        if(len <= 0) {
            break;
        }

        while ((len = ymavlink_get_packet(ybuf)) > 0) {
            autopilot_proc_packet(ybuf->buf+ybuf->offset, len);
            ymavlink_update_buf(ybuf, len);
        }

        ymavlink_cyclic_buf(ybuf);
    }

    return len;
}

static int handle_pilot(struct epoll_event *ev, struct epoll_context *epctx)
{
    struct ymavlink_buffer *ybuf = ap.ybuf;
    if( ev->events & (EPOLLERR | EPOLLHUP)
        || ((ev->events & (EPOLLIN)) && (proc_pilot(ybuf) < 0)) ) {
        loge(LOG_RCDAEMON, TAG, "file closed !!! This should never happen!\n");
    }
    return 0;
}

int init_pilot(int epfd, struct epoll_context *epctx)
{
    struct epoll_event ev;
    struct ymavlink_buffer *ybuf = malloc(sizeof(*ybuf));
    int fd;

    if((fd = open("/dev/ttyS2", O_RDWR | O_NOCTTY)) < 0 || !ybuf || !epctx) {
        loge(LOG_RCDAEMON, TAG, "open uart /dev/ttyS2 failed!!!");
        return -1;
    }
    set_serialport(fd, 230400, 0, 8, 2, 'n');
    fcntl(fd, F_SETFL, fcntl(fd, F_GETFL) | O_NONBLOCK);

    ap.epfd = epfd;
    ap.epctx = epctx;
    epctx->callback = handle_pilot;
    epctx->data = &ap;

    ybuf->fd = fd;
    ybuf->fdtype = FD_TYPE_FILE;
    ybuf->pilot = &ap;
    ymavlink_reset_buf(ybuf);
    ap.ybuf = ybuf;

    ev.events = EPOLLIN;
    ev.data.ptr = epctx;

    if(epoll_ctl(epfd, EPOLL_CTL_ADD, fd, &ev) < 0) {
        loge(LOG_RCDAEMON, TAG, "epoll ctl failed!!!");
        return -1;
    }

    init_rc_bindinfo();
    load_bindinfo(&ap);
    autopilot_set_state(STATE_SETUP_RUN);

    return 0;
}
