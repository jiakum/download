#ifndef __ANALOG_INPUT_H__
#define __ANALOG_INPUT_H__

#include <sys/types.h>

#define HW_JOYSTICK_NUMS    4
#define HW_KNOB_NUMS        2
#define ADC_NUMS            (HW_JOYSTICK_NUMS + HW_KNOB_NUMS)

#define CH_MAX              4095
#define CH_DEFAULT_VAL      2048

enum HW_ID {
    HW_ID_J1 = 0,
    HW_ID_J2,
    HW_ID_J3,
    HW_ID_J4,
    HW_ID_K1,
    HW_ID_K2,
    HW_ID_MAX
};

#define LIMIT(low, x, high) x=((x)>(high)?(high):(x)<(low)?(low):(x))

typedef struct {
    struct {
        int16_t max;
        int16_t mid;
        int16_t min;
    } in;
    struct {
        int16_t max;
        int16_t mid;
        int16_t min;
    } out;
    uint8_t isReverse;
} AnalogInput;

uint16_t analog_input_get_value(enum HW_ID id);

#endif /* __ANALOG_INPUT_H__ */
