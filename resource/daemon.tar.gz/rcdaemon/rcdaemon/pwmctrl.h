#ifndef __PWMCTRL_H__
#define __PWMCTRL_H__

#define PWM_INDEX_FAN       0
#define PWM_INDEX_BUZZER    1

// on_time: -1 for infinite, 0 for stop, >0 for on_time msecs
#define PWM_ON_TIME_INFINITE    -1
#define PWM_ON_TIME_STOP        0

int pwm_set_state(uint8_t index, int32_t on_time, uint32_t freq);

#endif /* __PWMCTRL_H__ */
