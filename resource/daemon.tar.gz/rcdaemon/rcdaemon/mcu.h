#ifndef __MCU_H__
#define __MCU_H__

#include "epoll_context.h"
#include "ymavlink.h"

#define MCU_CMD_GET_BAT         0xE2
typedef struct {
    uint16_t    volt_value;
    uint8_t     volt_percent;
    uint8_t     charge_state;
}__attribute__((packed)) BatteryInfo;

int init_mcu(int epfd, struct epoll_context *epctx);
void mcu_start_calibrate();
void mcu_stop_calibrate();

#endif /* __MCU_H__ */
