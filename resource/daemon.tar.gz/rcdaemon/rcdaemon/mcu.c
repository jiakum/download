#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include "common.h"
#include "rcprotocol.h"
#include "utils.h"
#include "ymavlink.h"
#include "mcu.h"
#include "rctimer.h"
#include "analog_input.h"
#include "setting.h"
#include "phone.h"
#include "local.h"

#define CALIBRATE_DATA_STR      "calibrate_data"

#define TAG "mcu"

typedef struct {
    BatteryInfo     batinfo;
    SendTask        *st_poll_adc;
    SendTask        *st_poll_batinfo;
    uint16_t        adc_table_output[ADC_NUMS];
    uint16_t        adc_table_input[ADC_NUMS];
    AnalogInput     analog_input_table[ADC_NUMS];
    int             calibrating;
    struct ymavlink_buffer *ybuf;
} MCU_Priv_data;

static MCU_Priv_data mcu_priv_data = {
    .analog_input_table = {
        {.in={.max=CH_MAX, .mid=CH_DEFAULT_VAL, .min=0}, .out={.max=CH_MAX, .mid=CH_DEFAULT_VAL, .min=0}, .isReverse=0},
        {.in={.max=CH_MAX, .mid=CH_DEFAULT_VAL, .min=0}, .out={.max=CH_MAX, .mid=CH_DEFAULT_VAL, .min=0}, .isReverse=0},
        {.in={.max=CH_MAX, .mid=CH_DEFAULT_VAL, .min=0}, .out={.max=CH_MAX, .mid=CH_DEFAULT_VAL, .min=0}, .isReverse=1},
        {.in={.max=CH_MAX, .mid=CH_DEFAULT_VAL, .min=0}, .out={.max=CH_MAX, .mid=CH_DEFAULT_VAL, .min=0}, .isReverse=0},
        {.in={.max=CH_MAX, .mid=CH_DEFAULT_VAL, .min=0}, .out={.max=CH_MAX, .mid=CH_DEFAULT_VAL, .min=0}, .isReverse=0},
        {.in={.max=CH_MAX, .mid=CH_DEFAULT_VAL, .min=0}, .out={.max=CH_MAX, .mid=CH_DEFAULT_VAL, .min=0}, .isReverse=0},
    },
    .batinfo={0},0
};

void mcu_start_calibrate()
{
    int i = 0;
    mcu_priv_data.calibrating = 1;
    for ( i = 0; i < ADC_NUMS; i++ ) {
        mcu_priv_data.analog_input_table[i].in.min = CH_DEFAULT_VAL-768;
        mcu_priv_data.analog_input_table[i].in.max = CH_DEFAULT_VAL+768;
    }
}

void mcu_stop_calibrate()
{
    int i = 0;
    uint16_t calibrate_data[ADC_NUMS][3];

    mcu_priv_data.calibrating = 0;
    for ( i = 0; i < ADC_NUMS; i++ ) {
        mcu_priv_data.analog_input_table[i].in.mid = mcu_priv_data.adc_table_input[i]; 
        LIMIT(0, mcu_priv_data.analog_input_table[i].in.min, CH_DEFAULT_VAL - 768);
        LIMIT(CH_DEFAULT_VAL - 512, mcu_priv_data.analog_input_table[i].in.mid, CH_DEFAULT_VAL + 512);
        LIMIT(CH_DEFAULT_VAL + 768, mcu_priv_data.analog_input_table[i].in.max, CH_MAX);
        calibrate_data[i][0] = mcu_priv_data.analog_input_table[i].in.min;
        calibrate_data[i][1] = mcu_priv_data.analog_input_table[i].in.mid;
        calibrate_data[i][2] = mcu_priv_data.analog_input_table[i].in.max;
    }

    store_data(NULL, CALIBRATE_DATA_STR, calibrate_data, sizeof(calibrate_data));
}

static inline void load_calibrate_data()
{
    int i = 0;
    uint16_t calibrate_data[ADC_NUMS][3];

    if (get_rawdata(NULL, CALIBRATE_DATA_STR, calibrate_data, sizeof(calibrate_data)) < 0) {
        logw(LOG_RCDAEMON, TAG, "load calibrate data faild, use default value.\n");
        return;
    }

    for ( i = 0; i < ADC_NUMS; i++ ) {
        mcu_priv_data.analog_input_table[i].in.min = calibrate_data[i][0];
        mcu_priv_data.analog_input_table[i].in.mid = calibrate_data[i][1];
        mcu_priv_data.analog_input_table[i].in.max = calibrate_data[i][2];
        LIMIT(0, mcu_priv_data.analog_input_table[i].in.min, CH_DEFAULT_VAL - 768);
        LIMIT(CH_DEFAULT_VAL - 512, mcu_priv_data.analog_input_table[i].in.mid, CH_DEFAULT_VAL + 512);
        LIMIT(CH_DEFAULT_VAL + 768, mcu_priv_data.analog_input_table[i].in.max, CH_MAX);
    }
}

static inline void init_adc_table()
{
    int i = 0;
    for ( i = 0; i < ADC_NUMS; i++ ) {
        mcu_priv_data.adc_table_input[i] = CH_DEFAULT_VAL;
        mcu_priv_data.adc_table_output[i] = CH_DEFAULT_VAL;
    }
}

static inline void update_adc_table(uint16_t *buf, int len)
{
    int i = 0;
    for ( i = 0; i < len; i++ ) {
        mcu_priv_data.adc_table_input[i] = buf[i];
        if ( mcu_priv_data.calibrating ) {
            if ( buf[i] < mcu_priv_data.analog_input_table[i].in.min ) {
                mcu_priv_data.analog_input_table[i].in.min = buf[i];
                LIMIT(0, mcu_priv_data.analog_input_table[i].in.min, CH_DEFAULT_VAL - 768);
            }
            if ( buf[i] > mcu_priv_data.analog_input_table[i].in.max ) {
                mcu_priv_data.analog_input_table[i].in.max = buf[i];
                LIMIT(CH_DEFAULT_VAL + 768, mcu_priv_data.analog_input_table[i].in.max, CH_MAX);
            }
        }
    }
}

uint16_t __analog_input_get_value(enum HW_ID id)
{
    uint16_t ret = mcu_priv_data.adc_table_input[id];
    AnalogInput *input = &mcu_priv_data.analog_input_table[id];

    if ( input->in.min >= input->in.mid || input->in.max <= input->in.mid ) {
        return CH_DEFAULT_VAL;
    }

    LIMIT(input->in.min, ret, input->in.max);

    if ( input->isReverse ) {
        if ( ret > input->in.mid ) {
            ret = input->out.min + (input->in.max-ret)*(input->out.mid - input->out.min)/(input->in.max - input->in.mid);
        } else {
            ret = input->out.mid + (input->in.mid-ret)*(input->out.max - input->out.mid)/(input->in.mid - input->in.min);
        }
    } else {
        if ( ret < input->in.mid ) {
            ret = input->out.min + (ret-input->in.min)*(input->out.mid - input->out.min)/(input->in.mid - input->in.min);
        } else {
            ret = input->out.mid + (ret-input->in.mid)*(input->out.max - input->out.mid)/(input->in.max - input->in.mid);
        }
    }

    return ret;
}

uint16_t analog_input_get_value(enum HW_ID id)
{
    if ( id >= HW_ID_MAX ) {
        return CH_DEFAULT_VAL;
    }

    return __analog_input_get_value(id);
}

static int open_mcu_tty(const char *name)
{
    int            fd;

    fd = open(name, O_RDWR|O_NOCTTY|O_NONBLOCK);
    if(fd < 0) {
        loge(LOG_RCDAEMON, TAG, "open %s failed! Check whether you have permission.\n", name);
        return -1;
    }
    set_serialport(fd, 115200, 0, 8, 1, 'n');

    fcntl(fd, F_SETFL, fcntl(fd, F_GETFL) | O_NONBLOCK);

    return fd;
}

#define MCU_CMD_GET_ADC         0xE1

static int proc_mcu(uint8_t *buf, int len)
{
    switch ( buf[COMAND_HEAD_DOMIAN_COMMAND] ) {
        case MCU_CMD_GET_ADC:
            update_adc_table((uint16_t *)(&(buf[COMAND_HEAD_DOMIAN_PARA])), ADC_NUMS);
            //logi(LOG_RCDAEMON, TAG, "J1=%d J2=%d J3=%d J4=%d K1=%d K2=%d\n", g_adc_table[0], g_adc_table[1], g_adc_table[2], g_adc_table[3], g_adc_table[4], g_adc_table[5]);
            break;
        case MCU_CMD_GET_BAT:
            phone_write_cmd(DATA_PACKET_TYPE_RESPONSE_FLAG, MCU_CMD_GET_BAT, &(buf[COMAND_HEAD_DOMIAN_PARA]), sizeof(BatteryInfo));
            local_write_cmd(DATA_PACKET_TYPE_RESPONSE_FLAG, MCU_CMD_GET_BAT, &(buf[COMAND_HEAD_DOMIAN_PARA]), sizeof(BatteryInfo));
            break;
        default:
            loge(LOG_RCDAEMON, TAG, "unknow cmd from MCU\n");
            print_buf(buf, len);
            return -1;
            break;
    }
    return 0;
}

static int handle_mcu(struct epoll_event *ev, struct epoll_context *epctx)
{
    struct ymavlink_buffer *ybuf = mcu_priv_data.ybuf;
    int ret;

    while(1) {
        ret = ymavlink_read_buf(ybuf);

        if(ret < 0) {
            return -1;
        } else if ( ret == 0 ) {
            return 0;
        }

        while ((ret = ymavlink_get_packet(ybuf)) > 0) {
            uint8_t *buf = ybuf->buf+ybuf->offset;
            ymavlink_update_buf(ybuf, ret);
            proc_mcu(buf, ret);
        }

        ymavlink_cyclic_buf(ybuf);
    }

    return ret;
}

static int start_poll_adc(struct ymavlink_buffer *ybuf)
{
    int ret = 0;
    if ( mcu_priv_data.st_poll_adc ) {
        del_sendtask( mcu_priv_data.st_poll_adc );
    }

    ret = write_command(ybuf, MCU_CMD_GET_ADC);
    if ( ret < 0 ) {
        return ret;
    }
    mcu_priv_data.st_poll_adc = add_sendtask(ybuf, ybuf->tx_buf, packet_len(ybuf->tx_buf), 200);
    return ret;
}

static int start_poll_batinfo(struct ymavlink_buffer *ybuf)
{
    int ret = 0;
    if ( mcu_priv_data.st_poll_batinfo) {
        del_sendtask( mcu_priv_data.st_poll_batinfo );
    }

    ret = write_command(ybuf, MCU_CMD_GET_BAT);
    if ( ret < 0){
        return ret;
    }
    mcu_priv_data.st_poll_batinfo = add_sendtask(ybuf, ybuf->tx_buf, packet_len(ybuf->tx_buf), 200); 
    return ret;
}

int init_mcu(int epfd, struct epoll_context *epctx)
{
    struct epoll_event ev;
    struct ymavlink_buffer *ybuf = malloc(sizeof(*ybuf));
    int fd;

    if((fd = open_mcu_tty("/dev/ttyS1")) < 0 || !epctx || !ybuf) {
        loge(LOG_RCDAEMON, TAG, "open uart failed!!!!\n");
        return -1;
    }

    epctx->callback = handle_mcu;
    epctx->data = &mcu_priv_data;
    ev.events = EPOLLIN;
    ev.data.ptr = epctx;

    if(epoll_ctl(epfd, EPOLL_CTL_ADD, fd, &ev) < 0) {
        loge(LOG_RCDAEMON, TAG, "epoll ctl failed for %s !!!\n", __func__);
        return -1;
    }
    memset(ybuf, 0, sizeof(*ybuf));
    ybuf->fd = fd; ybuf->fdtype = FD_TYPE_FILE;
    ymavlink_reset_buf(ybuf);
    mcu_priv_data.ybuf = ybuf;

    init_adc_table();
    load_calibrate_data();
    start_poll_adc(ybuf);
    start_poll_batinfo(ybuf);
    return 0;
}
