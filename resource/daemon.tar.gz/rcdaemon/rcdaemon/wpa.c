
#include <stdint.h>
#include <stddef.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/un.h>
#include <arpa/inet.h>
#include <sys/types.h>
#include <ctype.h>
#include <fcntl.h>
#include <sys/types.h>

#include <string.h>
#include <stdio.h>
#include <signal.h>
#include <errno.h>
#include "wpa.h"
#include "log.h"
#include "phone.h"
#include "local.h"
#include "rctimer.h"
#include "gpioctrl.h"

#define TAG "wpa"

#define WIFI_CACHE_SIZE (4096 * 2 - 1024)
struct wpa_context {
    int     fd,wfd,epfd;
    int     wstate;
    int     dhcp;
    char    wid[16];
    char    ssid[64];
    char    psk[128];
    struct  epoll_context *epctx;
    RcTimer *timer;
    char    buf[WIFI_CACHE_SIZE];
};

static struct wpa_context *wpactx;

static void response_all(int cmd, unsigned char *buf, int size)
{
    phone_response(cmd, buf, size);
    local_response(cmd, buf, size);
}

static inline int wsend_cmd(int fd, const char * cmd)
{
    return send(fd, cmd, strlen(cmd), 0);
}

static inline int wsend_internal(char *buf)
{
    int fd = wpactx->fd;

    if(fd < 0)
        return -1;
    else
        return wsend_cmd(fd, buf);
}

static int open_ictrl_internal(char *filename)
{
    int fd;
    struct sockaddr_un addr;
    struct sockaddr_un local;

    fd = socket(PF_UNIX, SOCK_DGRAM | SOCK_CLOEXEC, 0);
    if(fd < 0) {
        loge(LOG_RCDAEMON, TAG, "create local socket failed,errno:%d\n", errno);
        return -1;
    }

    local.sun_family = AF_UNIX;
    snprintf(local.sun_path, sizeof(local.sun_path),
            "/tmp/wpa_ctrl_%d-%d", getpid(), 1);
    unlink(local.sun_path);
    if(bind(fd, (const struct sockaddr *)&local, sizeof(local)) < 0) {
        loge(LOG_RCDAEMON, TAG, "bind local socket failed\n");
        close(fd);
        return -1;
    }

    addr.sun_family = AF_UNIX;
    strncpy(addr.sun_path, filename, sizeof(addr.sun_path));
    if(connect(fd, (const struct sockaddr *)&addr, sizeof(addr)) < 0) {
        close(fd);
        return -1;
    }
    fcntl(fd, F_SETFL, fcntl(fd, F_GETFL) | O_NONBLOCK);

    return fd;
}

int wpa_scan()
{
    if(wpactx->wstate == WSTATE_IDLE) {\
        wpactx->wstate = WSTATE_SCAN; \
        wsend_internal("SCAN"); \
    } else {\
        response_all(COMMAND_PAD_SCAN_WIFI, (unsigned char*)"FAILED", strlen("FAILED"));
    }
    return 0;
}

int wpa_get_status()
{
    //logi(LOG_RCDAEMON, TAG, "%s start,state:%d\n", __func__, wpactx->wstate);
    if(wpactx->wstate == WSTATE_IDLE) {\
        wpactx->wstate = WSTATE_GET_STATUS; \
        wsend_internal("STATUS"); \
    } else {\
        response_all(COMMAND_PAD_GET_WIFI_STATUS, (unsigned char*)"FAILED", strlen("FAILED"));
    }
    return 0;
}

int wpa_connect(char *essid, char *psk)
{
    if ( sizeof(wpactx->ssid) < strlen(essid) || sizeof(wpactx->psk) < strlen(psk) ) {
        response_all(COMMAND_PAD_CONNECT_WIFI, (unsigned char*)"FAILED", strlen("FAILED"));
        return -1;
    }

    strncpy(wpactx->ssid, essid, sizeof(wpactx->ssid));
    strncpy(wpactx->psk, psk, sizeof(wpactx->psk));
    wpactx->wstate = WSTATE_DISCONNECT; \
    wsend_internal("DISCONNECT"); \
    return 0;
}

#define UDHCPC_PID_FILE     "/var/run/dhcp.pid"

static int udhcpc_get_pid(void)
{
    int pid = -1;
    FILE *f = fopen(UDHCPC_PID_FILE, "r");

    if ( f == NULL ) {
        return -1;
    } else {
        if ( 1 != fscanf(f, "%d", &pid) ) {
            pid = -1;
        }
    }

    fclose(f);

    logi(LOG_RCDAEMON, TAG, "udhcp pid=%d\n", pid);
    return pid;
}

static int udhcpc_renew(void)
{
    wpactx->dhcp = udhcpc_get_pid();
    if (wpactx->dhcp < 0) {
        return -1;
    }

    if (kill(wpactx->dhcp, SIGUSR2) == -1) {
        return -1;
    }
    if (kill(wpactx->dhcp, SIGUSR1) == -1) {
        return -1;
    }

    return 0;
}
void wpa_deinit()
{
    epoll_ctl(wpactx->epfd, EPOLL_CTL_DEL, wpactx->fd, NULL);
    close(wpactx->fd);
    close(wpactx->wfd);
    wpactx->fd = wpactx->wfd = wpactx->dhcp = -1;
    wpactx->wstate = WSTATE_NONE;
    return;
}

static int handle_wpa(struct epoll_event *ev, struct epoll_context *epctx)
{
    unsigned char *buf = (unsigned char *)wpactx->buf;
    int           fd   = wpactx->fd, len, ret;

    if(ev->events & (EPOLLHUP | EPOLLERR)) {
        wpa_deinit();
        return 0;
    }

    ret = recv(fd, buf, WIFI_CACHE_SIZE, 0);
    if(ret <= 0) {
        if((errno != EAGAIN && errno != EINTR) || (ret == 0)) {
            return -1;
        }
        return 0;
    }

    len = ret;

    //logi(LOG_RCDAEMON, TAG, "wstate:%d\n",wpactx->wstate);
    switch(wpactx->wstate) {
        case WSTATE_IDLE:
            /* do nothing */
            break;
        case WSTATE_SCAN:
            if(len < 2 || strncmp((char*)buf, "OK", 2)) {
                loge(LOG_RCDAEMON, TAG, "wpa_supplicant scan failed. try again\n");
                wpactx->wstate = WSTATE_IDLE;
                response_all(COMMAND_PAD_SCAN_WIFI, (unsigned char*)"FAILED", strlen("FAILED"));
            } else {
                wpactx->wstate = WSTATE_GET_RESULTS;
                wsend_cmd(fd, "SCAN_RESULTS");
            }
            break;
        case WSTATE_GET_RESULTS:
            {
                int line;
                unsigned char *ptr = buf;

                response_all(COMMAND_PAD_SCAN_WIFI, (unsigned char*)"START", 5);
                line = get_line(ptr, len);
                len -= line;
                ptr += line;
                while(len > 0) {
                    line = get_line(ptr, len);
                    len -= line;
                    response_all(COMMAND_PAD_SCAN_WIFI, ptr, line);
                    ptr += line;
                }
                response_all(COMMAND_PAD_SCAN_WIFI, (unsigned char*)"END", 3);
                wpactx->wstate = WSTATE_IDLE;
            }
            break;
        case WSTATE_DISCONNECT:
            if(len < 2 || strncmp((char*)buf, "OK", 2)) {
                wpactx->wstate = WSTATE_IDLE;
                response_all(COMMAND_PAD_CONNECT_WIFI, (unsigned char*)"FAILED", strlen("FAILED"));
                loge(LOG_RCDAEMON, TAG, "wpa_supplicant disconnect failed. try again\n");
            } else {
                wpactx->wstate = WSTATE_ADDNET;
                wsend_cmd(fd, "ADD_NETWORK");
            }
            break;
        case WSTATE_ADDNET:
            {
                int i;
                char cmd[128];

                len--;
                wpactx->wid[len] = '\0';
                for(i = 0;i < len;i++) {
                    if(!isdigit(buf[i])) {
                        response_all(COMMAND_PAD_CONNECT_WIFI, (unsigned char*)"FAILED", strlen("FAILED"));
                        loge(LOG_RCDAEMON, TAG, "ADD_NETWORK command failed, return %s\n", buf);
                        wpactx->wstate = WSTATE_IDLE;
                        return 0;
                    }
                }
                memcpy(wpactx->wid, (char*)buf, len);
                logi(LOG_RCDAEMON, TAG, "wid:%s,len:%d\n", wpactx->wid,len);
                snprintf(cmd, sizeof(cmd), "SET_NETWORK %s ssid \"%s\"", wpactx->wid, wpactx->ssid);
                wpactx->wstate = WSTATE_SETSSID;
                wsend_cmd(fd, cmd);
            }
            break;
        case WSTATE_SETSSID:
            if(len < 2 || strncmp((char*)buf, "OK", 2)) {
                wpactx->wstate = WSTATE_IDLE;
                response_all(COMMAND_PAD_CONNECT_WIFI, (unsigned char*)"FAILED", strlen("FAILED"));
                loge(LOG_RCDAEMON, TAG, "wpa_supplicant set network ssid failed. try again\n");
            } else {
                char cmd[256];

                snprintf(cmd, sizeof(cmd), "SET_NETWORK %s psk \"%s\"", wpactx->wid, wpactx->psk);
                wpactx->wstate = WSTATE_SETPSK;
                wsend_cmd(fd, cmd);
            }
            break;
        case WSTATE_SETPSK:
            if(len < 2 || strncmp((char*)buf, "OK", 2)) {
                wpactx->wstate = WSTATE_IDLE;
                response_all(COMMAND_PAD_CONNECT_WIFI, (unsigned char*)"FAILED", strlen("FAILED"));
                loge(LOG_RCDAEMON, TAG, "wpa_supplicant set network psk failed. try again.");
            } else {
                char cmd[64];

                snprintf(cmd, sizeof(cmd), "SELECT_NETWORK %s", wpactx->wid);
                wpactx->wstate = WSTATE_SELECTNET;
                wsend_cmd(fd, cmd);
            }
            break;
        case WSTATE_SELECTNET:
            if(len < 2 || strncmp((char*)buf, "OK", 2)) {
                wpactx->wstate = WSTATE_IDLE;
                response_all(COMMAND_PAD_CONNECT_WIFI, (unsigned char*)"FAILED", strlen("FAILED"));
                loge(LOG_RCDAEMON, TAG, "wpa_supplicant select network. try again.\n");
            } else {
                char cmd[64];

                snprintf(cmd, sizeof(cmd), "ENABLE_NETWORK %s", wpactx->wid);
                wpactx->wstate = WSTATE_ENABLENET;
                wsend_cmd(fd, cmd);
            }
            break;
        case WSTATE_ENABLENET:
            if(len < 2 || strncmp((char*)buf, "OK", 2)) {
                wpactx->wstate = WSTATE_IDLE;
                response_all(COMMAND_PAD_CONNECT_WIFI, (unsigned char*)"FAILED", strlen("FAILED"));
                loge(LOG_RCDAEMON, TAG, "wpa_supplicant enable network failed. try again\n");
            } else {
                char cmd[512];
                static char wpa_conf[] = {"ap_scan=1\n\nnetwork={\n"
                    "	ssid=\"%s\"\n"
                        "	psk=\"%s\"\n" "}\n"};

                if(wpactx->wfd > 0) {
                    snprintf(cmd, sizeof(cmd), wpa_conf, wpactx->ssid, wpactx->psk);
                    len = strlen(cmd);
                    lseek(wpactx->wfd, SEEK_SET, 0);
                    write(wpactx->wfd, cmd, len);
                    ftruncate(wpactx->wfd, len);
                }
                response_all(COMMAND_PAD_CONNECT_WIFI, (unsigned char*)"OK", 2);
                wpactx->wstate = WSTATE_IDLE;

                if (udhcpc_renew() < 0) {
                    loge(LOG_RCDAEMON, TAG, "udhcpc renew failed!\n");
                }
            }
            break;
        case WSTATE_GET_STATUS:
            {
                int line, total = len;
                unsigned char *ptr = buf;

                ptr[len] = '\0';
                while(len > 0) {
                    line = get_line(ptr, len);
                    len -= line;
                    if(!strncmp((char*)ptr, "wpa_state=", strlen("wpa_state="))) {
                        if(strncmp((char*)ptr + strlen("wpa_state="), "COMPLETED", strlen("COMPLETED")))
                            response_all(COMMAND_PAD_GET_WIFI_STATUS, ptr, line);
                        else
                            response_all(COMMAND_PAD_GET_WIFI_STATUS, buf, total);
                        break;
                    }
                    ptr += line;
                }
                wpactx->wstate = WSTATE_IDLE;
            }
            break;
        default:
            break;
    }
    return 0;
}

static inline int open_ictrl(void) {
    return open_ictrl_internal("/var/run/wpa_supplicant/wlan0");
}

static int find_wpa_supplicant(RcTimer *timer)
{
    int fd;

    if((fd = open_ictrl()) >= 0) {
        struct epoll_event ev;
        struct epoll_context *epctx; 

        epctx       = wpactx->epctx;
        wpactx->fd  = fd;
        ev.events   = EPOLLIN;
        ev.data.ptr = epctx;

        if(epoll_ctl(wpactx->epfd, EPOLL_CTL_ADD, fd, &ev) < 0) {
            loge(LOG_RCDAEMON, TAG, "%s,epoll control add fd error.\n", __func__);
            return 0;
        }
        wpactx->wstate = WSTATE_IDLE;
        if((wpactx->wfd = open("/etc/wpa_supplicant.conf", O_RDWR | O_CREAT)) < 0)
            loge(LOG_RCDAEMON, TAG, "can not open /etc/wpa_supplicant.conf ! This should never happen\n");
        wpactx->dhcp = udhcpc_get_pid();
        stop_rctimer(wpactx->timer);
        logi(LOG_RCDAEMON, TAG, "%s success\n", __func__);
        gpio_set_state(WIFI_LED, 1);

        return 0;
    }

    if(timer)
        refresh_rctimer(timer, 100);

    return 0;
}

int wpa_init(int epfd, struct epoll_context *epctx)
{ 
    wpactx = malloc(sizeof(*wpactx));

    if(!wpactx || !epctx)
        return -ENOMEM;

    memset(wpactx, 0, sizeof(*wpactx));
    wpactx->epfd    = epfd;
    wpactx->fd      = -1;
    wpactx->epctx   = epctx;
    epctx->data     = wpactx;
    epctx->callback = handle_wpa;

    wpactx->timer   = add_rctimer(NULL, find_wpa_supplicant, 100);

    return 0;
}

