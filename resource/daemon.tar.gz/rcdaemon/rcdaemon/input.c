#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <dirent.h>
#include <unistd.h>
#include <sys/types.h>
#include <fcntl.h>
#include <linux/input.h>
#include "ymavlink.h"
#include "input.h"
#include "phone.h"
#include "local.h"
#include "channel.h"
#include "common.h"
#include "gpioctrl.h"
#include "pwmctrl.h"
#include "log.h"
#include <errno.h>

#define FOR_DEMO    1

#define TAG "input"

#define SW_NUMS 1

struct input_context {
    int fd;
    char g_device_name[8];
};

static struct input_context *input_ctx;

static InputItem g_item_table[] = {
    {.type = EV_SW, .code = SW_SWITCH, .value = 0},
    {.type = EV_KEY, .code = BTN_CAPTURE, .value = 0},
    {.type = EV_KEY, .code = BTN_FUNC, .value = 0},
    {.type = EV_KEY, .code = BTN_VIDEO, .value = 0},
    {.type = EV_KEY, .code = BTN_TAKEOFF, .value = 0},
    {.type = EV_KEY, .code = BTN_GOHOME, .value = 0},
    {.type = EV_REL, .code = REL_WHEEL, .value = 0},
};

static InputItem *event_to_item(struct input_event *event)
{
    int i = 0;
    if (event == NULL) {
        return NULL;
    }
    for (i = 0; i < sizeof(g_item_table) / sizeof(g_item_table[0]); i++) {
        if (g_item_table[i].type == event->type
            && g_item_table[i].code == event->code) {
            return g_item_table + i;
        }
    }

    return NULL;
}

static int send_input_event(InputItem *item)
{
    unsigned char param[4];
    param[0] = item->type;
    param[1] = (item->code >> 8) & 0x0FF;
    param[2] = item->code & 0x0FF;
    param[3] = item->value;

    phone_command(COMMAND_PAD_REPORT_INPUTEVENT, param, sizeof(param));
    local_command(COMMAND_PAD_REPORT_INPUTEVENT, param, sizeof(param));

    return 0;
}

static int button_long_press(RcTimer *timer)
{
    InputItem *item = (InputItem *)(timer->p);
    item->value = 2;
    send_input_event(item);
#if FOR_DEMO
    if ( item->code == BTN_GOHOME ) {
        channel_set_gohome(!channel_get_gohome());
    }
#endif
    del_rctimer(item->timer);
    item->timer = NULL;
    return 0;
}

static void on_switch_changed(InputItem *item)
{
    if ( item == NULL ) {
        return;
    }

    switch ( item->code ) {
        case SW_SWITCH:
            {
                logi(LOG_RCDAEMON, TAG, "item->value=%d", item->value);
                switch ( item->value ) {
                    case 0:
                        channel_set_smart_mode(0);
                        break;
                    case 1:
                        channel_set_smart_mode(1);
                        break;
                    case 2:
                        break;
                    default:
                        break;
                }
            }
            break;
        default:
            break;
    }
}

static int process_input_event(struct input_event *event)
{
    InputItem *item = event_to_item(event);
    if (item == NULL) {
        return -1;
    }
    switch (event->type) {
        case EV_SW:
            if (item->value != event->value) {
                item->value = event->value;
                memcpy(&item->tv, &event->time, sizeof(struct timeval));
                send_input_event(item);
                on_switch_changed(item);
            }
            break;
        case EV_KEY:
            if (item->value == 0 && event->value == 1) {
                item->value = 1;
                memcpy(&item->tv, &event->time, sizeof(struct timeval));
                item->timer = add_rctimer(item, button_long_press, 2000);
                send_input_event(item);
#if FOR_DEMO
                switch (item->code) {
                    case BTN_CAPTURE:
                        ch10_send_value(CH10_VAL_FOLLOW_ME_ON);
                        break;
                    case BTN_FUNC:
                        ch10_send_value(CH10_VAL_FOLLOW_ME_OFF);
                        gpio_set_state(4, 1);
                        break;
                    case BTN_VIDEO:
                        ch10_send_value(CH10_VAL_FOLLOW_ME_ON_AND_WATCH_ME);
                        pwm_set_state(PWM_INDEX_FAN, PWM_ON_TIME_INFINITE, 1000);
                        pwm_set_state(PWM_INDEX_BUZZER, PWM_ON_TIME_INFINITE, 3000);
                        break;
                    case BTN_TAKEOFF:
                        channel_set_extra_value(0, EXTRA_OVERRIDE, 0);
                        gpio_set_state(0, 1);
                        break;
                    case BTN_GOHOME:
                        break;
                    default:
                        break;
                }
#endif
            } else if (item->value > 0 && event->value == 0) {
                item->value = 0;
                memcpy(&item->tv, &event->time, sizeof(struct timeval));
                del_rctimer(item->timer);
                item->timer = NULL;
                send_input_event(item);
#if FOR_DEMO
                switch (item->code) {
                    case BTN_CAPTURE:
                        break;
                    case BTN_FUNC:
                        gpio_set_state(4, 0);
                        break;
                    case BTN_VIDEO:
                        pwm_set_state(PWM_INDEX_FAN, PWM_ON_TIME_STOP, 1000);
                        pwm_set_state(PWM_INDEX_BUZZER, PWM_ON_TIME_STOP, 3000);
                        break;
                    case BTN_TAKEOFF:
                        channel_set_extra_value(0, EXTRA_NOTHING, 0);
                        gpio_set_state(0, 0);
                        break;
                    case BTN_GOHOME:
                        break;
                    default:
                        break;
                }
#endif
            }
            break;
        case EV_REL:
            if (event->code == REL_WHEEL) {
                item->value = event->value;
                memcpy(&item->tv, &event->time, sizeof(struct timeval));
                send_input_event(item);
#if FOR_DEMO
                switch (item->value) {
                    case 1:
                        gpio_set_state(0, 1);
                        usleep(30000);
                        gpio_set_state(0, 0);
                        break;
                    case -1:
                        gpio_set_state(PWR_LED, 0);
                        usleep(30000);
                        gpio_set_state(PWR_LED, 1);
                        break;
                    default:
                        break;
                }
#endif
            }
            break;
        default:
            break;
    }
    return 0;
}

static int handle_input(struct epoll_event *ev, struct epoll_context *epctx)
{
    int ret = 0;
    struct input_event event;
    while (ret >= 0) {
        ret = read(input_ctx->fd, &event, sizeof(event));
        if ( ret < 0 ) {
            if ( errno != EAGAIN && errno != EINTR ) {
                return -1;
            }
            return 0;
        } else if(ret == 0) {
        /* fd is NON_BLOCK type. closed !*/
            return -1;
        }
        ret = process_input_event(&event);
    }

    return 0;
}

uint8_t get_switch_states()
{
    int size = 0;
    char buf[8];
    char path[80];

    sprintf(path, "%s/%s/%s", "/sys/class/input", input_ctx->g_device_name, "device/switch_state");
    int fd = open(path, O_RDONLY);
    if (fd < 0) {
        return -1;
    }

    size = read(fd, buf, sizeof(buf));
    if (size <= 0) {
        close(fd);
        return -1;
    }

    close(fd);
    return (uint8_t)atoi(buf);
}

static int find_input_device(const char *input_dir)
{
    int fd, found = 0;
    struct dirent *de;
    char name[80];
    char devname[64];

    DIR *dir = opendir(input_dir);
    if (dir == NULL) {
        return -1;
    }

    while((de = readdir(dir)) != 0) {
        if (strncmp(de->d_name, "event", strlen("event"))) {
            continue;
        }

        snprintf(devname, sizeof(devname), "%s/%s", input_dir, de->d_name);
        if ((fd = open(devname, O_RDONLY)) < 0) {
            continue;
        }

        if (ioctl(fd, EVIOCGNAME(sizeof(name) - 1), &name) < 1) {
            continue;
        }

        close(fd);

        if (!strcmp("st10c-gpiodev", name)) {
            strcpy(input_ctx->g_device_name, de->d_name);
            found = 1;
            break;
        }
    }
    closedir(dir);

    return found;
}

int open_input(int epfd, struct epoll_context *epctx)
{
    struct epoll_event ev;
    int i = 0, fd;
    uint8_t sw_states = 0;
    char path[80];

    input_ctx = malloc(sizeof(*input_ctx));

    if (find_input_device(INPUT_DIR) <= 0 || !epctx || !input_ctx) {
        return -1;
    }

    sw_states = get_switch_states();
    if (sw_states > 2) {
        logw(LOG_RCDAEMON, TAG, "get switch original states failed, use default state!\n");
    }

    for (i = 0; i < SW_NUMS; i++) {
        g_item_table[i].value = (sw_states >> (i * 2)) & 0x03;
        on_switch_changed(&g_item_table[i]);
    }

    sprintf(path, "%s/%s", INPUT_DIR, input_ctx->g_device_name);
    if(( fd = open(path, O_RDONLY)) < 0 ) {
        loge(LOG_RCDAEMON, TAG, "open %s failed! error:%s\n", path, strerror(errno));
        return -1;
    }
    fcntl(fd, F_SETFL, fcntl(fd, F_GETFL) | O_NONBLOCK);

    input_ctx->fd = fd;
    epctx->callback = handle_input;
    ev.events = EPOLLIN;
    ev.data.ptr = epctx;

    if(epoll_ctl(epfd, EPOLL_CTL_ADD, fd, &ev) < 0) {
        loge(LOG_RCDAEMON, TAG, "epoll ctl failed for %s\n", __func__);
        return -1;
    }

    return 0;
}

int close_input(int fd)
{
    close(fd);
    return 0;
}
