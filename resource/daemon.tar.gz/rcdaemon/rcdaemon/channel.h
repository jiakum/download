#ifndef __CHANNEL_H__
#define __CHANNEL_H__

#include "analog_input.h"

#define OWNER_ANUM                                  10
#define OWNER_ABITS                                 12
#define OWNER_SWNUM                                 2
#define OWNER_SWBITS                                2
#define OWNER_TRNUM                                 4
#define OWNER_TRBITS                                6
#define OWNER_EXTRANUM                              4
#define OWNER_EXTRABITS                             0

#define CURVE_RESOLUTION    16
#define DELTAX              (((float)(CH_MAX + 1))/CURVE_RESOLUTION)
#define MAX_POINTS_COUNT    (CURVE_RESOLUTION + 1)

typedef enum CHANNEL {
    CH_THR=0,
    CH_ALE,
    CH_ELE,
    CH_RUD,
    CH_5=4,
    CH_6,
    CH_7,
    CH_8,
    CH_9,
    CH_10,
    CH_11,
    CH_12
} CHANNEL_NAME;

enum CHANNEL_EXTRA_CONFIG {
    EXTRA_NOTHING = 0,
    EXTRA_OVERRIDE,
    EXTRA_ADD
};

#define CH10_VAL_GPS_OFF                    4
#define CH10_VAL_GPS_ON                     8
#define CH10_VAL_COMPASS_CALIBRATE          12
#define CH10_VAL_ACCELEROMETER_CALIBRATE    16
#define CH10_VAL_GIMBAL_CALIBRATE           24
#define CH10_VAL_FOLLOW_ME_OFF              28
#define CH10_VAL_FOLLOW_ME_ON               32
#define CH10_VAL_FOLLOW_ME_ON_AND_WATCH_ME  36
#define CH10_VAL_OBS_AVOID_ON               40
#define CH10_VAL_OBS_AVOID_OFF              44

int channel_init();
void channel_deinit();
int channel_set_extra_value(unsigned int index, int extra_type, int16_t val);
int fill_channel_data(unsigned char *buf, int size);
int ch10_send_value(int val);
void channel_set_gohome(int val);
int channel_get_gohome();
void channel_set_smart_mode(int val);
int channel_get_smart_mode();
int channel_get_map();
int channel_set_map(int index);
int channel_get_curve(int index, uint8_t *buf, int size);
int channel_set_curve(int index, uint8_t *buf, int size);

#endif /* __CHANNEL_H__ */
