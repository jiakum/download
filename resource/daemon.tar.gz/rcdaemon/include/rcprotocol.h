#ifndef __PROTOCOL_H__
#define __PROTOCOL_H__

#include <sys/types.h>

#define RF_SW_VERSION_LEN 27
#define RF_SW_VERSION_NUM_BIT 21
#define APP_SW_VERSION  "st15_rc_app_v00.00b01"

#define COMMAND_M3_SEND_PANID_ADDR_MSG_TO_M4        0x0C
#define COMMAND_M4_SEND_RAW_CHANNEL_TO_M3           0x30
#define COMMAND_M4_SEND_MIXED_CHANNEL_TO_M3         0x31
#define COMMAND_M4_SEND_TRIM_TO_M3                  0x32
#define COMMAND_M4_SEND_COMPRESS_TRIM_TO_M3         0x33
#define COMMAND_M4_GET_RF_SW_VERSION                0x34
#define COMMAND_M4_SET_SW_MAP_TO_M3                 0x35
#define COMMAND_M4_SET_SW_MAP_TO_M3_FINISH          0x36
#define COMMAND_M4_SET_RF_ENTER_RUN                 0x37
#define COMMAND_SEND_GPS_TO_M3                      0x38
#define COMMAND_SEND_COMPASS_TO_M4                  0x39
#define COMMAND_M4_BEGIN_UPDATE_RF_SW               0x3A
#define COMMAND_M4_SEND_UPDATE_RF_SW_DATA           0x3B
#define COMMAND_M4_FINISH_UPDATE_RF_SW              0x3C
#define COMMAND_M4_SET_RF_POWER                     0xF4
#define COMMAND_M4_GET_RF_POWER                     0xF5
#define COMMAND_M4_GET_M3_INIT_DATA                 0x50
#define COMMAND_M4_GET_RF_RSSI                      0xFF
#define COMMAND_PAD_GET_M4_INIT_DATA                0x64
#define COMMAND_PAD_ODDER_M4_SAVE_PARSE_FIGUER      0x65
#define COMMAND_PAD_ODDER_M4_ENTER_BIND             0x66
#define COMMAND_PAD_ODDER_M4_EXIT_BIND              0x67
#define COMMAND_PAD_ODDER_M4_ENTER_RUN              0x68
#define COMMAND_PAD_ODDER_M4_EXIT_RUN               0x69
#define COMMAND_PAD_ODDER_M4_START_CALIBRATESTICK   0x70
#define COMMAND_PAD_ODDER_M4_FINILISH_CALIBRATESTICK    0x71
#define COMMAND_PAD_ODDER_M4_ENTER_SIMULATOR        0x72
#define COMMAND_PAD_ODDER_M4_EXIT_SIMULATOR         0x73
#define COMMAND_PAD_ODDER_M4_DATA_TYPE_ONLY_RAW     0x74
#define COMMAND_PAD_ODDER_M4_DATA_TYPE_ONLY_MIXED   0x75
#define COMMAND_PAD_ODDER_M4_DATA_TYPE_RAW_AND_MIXED    0x76
#define COMMAND_M4_SEND_RAW_CHANNEL_TO_PAD          0x77
#define COMMAND_M4_SEND_MIXED_CHANNEL_TO_PAD        0x78
#define COMMAND_PAD_ADD_MIXED_DATA_TO_M4            0x79
#define COMMAND_PAD_UPDATE_MIXED_DATA_TO_M4         0x80
#define COMMAND_M4_SEND_TRIM_TO_PAD                 0x81
#define COMMAND_M4_SEND_COMPRESS_TRIM_TO_PAD        0x82
#define COMMAND_UPDATE_STATE                        0x83
#define COMMAND_PAD_SET_FMODE_HW                    0x84
#define COMMAND_PAD_DELETE_MIXED_DATA_TO_M4         0x85
#define COMMAND_PAD_CLEAR_BINDED                    0x86
#define COMMAND_PAD_GET_BIND_STATE                  0x87
#define COMMAND_M4_SEND_M3_BACK_CHANNEL_DATA        0x88
#define COMMAND_M4_SEND_PAD_CHANNGE_BUTTON          0x89
#define COMMAND_PAD_GET_HW_INPUT_VALUE              0x90
#define COMMAND_PAD_DONT_SEND_POWER_KEY             0x91
#define COMMAND_PAD_SET_VIRTUAL_SWITCH              0x92
#define COMMAND_PAD_GET_TRANSMITTER_MCU_SW_VERSION  0x93
#define COMMAND_PAD_GET_TRANSMITTER_RF_SW_VERSION   0x94
#define COMMAND_PAD_SET_MIXED_CHANNEL_MAP           0x95
#define COMMAND_PAD_CALIBRATION_OK                  0x96
#define COMMAND_PAD_SEND_GPS                        0x97
#define COMMAND_PAD_SEND_COMPASS                    0x98
#define COMMAND_PAD_ENTER_UPDATE_SOFTWARE           0x99
#define COMMAND_PAD_TRANSMIT_BIN_FILE               0x9A
#define COMMAND_PAD_EXIT_UPDATE_SOFTWARE            0x9B
#define COMMAND_PAD_SET_TRIM_STEP                   0x9D
#define COMMAND_PAD_GET_TRIM_STEP                   0x9E
#define COMMAND_PAD_ENTER_FACTORY_CALIBRATION       0x9F
#define COMMAND_PAD_EXIT_FACTORY_CALIBRATION        0xA0
#define COMMAND_PAD_SET_SUB_TRIM_POS                0xA1
#define COMMAND_PAD_GET_SUB_TRIM_POS                0xA2
#define COMMAND_PAD_CLEAR_ALL_MIXED_PARAMS          0xA3
#define COMMAND_PAD_BEGIN_UPDATE_RF_SW              0xA4
#define COMMAND_PAD_SEND_UPDATE_RF_SW_DATA          0xA5
#define COMMAND_PAD_FINISH_UPDATE_RF_SW             0xA6
#define COMMAND_PAD_HW_RAW_VALUE                    0xA7
#define COMMAND_PAD_SEND_DEBUG_MSG                  0xA8
#define COMMAND_PAD_GET_BOOT_SW_VER                 0xA9
#define COMMAND_PAD_UPDATE_FAILED                   0xAA
#define COMMAND_PAD_POWER_OFF                       0xAB
#define COMMAND_PAD_ENTER_RF_TEST                   0xAC
#define COMMAND_PAD_EXIT_RF_TEST                    0xAD
#define COMMAND_PAD_SET_RF_POWER                    0xAE
#define COMMAND_PAD_GET_RF_POWER                    0xAF
#define COMMAND_PAD_GET_RF_RSSI                     0xB1
#define COMMAND_PAD_GET_CAMERA_FOCUS                0xB2
#define COMMAND_PAD_GET_HW_DEF                      0xB3
#define COMMAND_PAD_SET_M3_SEND_TEST                0xB4
#define COMMAND_M4_SEND_TEST                        0x99
#define COMMAND_PAD_GET_GPS_USE                     0xB5
#define COMMAND_PAD_GET_GPS_DATA                    0xB6
#define COMMAND_PAD_SET_GPS_SAT                     0xB7
#define COMMAND_PAD_GET_GPS_SAT                     0xB8
#define COMMAND_PAD_SET_TORTOIES_VALUE              0xB9
#define COMMAND_PAD_GET_GPS_TIME                    0xB0
#define COMMAND_PAD_SET_PLAT_DATA                   0xBA
#define COMMAND_M4_SET_PLAT_DATA                    0x18
#define COMMAND_PAD_SET_TRIM_USE                    0xBB
#define COMMAND_PAD_ODDER_M4_ENTER_SETUP            0xBC
#define COMMAND_PAD_ODDER_M4_EXIT_TO_AWAIT          0xBD
#define COMMAND_PAD_SET_TRIM_STEP_ONEBYONE          0xBE
#define COMMAND_PAD_RESET_TRIM_POS                  0xBF
#define COMMAND_PAD_SET_CHANNEL_DATA                0xC0
#define COMMAND_PAD_SCAN_WIFI                       0xC1
#define COMMAND_PAD_CONNECT_WIFI                    0xC2
#define COMMAND_PAD_GET_WIFI_STATUS                 0xC3
#define COMMAND_PAD_REPORT_INPUTEVENT               0xC4
#define COMMAND_PAD_GET_SWITCH_STATES               0xC5
#define COMMAND_PAD_CHECK_RC_ALIVE                  0xC6
#define COMMAND_PAD_SET_CH_MAP                      0xC7
#define COMMAND_PAD_GET_CH_MAP                      0xC8
#define COMMAND_PAD_SET_CH_CURVE                    0xC9
#define COMMAND_PAD_GET_CH_CURVE                    0xCA

typedef struct __GPSDATA__ {
    int            lat;
    int            lon;
    float          alt;
    unsigned short accuracy;
    unsigned short speed; //over ground speed
    short          angle;
    unsigned char  no_satelites; // number of satelites
} __attribute__((packed)) GPSData;

#endif/*__PROTOCOL_H__*/
