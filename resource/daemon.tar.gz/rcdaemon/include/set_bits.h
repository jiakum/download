
#ifndef RCDAEMON_SET_BITS_H__
#define RCDAEMON_SET_BITS_H__

typedef struct SetBitContext {
    const uint8_t *buffer, *buffer_end;
    int index;
    int size_in_bits;
    int size_in_bits_plus8;
} SetBitContext;

#ifndef AV_RL32
#   define AV_RL32(x)                                \
	(((uint32_t)((const uint8_t*)(x))[3] << 24) |    \
				(((const uint8_t*)(x))[2] << 16) |    \
				(((const uint8_t*)(x))[1] <<  8) |    \
				((const uint8_t*)(x))[0])
#endif
#ifndef AV_RB32
#   define AV_RB32(x)                                \
	(((uint32_t)((const uint8_t*)(x))[0] << 24) |    \
				(((const uint8_t*)(x))[1] << 16) |    \
				(((const uint8_t*)(x))[2] <<  8) |    \
				((const uint8_t*)(x))[3])
#endif


static inline void skip_bits(SetBitContext *s, int bits)
{
	int index = s->index;

	index    += bits;
	s->index  = index;
}

static inline void set_bits(SetBitContext *s, int bits, uint32_t value)
{
	int       index = s->index;
	uint32_t  temp = 0xFFFFFFFF, org;
	int       offset;

	if(bits < 0 || bits > 24)
		return;

	offset = (32 - bits - (index & 0x07));
	temp <<= index & 0x07;
	temp >>= index & 0x07;
	temp >>= offset;
	temp <<= offset;
	temp   = ~temp;

	org    = AV_RB32(s->buffer + (index >> 3));
	org   &= temp;

	value <<= offset;
	org   |= value;
	org    = __bswap_32(org);

	*((uint32_t *)(s->buffer + (index >> 3))) = org;

	skip_bits(s, bits);
}
/**
 * Inititalize SetBitContext.
 * @param buffer bitstream buffer, must be FF_INPUT_BUFFER_PADDING_SIZE bytes larger than the actual read bits
 * because some optimized bitstream readers read 32 or 64 bit at once and could read over the end
 * @param bit_size the size of the buffer in bits
 */
static inline void init_set_bits(SetBitContext *s, const uint8_t *buffer,
                                 int bytes)
{
    int bits = bytes * 8;
    if (bits < 0) {
		return;
    }

    s->buffer       = buffer;
    s->size_in_bits = bits;
    s->size_in_bits_plus8 = bits + 8;
    s->buffer_end   = buffer + bytes;
    s->index        = 0;
}

#endif /* AVCODEC_GET_BITS_H */
