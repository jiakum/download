#ifndef _EPOLL_CONTEXT_H_
#define _EPOLL_CONTEXT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <sys/epoll.h>

struct epoll_context {
    int (*callback)(struct epoll_event *event, struct epoll_context *epctx);
    void *data;
};

#ifdef __cplusplus
}
#endif

#endif // _EPOLL_CONTEXT_H_

