#ifndef __COMMON_H__
#define __COMMON_H__

#ifdef __cplusplus
extern "C" {
#endif

/// common header
#include "list.h"
#include "log.h"

#define ALIGN32(a)               (((uint32_t)(a) + 0x03) & (~0x03))
#define BITS_TO_BYTES(x)         (x)/8 + ((x)%8?1:0)

#define FD_TYPE_FILE    0
#define FD_TYPE_SOCK    1

#define ARRAY_SIZE(x) (sizeof(x)/sizeof(x[0]))

#ifdef __cplusplus
}
#endif

#endif  /// __COMMON_H__
