#ifndef __LOG_H__
#define __LOG_H__

#ifdef __cplusplus
extern "C" {
#endif

#include <syslog.h>

#define LOG_RCDAEMON    LOG_LOCAL0
#define LOG_COMMAND     LOG_LOCAL1
#define LOG_CHANNEL     LOG_LOCAL2
#define LOG_MPLAYER     LOG_LOCAL3
#define LOG_EXCEPTION   LOG_LOCAL4      /// all exception log here

#define CURRENT_LOGLEVEL         LOG_DEBUG

#define loge(facility, tag, format, ...) \
        do { \
            if (CURRENT_LOGLEVEL >= LOG_ERR) { \
                openlog(tag, LOG_ODELAY, facility); \
                syslog(LOG_ERR, "%s:%d " format, __func__, __LINE__, ##__VA_ARGS__); \
            } \
        } while (0)

#define logw(facility, tag, format, ...) \
        do { \
            if (CURRENT_LOGLEVEL >= LOG_WARNING) { \
                openlog(tag, LOG_ODELAY, facility); \
                syslog(LOG_WARNING, "%s:%d " format, __func__, __LINE__, ##__VA_ARGS__); \
            } \
        } while (0)

#define logi(facility, tag, format, ...) \
        do { \
            if (CURRENT_LOGLEVEL >= LOG_INFO) { \
                openlog(tag, LOG_ODELAY, facility); \
                syslog(LOG_INFO, format, ##__VA_ARGS__); \
            } \
        } while (0)

#define logd(facility, tag, format, ...) \
        do { \
            if (CURRENT_LOGLEVEL >= LOG_DEBUG) { \
            openlog(tag, LOG_ODELAY, facility); \
            syslog(LOG_DEBUG, "%s:%d " format, __func__, __LINE__, ##__VA_ARGS__); \
            } \
        } while (0)

#define WARN_ONCE(facility, tag, format...) ({          \
    static int __warned;     \
    if (!__warned) {             \
        logw(facility, tag, format);            \
        __warned = 1;            \
    } \
})

#ifdef __cplusplus
}
#endif

#endif /* __LOG_H__ */
