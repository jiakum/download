#include <linux/module.h>
#include <linux/init.h>
#include <linux/poll.h>
#include <linux/delay.h>
#include <linux/wait.h>
#include <linux/err.h>
#include <linux/interrupt.h>
#include <linux/sched.h>
#include <linux/types.h>
#include <linux/device.h>
#include <linux/miscdevice.h>

#define MFI_BULK_BUFFER_SIZE           4096

#define TX_REQ_MAX 4

/* String IDs */
#define IAP2_STRING_INDEX   0
#define EA_STRING_INDEX     1

struct protocol_device {
    struct miscdevice mdev;

    struct usb_ep *ep_in;
    struct usb_ep *ep_out;

    int online;
    int error;

    spinlock_t lock;

    atomic_t read_excl;
    atomic_t write_excl;
    atomic_t open_excl;

    struct list_head tx_idle;

    wait_queue_head_t read_wq;
    wait_queue_head_t write_wq;
    struct usb_request *rx_req;
    int rx_done;
};

struct mfi_device {
    struct usb_function function;
    struct usb_composite_dev *cdev;

    struct protocol_device *iap2_dev;

    struct protocol_device *ea_dev;
} *_mfi_dev;

static struct usb_interface_descriptor iap2_interface_desc = {
    .bLength                = USB_DT_INTERFACE_SIZE,
    .bDescriptorType        = USB_DT_INTERFACE,
    .bInterfaceNumber       = 0,
    .bNumEndpoints          = 2,
    .bInterfaceClass        = 0xFF,
    .bInterfaceSubClass     = 0xF0,
    .bInterfaceProtocol     = 0x00,
};

static struct usb_endpoint_descriptor iap2_highspeed_in_desc = {
    .bLength                = USB_DT_ENDPOINT_SIZE,
    .bDescriptorType        = USB_DT_ENDPOINT,
    .bEndpointAddress       = USB_DIR_IN,
    .bmAttributes           = USB_ENDPOINT_XFER_BULK,
    .wMaxPacketSize         = __constant_cpu_to_le16(512),
};

static struct usb_endpoint_descriptor iap2_highspeed_out_desc = {
    .bLength                = USB_DT_ENDPOINT_SIZE,
    .bDescriptorType        = USB_DT_ENDPOINT,
    .bEndpointAddress       = USB_DIR_OUT,
    .bmAttributes           = USB_ENDPOINT_XFER_BULK,
    .wMaxPacketSize         = __constant_cpu_to_le16(512),
};

static struct usb_endpoint_descriptor iap2_fullspeed_in_desc = {
    .bLength                = USB_DT_ENDPOINT_SIZE,
    .bDescriptorType        = USB_DT_ENDPOINT,
    .bEndpointAddress       = USB_DIR_IN,
    .bmAttributes           = USB_ENDPOINT_XFER_BULK,
};

static struct usb_endpoint_descriptor iap2_fullspeed_out_desc = {
    .bLength                = USB_DT_ENDPOINT_SIZE,
    .bDescriptorType        = USB_DT_ENDPOINT,
    .bEndpointAddress       = USB_DIR_OUT,
    .bmAttributes           = USB_ENDPOINT_XFER_BULK,
};


static struct usb_interface_descriptor ea_interface_alt0 = {
    .bLength                = USB_DT_INTERFACE_SIZE,
    .bDescriptorType        = USB_DT_INTERFACE,
    .bInterfaceNumber       = 1,
    .bAlternateSetting      = 0,
    .bNumEndpoints          = 0,
    .bInterfaceClass        = 0xFF,
    .bInterfaceSubClass     = 0xF0,
    .bInterfaceProtocol     = 0x01,
};

static struct usb_interface_descriptor ea_interface_alt1 = {
    .bLength                = USB_DT_INTERFACE_SIZE,
    .bDescriptorType        = USB_DT_INTERFACE,
    .bInterfaceNumber       = 1,
    .bAlternateSetting      = 1,
    .bNumEndpoints          = 2,
    .bInterfaceClass        = 0xFF,
    .bInterfaceSubClass     = 0xF0,
    .bInterfaceProtocol     = 0x01,
};

static struct usb_endpoint_descriptor ea_highspeed_in_desc = {
    .bLength                = USB_DT_ENDPOINT_SIZE,
    .bDescriptorType        = USB_DT_ENDPOINT,
    .bEndpointAddress       = USB_DIR_IN,
    .bmAttributes           = USB_ENDPOINT_XFER_BULK,
    .wMaxPacketSize         = __constant_cpu_to_le16(512),
};

static struct usb_endpoint_descriptor ea_highspeed_out_desc = {
    .bLength                = USB_DT_ENDPOINT_SIZE,
    .bDescriptorType        = USB_DT_ENDPOINT,
    .bEndpointAddress       = USB_DIR_OUT,
    .bmAttributes           = USB_ENDPOINT_XFER_BULK,
    .wMaxPacketSize         = __constant_cpu_to_le16(512),
};

static struct usb_endpoint_descriptor ea_fullspeed_in_desc = {
    .bLength                = USB_DT_ENDPOINT_SIZE,
    .bDescriptorType        = USB_DT_ENDPOINT,
    .bEndpointAddress       = USB_DIR_IN,
    .bmAttributes           = USB_ENDPOINT_XFER_BULK,
};

static struct usb_endpoint_descriptor ea_fullspeed_out_desc = {
    .bLength                = USB_DT_ENDPOINT_SIZE,
    .bDescriptorType        = USB_DT_ENDPOINT,
    .bEndpointAddress       = USB_DIR_OUT,
    .bmAttributes           = USB_ENDPOINT_XFER_BULK,
};



static struct usb_descriptor_header *mfi_hs_descs[] = {
    (struct usb_descriptor_header *) &iap2_interface_desc,
    (struct usb_descriptor_header *) &iap2_highspeed_in_desc,
    (struct usb_descriptor_header *) &iap2_highspeed_out_desc,
    (struct usb_descriptor_header *) &ea_interface_alt0,
    (struct usb_descriptor_header *) &ea_interface_alt1,
    (struct usb_descriptor_header *) &ea_highspeed_in_desc,
    (struct usb_descriptor_header *) &ea_highspeed_out_desc,
    NULL,
};

static struct usb_descriptor_header *mfi_fs_descs[] = {
    (struct usb_descriptor_header *) &iap2_interface_desc,
    (struct usb_descriptor_header *) &iap2_fullspeed_in_desc,
    (struct usb_descriptor_header *) &iap2_fullspeed_out_desc,
    (struct usb_descriptor_header *) &ea_interface_alt0,
    (struct usb_descriptor_header *) &ea_interface_alt1,
    (struct usb_descriptor_header *) &ea_fullspeed_in_desc,
    (struct usb_descriptor_header *) &ea_fullspeed_out_desc,
    NULL,
};

static struct usb_string mfi_string_defs[] = {                                                                                                                  
    [IAP2_STRING_INDEX].s  = "iAP Interface",
    [EA_STRING_INDEX].s = "com.yuneec.video",
    {  },
};

static struct usb_gadget_strings mfi_string_table = {
    .language       = 0x0409,   /* en-US */
    .strings        = mfi_string_defs,
};

static struct usb_gadget_strings *mfi_strings[] = {                                                                                                             
    &mfi_string_table,
    NULL,
};

static inline struct mfi_device *func_to_mfi(struct usb_function *f)
{
    return container_of(f, struct mfi_device, function);
}

static inline int mfi_lock(atomic_t *excl)
{
    if (atomic_inc_return(excl) == 1) {
        return 0;
    } else {
        atomic_dec(excl);
        return -1;
    }
}

static inline void mfi_unlock(atomic_t *excl)
{
    atomic_dec(excl);
}

static struct usb_request *mfi_new_usb_request(struct usb_ep *ep, int buffer_size)
{
    struct usb_request *req = usb_ep_alloc_request(ep, GFP_KERNEL);
    if (!req)
        return NULL;

    /* now allocate buffers for the requests */
    req->buf = kmalloc(buffer_size, GFP_KERNEL);
    if (!req->buf) {
        usb_ep_free_request(ep, req);
        return NULL;
    }

    return req;
}

static void mfi_free_usb_request(struct usb_request *req, struct usb_ep *ep)
{
    if (req) {
        kfree(req->buf);
        usb_ep_free_request(ep, req);
    }
}

/* add a request to the tail of a list */
void mfi_put_usb_request(struct protocol_device *dev, struct list_head *head, struct usb_request *req)
{
    unsigned long flags;

    spin_lock_irqsave(&dev->lock, flags);
    list_add_tail(&req->list, head);
    spin_unlock_irqrestore(&dev->lock, flags);
}

/* remove a request from the head of a list */
struct usb_request *mfi_get_usb_request(struct protocol_device *dev, struct list_head *head)
{
    unsigned long flags;
    struct usb_request *req;

    spin_lock_irqsave(&dev->lock, flags);
    if (list_empty(head)) {
        req = 0;
    } else {
        req = list_first_entry(head, struct usb_request, list);
        list_del(&req->list);
    }
    spin_unlock_irqrestore(&dev->lock, flags);
    return req;
}

static void mfi_complete_in(struct usb_ep *ep, struct usb_request *req)
{
    struct protocol_device *pdev = NULL;
    
    if (_mfi_dev->iap2_dev->ep_in == ep)
        pdev = _mfi_dev->iap2_dev;
    else if (_mfi_dev->ea_dev->ep_in == ep)
        pdev = _mfi_dev->ea_dev;
    else
        return;

    if (req->status != 0)
        pdev->error = 1;

    mfi_put_usb_request(pdev, &pdev->tx_idle, req);

    printk("%s, %d, status = %d\n", __func__, __LINE__, req->status);
    wake_up(&pdev->write_wq);
}

static void mfi_complete_out(struct usb_ep *ep, struct usb_request *req)
{
    struct protocol_device *pdev = NULL;
    if (_mfi_dev->iap2_dev->ep_out == ep)
        pdev = _mfi_dev->iap2_dev;
    else if (_mfi_dev->ea_dev->ep_out == ep)
        pdev = _mfi_dev->ea_dev;
    else
        return;

    pdev->rx_done = 1;
    if (req->status != 0 && req->status != -ECONNRESET)
        pdev->error = 1;
    printk("%s, %d, status = %d\n", __func__, __LINE__, req->status);
    wake_up(&pdev->read_wq);
}

static int mfi_create_bulk_endpoints(struct protocol_device *dev, struct usb_endpoint_descriptor *in_desc, struct usb_endpoint_descriptor *out_desc)
{
    struct usb_composite_dev *cdev = _mfi_dev->cdev;
    struct usb_request *req;
    struct usb_ep *ep;
    int i;

    printk("create_bulk_endpoints dev: %p\n", dev);

    ep = usb_ep_autoconfig(cdev->gadget, in_desc);
    if (!ep) {
        printk("usb_ep_autoconfig for ep_in failed\n");
        return -ENODEV;
    }
    printk("usb_ep_autoconfig for ep_in got %s\n", ep->name);
    ep->driver_data = dev;		/* claim the endpoint */
    dev->ep_in = ep;

    ep = usb_ep_autoconfig(cdev->gadget, out_desc);
    if (!ep) {
        printk("usb_ep_autoconfig for ep_out failed\n");
        return -ENODEV;
    }
    printk("usb_ep_autoconfig for mfi ep_out got %s\n", ep->name);
    ep->driver_data = dev;		/* claim the endpoint */
    dev->ep_out = ep;

    /* now allocate requests for our endpoints */
    req = mfi_new_usb_request(dev->ep_out, MFI_BULK_BUFFER_SIZE);
    if (!req)
        goto fail;
    req->complete = mfi_complete_out;
    dev->rx_req = req;

    for (i = 0; i < TX_REQ_MAX; i++) {
        req = mfi_new_usb_request(dev->ep_in, MFI_BULK_BUFFER_SIZE);
        if (!req)
            goto fail;
        req->complete = mfi_complete_in;
        mfi_put_usb_request(dev, &dev->tx_idle, req);
    }

    return 0;

fail:
    printk(KERN_ERR "mfi_bind() could not allocate requests\n");
    return -1;
}

static ssize_t mfi_read(struct file *fp, char __user *buf, size_t count, loff_t *pos)
{
    struct protocol_device *pdev = (struct protocol_device *)fp->private_data;
    struct usb_request *req;
    int r = count, xfer;
    int ret;

    printk("mfi_read(%d), device = %s\n", count, pdev->mdev.name);
    if (!pdev)
        return -ENODEV;

    if (count > MFI_BULK_BUFFER_SIZE)
        return -EINVAL;

    if (mfi_lock(&pdev->read_excl))
        return -EBUSY;

    /* we will block until we're online */
    while (!(pdev->online || pdev->error)) {
        printk("mfi_read: waiting for online state\n");
        ret = wait_event_interruptible(pdev->read_wq, (pdev->online || pdev->error));
        if (ret < 0) {
            mfi_unlock(&pdev->read_excl);
            return ret;
        }
    }
    if (pdev->error) {
        r = -EIO;
        goto done;
    }

requeue_req:
    /* queue a request */
    req = pdev->rx_req;
    req->length = count;
    pdev->rx_done = 0;
    ret = usb_ep_queue(pdev->ep_out, req, GFP_ATOMIC);
    if (ret < 0) {
        printk("mfi_read: failed to queue req %p (%d)\n", req, ret);
        r = -EIO;
        pdev->error = 1;
        goto done;
    } else {
        printk("rx %p queue\n", req);
    }

    /* wait for a request to complete */
    ret = wait_event_interruptible(pdev->read_wq, pdev->rx_done);
    if (ret < 0) {
        if (ret != -ERESTARTSYS)
            pdev->error = 1;
        r = ret;
        usb_ep_dequeue(pdev->ep_out, req);
        goto done;
    }
    if (!pdev->error) {
        /* If we got a 0-len packet, throw it back and try again. */
        if (req->actual == 0)
            goto requeue_req;

        printk("rx %p %d\n", req, req->actual);
        xfer = req->actual;
        if (copy_to_user(buf, req->buf, xfer))
            r = -EFAULT;
        else
            r = xfer;

    } else
        r = -EIO;

done:
    mfi_unlock(&pdev->read_excl);
    printk("mfi_read returning %d\n", r);
    return r;
}

static ssize_t mfi_write(struct file *fp, const char __user *buf, size_t count, loff_t *pos)
{
    struct protocol_device *pdev = (struct protocol_device *)fp->private_data;
    struct usb_request *req = 0;
    int r = count, xfer;
    int ret;

    if (!pdev)
        return -ENODEV;

    if (mfi_lock(&pdev->write_excl))
        return -EBUSY;

    while (count > 0) {
        if (pdev->error) {
            printk("mfi_write dev->error\n");
            r = -EIO;
            break;
        }

        /* get an idle tx request to use */
        req = 0;
        ret = wait_event_interruptible(pdev->write_wq, (req = mfi_get_usb_request(pdev, &pdev->tx_idle)) || pdev->error);

        if (ret < 0) {
            r = ret;
            break;
        }

        if (req != 0) {
            if (count > MFI_BULK_BUFFER_SIZE)
                xfer = MFI_BULK_BUFFER_SIZE;
            else
                xfer = count;
            if (copy_from_user(req->buf, buf, xfer)) {
                r = -EFAULT;
                break;
            }

            req->length = xfer;
            ret = usb_ep_queue(pdev->ep_in, req, GFP_ATOMIC);
            if (ret < 0) {
                printk("mfi_write: xfer error %d\n", ret);
                pdev->error = 1;
                r = -EIO;
                break;
            }

            buf += xfer;
            count -= xfer;

            /* zero this so we don't try to free it on error exit */
            req = 0;
        }
    }

    if (req)
        mfi_put_usb_request(pdev, &pdev->tx_idle, req);

    mfi_unlock(&pdev->write_excl);
    printk("mfi_write returning %d\n", r);
    return r;
}

static int mfi_open(struct inode *ip, struct file *fp)
{
    struct protocol_device *pdev = NULL;

    if (!_mfi_dev)
        return -ENODEV;

    printk("inode.minor = %d, iap2_dev->mdev.minor = %d, ea_dev->mdev.minor = %d\n", MINOR(ip->i_rdev), _mfi_dev->iap2_dev->mdev.minor, _mfi_dev->ea_dev->mdev.minor);

    if (MINOR(ip->i_rdev) == _mfi_dev->iap2_dev->mdev.minor)
        pdev = _mfi_dev->iap2_dev;
    else if (MINOR(ip->i_rdev) == _mfi_dev->ea_dev->mdev.minor)
        pdev = _mfi_dev->ea_dev;
    else 
        return -ENODEV;

    if (mfi_lock(&pdev->open_excl))
        return -EBUSY;

    fp->private_data = pdev;

    /* clear the error latch */
    pdev->error = 0;

    return 0;
}

static int mfi_release(struct inode *ip, struct file *fp)
{
    struct protocol_device *pdev = (struct protocol_device *)fp->private_data;
    mfi_unlock(&pdev->open_excl);
    return 0;
}

static const struct file_operations mfi_fops = {
    .owner = THIS_MODULE,
    .read = mfi_read,
    .write = mfi_write,
    .open = mfi_open,
    .release = mfi_release,
};

static int mfi_function_bind(struct usb_configuration *c, struct usb_function *f)
{
    struct usb_composite_dev *cdev = c->cdev;
    struct mfi_device	*dev = func_to_mfi(f);
    int			id;
    int			ret;

    dev->cdev = cdev;
    printk("%s, %d enter\n", __func__, __LINE__);

    /* allocate interface ID(s) */
    id = usb_interface_id(c, f);
    if (id < 0)
        return id;
    iap2_interface_desc.bInterfaceNumber = id;

    /* allocate endpoints */
    ret = mfi_create_bulk_endpoints(dev->iap2_dev, &iap2_fullspeed_in_desc, &iap2_fullspeed_out_desc);
    if (ret)
        return ret;

    id = usb_interface_id(c, f);
    if (id < 0)
        return id;
    ea_interface_alt0.bInterfaceNumber = id;
    ea_interface_alt1.bInterfaceNumber = id;

    ret = mfi_create_bulk_endpoints(dev->ea_dev, &ea_fullspeed_in_desc, &ea_fullspeed_out_desc);
    if (ret)
        return ret;

    /* support high speed hardware */
    if (gadget_is_dualspeed(c->cdev->gadget)) {
        iap2_highspeed_in_desc.bEndpointAddress = iap2_fullspeed_in_desc.bEndpointAddress;
        iap2_highspeed_out_desc.bEndpointAddress = iap2_fullspeed_out_desc.bEndpointAddress;
        ea_highspeed_in_desc.bEndpointAddress = ea_fullspeed_in_desc.bEndpointAddress;
        ea_highspeed_out_desc.bEndpointAddress = ea_fullspeed_out_desc.bEndpointAddress;
    }

    return 0;
}

static void mfi_function_unbind(struct usb_configuration *c, struct usb_function *f)
{
    struct usb_request *req;
    struct protocol_device *iap2_dev = _mfi_dev->iap2_dev;
    struct protocol_device *ea_dev = _mfi_dev->ea_dev;

    printk("%s, %d enter\n", __func__, __LINE__);
    if (iap2_dev->online) {
        iap2_dev->online = 0;
        iap2_dev->error = 1;

        wake_up(&iap2_dev->read_wq);

        mfi_free_usb_request(iap2_dev->rx_req, iap2_dev->ep_out);
        while ((req = mfi_get_usb_request(iap2_dev, &iap2_dev->tx_idle)))
            mfi_free_usb_request(req, iap2_dev->ep_in);
    }

    if (ea_dev->online) {
        ea_dev->online = 0;
        ea_dev->error = 1;

        wake_up(&ea_dev->read_wq);

        mfi_free_usb_request(ea_dev->rx_req, ea_dev->ep_out);
        while ((req = mfi_get_usb_request(ea_dev, &ea_dev->tx_idle)))
            mfi_free_usb_request(req, ea_dev->ep_in);
    }
    printk("%s, %d exit\n", __func__, __LINE__);
}

static int mfi_function_set_alt(struct usb_function *f, unsigned intf, unsigned alt)
{
    struct protocol_device *pdev = NULL, *ea_dev;
    struct usb_composite_dev *cdev = f->config->cdev;
    int ret;

    printk("mfi_function_set_alt intf: %d alt: %d\n", intf, alt);

    if (intf == iap2_interface_desc.bInterfaceNumber) {
        pdev = _mfi_dev->iap2_dev;
    } else if (intf == ea_interface_alt1.bInterfaceNumber && alt == 1) {
        pdev = _mfi_dev->ea_dev;
    } else if (intf == ea_interface_alt1.bInterfaceNumber && alt == 0) {
        ea_dev = _mfi_dev->ea_dev;
        if (ea_dev->online) {
            ea_dev->online = 0;
            ea_dev->error = 1;
            usb_ep_disable(ea_dev->ep_in);
            usb_ep_disable(ea_dev->ep_out);
            wake_up(&ea_dev->read_wq);
        }
    }

    if (pdev) {
        ret = config_ep_by_speed(cdev->gadget, f, pdev->ep_in);
        if (ret)
            return ret;

        ret = usb_ep_enable(pdev->ep_in);
        if (ret)
            return ret;

        ret = config_ep_by_speed(cdev->gadget, f, pdev->ep_out);
        if (ret)
            return ret;

        ret = usb_ep_enable(pdev->ep_out);
        if (ret) {
            usb_ep_disable(pdev->ep_in);
            return ret;
        }
        pdev->online = 1;

        /* readers may be blocked waiting for us to go online */
        wake_up(&pdev->read_wq);
    }
    printk("%s, %d exit\n", __func__, __LINE__);
    return 0;
}

static void mfi_function_disable(struct usb_function *f)
{
    struct protocol_device *iap2_dev = _mfi_dev->iap2_dev;
    struct protocol_device *ea_dev = _mfi_dev->ea_dev;

    printk("%s, %d enter\n", __func__, __LINE__);

    if (iap2_dev->online) {
        iap2_dev->online = 0;
        iap2_dev->error = 1;
        usb_ep_disable(iap2_dev->ep_in);
        usb_ep_disable(iap2_dev->ep_out);
        wake_up(&iap2_dev->read_wq);
    }

    if (ea_dev->online) {
        ea_dev->online = 0;
        ea_dev->error = 1;
        usb_ep_disable(ea_dev->ep_in);
        usb_ep_disable(ea_dev->ep_out);
        wake_up(&ea_dev->read_wq);
    }

    printk("%s, %d exit\n", __func__, __LINE__);
}

static int mfi_bind_config(struct usb_configuration *c)
{
    int ret = 0;
    struct mfi_device *dev = _mfi_dev;

    printk("%s, %d enter\n", __func__, __LINE__);

    if (mfi_string_defs[IAP2_STRING_INDEX].id == 0) {
        ret = usb_string_id(c->cdev);
        if (ret < 0)
            return ret;
        mfi_string_defs[IAP2_STRING_INDEX].id = ret;
        iap2_interface_desc.iInterface = ret;
    }

    if (mfi_string_defs[EA_STRING_INDEX].id == 0) {
        ret = usb_string_id(c->cdev);
        if (ret < 0)
            return ret;
        mfi_string_defs[EA_STRING_INDEX].id = ret;
        ea_interface_alt0.iInterface = ret;
        ea_interface_alt1.iInterface = ret;
    }

    dev->cdev = c->cdev;
    dev->function.name = "mfi";
    dev->function.strings = mfi_strings;
    dev->function.descriptors = mfi_fs_descs;
    dev->function.hs_descriptors = mfi_hs_descs;
    dev->function.bind = mfi_function_bind;
    dev->function.unbind = mfi_function_unbind;
    dev->function.set_alt = mfi_function_set_alt;
    dev->function.disable = mfi_function_disable;

    return usb_add_function(c, &dev->function);
}

static int mfi_setup(void)
{
    int ret;

    printk("%s, %d enter\n", __func__, __LINE__);
    _mfi_dev = kzalloc(sizeof(*_mfi_dev), GFP_KERNEL);
    if (!_mfi_dev) {
        ret = -ENOMEM;
        goto fail1;
    }

    _mfi_dev->iap2_dev = kzalloc(sizeof(struct protocol_device), GFP_KERNEL);
    if (!_mfi_dev->iap2_dev) {
        ret = -ENOMEM;
        goto fail2;
    }

    _mfi_dev->iap2_dev->mdev.minor = MISC_DYNAMIC_MINOR;
    _mfi_dev->iap2_dev->mdev.name = "iap2_mdev";
    _mfi_dev->iap2_dev->mdev.fops = &mfi_fops;
    ret = misc_register(&_mfi_dev->iap2_dev->mdev);
    if (ret) {
        ret = -ENODEV;
        goto fail3;
    }

    spin_lock_init(&_mfi_dev->iap2_dev->lock);

    init_waitqueue_head(&_mfi_dev->iap2_dev->read_wq);
    init_waitqueue_head(&_mfi_dev->iap2_dev->write_wq);

    atomic_set(&_mfi_dev->iap2_dev->open_excl, 0);
    atomic_set(&_mfi_dev->iap2_dev->read_excl, 0);
    atomic_set(&_mfi_dev->iap2_dev->write_excl, 0);

    INIT_LIST_HEAD(&_mfi_dev->iap2_dev->tx_idle);


    _mfi_dev->ea_dev = kzalloc(sizeof(struct protocol_device), GFP_KERNEL);
    if (!_mfi_dev->ea_dev) {
        ret = -ENOMEM;
        goto fail4;
    }

    _mfi_dev->ea_dev->mdev.minor = MISC_DYNAMIC_MINOR;
    _mfi_dev->ea_dev->mdev.name = "ea_mdev";
    _mfi_dev->ea_dev->mdev.fops = &mfi_fops;
    ret = misc_register(&_mfi_dev->ea_dev->mdev);
    if (ret) {
        ret = -ENODEV;
        goto fail5;
    }

    spin_lock_init(&_mfi_dev->ea_dev->lock);

    init_waitqueue_head(&_mfi_dev->ea_dev->read_wq);
    init_waitqueue_head(&_mfi_dev->ea_dev->write_wq);

    atomic_set(&_mfi_dev->ea_dev->open_excl, 0);
    atomic_set(&_mfi_dev->ea_dev->read_excl, 0);
    atomic_set(&_mfi_dev->ea_dev->write_excl, 0);

    INIT_LIST_HEAD(&_mfi_dev->ea_dev->tx_idle);

    printk("%s, %d exit\n", __func__, __LINE__);
    return 0;

fail5:
    kfree(_mfi_dev->ea_dev);
fail4:
    misc_deregister(&_mfi_dev->iap2_dev->mdev);
fail3:
    kfree(_mfi_dev->iap2_dev);
fail2:
    kfree(_mfi_dev);
fail1:
    printk(KERN_ERR "mfi gadget driver failed to initialize\n");
    return ret;
}

static void mfi_cleanup(void)
{
    printk("%s, %d enter\n", __func__, __LINE__);
    if (!_mfi_dev)
        return;
    
    misc_deregister(&_mfi_dev->iap2_dev->mdev);
    kfree(_mfi_dev->iap2_dev);
    _mfi_dev->iap2_dev = NULL;

    misc_deregister(&_mfi_dev->ea_dev->mdev);
    kfree(_mfi_dev->ea_dev);
    _mfi_dev->ea_dev = NULL;

    kfree(_mfi_dev);
    _mfi_dev = NULL;
}
